/*
 * ============================================================================
 *  Topic   : 15 Arrays
 *  Example : 01 - A const array of LED pins: declare, index, iterate, ARRAY_SIZE
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : An array is N elements of ONE type in consecutive memory. Indexes run
 *            0 .. N-1, so the last valid index is N-1. The element count is
 *            computed with sizeof(a) / sizeof(a[0]) so it can never get out of
 *            sync with the initialiser list. If you give an initialiser, elements you do
 *            not list are 0 (a local array with NO initialiser holds garbage).
 *  Embedded use : boards rarely wire LEDs to consecutive pins. A const table maps
 *            "LED number" -> "port pin", and one loop drives any number of LEDs.
 *  Real STM32F4 : GPIOA->ODR |= (1U << led_pins[i]);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_led_pin_table.c -o ex01
 *  Output  : the element addresses (offsets), then a back-and-forth running light
 *            over five LEDs wired to PA0, PA2, PA5, PA7 and PA9
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a sixth pin (PA11) to the table - how many other lines change?
 *            2) Why would 'i <= LED_COUNT' in the loop be a bug? (see -DDEMO_BUG)
 * ============================================================================
 */
#include "hw_sim.h"

#define ARRAY_SIZE(a)  (sizeof(a) / sizeof((a)[0]))

/* LED k is wired to pin led_pins[k]. 'const' keeps the table in flash. */
static const uint8_t led_pins[] = { 0U, 2U, 5U, 7U, 9U };
#define LED_COUNT  ARRAY_SIZE(led_pins)

int main(void)
{
    /* Same data, wider elements: the byte distance between neighbours = element size. */
    static const uint16_t pin_masks[] = { 1U << 0, 1U << 2, 1U << 5, 1U << 7, 1U << 9 };
    for (size_t i = 0; i < ARRAY_SIZE(pin_masks); i++) {
        printf("pin_masks[%zu] = 0x%04X   byte offset from start = %zu\n", i,
               (unsigned)pin_masks[i],
               (size_t)((const char *)&pin_masks[i] - (const char *)pin_masks));
    }
    printf("whole array = %zu bytes = %zu elements x %zu bytes\n\n",
           sizeof pin_masks, ARRAY_SIZE(pin_masks), sizeof pin_masks[0]);

    /* Only the first two of six entries are listed; the other four are zero. */
    uint8_t duty[6] = { 10U, 20U };
    printf("duty[] = {");
    for (size_t i = 0; i < ARRAY_SIZE(duty); i++) {
        printf("%s%u", i ? ", " : "", duty[i]);
    }
    puts("}   (unlisted elements are zero)\n");

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    for (size_t i = 0; i < LED_COUNT; i++) {              /* make every LED pin an output */
        GPIOA->MODER &= ~(3U << (led_pins[i] * 2U));
        GPIOA->MODER |=  (1U << (led_pins[i] * 2U));
    }

    puts("running light (forward, then back):");
    for (size_t i = 0; i < LED_COUNT; i++) {              /* valid indexes: 0 .. LED_COUNT-1 */
        GPIOA->ODR = (1U << led_pins[i]);
        sim_delay_ms(100);
        printf("LED %zu = PA%u  ", i, led_pins[i]);
        sim_show_port("GPIOA", GPIOA);
    }
    for (size_t i = LED_COUNT - 1U; i > 0U; i--) {        /* walk back without going below 0 */
        GPIOA->ODR = (1U << led_pins[i - 1U]);
        sim_delay_ms(100);
        printf("LED %zu = PA%u  ", i - 1U, led_pins[i - 1U]);
        sim_show_port("GPIOA", GPIOA);
    }

#ifdef DEMO_BUG
    /* Off-by-one: led_pins[LED_COUNT] is one element PAST the end. C does not check;
     * the read returns whatever bytes follow (undefined behaviour). Build with
     * -fsanitize=address,undefined to see "index 5 out of bounds" reported.        */
    printf("past the end: %u\n", led_pins[LED_COUNT]);
#endif
    return 0;
}
