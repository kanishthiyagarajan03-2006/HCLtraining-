/*
 * ============================================================================
 *  Topic   : 15 Arrays
 *  Example : 03 - const lookup tables (sine wave and LED gamma) kept in flash
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : An array of precomputed results replaces slow maths: one indexed read
 *            instead of sin() or pow(). Marking it 'const' lets the linker put it
 *            in flash (.rodata) instead of copying it into scarce RAM at startup.
 *            Index with a mask (i & (N-1)) when N is a power of two to wrap safely.
 *  Embedded use : breathing LEDs, DAC waveforms, PWM sine drive, CRC tables, and the
 *            gamma curve that makes LED brightness look linear to the eye.
 *  Real STM32F4 : TIM3->CCR1 = sine32[phase];       // update PWM duty from the table
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex03_const_lookup_table.c -o ex03
 *  Output  : a bar-graph of one sine period (32 steps of an 8-bit PWM duty), then
 *            16 brightness levels with and without the gamma table
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Advance the phase by 2 per step instead of 1 - what happens to the wave?
 *            2) Remove 'const' from sine32: what is the cost on a 128 KB-RAM chip?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define ARRAY_SIZE(a)  (sizeof(a) / sizeof((a)[0]))
#define BAR_WIDTH      32U

/* Generated offline: round(127.5 + 127.5 * sin(2 * pi * i / 32)) for i = 0..31.
 * 32 bytes of flash replace a floating-point sin() call that costs thousands of cycles. */
static const uint8_t sine32[32] = {
    128, 152, 176, 198, 218, 234, 245, 253, 255, 253, 245, 234, 218, 198, 176, 152,
    128, 103,  79,  57,  37,  21,  10,   2,   0,   2,  10,  21,  37,  57,  79, 103
};

/* Generated offline: round(255 * (level / 15) ^ 2.2) for level = 0..15. */
static const uint8_t gamma16[16] = {
      0,   1,   3,   7,  14,  23,  34,  48,  64,  83, 105, 129, 156, 186, 219, 255
};

static void bar(uint8_t duty)
{
    unsigned len = ((unsigned)duty * BAR_WIDTH) / 255U;
    for (unsigned i = 0U; i < len; i++) {
        putchar('#');
    }
}

int main(void)
{
    printf("sine32 uses %zu bytes (const -> flash/.rodata)\n\n", sizeof sine32);

    puts("one period of the PWM sine (duty 0..255):");
    uint8_t phase = 0U;
    for (unsigned step = 0U; step < ARRAY_SIZE(sine32); step++) {
        uint8_t duty = sine32[phase];            /* TIMx->CCRx would receive this */
        printf("phase %2u duty %3u |", phase, duty);
        bar(duty);
        putchar('\n');
        phase = (uint8_t)((phase + 1U) & (ARRAY_SIZE(sine32) - 1U));   /* wrap 31 -> 0 */
    }

    puts("\nbrightness level -> PWM duty, linear vs gamma-corrected:");
    for (unsigned level = 0U; level < ARRAY_SIZE(gamma16); level++) {
        uint8_t linear = (uint8_t)(level * 17U);          /* 0, 17, 34 ... 255      */
        printf("level %2u  linear %3u |", level, linear);
        bar(linear);
        printf("\n          gamma  %3u |", gamma16[level]);
        bar(gamma16[level]);
        putchar('\n');
    }
    return 0;
}
