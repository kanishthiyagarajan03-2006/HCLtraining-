/*
 * ============================================================================
 *  Topic   : 15 Arrays
 *  Example : 07 - A const task table drives task creation (and per-task counters)
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A const array of descriptors holds ALL task settings (name, function,
 *            period, priority) in one place. A loop over the table creates the
 *            tasks, and a parallel array indexed by the same number holds
 *            per-task counters. Adding a task = adding one row.
 *  Embedded use : real RTOS projects keep a task table (or a scheduler table in a
 *            cyclic executive) so priorities and periods are reviewed together
 *            instead of being scattered over many xTaskCreate() calls.
 *  Real FreeRTOS : for (i = 0; i < N; i++)
 *                      xTaskCreate(t[i].fn, t[i].name, 256, &t[i], t[i].prio, NULL);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_rtos_task_table.c -o ex07
 *  Output  : three periodic tasks (100, 200 and 500 ms) log their runs for one
 *            second; main prints the run-count array: 10, 5 and 2
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a fourth row (period 250 ms) - how many runs do you expect?
 *            2) Swap the priorities of "sense" and "report": do the run counts or only
 *               the time stamps change?
 * ============================================================================
 */
#include "mini_rtos.h"

#define ARRAY_SIZE(a)  (sizeof(a) / sizeof((a)[0]))

typedef struct {
    const char *name;
    void      (*fn)(void *);
    uint32_t    period_ms;
    int         prio;
} task_def_t;

static void periodic_task(void *arg);

/* One row per task: easy to review, easy to extend. */
static const task_def_t task_table[] = {
    { "sense",   periodic_task, 100U, 3 },
    { "control", periodic_task, 200U, 2 },
    { "report",  periodic_task, 500U, 1 },
};
#define N_TASKS  ARRAY_SIZE(task_table)

static uint32_t run_count[N_TASKS];       /* parallel array: same index as task_table */

static void periodic_task(void *arg)
{
    const task_def_t *def = (const task_def_t *)arg;
    size_t idx = (size_t)(def - task_table);          /* which row am I?          */
    uint32_t last_wake = rtos_ticks();

    for (;;) {
        run_count[idx]++;
        rtos_log("run %2u (period %u ms)", (unsigned)run_count[idx], (unsigned)def->period_ms);
        rtos_busy(2);                                 /* pretend to do 2 ms of work */
        rtos_delay_until(&last_wake, def->period_ms); /* fixed rate, no drift       */
    }
}

int main(void)
{
    for (size_t i = 0; i < N_TASKS; i++) {
        rtos_task_create(task_table[i].name, task_table[i].fn, (void *)&task_table[i],
                         task_table[i].prio, 0);
    }
    rtos_start(1000);

    printf("\nrun counts after 1000 ms:");
    for (size_t i = 0; i < N_TASKS; i++) {
        printf("  %s=%u", task_table[i].name, (unsigned)run_count[i]);
    }
    putchar('\n');

    rtos_shutdown();
    return 0;
}
