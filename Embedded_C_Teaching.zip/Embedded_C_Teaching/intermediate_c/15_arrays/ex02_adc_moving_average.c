/*
 * ============================================================================
 *  Topic   : 15 Arrays
 *  Example : 02 - ADC sample window and moving average (circular index)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : An array can be used as a sliding window: the newest sample overwrites
 *            the oldest, and the write index wraps with (i + 1) % N. A running
 *            sum makes the average cost O(1) per sample instead of O(N).
 *  Embedded use : a noisy ADC channel (potentiometer, battery, temperature) is
 *            smoothed with a small moving-average filter before it is used. N = 8
 *            is popular because the divide becomes a cheap shift (sum >> 3).
 *  Real STM32F4 : sample = (uint16_t)ADC1->DR;   // 12-bit result, 0..4095
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex02_adc_moving_average.c -o ex02
 *  Output  : one line per sample with the raw value and the filtered value; the
 *            filter output follows a step from ~1000 to ~2000 with a delay
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change WINDOW to 4 - is the output noisier or smoother? Faster or slower?
 *            2) Why is 'sum' a uint32_t although each sample fits in 16 bits?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define WINDOW  8U                 /* power of two: average = sum >> 3 */

/* File-scope state: arrays and counters that live as long as the program runs. */
static uint16_t window[WINDOW];    /* the last WINDOW samples (a ring of values)   */
static uint32_t sum;               /* running total of everything in window[]      */
static uint8_t  next_slot;         /* index that will be overwritten next          */
static uint8_t  count;             /* how many valid samples so far (<= WINDOW)    */

/* Insert one sample, return the average of the samples currently in the window. */
static uint16_t mavg_update(uint16_t sample)
{
    sum -= window[next_slot];      /* remove the oldest value (0 while warming up) */
    window[next_slot] = sample;    /* overwrite it with the newest                 */
    sum += sample;
    next_slot = (uint8_t)((next_slot + 1U) % WINDOW);   /* wrap around: 0..WINDOW-1 */
    if (count < WINDOW) {
        count++;
    }
    return (uint16_t)(sum / count);        /* right even before the window is full  */
}                                          /* (full window: sum >> 3 is the same)   */

int main(void)
{
    /* Canned "ADC" readings: noise around 1000, a step to about 2000 at sample 12. */
    static const uint16_t adc_raw[] = {
         998, 1012,  985, 1020, 1003,  990, 1015, 1001,  996, 1008,  994, 1011,
        2005, 1990, 2012, 1988, 2003, 2010,  1995, 2001, 1987, 2008, 1999, 2004
    };

    printf("%3s %6s %9s\n", "#", "raw", "filtered");
    for (size_t i = 0; i < sizeof adc_raw / sizeof adc_raw[0]; i++) {
        uint16_t avg = mavg_update(adc_raw[i]);
        printf("%3zu %6u %9u%s\n", i, adc_raw[i], avg,
               (i + 1U == WINDOW) ? "   <-- window full from here on" : "");
    }
    return 0;
}
