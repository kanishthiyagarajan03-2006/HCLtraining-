/*
 * ============================================================================
 *  Topic   : 15 Arrays
 *  Example : 05 - UART receive ring buffer (circular array with head and tail)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A ring buffer treats a fixed array as a circle. 'head' is where the
 *            producer writes next, 'tail' where the consumer reads next. Both
 *            wrap with (i + 1) & MASK when the size is a power of two. head == tail
 *            means EMPTY, so one slot is sacrificed and capacity is SIZE - 1.
 *  Embedded use : the UART receive interrupt must store each byte at once, while
 *            main() reads them whenever it has time. Only the ISR writes 'head'
 *            and only main writes 'tail', so no lock is needed (one producer,
 *            one consumer, single-core MCU, byte-sized indexes). The shared variables
 *            are 'volatile'. On a multi-core CPU you would need atomics or barriers.
 *  Real STM32F4 : void USART2_IRQHandler(void) { rx_put((uint8_t)USART2->DR); }
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex05_uart_rx_ring_buffer.c -o ex05
 *  Output  : a burst of 10 bytes into the 8-slot buffer (3 dropped), partial read,
 *            more bytes arriving (index wraps around), then the buffer is drained
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change RX_SIZE to 16 - how many of the 10 burst bytes survive?
 *            2) With 7 bytes stored, one more byte arrives: which variable changes,
 *               and what is lost?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define RX_SIZE  8U                       /* must be a power of two             */
#define RX_MASK  (RX_SIZE - 1U)

static volatile uint8_t  rx_buf[RX_SIZE];
static volatile uint8_t  rx_head;         /* next write position (ISR owns it)  */
static volatile uint8_t  rx_tail;         /* next read position (main owns it)  */
static volatile uint32_t rx_dropped;      /* bytes lost because the ring was full */

/* Producer: the hardware calls this once per received byte. */
static void rx_put(uint8_t byte)
{
    uint8_t next = (uint8_t)((rx_head + 1U) & RX_MASK);    /* wrap 7 -> 0 */
    if (next == rx_tail) {                                  /* ring full   */
        rx_dropped++;                                       /* drop newest */
        return;
    }
    rx_buf[rx_head] = byte;
    rx_head = next;                                         /* publish last */
}

/* Consumer: returns the oldest byte, or -1 if nothing is waiting. */
static int rx_get(void)
{
    if (rx_head == rx_tail) {
        return -1;
    }
    uint8_t byte = rx_buf[rx_tail];
    rx_tail = (uint8_t)((rx_tail + 1U) & RX_MASK);
    return byte;
}

static unsigned rx_count(void)
{
    return (unsigned)((rx_head - rx_tail) & RX_MASK);
}

/* Draw the array: letters in use, dots for free slots, markers for head and tail. */
static void show(const char *what)
{
    printf("%-26s |", what);
    for (unsigned i = 0U; i < RX_SIZE; i++) {
        unsigned used = (i - rx_tail) & RX_MASK;            /* distance from tail */
        putchar(used < rx_count() ? (char)rx_buf[i] : '.');
    }
    printf("|  head=%u tail=%u count=%u dropped=%u\n", (unsigned)rx_head,
           (unsigned)rx_tail, rx_count(), (unsigned)rx_dropped);
}

int main(void)
{
    show("empty");

    /* main() was busy; 10 bytes arrive and the ISR stores what fits (SIZE-1 = 7). */
    for (char c = 'A'; c <= 'J'; c++) {
        rx_put((uint8_t)c);
    }
    show("burst A..J arrived");

    printf("main reads: ");
    for (int i = 0; i < 5; i++) {
        printf("%c", (char)rx_get());
    }
    putchar('\n');
    show("after reading 5");

    rx_put('k');                                            /* head wraps past slot 7 */
    rx_put('l');
    rx_put('m');
    show("k l m arrive (wrap)");

    printf("main drains: ");
    int c;
    while ((c = rx_get()) >= 0) {
        printf("%c", (char)c);
    }
    putchar('\n');
    show("drained");
    return 0;
}
