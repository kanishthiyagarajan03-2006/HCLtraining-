# Topic 15 - Arrays
**Suggested session:** 90 min | **Prerequisite topics:** 03 Constants and Variable Types, 08 Control Loops, 13 Storage Classes

Students should leave able to declare, initialise and index arrays, compute the element count with `sizeof`, and use arrays the way firmware does: pin tables, sample windows, ring buffers, lookup tables in flash, and enum-indexed configuration tables. Arrays are kept at file scope or in `main` on purpose; passing them to functions (array decay) is Topic 22 and pointers are Topic 17. The examples progress from a simple table to a lock-free ring buffer and to reading arrays from files and RTOS task tables.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_led_pin_table.c` | MCU | Declaration, indexes 0..N-1, `ARRAY_SIZE`, zero-fill of unlisted elements, element addresses, running light over a `const` pin table |
| 02 | `ex02_adc_moving_average.c` | MCU | Array as a sliding window, wrap-around index with `%`, running sum, warm-up handling |
| 03 | `ex03_const_lookup_table.c` | MCU | `const` sine and gamma tables in flash, wrap with `& (N-1)`, why tables beat `sin()`/`pow()` |
| 04 | `ex04_designated_init_table.c` | MCU | `[CH_X] = ...` designated initialisers, enum-indexed config table, sparse arrays, `_Static_assert` on table length |
| 05 | `ex05_uart_rx_ring_buffer.c` | MCU | Ring buffer with head/tail, power-of-two mask, full/empty rule, `volatile` ISR/main sharing, dropped-byte counter |
| 06 | `ex06_adc_stats_histogram.c` | MCU | One-pass min/max/mean/threshold scan and a histogram array indexed by computed bin |
| 07 | `ex07_rtos_task_table.c` | RTOS | `const` array of task descriptors drives task creation; parallel per-task counter array |
| 08 | `ex08_linux_fread_samples.c` | LINUX | `fwrite`/`fread` of a raw array, item counts, short reads, truncated record detection |

## Teaching notes
* Index 0 is the first element; the valid range is `0 .. N-1`. Off-by-one loops (`<=` instead of `<`) are the most common array bug: C does not check bounds, so the program silently reads or corrupts neighbouring memory. Show it with `-DDEMO_BUG` in ex01 under the sanitizers.
* `sizeof(a) / sizeof(a[0])` only works where the compiler still sees the real array (not after it was passed to a function). Preview this problem for Topic 22.
* `const` on a table is a memory decision, not just style: without it the linker copies the table from flash into RAM at start-up (ex03).
* In the ring buffer (ex05) ask why one slot is wasted, why `volatile` is needed and what would break with two writers. Compare with the RTOS queue (`xQueueSend`) which solves the same problem with locking.
* Designated initialisers (ex04) make tables robust against reordering. Ask what happens to elements you do not mention (zero or NULL).

## Live-demo tips
* Run ex01 with `gcc -DDEMO_BUG -fsanitize=address,undefined -g -I../../common ex01_led_pin_table.c` to show the out-of-bounds report with file and line.
* In ex05 step through `show()` output with the class and predict `head`, `tail` and `count` before each line appears.
* For ex08, temporarily comment out the two cleanup calls (`unlink`, `rmdir`) and print `path`; then `xxd <path>` shows the little-endian byte order of the raw samples (512 = `00 02`).
