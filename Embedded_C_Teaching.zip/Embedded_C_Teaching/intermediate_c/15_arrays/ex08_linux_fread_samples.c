/*
 * ============================================================================
 *  Topic   : 15 Arrays
 *  Example : 08 - Reading binary sensor samples into an array with fread()
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A file of raw records has the same layout as an array in memory, so
 *            fwrite() can save an array in one call and fread() can load it back.
 *            fread() returns the number of ITEMS read: compare it with what you
 *            asked for to detect short reads and a truncated final record.
 *  Embedded use : data loggers on embedded Linux store samples as raw binary (compact,
 *            fast). The reader must check the item count, the file size and the
 *            byte order: a raw dump is only portable between same-endian machines.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex08_linux_fread_samples.c -o ex08
 *  Output  : 12 samples written to a temp file (plus one stray byte), read back in
 *            chunks of 5, statistics, and a warning about the truncated record
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change CHUNK to 4 - the totals must not change. Why?
 *            2) Remove the stray byte and confirm the warning disappears.
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define ARRAY_SIZE(a)  (sizeof(a) / sizeof((a)[0]))
#define CHUNK          5U

int main(void)
{
    static const uint16_t log_data[] = {
        512, 530, 498, 1020, 1033, 1011, 990, 505, 520, 515, 2047, 4095
    };
    static const uint8_t  stray = 0x7FU;           /* half of a record: a cut-off write */

    char dir[] = "/tmp/samples_XXXXXX";
    if (mkdtemp(dir) == NULL) {
        perror("mkdtemp");
        return 1;
    }
    char path[64];
    snprintf(path, sizeof path, "%s/adc.bin", dir);

    /* ---- write: the whole array in one call, then one stray byte ---- */
    FILE *f = fopen(path, "wb");
    if (f == NULL) {
        perror("fopen write");
        rmdir(dir);
        return 1;
    }
    size_t wrote = fwrite(log_data, sizeof log_data[0], ARRAY_SIZE(log_data), f);
    fwrite(&stray, 1, 1, f);
    fclose(f);
    printf("wrote %zu samples x %zu bytes + 1 stray byte\n", wrote, sizeof log_data[0]);
    if (wrote != ARRAY_SIZE(log_data)) {
        fprintf(stderr, "short write\n");
    }

    /* ---- read back in chunks of CHUNK items ---- */
    f = fopen(path, "rb");
    if (f == NULL) {
        perror("fopen read");
        unlink(path);
        rmdir(dir);
        return 1;
    }
    uint16_t chunk[CHUNK];
    uint16_t min = UINT16_MAX, max = 0U;
    uint32_t sum = 0U;
    size_t total = 0U, got;

    while ((got = fread(chunk, sizeof chunk[0], ARRAY_SIZE(chunk), f)) > 0U) {
        printf("fread asked for %zu items, got %zu:", ARRAY_SIZE(chunk), got);
        for (size_t i = 0; i < got; i++) {           /* only the first `got` are valid */
            printf(" %u", chunk[i]);
            if (chunk[i] < min) min = chunk[i];
            if (chunk[i] > max) max = chunk[i];
            sum += chunk[i];
        }
        putchar('\n');
        total += got;
    }
    long file_size = (fseek(f, 0, SEEK_END) == 0) ? ftell(f) : -1L;
    fclose(f);

    printf("total %zu samples   min %u   max %u   mean %u\n", total, min, max,
           total > 0U ? (unsigned)(sum / total) : 0U);
    long leftover = file_size - (long)(total * sizeof(uint16_t));
    if (leftover != 0L) {
        printf("WARNING: %ld byte(s) left over - the last record is truncated\n", leftover);
    }

    unlink(path);                                    /* clean up the temp file/dir */
    rmdir(dir);
    return 0;
}
