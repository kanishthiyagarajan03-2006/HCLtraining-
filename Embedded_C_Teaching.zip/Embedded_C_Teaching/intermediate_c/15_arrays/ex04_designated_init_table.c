/*
 * ============================================================================
 *  Topic   : 15 Arrays
 *  Example : 04 - Designated initialisers: tables indexed by an enum
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : C99 lets you write  [index] = value  inside an initialiser. The order
 *            no longer matters, gaps are zero-filled, and the array length is the
 *            highest index + 1. With an enum as the index the table can be read
 *            like a dictionary: adc_cfg[CH_TEMP].
 *  Embedded use : channel configuration, error-text tables, pin alternate-function
 *            maps and interrupt tables are sparse or reordered during development.
 *            Designators stop a new enum value from silently shifting every row.
 *  Real STM32F4 : GPIOA->AFR[0] = (7U << (2 * 4));   // AF7 = USART2 on PA2
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex04_designated_init_table.c -o ex04
 *  Output  : the four ADC channel settings looked up by enum, a sparse error-text
 *            table with "(unused)" holes, and the computed table lengths
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add CH_VREF before CH_COUNT and rebuild: which message appears, and
 *               why is a build error better than a silent wrong table?
 *            2) Why do unlisted err_text slots hold NULL, and what happens if you
 *               pass one to printf("%s")?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define ARRAY_SIZE(a)  (sizeof(a) / sizeof((a)[0]))

typedef enum { CH_TEMP, CH_VBAT, CH_LIGHT, CH_POT, CH_COUNT } adc_ch_t;

typedef struct {
    const char *name;
    uint8_t     pin;            /* PA pin number of the analog input   */
    uint16_t    full_scale_mv;  /* sensor voltage at ADC reading 4095  */
} adc_cfg_t;

/* Rows written OUT OF ORDER on purpose: each one names the slot it fills. */
static const adc_cfg_t adc_cfg[] = {
    [CH_POT]   = { "pot",   3U, 3300U },
    [CH_TEMP]  = { "temp",  0U, 1000U },
    [CH_LIGHT] = { "light", 2U, 3300U },
    [CH_VBAT]  = { "vbat",  1U, 6600U },       /* resistor divider: 2 x 3.3 V */
};

/* The length comes from the highest designator, so a forgotten row at the END of the
 * enum would silently shorten the table. This check turns that into a build error. */
_Static_assert(ARRAY_SIZE(adc_cfg) == CH_COUNT, "adc_cfg needs one row per channel");

/* Sparse table: the array length becomes 8 (highest index 7, plus one). */
static const char *const err_text[] = {
    [0] = "OK",
    [3] = "TIMEOUT",
    [7] = "CRC MISMATCH",
};

/* Alternate-function numbers per pin of one port; every pin not named is AF0. */
static const uint8_t af_map[16] = { [2] = 7U, [3] = 7U, [5] = 5U, [6] = 5U, [7] = 5U };

int main(void)
{
    static const uint16_t raw[CH_COUNT] = {
        [CH_TEMP] = 1230U, [CH_VBAT] = 2482U, [CH_LIGHT] = 4095U, [CH_POT] = 2048U
    };

    puts("ADC channel table (looked up by enum, not by position):");
    for (unsigned ch = 0U; ch < CH_COUNT; ch++) {
        uint32_t mv = ((uint32_t)raw[ch] * adc_cfg[ch].full_scale_mv) / 4095U;
        printf("  ch %u %-5s on PA%u  raw %4u  ->  %4u mV\n", ch, adc_cfg[ch].name,
               adc_cfg[ch].pin, raw[ch], (unsigned)mv);
    }
    printf("adc_cfg has %zu rows, enum says %d\n\n", ARRAY_SIZE(adc_cfg), (int)CH_COUNT);

    printf("err_text has %zu slots (highest designator was [7]):\n", ARRAY_SIZE(err_text));
    for (size_t code = 0U; code < ARRAY_SIZE(err_text); code++) {
        /* unlisted slots are NULL pointers: always test before printing them */
        printf("  code %zu = %s\n", code, err_text[code] != NULL ? err_text[code] : "(unused)");
    }

    puts("\npin alternate function map:");
    for (unsigned pin = 0U; pin < ARRAY_SIZE(af_map); pin++) {
        if (af_map[pin] != 0U) {
            printf("  PA%u -> AF%u\n", pin, af_map[pin]);
        }
    }
    return 0;
}
