/*
 * ============================================================================
 *  Topic   : 15 Arrays
 *  Example : 06 - Scan an ADC buffer: min, max, mean, threshold crossings, histogram
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Loops over arrays compute statistics in one pass. A second array can
 *            act as a counter table: bin[value / width]++ is a histogram, with
 *            the bin index itself computed from the data. Always check the computed
 *            index against the array size before using it.
 *  Embedded use : sanity-check a batch of ADC samples taken by DMA: is the signal
 *            clipping, how noisy is it, did it cross an alarm threshold, and how
 *            is it distributed? Often done in the main loop after a DMA-complete flag.
 *  Real STM32F4 : HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adc_buf, N_SAMPLES);
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex06_adc_stats_histogram.c -o ex06
 *  Output  : min / max / mean of 64 samples, the first alarm crossing, and an
 *            8-bin ASCII histogram that looks like a bell curve
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change ALARM_LEVEL to 3500 - how many samples cross it now?
 *            2) Use 16 bins instead of 8: which constants must you change?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define N_SAMPLES   64U
#define ADC_MAX     4095U                 /* 12-bit converter                  */
#define N_BINS      8U
#define BIN_WIDTH   ((ADC_MAX + 1U) / N_BINS)       /* 512 counts per bin      */
#define ALARM_LEVEL 3000U

static uint16_t samples[N_SAMPLES];       /* would be filled by the DMA        */
static uint16_t bins[N_BINS];

/* Tiny LCG so the "ADC data" is the same on every run and every machine. */
static uint32_t lcg_state = 2024U;
static uint32_t lcg_next(void)
{
    lcg_state = lcg_state * 1664525U + 1013904223U;
    return lcg_state >> 16;
}

int main(void)
{
    /* Average of two uniform values -> triangular distribution around 2048. */
    for (size_t i = 0; i < N_SAMPLES; i++) {
        uint32_t a = lcg_next() % (ADC_MAX + 1U);
        uint32_t b = lcg_next() % (ADC_MAX + 1U);
        samples[i] = (uint16_t)((a + b) / 2U);
    }

    uint16_t min = samples[0], max = samples[0];
    uint32_t sum = 0U;
    unsigned above = 0U;
    int first_alarm = -1;

    for (size_t i = 0; i < N_SAMPLES; i++) {
        uint16_t s = samples[i];
        if (s < min) min = s;
        if (s > max) max = s;
        sum += s;
        if (s > ALARM_LEVEL) {
            above++;
            if (first_alarm < 0) first_alarm = (int)i;
        }
        unsigned bin = s / BIN_WIDTH;     /* 0..4095 -> 0..7                   */
        if (bin < N_BINS) {               /* never trust a computed index      */
            bins[bin]++;
        }
    }

    printf("samples: %u   min: %u   max: %u   mean: %u\n", N_SAMPLES, min, max,
           (unsigned)(sum / N_SAMPLES));
    printf("samples above %u: %u", ALARM_LEVEL, above);
    if (first_alarm >= 0) {
        printf("   (first one is sample #%d = %u)", first_alarm, samples[first_alarm]);
    }
    puts("\n");

    puts("histogram (one # per sample):");
    for (unsigned b = 0U; b < N_BINS; b++) {
        printf("%4u-%4u | ", b * BIN_WIDTH, (b + 1U) * BIN_WIDTH - 1U);
        for (unsigned k = 0U; k < bins[b]; k++) {
            putchar('#');
        }
        printf(" %u\n", bins[b]);
    }
    return 0;
}
