/*
 * ============================================================================
 *  Topic   : 16 Strings
 *  Example : 03 - Number <-> text by hand (itoa / atoi) with error checking
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A digit character is a number: '0' is 48, so c - '0' is the digit value.
 *            Number -> text: peel off digits with % base and / base (they come out
 *            last-digit-first), then reverse. Text -> number: result = result * 10 +
 *            digit for each character, checking for bad characters and overflow.
 *  Embedded use : tiny firmware prints numbers on a UART or LCD and parses them from
 *            commands WITHOUT printf/scanf (those can cost 10-20 KB of flash).
 *            Every parser must reject garbage instead of returning 0 silently.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex03_itoa_atoi_by_hand.c -o ex03
 *  Output  : numbers converted to decimal and hex text, then a table of inputs
 *            ("42", "  -7", "12ab", "", "2147483648") showing value or the error
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Convert 255 to base 2 (binary text) - which line do you call?
 *            2) Why is 'acc' an int64_t? What would go wrong with an int32_t?
 * ============================================================================
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

/* Write v in the given base (2..16) into out[cap]. Returns false if it does not fit. */
static bool u32_to_str(uint32_t v, unsigned base, char *out, size_t cap)
{
    static const char digits[] = "0123456789ABCDEF";
    char tmp[33];                              /* 32 binary digits + '\0'         */
    size_t n = 0U;

    if (base < 2U || base > 16U) {
        return false;
    }
    do {                                       /* do-while: v == 0 must give "0"  */
        tmp[n++] = digits[v % base];           /* last digit first                */
        v /= base;
    } while (v != 0U);

    if (n + 1U > cap) {                        /* digits + terminator must fit    */
        return false;
    }
    for (size_t i = 0U; i < n; i++) {
        out[i] = tmp[n - 1U - i];              /* reverse into the caller buffer  */
    }
    out[n] = '\0';
    return true;
}

typedef enum { PARSE_OK, PARSE_EMPTY, PARSE_BAD_CHAR, PARSE_OVERFLOW } parse_t;

/* Parse an optional sign and decimal digits. Leading spaces are skipped. */
static parse_t str_to_i32(const char *s, int32_t *out)
{
    while (*s == ' ') {
        s++;
    }
    bool neg = false;
    if (*s == '-' || *s == '+') {
        neg = (*s == '-');
        s++;
    }
    if (*s == '\0') {
        return PARSE_EMPTY;                    /* no digits at all                */
    }
    int64_t acc = 0;
    for (; *s != '\0'; s++) {
        if (*s < '0' || *s > '9') {
            return PARSE_BAD_CHAR;
        }
        acc = acc * 10 + (*s - '0');           /* '7' - '0' == 7                  */
        if (acc > 2147483648LL) {              /* too big: stop before acc grows  */
            return PARSE_OVERFLOW;
        }
    }
    if (neg) acc = -acc;
    if (acc > INT32_MAX || acc < INT32_MIN) {
        return PARSE_OVERFLOW;
    }
    *out = (int32_t)acc;
    return PARSE_OK;
}

int main(void)
{
    static const uint32_t values[] = { 0U, 7U, 1234567U, 4294967295U, 0xDEADBEEFU };
    char text[12];

    puts("--- number to text ---");
    for (size_t i = 0; i < sizeof values / sizeof values[0]; i++) {
        char dec[12], hex[12];
        if (u32_to_str(values[i], 10U, dec, sizeof dec) &&
            u32_to_str(values[i], 16U, hex, sizeof hex)) {
            printf("%10s  =  0x%s\n", dec, hex);
        }
    }
    printf("255 in 12-byte buffer, base 2 : %s\n",
           u32_to_str(255U, 2U, text, sizeof text) ? text : "(does not fit)");
    printf("255 in  8-byte buffer, base 2 : %s\n",
           u32_to_str(255U, 2U, text, 8U) ? text : "(does not fit: needs 8 digits + '\\0')");

    puts("\n--- text to number ---");
    static const char *const inputs[] = { "42", "  -7", "+300", "12ab", "", "-", "2147483647",
                                          "2147483648", "-2147483648" };
    static const char *const names[] = { "ok", "empty", "bad character", "overflow" };
    for (size_t i = 0; i < sizeof inputs / sizeof inputs[0]; i++) {
        int32_t v = 0;
        parse_t r = str_to_i32(inputs[i], &v);
        if (r == PARSE_OK) {
            printf("\"%s\"  ->  %d\n", inputs[i], (int)v);
        } else {
            printf("\"%s\"  ->  rejected (%s)\n", inputs[i], names[r]);
        }
    }
    return 0;
}
