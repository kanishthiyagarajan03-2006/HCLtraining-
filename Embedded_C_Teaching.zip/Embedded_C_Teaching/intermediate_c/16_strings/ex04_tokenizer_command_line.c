/*
 * ============================================================================
 *  Topic   : 16 Strings
 *  Example : 04 - Split a UART command line into words (in-place tokenizer)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A tokenizer walks the line once. At each space it overwrites the space
 *            with '\0', so the ONE buffer now holds several strings, and it
 *            remembers where each word starts in a small pointer array (argv[]).
 *            This only works on a modifiable char ARRAY, never on a string literal.
 *  Embedded use : a serial console ("LED ON", "PWM 50", "BLINK 3 200") needs no heap
 *            and no strtok(): receive a line into a RAM buffer, split, dispatch.
 *  Real STM32F4 : TIM3->CCR1 = (TIM3->ARR * duty) / 100U;   // what "PWM 50" would do
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_tokenizer_command_line.c -o ex04
 *  Output  : each command line, its words, and the effect on PA5 (LED) and the PWM duty;
 *            odd input (extra spaces, empty line, unknown word) is handled politely
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a command "LED TOGGLE". Which function do you edit?
 *            2) Pass a string literal straight to tokenize() - why would it crash?
 * ============================================================================
 */
#include <stdbool.h>
#include <stdlib.h>
#include "hw_sim.h"

#define LED_PIN   5U
#define MAX_WORDS 4U
#define LINE_MAX_LEN 32U

static uint8_t pwm_duty;                 /* percent, would go to a timer compare reg */

static bool str_eq(const char *a, const char *b)
{
    while (*a != '\0' && *a == *b) {
        a++;
        b++;
    }
    return *a == *b;                     /* equal only if both ended together */
}

/* Split `line` in place. words[i] points INTO line. Returns the number of words. */
static size_t tokenize(char *line, char *words[], size_t max_words)
{
    size_t n = 0U;
    char *p = line;

    while (*p != '\0') {
        while (*p == ' ') {              /* skip separators (also handles runs)  */
            p++;
        }
        if (*p == '\0') {
            break;
        }
        if (n == max_words) {            /* too many words: ignore the rest      */
            *p = '\0';
            break;
        }
        words[n++] = p;                  /* a word starts here                   */
        while (*p != '\0' && *p != ' ') {
            p++;
        }
        if (*p == ' ') {
            *p = '\0';                   /* end the word, keep scanning after it */
            p++;
        }
    }
    return n;
}

static void execute(size_t argc, char *argv[])
{
    if (argc == 0U) {
        puts("  -> empty line, nothing to do");
    } else if (str_eq(argv[0], "LED") && argc == 2U) {
        if (str_eq(argv[1], "ON"))       GPIOA->ODR |=  (1U << LED_PIN);
        else if (str_eq(argv[1], "OFF")) GPIOA->ODR &= ~(1U << LED_PIN);
        else { puts("  -> LED needs ON or OFF"); return; }
        printf("  -> LED is %s\n", (GPIOA->ODR & (1U << LED_PIN)) ? "ON" : "OFF");
    } else if (str_eq(argv[0], "PWM") && argc == 2U) {
        int pct = atoi(argv[1]);         /* (safer parsing: see example 03)      */
        pwm_duty = (uint8_t)(pct < 0 ? 0 : (pct > 100 ? 100 : pct));
        printf("  -> PWM duty = %u%%\n", pwm_duty);
    } else if (str_eq(argv[0], "BLINK") && argc == 3U) {
        printf("  -> blink %d times, %d ms each\n", atoi(argv[1]), atoi(argv[2]));
    } else {
        printf("  -> unknown command \"%s\" with %zu argument(s)\n", argv[0], argc - 1U);
    }
}

int main(void)
{
    /* Test lines. Note "led" in lower case: str_eq() is case-sensitive, so it is rejected. */
    static const char *const input[] = {
        "LED ON", "PWM 50", "  led   OFF ", "BLINK 3 200", "", "LED ON now please extra",
        "PWM 250", "LED OFF"
    };

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->MODER |= (1U << (LED_PIN * 2U));

    for (size_t i = 0; i < sizeof input / sizeof input[0]; i++) {
        char line[LINE_MAX_LEN];                      /* writable copy of the text */
        snprintf(line, sizeof line, "%s", input[i]);

        printf("rx \"%s\"\n", input[i]);
        char *words[MAX_WORDS];
        size_t argc = tokenize(line, words, MAX_WORDS);
        for (size_t w = 0; w < argc; w++) {
            printf("  word %zu = \"%s\"\n", w, words[w]);
        }
        execute(argc, words);
    }
    return 0;
}
