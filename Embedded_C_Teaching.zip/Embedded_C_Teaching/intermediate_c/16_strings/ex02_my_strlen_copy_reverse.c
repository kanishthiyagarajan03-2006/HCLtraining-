/*
 * ============================================================================
 *  Topic   : 16 Strings
 *  Example : 02 - Write your own strlen, safe copy, reverse and compare
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Every string function is a loop that walks until it meets '\0'.
 *            Writing them yourself shows why: strlen counts characters, a safe copy
 *            must stop at the destination size AND terminate, reverse swaps from
 *            both ends, compare stops at the first difference or at the '\0'.
 *  Embedded use : small MCUs often avoid <string.h> to save flash and to control exactly
 *            what happens on overflow. uart_puts() is nothing but "send bytes until
 *            '\0'". Truncating safely beats overflowing a neighbouring variable.
 *  Real STM32F4 : while (*s) { while (!(USART2->SR & USART_SR_TXE)) {} USART2->DR = *s++; }
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex02_my_strlen_copy_reverse.c -o ex02
 *  Output  : lengths, a reversed string, a copy that is cut to fit an 8-byte buffer
 *            with the truncation reported, and compare results
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Copy "CAN" into a 4-byte buffer and then into a 3-byte buffer. What differs?
 *            2) Make my_reverse() work on only the first 4 characters.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

/* Stand-in for the UART data register: one character goes out per call. */
static void uart_putc(char c)
{
    putchar(c);
}

static void uart_puts(const char *s)
{
    while (*s != '\0') {                 /* walk until the terminator */
        uart_putc(*s);
        s++;
    }
}

static size_t my_strlen(const char *s)
{
    size_t n = 0U;
    while (s[n] != '\0') {
        n++;
    }
    return n;                            /* the '\0' itself is not counted */
}

/* Copy src into dst (capacity `cap` bytes). Always terminates when cap > 0.
 * Returns the length src WOULD have needed, so the caller can detect truncation. */
static size_t my_copy(char *dst, size_t cap, const char *src)
{
    size_t i = 0U;
    while (src[i] != '\0') {
        if (i + 1U < cap) {              /* keep one byte free for '\0' */
            dst[i] = src[i];
        }
        i++;
    }
    if (cap > 0U) {
        dst[(i < cap) ? i : cap - 1U] = '\0';
    }
    return i;
}

static void my_reverse(char *s)
{
    size_t len = my_strlen(s);
    for (size_t i = 0U; i < len / 2U; i++) {
        char tmp = s[i];
        s[i] = s[len - 1U - i];
        s[len - 1U - i] = tmp;
    }
}

/* <0, 0, >0 like strcmp: difference of the first differing characters. */
static int my_compare(const char *a, const char *b)
{
    while (*a != '\0' && *a == *b) {
        a++;
        b++;
    }
    return (int)(uint8_t)*a - (int)(uint8_t)*b;
}

int main(void)
{
    uart_puts("uart_puts sends: STM32F407\n");

    printf("my_strlen(\"STM32F407\") = %zu\n", my_strlen("STM32F407"));
    printf("my_strlen(\"\")          = %zu\n\n", my_strlen(""));

    char word[] = "STM32F4";             /* must be a char ARRAY: reverse edits it */
    my_reverse(word);
    printf("reversed: %s\n\n", word);

    char small[8];
    const char *names[] = { "UART2", "TEMPERATURE_SENSOR" };
    for (size_t i = 0; i < sizeof names / sizeof names[0]; i++) {
        size_t needed = my_copy(small, sizeof small, names[i]);
        printf("copy of \"%s\" into char[%zu] -> \"%s\"", names[i], sizeof small, small);
        if (needed >= sizeof small) {
            printf("   TRUNCATED (needed %zu bytes + terminator)", needed);
        }
        putchar('\n');
    }

    printf("\ncompare(\"LED1\", \"LED1\") = %d\n", my_compare("LED1", "LED1"));
    printf("compare(\"LED1\", \"LED2\") = %d\n", my_compare("LED1", "LED2"));
    printf("compare(\"LED\",  \"LED1\") = %d   (shorter string sorts first)\n",
           my_compare("LED", "LED1"));
    return 0;
}
