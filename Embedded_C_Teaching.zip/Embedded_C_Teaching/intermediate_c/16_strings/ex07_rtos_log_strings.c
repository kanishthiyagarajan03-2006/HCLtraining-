/*
 * ============================================================================
 *  Topic   : 16 Strings
 *  Example : 07 - RTOS logging: task-name strings and fixed-size message buffers
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Strings that travel through an RTOS queue must be COPIED into a fixed-size
 *            char array: a pointer to a local buffer would be gone by the time the
 *            receiver reads it. vsnprintf() formats safely into that array and
 *            truncates long text instead of overflowing it. In mini_rtos a task name is
 *            just a 'const char *' to a literal; real FreeRTOS COPIES the name into the
 *            TCB and cuts it to configMAX_TASK_NAME_LEN (default 16, including '\0').
 *  Embedded use : many tasks want to log, but only ONE task owns the UART. Tasks post
 *            short messages to a queue; a low-priority logger task prints them, so
 *            printing never stalls a time-critical task.
 *  Real FreeRTOS : xQueueSend(logQ, &msg, 0);   pcTaskGetName(NULL) = current task's name
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_rtos_log_strings.c -o ex07
 *  Output  : short sensor messages every 100 ms and a long network message every
 *            250 ms (cut to 31 characters), all printed by the logger task
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Raise MSG_TEXT_LEN to 64 - is the net message still truncated?
 *            2) Set QUEUE_LEN to 1: which counter in the summary changes, and why?
 * ============================================================================
 */
#include "mini_rtos.h"

#define MSG_TEXT_LEN  32U             /* 31 characters + '\0'                 */
#define WHO_LEN       10U
#define QUEUE_LEN     8U

#if defined(__GNUC__)
#  define CHECK_PRINTF(fmt_idx, arg_idx)  __attribute__((format(printf, fmt_idx, arg_idx)))
#else
#  define CHECK_PRINTF(fmt_idx, arg_idx)
#endif

typedef struct {
    uint32_t tick;                     /* when the message was posted          */
    char     who[WHO_LEN];             /* COPY of the task name                */
    char     text[MSG_TEXT_LEN];       /* the formatted message                */
} log_msg_t;

static rtos_queue_t *log_q;
static unsigned truncated_count;
static unsigned dropped_count;

/* printf-style logging from any task. The message is built in a local struct and
 * copied into the queue, so nothing dangles after this function returns.        */
static void log_post(const char *fmt, ...) CHECK_PRINTF(1, 2);

static void log_post(const char *fmt, ...)
{
    log_msg_t m;
    memset(&m, 0, sizeof m);
    m.tick = rtos_ticks();
    snprintf(m.who, sizeof m.who, "%s", rtos_task_name());   /* safe copy of the name */

    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(m.text, sizeof m.text, fmt, ap);
    va_end(ap);
    if (n >= (int)sizeof m.text) {
        truncated_count++;                                   /* text was cut to fit  */
    }
    if (!rtos_queue_send(log_q, &m, RTOS_NO_WAIT)) {
        dropped_count++;                                     /* queue full: lose it  */
    }
}

static void sensor_task(void *arg)
{
    (void)arg;
    unsigned raw = 2000U;
    for (;;) {
        log_post("ADC=%u -> %u mV", raw, raw * 3300U / 4095U);
        raw += 37U;
        rtos_delay(100);
    }
}

static void net_task(void *arg)
{
    (void)arg;
    unsigned retry = 0U;
    for (;;) {
        log_post("rssi %d dBm retry %u host %s", -67, retry++, "gateway-eu-west-1.example.net");
        rtos_delay(250);
    }
}

static void logger_task(void *arg)
{
    (void)arg;
    log_msg_t m;
    for (;;) {
        if (rtos_queue_recv(log_q, &m, RTOS_WAIT_FOREVER)) {
            printf("[%4u ms] %-9s %s\n", (unsigned)m.tick, m.who, m.text);
        }
    }
}

int main(void)
{
    log_q = rtos_queue_create(QUEUE_LEN, sizeof(log_msg_t));
    if (log_q == NULL) {
        return 1;
    }
    rtos_task_create("sensor", sensor_task, NULL, 3, 0);
    rtos_task_create("net",    net_task,    NULL, 2, 0);
    rtos_task_create("logger", logger_task, NULL, 1, 0);   /* lowest priority */
    rtos_start(600);

    printf("\nsummary: %u message(s) truncated to %u characters, %u dropped\n",
           truncated_count, MSG_TEXT_LEN - 1U, dropped_count);

    rtos_queue_delete(log_q);
    rtos_shutdown();
    return 0;
}
