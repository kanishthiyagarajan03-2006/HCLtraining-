/*
 * ============================================================================
 *  Topic   : 16 Strings
 *  Example : 01 - char array vs pointer to a literal, and the '\0' terminator
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : C has no string type: a string is a char array that ends with a '\0'
 *            byte. "AT" needs 3 bytes. 'char buf[] = "AT"' makes a modifiable COPY
 *            in RAM; 'const char *p = "AT"' only points at read-only text that the
 *            linker placed in flash (.rodata). sizeof counts bytes of the array,
 *            strlen counts characters up to (not including) the '\0'. A plain local
 *            'const char a[] = "..."' is still a stack copy: use 'static const' for a
 *            text table that must stay in flash.
 *  Embedded use : text constants (menus, AT commands, error messages) belong in flash
 *            to save RAM; only text you edit (a line being received) needs RAM.
 *            A missing '\0' makes every string function run on into other memory.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex01_char_array_vs_literal.c -o ex01
 *  Output  : sizeof/strlen for different declarations and a byte dump showing the
 *            terminating 00; an edit that works on the RAM copy only
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Predict sizeof and strlen of  char t[] = "AB\0CD";  then check by running.
 *            2) Build with -DDEMO_BUG_WRITE: why does writing into a literal crash?
 *               (and -DDEMO_BUG shows what a missing '\0' does)
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

/* Print the raw bytes of a string including the terminator. */
static void dump(const char *label, const char *s, size_t nbytes)
{
    printf("%-9s", label);
    for (size_t i = 0; i < nbytes; i++) {
        printf(" %02X", (unsigned)(uint8_t)s[i]);
    }
    printf("   | ");
    for (size_t i = 0; i < nbytes; i++) {
        char c = s[i];
        if (c == '\0') printf("\\0 ");
        else           printf("%c  ", c);
    }
    putchar('\n');
}

int main(void)
{
    char        ram_copy[] = "AT+OK";            /* 6 bytes in RAM, editable          */
    const char *flash_ptr  = "AT+OK";            /* pointer to read-only text         */
    static const char flash_arr[] = "READY";     /* static const: really lives in flash */
    char        padded[10] = "AB";               /* "AB", then 8 more zero bytes      */

    printf("ram_copy  : sizeof = %2zu  strlen = %zu\n", sizeof ram_copy, strlen(ram_copy));
    printf("flash_ptr : sizeof = %2zu  strlen = %zu   (pointer size: 4 on a Cortex-M)\n",
           sizeof flash_ptr, strlen(flash_ptr));
    printf("flash_arr : sizeof = %2zu  strlen = %zu\n", sizeof flash_arr, strlen(flash_arr));
    printf("padded    : sizeof = %2zu  strlen = %zu   (only 2 characters, rest is '\\0')\n\n",
           sizeof padded, strlen(padded));

    dump("ram_copy", ram_copy, sizeof ram_copy);
    dump("padded", padded, sizeof padded);
    char single = 'A';
    printf("char single = 'A' takes %zu byte, the string \"A\" takes %zu bytes\n\n",
           sizeof single, sizeof "A");

    /* Editing: allowed on the RAM copy, impossible on the literal. */
    ram_copy[0] = 'a';
    ram_copy[1] = 't';
    printf("after editing the copy: %s   (literal still says %s)\n", ram_copy, flash_ptr);

    /* The classic mistake: filling a char array completely leaves no room for '\0'. */
#ifdef DEMO_BUG
    char tag[3] = { 'A', 'B', 'C' };             /* no terminator: NOT a string        */
    printf("strlen(tag) = %zu\n", strlen(tag));  /* reads past the array: UB           */
#endif
#ifdef DEMO_BUG_WRITE
    char *lit = (char *)flash_ptr;               /* the cast hides the 'const'         */
    lit[0] = 'X';                                /* write to .rodata: crash (SIGSEGV)  */
#endif
    return 0;
}
