/*
 * ============================================================================
 *  Topic   : 16 Strings
 *  Example : 05 - Parse AT commands (AT+LED=1, AT+BAUD=115200, AT+TEMP?)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A string can be parsed with an index that moves left to right: check
 *            the prefix, read the command name up to '=' or '?', then read the
 *            value. Each step looks at ONE character at a time and never trusts the
 *            line to be well formed. Strip the trailing '\r' / '\n' first.
 *  Embedded use : Bluetooth, GSM and WiFi modules (HC-05, SIM800, ESP8266) are all
 *            configured with AT commands. Firmware answers "OK", "ERROR" or
 *            "+NAME:value" followed by "OK".
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex05_at_command_parser.c -o ex05
 *  Output  : each received line followed by the reply (OK / ERROR / +TEMP:25.3);
 *            reads stdin if you type or pipe lines, otherwise a canned session
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Run  echo "AT+LED=1" | ./ex05  and then type your own lines.
 *            2) Add AT+NAME=<text> that stores up to 8 characters safely.
 * ============================================================================
 */
#include <ctype.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define LINE_SIZE  40U

static uint8_t  led_on;
static uint32_t baud = 9600U;
static const uint32_t valid_baud[] = { 9600U, 19200U, 38400U, 57600U, 115200U };

/* Case-insensitive "does `s` start with `prefix`?"; on success advance *s past it. */
static bool take_prefix(const char **s, const char *prefix)
{
    const char *p = *s;
    while (*prefix != '\0') {
        if (toupper((unsigned char)*p) != *prefix) {
            return false;
        }
        p++;
        prefix++;
    }
    *s = p;
    return true;
}

static bool parse_uint(const char *s, uint32_t *out)
{
    if (*s == '\0') {
        return false;
    }
    uint32_t v = 0U;
    for (; *s != '\0'; s++) {
        if (!isdigit((unsigned char)*s)) {
            return false;
        }
        uint32_t digit = (uint32_t)(*s - '0');
        if (v > (UINT32_MAX - digit) / 10U) {           /* v*10+digit would overflow */
            return false;
        }
        v = v * 10U + digit;
    }
    *out = v;
    return true;
}

static void reply(const char *text)
{
    printf("  <- %s\n", text);
}

static void handle_line(char *line)
{
    line[strcspn(line, "\r\n")] = '\0';                 /* strip the line ending */
    printf("-> \"%s\"\n", line);

    const char *p = line;
    if (!take_prefix(&p, "AT")) {
        reply("ERROR");
    } else if (*p == '\0') {                            /* plain "AT" = ping      */
        reply("OK");
    } else if (take_prefix(&p, "+LED=")) {
        uint32_t v;
        if (parse_uint(p, &v) && v <= 1U) {
            led_on = (uint8_t)v;
            reply("OK");
        } else {
            reply("ERROR");
        }
    } else if (take_prefix(&p, "+BAUD=")) {
        uint32_t v;
        bool ok = false;
        if (parse_uint(p, &v)) {
            for (size_t i = 0; i < sizeof valid_baud / sizeof valid_baud[0]; i++) {
                if (valid_baud[i] == v) ok = true;
            }
        }
        if (ok) baud = v;
        reply(ok ? "OK" : "ERROR");
    } else if (take_prefix(&p, "+TEMP?") && *p == '\0') {
        reply("+TEMP:25.3");
        reply("OK");
    } else if (take_prefix(&p, "+STATE?") && *p == '\0') {
        printf("  <- +STATE:LED=%u,BAUD=%u\n", led_on, (unsigned)baud);
        reply("OK");
    } else {
        reply("ERROR");                                 /* unknown command        */
    }
}

int main(void)
{
    char line[LINE_SIZE];
    int lines = 0;

    printf("Type AT commands, one per line (Ctrl-D / Ctrl-Z to stop).\n");
    /* fgets stops at LINE_SIZE-1 characters: a longer line would arrive as two chunks.
     * Real firmware would detect that and discard the whole overlong line.            */
    while (fgets(line, sizeof line, stdin) != NULL) {   /* real UART RX line      */
        handle_line(line);
        lines++;
    }

    if (lines == 0) {
        puts("(no stdin - using simulated UART input)");
        static const char *const canned[] = {
            "AT\r\n", "AT+LED=1\r\n", "at+baud=115200\r\n", "AT+BAUD=1234\r\n",
            "AT+TEMP?\r\n", "AT+LED=7\r\n", "HELLO\r\n", "AT+STATE?\r\n"
        };
        for (size_t i = 0; i < sizeof canned / sizeof canned[0]; i++) {
            snprintf(line, sizeof line, "%s", canned[i]);   /* handle_line edits it  */
            handle_line(line);
        }
    }
    return 0;
}
