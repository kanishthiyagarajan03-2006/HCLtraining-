/*
 * ============================================================================
 *  Topic   : 16 Strings
 *  Example : 08 - argv strings, --key=value options, /etc/hostname and uname()
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : main(int argc, char *argv[]) hands the program its command line as an
 *            array of strings; argv[0] is the program name and argv[argc] is NULL.
 *            fgets() keeps the trailing '\n', which you must strip before using the
 *            text; strchr() splits "key=value" at the '='.
 *  Embedded use : an embedded Linux daemon is configured by command-line options
 *            (--rate=100) and identifies the board with its hostname and kernel
 *            version, usually read from /etc/hostname and uname().
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex08_linux_argv_and_hostname.c -o ex08
 *  Output  : the arguments with their lengths, the parsed key/value options, the
 *            board hostname (with the newline stripped) and the kernel name/version
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Run  ./ex08 --rate=100 --name=gateway verbose  and compare the output.
 *            2) What does strlen() return for the hostname line BEFORE the newline is stripped?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stdio.h>
#include <string.h>
#include <sys/utsname.h>
#include <unistd.h>

#define NAME_MAX_LEN  64U

/* Show every argument and split the ones that look like --key=value. */
static void show_args(int argc, char *argv[])
{
    for (int i = 0; i < argc; i++) {
        printf("argv[%d] = \"%s\"  (%zu characters)\n", i, argv[i], strlen(argv[i]));
    }
    puts("options:");
    for (int i = 1; i < argc; i++) {
        if (strncmp(argv[i], "--", 2) == 0) {
            const char *key = argv[i] + 2;                  /* skip the two dashes   */
            const char *eq  = strchr(key, '=');             /* NULL if there is no '=' */
            if (eq != NULL) {
                printf("  key \"%.*s\" = value \"%s\"\n", (int)(eq - key), key, eq + 1);
            } else {
                printf("  flag \"%s\" (no value)\n", key);
            }
        } else {
            printf("  plain argument \"%s\"\n", argv[i]);
        }
    }
}

/* Read the board name; fall back to gethostname() if the file is missing. */
static void read_hostname(char *out, size_t cap)
{
    FILE *f = fopen("/etc/hostname", "r");
    if (f != NULL) {
        if (fgets(out, (int)cap, f) != NULL) {
            printf("raw line from file : length %zu (newline included)\n", strlen(out));
            out[strcspn(out, "\r\n")] = '\0';               /* strip the line ending */
            printf("after stripping    : length %zu\n", strlen(out));
            fclose(f);
            return;
        }
        fclose(f);
    }
    if (gethostname(out, cap) != 0) {
        snprintf(out, cap, "%s", "unknown");
    }
    out[cap - 1U] = '\0';                                   /* gethostname may not terminate */
    puts("(/etc/hostname not readable - used gethostname())");
}

int main(int argc, char *argv[])
{
    if (argc <= 1) {
        puts("(no arguments given - showing a simulated command line)");
        char *demo[] = { "ex08", "--rate=100", "--name=gateway", "--verbose", "log.txt" };
        show_args((int)(sizeof demo / sizeof demo[0]), demo);
    } else {
        show_args(argc, argv);
    }

    char host[NAME_MAX_LEN];
    puts("\nhostname:");
    read_hostname(host, sizeof host);
    printf("board hostname     : \"%s\"\n", host);

    struct utsname u;
    if (uname(&u) == 0) {
        printf("kernel             : %s %s (%s)\n", u.sysname, u.release, u.machine);
    }
    return 0;
}
