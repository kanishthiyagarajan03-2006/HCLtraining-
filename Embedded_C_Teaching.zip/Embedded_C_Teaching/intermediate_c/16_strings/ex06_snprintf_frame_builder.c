/*
 * ============================================================================
 *  Topic   : 16 Strings
 *  Example : 06 - Build a telemetry frame safely with snprintf (and a checksum)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : snprintf(buf, size, ...) never writes more than 'size' bytes (including
 *            the '\0') and RETURNS the length the full text would have had. If the
 *            return value is >= size the text was truncated. sprintf has no size
 *            limit and is the classic cause of stack-smashing bugs.
 *  Embedded use : NMEA-style frames ("$TEMP,25.3,VBAT,3300*3B") are built into a RAM
 *            buffer, protected by an XOR checksum, then sent by UART or DMA. A frame
 *            must never overflow its buffer, and must never be sent half-built.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex06_snprintf_frame_builder.c -o ex06
 *  Output  : a complete frame with its checksum, the same frame built with a buffer that
 *            is too small (truncation detected), and a frame built field by field
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change FRAME_SIZE to 20 - which message do you get, and why?
 *            2) Build with -DDEMO_BUG and read the sanitizer report.
 * ============================================================================
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define FRAME_SIZE  48U

/* XOR of every character between '$' and '*' - the NMEA 0183 checksum. */
static uint8_t xor_checksum(const char *body)
{
    uint8_t cs = 0U;
    for (; *body != '\0'; body++) {
        cs ^= (uint8_t)*body;
    }
    return cs;
}

/* Build "$<body>*<CS>\r\n" into out[cap]. Returns false if it did not fit. */
static bool make_frame(char *out, size_t cap, const char *body)
{
    int n = snprintf(out, cap, "$%s*%02X\r\n", body, (unsigned)xor_checksum(body));
    return n > 0 && (size_t)n < cap;                    /* >= cap means truncated */
}

static void show(const char *label, const char *frame, bool ok)
{
    /* print without the CR LF so the console output stays on one line */
    size_t len = strcspn(frame, "\r\n");
    printf("%-22s [%.*s]  %s\n", label, (int)len, frame, ok ? "complete" : "TRUNCATED - not sent");
}

int main(void)
{
    int temp_tenth = 253;                               /* 25.3 C as fixed point  */
    unsigned vbat_mv = 3300U;

    /* fixed-point text: no float needed, no %f (which is large on small MCUs)     */
    char body[32];
    snprintf(body, sizeof body, "TEMP,%d.%d,VBAT,%u", temp_tenth / 10, temp_tenth % 10, vbat_mv);
    printf("body: %s\n\n", body);

    char frame[FRAME_SIZE];
    bool ok = make_frame(frame, sizeof frame, body);
    show("48-byte buffer:", frame, ok);

    char tiny[16];
    ok = make_frame(tiny, sizeof tiny, body);           /* too small: cut but safe */
    show("16-byte buffer:", tiny, ok);
    printf("  (tiny is still a valid C string: strlen = %zu, last char index %zu is '\\0')\n\n",
           strlen(tiny), sizeof tiny - 1U);

    /* Appending field by field: keep track of the position and the space left.     */
    char log[40];
    size_t pos = 0U;
    for (int ch = 0; ch < 6; ch++) {
        if (pos < sizeof log) {
            unsigned value = 1000U + 111U * (unsigned)ch;
            int n = snprintf(log + pos, sizeof log - pos, "CH%d=%u;", ch, value);
            if (n > 0) pos += (size_t)n;                /* may exceed size: checked above */
        }
    }
    bool fits = pos < sizeof log;
    printf("appended text (%s): %s\n", fits ? "fits" : "TRUNCATED", log);
    printf("needed at least %zu characters, buffer holds %zu\n", pos, sizeof log - 1U);

#ifdef DEMO_BUG
    /* sprintf has no idea how big 'tiny' is: it happily writes past the end of the array
     * (stack-buffer-overflow). Never use sprintf for variable-length text.             */
    sprintf(tiny, "$%s*%02X\r\n", body, (unsigned)xor_checksum(body));
#endif
    return 0;
}
