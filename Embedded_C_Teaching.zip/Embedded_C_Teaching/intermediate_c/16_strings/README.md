# Topic 16 - Strings
**Suggested session:** 90 min | **Prerequisite topics:** 08 Control Loops, 13 Storage Classes, 15 Arrays (pointers are met properly in Topic 17)

Students should leave knowing that a C string is just a `char` array ending in `'\0'`, why `char buf[]` and `const char *p` are different objects, and how to handle text safely on a device with little RAM. The examples start with the memory layout, then write the basic string functions by hand, convert numbers to text and back, split and parse command lines (console and AT commands), build frames safely with `snprintf`, and finish with RTOS log messages and embedded-Linux `argv` and hostname handling.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_char_array_vs_literal.c` | MCU | `'\0'` terminator, `sizeof` vs `strlen`, RAM copy vs flash literal, byte dump, padding with zeros |
| 02 | `ex02_my_strlen_copy_reverse.c` | MCU | Hand-written `strlen`, truncating-safe copy, in-place reverse, compare; `uart_puts` as a loop to `'\0'` |
| 03 | `ex03_itoa_atoi_by_hand.c` | MCU | `c - '0'`, number to text in any base, text to number with bad-character and overflow checks |
| 04 | `ex04_tokenizer_command_line.c` | MCU | In-place tokenizer (`'\0'` over spaces), word pointer array, dispatch of `LED ON`, `PWM 50` |
| 05 | `ex05_at_command_parser.c` | MCU | Index-based parser for `AT+LED=1`, `AT+BAUD=...`, `AT+TEMP?`; stdin with canned fallback |
| 06 | `ex06_snprintf_frame_builder.c` | MCU | `snprintf` return value and truncation, XOR checksum frame, appending with a position, `sprintf` hazard |
| 07 | `ex07_rtos_log_strings.c` | RTOS | Copying strings into fixed-size queue messages, `vsnprintf`, task-name strings, logger task |
| 08 | `ex08_linux_argv_and_hostname.c` | LINUX | `argv` strings, `--key=value` splitting with `strchr`, `/etc/hostname` newline stripping, `uname()` |

## Teaching notes
* Count bytes aloud: `"AT"` is 3 bytes. Most string bugs are off-by-one errors about the terminator (ex01, ex06).
* `char buf[] = "text"` copies the literal into writable RAM; `const char *p = "text"` points at read-only memory. Writing through `p` crashes (see `-DDEMO_BUG_WRITE` in ex01; `-DDEMO_BUG` shows the missing terminator). Tokenizing in ex04 only works on the array, which is why `main` copies each test line first.
* `strlen` is O(n): it walks the whole string every call. Do not call it in a loop condition on a slow MCU.
* Prefer `snprintf` (and check its return value). `strcpy`, `strcat` and `sprintf` know nothing about the destination size. Topic 20 covers the full `<string.h>` set; here we write the core ones by hand to see why they behave as they do.
* Parsers must reject bad input (ex03, ex05): returning 0 for `"abc"` is a silent bug that is very hard to find later.
* Strings placed in a queue must be copied into the message (ex07); a pointer to a task's local buffer would dangle.

## Live-demo tips
* ex01: build with `-DDEMO_BUG -fsanitize=address,undefined` to show the unterminated array, and with `-DDEMO_BUG_WRITE` for the write to a literal; run `size` or `nm` to show `.rodata` growing when you add long literals.
* ex05 is interactive: `echo "AT+LED=1" | ./ex05`, or type commands and finish with Ctrl-D. With no input it replays a canned session.
* ex08: run it plain, then `./ex08 --rate=100 --name=gateway verbose` to compare the parsed options.
