/*
 * ============================================================================
 *  Topic   : 24 Pointer to Pointer
 *  Example : 05 - Callback registration through a pointer to a function pointer
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A callback is stored in a struct field of type cb_t (a function pointer).
 *            To CHANGE that field from another function you pass its address: a
 *            "cb_t *", i.e. a pointer to a function pointer. The same call can also
 *            hand back the previous handler, which allows chaining and unregistering.
 *  Embedded use : HAL drivers keep per-event callbacks (RX done, TX done, error) that
 *            the application can replace at run time without editing the driver.
 *  Real STM32F4 : HAL_UART_RegisterCallback(&huart2, HAL_UART_RX_COMPLETE_CB_ID, my_rx_cb);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_callback_slot_registration.c -o ex05
 *  Output  : events hit the default handler, then an application handler, then a
 *            logging hook that chains to the old one, then back to the default
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Register app_rx twice, passing &previous_rx each time - what is saved?
 *            2) Add an EV_IDLE event: which functions and tables must you extend?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

typedef void (*cb_t)(uint32_t arg);                 /* callback: receives one value */

typedef enum { EV_RX, EV_TX_DONE, EV_ERROR, EV_COUNT } uart_event_t;

typedef struct {
    cb_t on_rx;
    cb_t on_tx_done;
    cb_t on_error;
} uart_handle_t;

static void default_cb(uint32_t arg)
{
    printf("  default handler: event ignored (arg=0x%02X)\n", (unsigned)arg);
}

/* Returns the ADDRESS of the callback field for an event: a pointer to a function pointer. */
static cb_t *slot_of(uart_handle_t *h, uart_event_t ev)
{
    switch (ev) {
    case EV_RX:      return &h->on_rx;
    case EV_TX_DONE: return &h->on_tx_done;
    case EV_ERROR:   return &h->on_error;
    default:         return NULL;
    }
}

/* slot is a cb_t * : writing *slot replaces the function pointer stored in the handle.
 * fn == NULL restores the default. The old handler is optionally returned for chaining. */
static int register_cb(cb_t *slot, cb_t fn, cb_t *previous)
{
    if (slot == NULL) {
        return -1;
    }
    if (previous != NULL) {
        *previous = *slot;
    }
    *slot = (fn != NULL) ? fn : default_cb;
    return 0;
}

static void fire(uart_handle_t *h, uart_event_t ev, uint32_t arg)
{
    cb_t *slot = slot_of(h, ev);
    if (slot != NULL && *slot != NULL) {
        (*slot)(arg);                               /* call through the stored pointer */
    }
}

/* ---- application handlers -------------------------------------------------- */
static void app_rx(uint32_t byte)
{
    printf("  app_rx: got byte 0x%02X ('%c')\n", (unsigned)byte, (char)byte);
}

static cb_t previous_rx;                            /* filled by register_cb */

static void logging_rx(uint32_t byte)
{
    printf("  logging_rx: saw a byte, passing it on\n");
    if (previous_rx != NULL) {
        previous_rx(byte);                          /* chain to whoever was registered before */
    }
}

static void error_led(uint32_t code)
{
    printf("  error_led: error code %u -> red LED on\n", (unsigned)code);
}

int main(void)
{
    uart_handle_t huart = { default_cb, default_cb, default_cb };

    printf("1) nothing registered:\n");
    fire(&huart, EV_RX, 0x41);

    printf("2) register app_rx and error_led:\n");
    register_cb(slot_of(&huart, EV_RX), app_rx, NULL);
    register_cb(slot_of(&huart, EV_ERROR), error_led, NULL);
    fire(&huart, EV_RX, 0x41);
    fire(&huart, EV_ERROR, 3);
    fire(&huart, EV_TX_DONE, 0);                    /* still the default */

    printf("3) hook logging_rx in front of app_rx (previous handler saved):\n");
    register_cb(slot_of(&huart, EV_RX), logging_rx, &previous_rx);
    fire(&huart, EV_RX, 0x42);

    printf("4) bad arguments are rejected: register_cb(NULL slot) = %d\n",
           register_cb(slot_of(&huart, EV_COUNT), app_rx, NULL));

    printf("5) unregister (fn = NULL restores the default):\n");
    register_cb(slot_of(&huart, EV_RX), NULL, NULL);
    fire(&huart, EV_RX, 0x43);

    /* An array of pointers to function pointers: inspect all slots with one loop. */
    cb_t *slots[EV_COUNT] = { &huart.on_rx, &huart.on_tx_done, &huart.on_error };
    static const char *const names[EV_COUNT] = { "RX", "TX_DONE", "ERROR" };
    for (size_t i = 0; i < EV_COUNT; i++) {
        printf("slot %-7s : %s\n", names[i], *slots[i] == default_cb ? "default" : "custom");
    }
    return 0;
}
