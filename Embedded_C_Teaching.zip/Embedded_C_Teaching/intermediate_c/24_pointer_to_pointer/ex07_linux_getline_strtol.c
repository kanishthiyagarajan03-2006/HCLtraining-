/*
 * ============================================================================
 *  Topic   : 24 Pointer to Pointer
 *  Example : 07 - getline(&line, &cap, fp) and strtol(s, &end, 10)
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Two libc functions need a pointer to pointer:
 *              getline(char **lineptr, size_t *n, FILE *fp)   (a growing buffer)
 *              strtol(const char *s, char **endptr, int base) (where parsing stopped)
 *            getline may malloc/realloc, so it must be able to REPLACE your pointer.
 *            strtol stores the address of the first unparsed character in *endptr,
 *            which is how you detect "no digits" and trailing junk, and how you
 *            parse a whole list of numbers from one string.
 *  Embedded use : an embedded-Linux daemon reads "key=value" config or log files of
 *            unknown line length and must not trust sensor text blindly.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex07_linux_getline_strtol.c -o ex07
 *  Output  : a generated config file parsed line by line: good numbers, a missing
 *            number, trailing junk, a comment, and a list of numbers walked with 'end'
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add the line "gain=99999999999999999999" - which check catches it?
 *            2) Why must main() call free(line) even though it never called malloc()?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

/* Parse the text after '=' as a decimal integer, with every failure mode checked. */
static void parse_value(const char *key, const char *text)
{
    char *end;                               /* strtol fills this: a pointer into text */
    errno = 0;
    long v = strtol(text, &end, 10);
    if (end == text) {
        printf("  %-8s -> no digits in \"%s\"\n", key, text);
    } else if (errno == ERANGE) {
        printf("  %-8s -> out of range\n", key);
    } else if (*end != '\0') {
        printf("  %-8s -> %ld, but trailing junk \"%s\"\n", key, v, end);
    } else {
        printf("  %-8s -> %ld\n", key, v);
    }
}

/* Walk "10 20 30 x40": strtol leaves 'end' just after each number; we restart from there. */
static void parse_list(const char *s)
{
    printf("  list \"%s\" ->", s);
    const char *p = s;
    for (;;) {
        char *end;
        long v = strtol(p, &end, 10);
        if (end == p) {
            break;                           /* nothing more that looks like a number */
        }
        printf(" %ld", v);
        p = end;                             /* continue after the number just read */
    }
    printf("  (stopped at \"%s\")\n", p);
}

int main(void)
{
    char dir[] = "/tmp/ex07_XXXXXX";
    if (mkdtemp(dir) == NULL) {
        perror("mkdtemp");
        return 1;
    }
    char path[64];
    snprintf(path, sizeof path, "%s/sensor.cfg", dir);

    FILE *fp = fopen(path, "w");
    if (fp == NULL) {
        perror("fopen");
        rmdir(dir);
        return 1;
    }
    fputs("# sensor configuration\n"
          "samples=64\n"
          "offset=-5\n"
          "gain=abc\n"
          "period=250ms\n"
          "\n"
          "channels=1 2 4 x8\n", fp);
    fclose(fp);

    fp = fopen(path, "r");
    if (fp == NULL) {
        perror("fopen");
        unlink(path);
        rmdir(dir);
        return 1;
    }

    char *line = NULL;                       /* getline will allocate it for us ... */
    size_t cap = 0;                          /* ... and tell us how big it made it */
    ssize_t len;
    int lineno = 0;
    while ((len = getline(&line, &cap, fp)) != -1) {   /* &line is a char ** */
        lineno++;
        if (len > 0 && line[len - 1] == '\n') {
            line[len - 1] = '\0';            /* strip the newline */
        }
        printf("line %d (%zd bytes): \"%s\"\n", lineno, len, line);
        if (line[0] == '#' || line[0] == '\0') {
            continue;
        }
        char *eq = strchr(line, '=');
        if (eq == NULL) {
            continue;
        }
        *eq = '\0';                          /* split into key and value in place */
        if (strcmp(line, "channels") == 0) {
            parse_list(eq + 1);
        } else {
            parse_value(line, eq + 1);
        }
    }

    free(line);                              /* getline's allocation belongs to us */
    fclose(fp);
    unlink(path);
    rmdir(dir);
    return 0;
}
