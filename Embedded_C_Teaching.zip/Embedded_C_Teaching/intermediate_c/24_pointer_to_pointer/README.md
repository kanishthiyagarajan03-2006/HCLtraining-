# Topic 24 - Pointer to Pointer
**Suggested session:** 75 min | **Prerequisite topics:** 17 Pointers, 21 Call by Value vs Call by Address, 23 Array of Pointers

Students should leave knowing that `T **` is needed whenever a function must change a pointer owned by its caller (set it,
advance it, reset it) and whenever a table is an array of pointers. The examples go from an allocator out-parameter, to
linked lists, a text cursor, an array of row pointers and callback slots, then an RTOS delayed list and the libc functions
`getline` and `strtol` that use the same idea.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_out_param_pool_alloc.c` | MCU | `pool_alloc(uint8_t **out)` vs the by-value mistake, `pool_free(&p)` resets the caller's pointer |
| 02 | `ex02_linked_list_head_pointer.c` | MCU | `insert(node_t **head, ...)`, sorted insert and removal with `node_t **pp` and no head special-case |
| 03 | `ex03_tokenizer_cursor.c` | MCU | `next_token(const char **cursor, ...)`: helpers consume text and leave the caller's cursor behind |
| 04 | `ex04_row_pointer_table_scroll.c` | MCU | `char **rows`: scrolling an LCD by rotating row pointers, not characters |
| 05 | `ex05_callback_slot_registration.c` | MCU | `cb_t *slot`: register, chain and unregister callbacks through a pointer to a function pointer |
| 06 | `ex06_rtos_delayed_list_tcb_pp.c` | RTOS | Delayed list sorted by wake tick using `tcb_t **`; tick handler pops expired tasks (plain-C model) |
| 07 | `ex07_linux_getline_strtol.c` | LINUX | `getline(&line, &cap, fp)` and `strtol(s, &end, 10)`: the two famous `**` parameters |

## Teaching notes
* Draw boxes and arrows: `out` points to the caller's `buf`, which points to the block. One `*` per hop. Run ex01 slowly with the diagram on the board.
* The rule of thumb: to modify a `T`, pass a `T *`. If `T` is itself a pointer type, you pass a `T **`.
* In ex02 the `node_t **pp` idiom is worth five minutes: `pp` holds the address of the LINK that points at the current node, so inserting "before" a node and replacing the head are the same assignment.
* `const char **` and `char **` are different types in C; ex03 shows why the cursor is declared `const char **` for read-only text.
* ex04 and `argv` (topic 23 ex06) are both "array of pointers", passed as `char **`.
* After `getline` the buffer belongs to you: `free(line)` once at the end, even though you never called `malloc` (ex07).

## Live-demo tips
* ex01: single-step in a debugger and watch `buf` stay NULL after `pool_alloc_wrong`, then change after `pool_alloc(&buf)`.
* ex06: change the periods so two tasks wake on the same tick and observe the arrival-order tie-break (`<=` in the loop condition).
* ex07: add `gain=99999999999999999999` to the generated file to trigger the `ERANGE` path.
