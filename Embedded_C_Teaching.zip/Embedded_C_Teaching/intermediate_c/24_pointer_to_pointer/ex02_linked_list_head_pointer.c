/*
 * ============================================================================
 *  Topic   : 24 Pointer to Pointer
 *  Example : 02 - Linked list of software timers: insert(node_t **head, ...)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : The list head is itself a pointer, and insert/remove may have to CHANGE
 *            it. So the functions take node_t **head. Walking with a "node_t **pp"
 *            (the address of the link that points at the current node) removes the
 *            special case for the first node: *pp = n works for head and middle alike.
 *  Embedded use : sorted lists of software timers or scheduled events, built from a
 *            static node pool so no malloc/free is needed on the MCU.
 *  Real STM32F4 : none - the same idea FreeRTOS vListInsert() uses to keep lists ordered
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_linked_list_head_pointer.c -o ex02
 *  Output  : push_front by value leaves the list empty, by node_t ** works; timers are
 *            inserted sorted by expiry (ties keep arrival order); a middle node and the head
 *            are then cancelled
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Insert a timer with expiry 20 again - where does it land among the 20s?
 *            2) Write pop_first(node_t **head) that removes and returns the earliest timer.
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef struct node {
    uint32_t     expiry_ms;
    const char  *name;
    struct node *next;
} node_t;

static node_t pool[8];                       /* static node storage: no heap on the MCU */
static size_t pool_used;

static node_t *node_new(uint32_t expiry_ms, const char *name)
{
    if (pool_used >= sizeof pool / sizeof pool[0]) {
        return NULL;
    }
    node_t *n = &pool[pool_used++];
    n->expiry_ms = expiry_ms;
    n->name = name;
    n->next = NULL;
    return n;
}

/* WRONG: head is a copy of the caller's head pointer; the caller never sees the change. */
static void push_front_wrong(node_t *head, node_t *n)
{
    n->next = head;
    head = n;                                /* only the local copy moves */
    (void)head;
}

static void push_front(node_t **head, node_t *n)
{
    n->next = *head;
    *head = n;                               /* the caller's head pointer is updated */
}

/* Keep the list sorted by expiry. pp always holds the ADDRESS of the link to examine:
 * first &head, then &first->next, ... so "insert before the current node" is uniform. */
static void insert_sorted(node_t **head, node_t *n)
{
    node_t **pp = head;
    while (*pp != NULL && (*pp)->expiry_ms <= n->expiry_ms) {
        pp = &(*pp)->next;
    }
    n->next = *pp;
    *pp = n;
}

/* Unlink by name. Needs no "previous node" variable and no special case for the head. */
static node_t *remove_by_name(node_t **head, const char *name)
{
    node_t **pp = head;
    while (*pp != NULL && strcmp((*pp)->name, name) != 0) {
        pp = &(*pp)->next;
    }
    node_t *found = *pp;
    if (found != NULL) {
        *pp = found->next;                         /* skip over it */
        found->next = NULL;
    }
    return found;
}

static void print_list(const char *title, const node_t *head)
{
    printf("%s", title);
    if (head == NULL) {
        printf(" (empty)");
    }
    for (const node_t *n = head; n != NULL; n = n->next) {
        printf(" %s@%ums%s", n->name, (unsigned)n->expiry_ms, n->next ? " ->" : "");
    }
    printf("\n");
}

int main(void)
{
    node_t *list = NULL;
    push_front_wrong(list, node_new(5U, "tmp"));
    print_list("after push_front_wrong:", list);
    push_front(&list, node_new(5U, "tmp"));
    print_list("after push_front      :", list);
    (void)remove_by_name(&list, "tmp");              /* removing the head empties the list */
    print_list("after removing tmp    :", list);

    insert_sorted(&list, node_new(50U, "uart"));
    insert_sorted(&list, node_new(20U, "led"));
    insert_sorted(&list, node_new(100U, "wdt"));
    insert_sorted(&list, node_new(20U, "adc"));      /* ties: after the earlier 20 ms timer */
    insert_sorted(&list, node_new(5U, "retry"));     /* becomes the new head */
    print_list("sorted timers:", list);

    node_t *gone = remove_by_name(&list, "uart");    /* from the middle */
    printf("cancelled %s\n", gone ? gone->name : "(none)");
    gone = remove_by_name(&list, "retry");           /* the head: *head changes */
    printf("cancelled %s (it was the head)\n", gone ? gone->name : "(none)");
    print_list("remaining    :", list);
    printf("first to fire: %s at %u ms\n", list->name, (unsigned)list->expiry_ms);
    return 0;
}
