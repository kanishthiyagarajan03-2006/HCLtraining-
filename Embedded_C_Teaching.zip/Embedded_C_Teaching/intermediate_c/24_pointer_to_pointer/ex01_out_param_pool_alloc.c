/*
 * ============================================================================
 *  Topic   : 24 Pointer to Pointer
 *  Example : 01 - Out-parameter allocation: pool_alloc(uint8_t **out)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A function that must SET a caller's pointer needs the ADDRESS of that
 *            pointer, i.e. a pointer to pointer ("uint8_t **out"). Passing the
 *            pointer itself hands over a copy, so "p = block" changes only the copy.
 *              out   -> [ caller's buf ] -> [ block bytes ... ]
 *              *out  is the caller's pointer      **out is the first byte
 *            The same trick lets pool_free(&buf) set the caller's pointer to NULL.
 *  Embedded use : firmware avoids malloc and carves fixed blocks from a static pool
 *            (UART frames, CAN messages, RTOS buffers); exhaustion is a status code.
 *  Real STM32F4 : similar real APIs: CMSIS-RTOS2 osMemoryPoolAlloc(pool_id, timeout), pvPortMalloc
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_out_param_pool_alloc.c -o ex01
 *  Output  : the by-value version leaves buf NULL, the **out version fills it; a 3-block
 *            pool runs dry on the 4th request; free nulls the pointer and is safe twice
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a fourth block (NUM_BLOCKS 4) - which line of output changes?
 *            2) Make pool_free() leave *p alone and call it twice - what could go wrong?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define BLOCK_SIZE 16U
#define NUM_BLOCKS 3U

static uint8_t pool[NUM_BLOCKS][BLOCK_SIZE];     /* all storage is static: no malloc */
static uint8_t in_use[NUM_BLOCKS];

typedef enum { POOL_OK = 0, POOL_EMPTY, POOL_BAD_ARG } pool_status_t;

static const char *status_text(pool_status_t s)
{
    static const char *const text[] = { "OK", "POOL_EMPTY", "BAD_ARG" };
    return text[s];
}

static size_t block_index(const uint8_t *p)      /* which block does p point to? */
{
    for (size_t i = 0; i < NUM_BLOCKS; i++) {
        if (p == pool[i]) {
            return i;
        }
    }
    return NUM_BLOCKS;
}

/* WRONG: p is a COPY of the caller's pointer. Assigning to it is invisible outside.
 * (A real buggy allocator would also mark the block used and so leak it.) */
static pool_status_t pool_alloc_wrong(uint8_t *p)
{
    p = pool[0];
    printf("  inside wrong version: p = block %zu (looks fine here)\n", block_index(p));
    return POOL_OK;
}

/* RIGHT: out is the address of the caller's pointer, so *out = ... changes the caller. */
static pool_status_t pool_alloc(uint8_t **out)
{
    if (out == NULL) {
        return POOL_BAD_ARG;
    }
    *out = NULL;                                  /* never leave a stale pointer on failure */
    for (size_t i = 0; i < NUM_BLOCKS; i++) {
        if (!in_use[i]) {
            in_use[i] = 1U;
            *out = pool[i];
            return POOL_OK;
        }
    }
    return POOL_EMPTY;
}

/* Takes uint8_t ** so it can reset the caller's pointer: no dangling pointer is left. */
static pool_status_t pool_free(uint8_t **p)
{
    if (p == NULL || *p == NULL) {
        return POOL_BAD_ARG;                      /* double free is detected, not fatal */
    }
    size_t i = block_index(*p);
    if (i == NUM_BLOCKS) {
        return POOL_BAD_ARG;                      /* not one of our blocks */
    }
    in_use[i] = 0U;
    *p = NULL;
    return POOL_OK;
}

int main(void)
{
    uint8_t *buf = NULL;

    (void)pool_alloc_wrong(buf);
    printf("after pool_alloc_wrong(buf): buf is %s\n", buf == NULL ? "still NULL" : "set");

    pool_status_t st = pool_alloc(&buf);          /* &buf has type uint8_t ** */
    printf("pool_alloc(&buf)          : %s, buf is %s (block %zu)\n", status_text(st),
           buf == NULL ? "NULL" : "set", block_index(buf));
    snprintf((char *)buf, BLOCK_SIZE, "RX frame %d", 1);
    printf("block content via the pointer: \"%s\"\n", (char *)buf);

    uint8_t *more[3] = { NULL, NULL, NULL };
    for (size_t i = 0; i < 3U; i++) {
        st = pool_alloc(&more[i]);
        printf("request %zu: %-10s more[%zu] is %s\n", i + 2U, status_text(st), i,
               more[i] == NULL ? "NULL (pool exhausted)" : "a valid block");
    }

    st = pool_free(&buf);
    printf("pool_free(&buf)           : %s, buf is now %s\n", status_text(st),
           buf == NULL ? "NULL" : "dangling!");
    st = pool_free(&buf);
    printf("pool_free(&buf) again     : %s (harmless: the pointer was reset)\n", status_text(st));

    st = pool_alloc(&buf);                        /* the freed block is available again */
    printf("pool_alloc(&buf) again    : %s, recycled block %zu\n", status_text(st),
           block_index(buf));
    return 0;
}
