/*
 * ============================================================================
 *  Topic   : 24 Pointer to Pointer
 *  Example : 03 - UART command parser with a cursor: next_token(const char **cursor)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A parser walks through text with a char pointer (its "cursor"). To let
 *            helper functions consume part of the line AND leave the cursor where
 *            they stopped, pass the ADDRESS of the cursor: const char **cursor.
 *            The helper reads *cursor, advances a local copy, and stores it back.
 *            Nothing is copied or modified in the input text itself.
 *  Embedded use : AT-command and console parsers on small MCUs: no strtok (it keeps
 *            hidden static state and writes '\0' into your buffer), no heap.
 *  Real STM32F4 : the line normally arrives from the USART RX interrupt / ring buffer
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_tokenizer_cursor.c -o ex03
 *  Output  : six command lines parsed (LED/PWM/SET BAUD, a bad pin, an empty line, an
 *            unknown word); after each, the unparsed rest of the line is shown
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add the command "ADC <channel>" using parse_uint().
 *            2) Why does parse_uint() leave the cursor alone when it fails?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define TOKEN_MAX 12U

/* Copies the next blank-separated word into out (cap >= 1) and advances *cursor. */
static int next_token(const char **cursor, char *out, size_t cap)
{
    const char *p = *cursor;                 /* work on a local copy of the pointer ... */
    while (*p == ' ' || *p == '\t') {
        p++;
    }
    size_t n = 0U;
    while (*p != '\0' && *p != ' ' && *p != '\t') {
        if (n + 1U < cap) {
            out[n++] = *p;                   /* over-long words are truncated, never overrun */
        }
        p++;
    }
    out[n] = '\0';
    *cursor = p;                             /* ... and publish where we stopped */
    return n > 0U;
}

/* Parses an unsigned decimal. On failure the cursor is NOT moved, so the caller can retry. */
static int parse_uint(const char **cursor, uint32_t *out)
{
    const char *p = *cursor;
    while (*p == ' ') {
        p++;
    }
    if (*p < '0' || *p > '9') {
        return 0;
    }
    uint32_t v = 0U;
    while (*p >= '0' && *p <= '9') {
        uint32_t digit = (uint32_t)(*p - '0');
        if (v > (UINT32_MAX - digit) / 10U) {
            return 0;                        /* would overflow 32 bits */
        }
        v = v * 10U + digit;
        p++;
    }
    *out = v;
    *cursor = p;
    return 1;
}

static void handle_line(const char *line)
{
    const char *cur = line;                  /* the cursor: points INTO the caller's text */
    char word[TOKEN_MAX];
    uint32_t num;

    printf("> \"%s\"\n", line);
    if (!next_token(&cur, word, sizeof word)) {      /* &cur is a const char ** */
        printf("  (empty line)\n");
        return;
    }

    if (strcmp(word, "LED") == 0) {
        char state[TOKEN_MAX];
        if (parse_uint(&cur, &num) && next_token(&cur, state, sizeof state)) {
            printf("  -> LED %u %s\n", (unsigned)num, state);
        } else {
            printf("  usage: LED <pin> <ON|OFF>\n");
        }
    } else if (strcmp(word, "PWM") == 0) {
        if (parse_uint(&cur, &num) && num <= 100U) {
            printf("  -> PWM duty %u%%\n", (unsigned)num);
        } else {
            printf("  usage: PWM <0..100>\n");
        }
    } else if (strcmp(word, "SET") == 0) {
        char what[TOKEN_MAX];
        if (next_token(&cur, what, sizeof what) && strcmp(what, "BAUD") == 0 &&
            parse_uint(&cur, &num)) {
            printf("  -> baud rate %u\n", (unsigned)num);
        } else {
            printf("  usage: SET BAUD <rate>\n");
        }
    } else {
        printf("  unknown command \"%s\"\n", word);
    }
    printf("  unparsed rest: \"%s\"\n", cur);          /* shows where the cursor ended up */
}

int main(void)
{
    static const char *const lines[] = {
        "LED 3 ON",
        "  PWM   75  ",
        "SET BAUD 115200 extra",
        "LED x ON",
        "",
        "REBOOTNOW",
    };
    for (size_t i = 0; i < sizeof lines / sizeof lines[0]; i++) {
        handle_line(lines[i]);
    }
    return 0;
}
