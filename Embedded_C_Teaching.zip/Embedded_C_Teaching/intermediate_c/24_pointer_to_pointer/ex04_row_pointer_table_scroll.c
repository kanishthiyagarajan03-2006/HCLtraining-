/*
 * ============================================================================
 *  Topic   : 24 Pointer to Pointer
 *  Example : 04 - Text LCD scrolling by rotating an array of row pointers (char **)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A 2-D "table" can be an array of ROW POINTERS: char *rows[4]. A function
 *            that works on the whole table takes char **rows (pointer to the first
 *            row pointer). Reordering rows is then just reordering pointers - the
 *            text bytes never move. Heap-built 2-D arrays use the same shape.
 *  Embedded use : 16x2 / 20x4 character LCDs and OLED consoles scroll a log without
 *            copying every character; fewer RAM writes means less CPU time.
 *  Real STM32F4 : (HD44780 driver: lcd_write_line(row_ptr[i]) over I2C/GPIO)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_row_pointer_table_scroll.c -o ex04
 *  Output  : a 4-line, 16-column screen filled by six log messages; the row-to-buffer
 *            map shows buffers being recycled, and bytes moved are compared
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change ROWS to 3 - which message is the oldest one still visible?
 *            2) Write lcd_scroll_down() (hint: the mirror image of lcd_println).
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define ROWS 4U
#define COLS 16U

static char storage[ROWS][COLS + 1U];       /* the real character buffers (+1 for '\0') */
static char *rows[ROWS];                    /* screen row i is currently storage[?] */

static size_t bytes_moved_ptr;              /* what we really moved */
static size_t bytes_if_copied;              /* what a memmove-based scroll would have moved */

/* rows decays to char ** : a pointer to the first row pointer. */
static void lcd_init(char **row, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        row[i] = storage[i];
        memset(row[i], ' ', COLS);
        row[i][COLS] = '\0';
    }
}

/* Scroll up by shifting POINTERS, then reuse the oldest buffer for the new bottom line. */
static void lcd_println(char **row, size_t n, const char *text)
{
    char *recycled = row[0];                /* the line that scrolls off the top */
    for (size_t i = 0; i + 1U < n; i++) {
        row[i] = row[i + 1U];               /* one pointer move, not COLS character moves */
    }
    row[n - 1U] = recycled;
    snprintf(recycled, COLS + 1U, "%-*.*s", (int)COLS, (int)COLS, text);   /* pad or cut */
    bytes_moved_ptr += (n - 1U) * sizeof(char *);
    bytes_if_copied += (n - 1U) * COLS;
}

static size_t storage_index(const char *p)
{
    for (size_t i = 0; i < ROWS; i++) {
        if (p == storage[i]) {
            return i;
        }
    }
    return ROWS;
}

static void lcd_show(char *const *row, size_t n)
{
    printf("  +----------------+   screen row -> buffer\n");
    for (size_t i = 0; i < n; i++) {
        printf("  |%s|   %zu -> storage[%zu]\n", row[i], i, storage_index(row[i]));
    }
    printf("  +----------------+\n");
}

int main(void)
{
    static const char *const log_lines[] = {
        "boot ok", "adc: 2048", "temp: 25.3 C", "uart: 115200", "wdt kicked",
        "ERROR: bus timeout 5",           /* longer than 16 columns: cut by snprintf */
    };

    lcd_init(rows, ROWS);
    for (size_t i = 0; i < sizeof log_lines / sizeof log_lines[0]; i++) {
        lcd_println(rows, ROWS, log_lines[i]);
        if (i == 3U || i == 5U) {
            printf("after message %zu (\"%s\"):\n", i + 1U, log_lines[i]);
            lcd_show(rows, ROWS);
        }
    }

    printf("scrolled %zu times\n", sizeof log_lines / sizeof log_lines[0]);
    printf("bytes moved by pointer rotation          : %zu (%zu with 4-byte Cortex-M pointers)\n",
           bytes_moved_ptr, bytes_moved_ptr / sizeof(char *) * 4U);
    printf("bytes a character-copy scroll would move : %zu\n", bytes_if_copied);
    return 0;
}
