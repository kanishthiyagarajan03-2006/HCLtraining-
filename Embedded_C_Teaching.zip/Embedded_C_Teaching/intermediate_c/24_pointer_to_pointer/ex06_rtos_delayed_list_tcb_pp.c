/*
 * ============================================================================
 *  Topic   : 24 Pointer to Pointer
 *  Example : 06 - RTOS delayed list: insert tasks sorted by wake time with TCB **
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : When a task calls delay(), the kernel links its TCB into a list sorted by
 *            wake-up tick. Inserting into (or removing from) the FRONT of a list changes
 *            the list head, so the functions take tcb_t **list and walk with a tcb_t **pp
 *            that always points at the link to be rewritten. The tick handler then only
 *            has to look at the head: the earliest wake time is always first.
 *  Embedded use : this is FreeRTOS' pxDelayedTaskList. vTaskDelay() ends in
 *            prvAddCurrentTaskToDelayedList() -> vListInsert(); xTaskIncrementTick()
 *            moves expired tasks from the head of that list back to the ready list.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_rtos_delayed_list_tcb_pp.c -o ex06
 *  Output  : the delayed list after each task blocks (sorted), then 60 ticks showing
 *            which tasks wake up and re-delay; equal wake times keep arrival order
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Give task A a period of 20 - who wakes first at tick 20, B or A?
 *            2) The wake time overflows after 2^32 ticks. Why does FreeRTOS keep TWO lists?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

typedef struct tcb {
    const char *name;
    uint32_t    period;          /* how long this task delays each cycle (ticks) */
    uint32_t    wake_tick;
    struct tcb *next;
} tcb_t;

static tcb_t *delayed_list;      /* head = task with the EARLIEST wake_tick */

/* Insert t so the list stays sorted. Equal wake times go after the existing ones (FIFO).
 * (Tick-counter overflow is ignored here; real kernels use a second "overflow" list.) */
static void delay_insert(tcb_t **list, tcb_t *t, uint32_t now, uint32_t ticks)
{
    t->wake_tick = now + ticks;
    tcb_t **pp = list;           /* address of the link we may have to rewrite */
    while (*pp != NULL && (*pp)->wake_tick <= t->wake_tick) {
        pp = &(*pp)->next;
    }
    t->next = *pp;               /* new node points at the first LATER task (or NULL) ... */
    *pp = t;                     /* ... and the link before it now points at the new node */
}

/* Called by the tick handler: unlink and return the head if its time has come. */
static tcb_t *delay_pop_expired(tcb_t **list, uint32_t now)
{
    tcb_t *t = *list;
    if (t == NULL || t->wake_tick > now) {
        return NULL;
    }
    *list = t->next;             /* the caller's head pointer moves to the next task */
    t->next = NULL;
    return t;
}

static void print_delayed(const char *title)
{
    printf("%s", title);
    for (const tcb_t *t = delayed_list; t != NULL; t = t->next) {
        printf(" %s(%u)", t->name, (unsigned)t->wake_tick);
    }
    printf("\n");
}

int main(void)
{
    tcb_t tasks[] = {
        { "A", 50U, 0U, NULL },
        { "B", 20U, 0U, NULL },
        { "C", 50U, 0U, NULL },
        { "D", 10U, 0U, NULL },
        { "E", 30U, 0U, NULL },
    };
    const size_t n = sizeof tasks / sizeof tasks[0];

    printf("tick 0: every task calls delay(period); list shows name(wake_tick)\n");
    for (size_t i = 0; i < n; i++) {
        delay_insert(&delayed_list, &tasks[i], 0U, tasks[i].period);
        printf("  after %s blocks:", tasks[i].name);
        print_delayed("");
    }

    printf("--- running 60 ticks ---\n");
    for (uint32_t tick = 1U; tick <= 60U; tick++) {
        tcb_t *t;
        while ((t = delay_pop_expired(&delayed_list, tick)) != NULL) {
            printf("tick %2u: %s wakes up (ready), does its work, delays %u more\n",
                   (unsigned)tick, t->name, (unsigned)t->period);
            delay_insert(&delayed_list, t, tick, t->period);   /* blocks again */
        }
    }
    print_delayed("still delayed at tick 60:");
    return 0;
}
