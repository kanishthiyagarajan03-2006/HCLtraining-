/*
 * ============================================================================
 *  Topic   : 19 Array of Array (2-D arrays)
 *  Example : 04 - Row-major memory layout, flat index math and transpose
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Memory is one-dimensional. C stores a[ROWS][COLS] ROW BY ROW ("row-major"):
 *            element [r][c] sits at byte offset (r * COLS + c) * sizeof(element).
 *            Each row a[r] is itself an array of COLS elements. Looping rows in the
 *            outer loop and columns in the inner loop walks memory in order.
 *  Embedded use : thermal-camera and touch-panel buffers are 2-D grids; DMA copies them as
 *            one flat block, and the index formula is how you address them from a
 *            flat buffer or convert between layouts.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_row_major_layout_transpose.c -o ex04
 *  Output  : a 3x4 grid with each element's byte offset, the flat-index check, and the
 *            4x3 transpose with a verification line
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a fourth row {130,...,133} and set ROWS to 4: which numbers change?
 *            2) Swap the loop order in print_layout(): are the offsets still increasing?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define ROWS 3U
#define COLS 4U

/* A 3x4 grid of 16-bit readings, e.g. thermal pixels in 0.1 degC. */
static const uint16_t grid[ROWS][COLS] = {
    { 100, 101, 102, 103 },
    { 110, 111, 112, 113 },
    { 120, 121, 122, 123 },
};

static void print_layout(void)
{
    const unsigned char *base = (const unsigned char *)grid;   /* byte view of the whole array */
    unsigned matches = 0U;
    for (unsigned r = 0; r < ROWS; r++) {                      /* outer = rows ...             */
        for (unsigned c = 0; c < COLS; c++) {                  /* ... inner = columns          */
            size_t offset = (size_t)((const unsigned char *)&grid[r][c] - base);
            printf("[%u][%u]=%3u @byte %2zu   ", r, c, (unsigned)grid[r][c], offset);
            matches += (offset == (r * COLS + c) * sizeof grid[0][0]);
        }
        putchar('\n');
    }
    printf("byte offset == (r * COLS + c) * sizeof(element) for %u of %u cells\n", matches,
           ROWS * COLS);
}

/* Transpose: element [r][c] of the source becomes [c][r] of the destination. */
static void transpose(const uint16_t src[ROWS][COLS], uint16_t dst[COLS][ROWS])
{
    for (unsigned r = 0; r < ROWS; r++)
        for (unsigned c = 0; c < COLS; c++)
            dst[c][r] = src[r][c];
}

int main(void)
{
    printf("sizeof(grid)=%zu  sizeof(grid[0])=%zu  sizeof(grid[0][0])=%zu  rows=%zu cols=%zu\n",
           sizeof grid, sizeof grid[0], sizeof grid[0][0], sizeof grid / sizeof grid[0],
           sizeof grid[0] / sizeof grid[0][0]);
    print_layout();

    /* Because the layout is row-major, the whole grid can be copied as ONE flat block
     * (this is what DMA does) and indexed with r * COLS + c.                        */
    uint16_t flat[ROWS * COLS];
    memcpy(flat, grid, sizeof flat);
    int same = 1;
    for (unsigned r = 0; r < ROWS; r++)
        for (unsigned c = 0; c < COLS; c++)
            if (flat[r * COLS + c] != grid[r][c]) same = 0;
    printf("flat[r*COLS+c] == grid[r][c] for every cell: %s\n", same ? "yes" : "NO!");

    uint16_t t[COLS][ROWS];
    transpose(grid, t);
    printf("transpose is %u x %u:\n", COLS, ROWS);
    for (unsigned r = 0; r < COLS; r++) {
        for (unsigned c = 0; c < ROWS; c++) printf("%4u", (unsigned)t[r][c]);
        putchar('\n');
    }
    int ok = (t[2][1] == grid[1][2]) && (t[3][0] == grid[0][3]);
    printf("t[2][1] == grid[1][2] and t[3][0] == grid[0][3]: %s\n", ok ? "yes" : "NO!");

#ifdef DEMO_BUG
    /* BUG: the column index is out of range. grid[1][4] is NOT "the first element of row 2"
     * as far as the compiler is concerned - it is an out-of-bounds access (undefined). */
    unsigned col = COLS;
    printf("grid[1][%u] = %u\n", col, (unsigned)grid[1][col]);
#endif
    return (same && ok) ? 0 : 1;
}
