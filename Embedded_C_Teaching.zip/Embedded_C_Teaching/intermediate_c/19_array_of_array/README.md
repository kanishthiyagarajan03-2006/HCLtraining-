# Topic 19 - Array of Array (2-D arrays)
**Suggested session:** 75 min | **Prerequisite topics:** 08 Control Loops, 10 Functions, 15 Arrays

Students should be able to declare, initialise and traverse `a[ROWS][COLS]`, explain that it is stored row by row in one contiguous block, and recognise the 2-D shapes that appear in real firmware: display frame buffers, keypad maps, state tables, fonts and schedule tables. The examples go from a display buffer, through lookup tables, to memory layout and finally to a table that drives an RTOS and a file loader on Linux.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_led_matrix_8x8.c` | MCU | `canvas[8][8]` drawn with nested loops, packed into `frame[8]` (a byte per row), row/column scan on two ports |
| 02 | `ex02_keypad_4x4_scan.c` | MCU | `const char keymap[4][4]` lookup, row-drive/column-read scan, multi-key presses rejected |
| 03 | `ex03_state_transition_table.c` | MCU | `next_state[state][event]` with enums and designated initialisers, range guards |
| 04 | `ex04_row_major_layout_transpose.c` | MCU | byte offset `(r*COLS+c)*sizeof`, `sizeof` of rows and cells, flat copy, transpose |
| 05 | `ex05_font_5x7_glyphs.c` | MCU | `font[glyph][5]` const table in flash, three-level loop that renders text |
| 06 | `ex06_oled_page_buffer.c` | MCU | `gfb[page][column]`, 8 vertical pixels per byte, pixel (x,y) to page and bit, clipping |
| 07 | `ex07_schedule_table_2d.c` | RTOS | `sched[task][period, prio, work]` with named columns, load report, tasks created from the table |
| 08 | `ex08_csv_to_2d_array.c` | LINUX | `fgets` + `strtol` into `int grid[R][C]` with bounds and format checks, temp-file cleanup |

## Teaching notes
* Begin on the board: draw the 3x4 grid, then draw the same 12 cells in one long strip. That strip is what the machine sees (ex04).
* The first index is the row (outer loop), the second is the column (inner loop). Swapping them still works but walks memory out of order.
* Ask: "what is `sizeof(a[0])`?" (one row). It is the easiest way to get the column count and it keeps working if the declaration changes.
* A table is data: ex03 and ex07 change behaviour by editing the table, not the code. Good place to introduce review and testing of tables.
* Out-of-range indexes are not caught by the compiler: ex02/ex06/ex08 each carry an explicit guard; ex04's DEMO_BUG shows UBSan reporting `grid[1][4]`.

## Live-demo tips
* ex01 and ex05 are visual: project the terminal and change a hex constant or a glyph byte live to see the picture change.
* ex04: compile with `-DDEMO_BUG -fsanitize=undefined` to see "index 4 out of bounds for type uint16_t [4]".
* ex07: edit one number in `sched[][]` (for example give LOGGER priority 5) and re-run to show preemption order change.
