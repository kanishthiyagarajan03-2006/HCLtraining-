/*
 * ============================================================================
 *  Topic   : 19 Array of Array (2-D arrays)
 *  Example : 07 - A task schedule table sched[task][period, priority, work]
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Rows are tasks, columns are properties. Named column indexes (an enum)
 *            make sched[i][COL_PERIOD] self-documenting. The same table drives task
 *            creation AND a CPU-utilisation report, so the numbers can never disagree.
 *  Embedded use : real-time design: list every periodic task with its period and
 *            worst-case run time, check total utilisation, then create the tasks
 *            from that one table (data-driven setup instead of copy-pasted code).
 *            Utilisation <= 100% is only a NECESSARY check for fixed priorities; the
 *            rate-monotonic bound for 3 tasks is ~78%, else do a response-time analysis.
 *  Real FreeRTOS: xTaskCreate(task_fn, names[i], 256, (void *)i, sched[i][COL_PRIO], NULL);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_schedule_table_2d.c -o ex07
 *  Output  : the schedule table with CPU load per task, then 400 ms of execution in which
 *            CONTROL and SENSOR run ahead of the slow LOGGER (SENSOR preempts it)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Raise LOGGER work from 30 to 90 ms - what does the total load become?
 *            2) Give LOGGER the highest priority: when does SENSOR's first job now finish?
 * ============================================================================
 */
#include "mini_rtos.h"

enum { COL_PERIOD_MS, COL_PRIO, COL_WORK_MS, N_COLS };       /* column names */
#define N_TASKS 3U

static const char *const task_names[N_TASKS] = { "SENSOR", "CONTROL", "LOGGER" };

/* one row per task:     period  prio  work
 * (priorities here follow importance, not rate-monotonic order)  */
static const uint16_t sched[N_TASKS][N_COLS] = {
    { 50U,  3U,  5U },       /* SENSOR : every  50 ms, runs  5 ms */
    { 100U, 4U, 20U },       /* CONTROL: every 100 ms, runs 20 ms (highest priority) */
    { 200U, 1U, 30U },       /* LOGGER : every 200 ms, runs 30 ms (lowest priority)  */
};

/* The task gets its ROW NUMBER (smuggled in the void *), not a copy of the values. */
static void periodic_task(void *arg)
{
    size_t row = (size_t)(uintptr_t)arg;
    uint32_t last_wake = 0U;                              /* all tasks are released at t = 0 */
    for (;;) {
        rtos_log("job starts (needs %u ms)", (unsigned)sched[row][COL_WORK_MS]);
        rtos_busy(sched[row][COL_WORK_MS]);               /* "do the job" (preemptible) */
        rtos_log("job done");
        rtos_delay_until(&last_wake, sched[row][COL_PERIOD_MS]);
    }
}

int main(void)
{
    /* Report: walk the 2-D table with nested loops, compute load = work / period. */
    printf("%-8s %9s %5s %7s %6s\n", "task", "period_ms", "prio", "work_ms", "load");
    unsigned total_load = 0U;
    for (size_t i = 0; i < N_TASKS; i++) {
        unsigned load = (unsigned)(100U * sched[i][COL_WORK_MS] / sched[i][COL_PERIOD_MS]);
        printf("%-8s %9u %5u %7u %5u%%\n", task_names[i], (unsigned)sched[i][COL_PERIOD_MS],
               (unsigned)sched[i][COL_PRIO], (unsigned)sched[i][COL_WORK_MS], load);
        total_load += load;
    }
    printf("total CPU load = %u%% (%s)\n\n", total_load,
           total_load <= 100U ? "not overloaded" : "OVERLOAD");

    /* Create every task from its row. */
    for (size_t i = 0; i < N_TASKS; i++)
        rtos_task_create(task_names[i], periodic_task, (void *)(uintptr_t)i,
                         (int)sched[i][COL_PRIO], 0);

    rtos_start(400);
    rtos_shutdown();
    return 0;
}
