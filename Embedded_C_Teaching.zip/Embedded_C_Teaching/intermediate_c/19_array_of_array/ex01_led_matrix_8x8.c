/*
 * ============================================================================
 *  Topic   : 19 Array of Array (2-D arrays)
 *  Example : 01 - 8x8 LED matrix: canvas[8][8] packed into frame[8] (one byte per row)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A 2-D array is an array whose elements are arrays: canvas[row][col].
 *            Two nested for-loops visit every element. We draw in an easy
 *            "one byte per pixel" canvas, then PACK each row of 8 bytes into one
 *            byte (one bit per LED) - the format the matrix hardware wants.
 *  Embedded use : 8x8 LED matrices (MAX7219, TM1640, direct GPIO scan) take 8 row
 *            bytes. The firmware sends/scans frame[0..7] to refresh the display.
 *  Real STM32F4 : GPIOA->ODR = (1U << row); GPIOB->ODR = frame[row];  // ~frame[] if common-anode
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_led_matrix_8x8.c -o ex01
 *  Output  : an ASCII picture of a box with a diagonal, its 8 hex row bytes, and
 *            the first three scan steps showing row-select and column-data ports
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Draw the other diagonal too (x = 7 - y).
 *            2) Make column 0 the LEAST significant bit in pack_rows() and
 *               predict how the hex bytes change.
 * ============================================================================
 */
#include <string.h>
#include "hw_sim.h"

#define ROWS 8U
#define COLS 8U

static uint8_t canvas[ROWS][COLS];      /* 64 bytes: 1 = lit pixel, easy to draw */
static uint8_t frame[ROWS];             /* 8 bytes : bit 7 = leftmost column      */

static void pixel_set(unsigned x, unsigned y)
{
    if (x < COLS && y < ROWS) canvas[y][x] = 1U;          /* [row][col] = [y][x] */
}

/* Pack: for every row, fold 8 pixel bytes into 1 byte, leftmost pixel -> bit 7. */
static void pack_rows(void)
{
    for (unsigned r = 0; r < ROWS; r++) {
        uint8_t bits = 0U;
        for (unsigned c = 0; c < COLS; c++) {
            if (canvas[r][c]) bits |= (uint8_t)(0x80U >> c);
        }
        frame[r] = bits;
    }
}

static void print_picture(void)
{
    for (unsigned r = 0; r < ROWS; r++) {
        for (unsigned c = 0; c < COLS; c++) putchar(canvas[r][c] ? '#' : '.');
        printf("   row %u = 0x%02X\n", r, (unsigned)frame[r]);
    }
}

int main(void)
{
    memset(canvas, 0, sizeof canvas);          /* sizeof works on the whole 2-D array */
    printf("canvas is %zu bytes = %u rows x %u cols; one row is %zu bytes\n", sizeof canvas,
           ROWS, COLS, sizeof canvas[0]);

    /* Draw a border box and a diagonal using the nested-index form canvas[y][x]. */
    for (unsigned i = 0; i < 8U; i++) {
        pixel_set(i, 0U);                      /* top edge    */
        pixel_set(i, 7U);                      /* bottom edge */
        pixel_set(0U, i);                      /* left edge   */
        pixel_set(7U, i);                      /* right edge  */
        pixel_set(i, i);                       /* diagonal    */
    }
    pixel_set(9U, 9U);                         /* out of range: silently ignored by the guard */

    pack_rows();
    print_picture();

    /* Scanning: each refresh step selects ONE row and puts its byte on the column port. */
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN;
    GPIOA->MODER = 0x00005555U;                /* PA0..PA7 outputs: row select */
    GPIOB->MODER = 0x00005555U;                /* PB0..PB7 outputs: column data */
    for (unsigned r = 0; r < 3U; r++) {        /* real firmware loops over all 8 rows */
        GPIOA->ODR = 1U << r;
        GPIOB->ODR = frame[r];
        printf("scan row %u: ", r);
        sim_show_port("GPIOA(row)", GPIOA);
        printf("            ");
        sim_show_port("GPIOB(col)", GPIOB);
        sim_delay_ms(1U);                      /* ~1 ms per row = 125 Hz refresh */
    }
    return 0;
}
