/*
 * ============================================================================
 *  Topic   : 19 Array of Array (2-D arrays)
 *  Example : 08 - Load a small CSV file into int grid[ROWS][COLS] (with bounds checks)
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Text data arrives as lines and fields; a 2-D array stores it as rows and
 *            columns. fgets reads a line, strtol walks its numbers. Because the
 *            array has FIXED size, every row and column index is checked before it
 *            is written - bad input is rejected, never allowed to overflow.
 *  Embedded use : embedded Linux gateways load calibration tables, lookup curves or sensor
 *            logs from CSV files in /etc or /var. Same loader pattern, any table.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex08_csv_to_2d_array.c -o ex08
 *  Output  : the file is created in a temp directory, parsed into a 2-D array, printed,
 *            row sums and column maxima are computed; a too-wide line is rejected
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change MAX_COLS to 4 - which lines are rejected now?
 *            2) Add a per-row average column to the printout.
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_ROWS 6U
#define MAX_COLS 5U

static int grid[MAX_ROWS][MAX_COLS];

/* Parse one CSV line into grid[row][...]. Returns the column count, -1 for a bad number,
 * -2 for a line wider than the array.                                                  */
static int parse_line(const char *line, size_t row)
{
    size_t col = 0U;
    const char *p = line;
    while (*p != '\0' && *p != '\n') {
        char *end = NULL;
        errno = 0;
        long v = strtol(p, &end, 10);                /* end = first char after the number */
        if (end == p || errno != 0) return -1;       /* no digits found, or out of range */
        if (col >= MAX_COLS) return -2;              /* too many columns for the array  */
        grid[row][col++] = (int)v;
        p = end;
        if (*p == ',') p++;                          /* skip the separator */
    }
    return (int)col;
}

int main(void)
{
    /* 1) Create a temp directory and a CSV file inside it (never touch the source tree). */
    char dir[] = "/tmp/csv2d_XXXXXX";
    if (mkdtemp(dir) == NULL) { perror("mkdtemp"); return 1; }
    char path[64];
    snprintf(path, sizeof path, "%s/samples.csv", dir);

    FILE *f = fopen(path, "w");
    if (f == NULL) { perror("fopen"); rmdir(dir); return 1; }
    fputs("21,22,23,24,25\n"
          "30,31,29,28,27\n"
          "9,9,9,9,9,9,9\n"                /* 7 columns: too wide for COLS=5 */
          "40,-41,42,43,44\n"
          "50,51,x2,53,54\n"               /* bad number */
          "60,61,62,63,64\n", f);
    fclose(f);

    /* 2) Read it back line by line into the 2-D array. */
    f = fopen(path, "r");
    if (f == NULL) { perror("fopen"); unlink(path); rmdir(dir); return 1; }
    char line[80];
    size_t rows = 0U, lineno = 0U;
    int cols_seen = 0;
    while (fgets(line, sizeof line, f) != NULL) {
        lineno++;
        if (rows >= MAX_ROWS) { printf("line %zu: grid full, ignored\n", lineno); continue; }
        int n = parse_line(line, rows);
        if (n == -1) {
            printf("line %zu: rejected, not a number\n", lineno);
            continue;
        }
        if (n == -2) {
            printf("line %zu: rejected, more than %u columns\n", lineno, MAX_COLS);
            continue;
        }
        if (n != (int)MAX_COLS) {
            printf("line %zu: expected %u columns\n", lineno, MAX_COLS);
            continue;
        }
        cols_seen = n;
        rows++;
    }
    fclose(f);
    unlink(path);                                    /* always clean up what we created */
    rmdir(dir);

    /* 3) Use the table: print, row sums, column maxima. */
    printf("loaded %zu rows x %d cols\n", rows, cols_seen);
    for (size_t r = 0; r < rows; r++) {
        int sum = 0;
        for (size_t c = 0; c < MAX_COLS; c++) {
            printf("%5d", grid[r][c]);
            sum += grid[r][c];
        }
        printf("   | sum %d\n", sum);
    }
    printf("max per column:");
    for (size_t c = 0; c < MAX_COLS; c++) {
        int hi = grid[0][c];
        for (size_t r = 1; r < rows; r++)
            if (grid[r][c] > hi) hi = grid[r][c];
        printf(" %d", hi);
    }
    putchar('\n');
    return 0;
}
