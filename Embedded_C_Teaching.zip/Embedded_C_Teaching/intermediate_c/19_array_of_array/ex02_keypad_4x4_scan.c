/*
 * ============================================================================
 *  Topic   : 19 Array of Array (2-D arrays)
 *  Example : 02 - 4x4 keypad: keymap[row][col] turns a scan position into a character
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A const 2-D array is a lookup table indexed by two numbers. The row/col
 *            where a contact is found picks the key: keymap[row][col]. A nested
 *            loop (outer = rows, inner = columns) is the natural way to scan it.
 *  Embedded use : a matrix keypad needs only 4+4 GPIO pins for 16 keys. Firmware drives
 *            one row at a time and reads the 4 column pins; the table is stored in flash.
 *  Real STM32F4 : GPIOA->ODR = ~(1U << row);  cols = ~GPIOB->IDR & 0x0FU;
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_keypad_4x4_scan.c -o ex02
 *  Output  : for each key in the test string, the (row,col) found by the scan and the
 *            character looked up; two simultaneous keys are rejected with '?'
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Swap the '*' and '#' keys in keymap - nothing else needs to change.
 *            2) Make scan_keypad() return the number of keys held down.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define KP_ROWS 4U
#define KP_COLS 4U

static const char keymap[KP_ROWS][KP_COLS] = {      /* const: stays in flash */
    { '1', '2', '3', 'A' },
    { '4', '5', '6', 'B' },
    { '7', '8', '9', 'C' },
    { '*', '0', '#', 'D' },
};

/* ---- the "hardware": which switches are closed (set by the test, not by the code) ---- */
static uint8_t contact[KP_ROWS][KP_COLS];

/* Real silicon: drive one row, read the column pins. Here: look in the contact array. */
static uint8_t read_columns(unsigned driven_row)
{
    uint8_t cols = 0U;
    for (unsigned c = 0; c < KP_COLS; c++)
        if (contact[driven_row][c]) cols |= (uint8_t)(1U << c);
    return cols;
}

/* Scan all rows. Returns the key character, 0 for none, '?' for more than one key. */
static char scan_keypad(unsigned *row_out, unsigned *col_out)
{
    char key = '\0';
    unsigned keys_down = 0U;
    for (unsigned r = 0; r < KP_ROWS; r++) {              /* drive row r ...            */
        uint8_t cols = read_columns(r);                   /* ... and read the columns   */
        for (unsigned c = 0; c < KP_COLS; c++) {
            if (cols & (1U << c)) {
                key = keymap[r][c];                       /* 2-D table lookup           */
                *row_out = r;
                *col_out = c;
                keys_down++;
            }
        }
    }
    return (keys_down > 1U) ? '?' : key;
}

/* Test helper: close the contact for a given character by searching the table. */
static int press(char ch, int down)
{
    for (unsigned r = 0; r < KP_ROWS; r++)
        for (unsigned c = 0; c < KP_COLS; c++)
            if (keymap[r][c] == ch) { contact[r][c] = (uint8_t)down; return 0; }
    return -1;                                            /* not on this keypad */
}

int main(void)
{
    const char *typed = "1A9*0#D";                        /* the user's finger sequence */
    printf("keymap uses %zu bytes of flash\n", sizeof keymap);

    for (const char *p = typed; *p != '\0'; p++) {
        unsigned r = 0U, c = 0U;
        press(*p, 1);
        char k = scan_keypad(&r, &c);
        printf("pressed '%c' -> scan found row %u, col %u -> key '%c' %s\n", *p, r, c, k,
               (k == *p) ? "OK" : "MISMATCH");
        press(*p, 0);                                     /* release before the next key */
    }

    /* Two keys at once: this simple driver just refuses them ('?'). With 3 or more keys
     * a diode-less matrix can also show phantom "ghost" keys, so refusing is the safe policy. */
    unsigned r = 0U, c = 0U;
    press('5', 1);
    press('8', 1);
    printf("'5' and '8' together -> scan_keypad returns '%c' (more than one key, ignore it)\n",
           scan_keypad(&r, &c));
    press('5', 0);
    press('8', 0);

    printf("nothing pressed -> scan_keypad returns code %d\n", (int)scan_keypad(&r, &c));
    printf("press('Z') on this keypad returns %d (no such key)\n", press('Z', 1));
    return 0;
}
