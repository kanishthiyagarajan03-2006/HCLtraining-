/*
 * ============================================================================
 *  Topic   : 19 Array of Array (2-D arrays)
 *  Example : 03 - A state machine driven by a 2-D transition table next[state][event]
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Enums give the rows (states) and columns (events) readable names; the table
 *            cell next[state][event] holds the NEXT state. Replacing a big
 *            switch-in-switch with one table lookup makes the behaviour data, easy to
 *            review. Write EVERY cell: an omitted cell silently becomes 0 (= ST_STOPPED).
 *  Embedded use : motor controllers, button handlers, UART protocol parsers and
 *            bootloaders are all state machines; a table keeps them small and testable.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_state_transition_table.c -o ex03
 *  Output  : the table is printed as a grid, then ten events drive the motor through
 *            STOPPED / RUNNING / FAULT with each transition listed
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add an EV_JOG event column that goes from STOPPED to RUNNING only.
 *            2) What happens if the table has a bad cell? (Look at the range guard.)
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

typedef enum { ST_STOPPED, ST_RUNNING, ST_FAULT, ST_COUNT } state_t;
typedef enum { EV_START, EV_STOP, EV_OVERCURRENT, EV_RESET, EV_COUNT } event_t;

static const char *const state_name[ST_COUNT] = { "STOPPED", "RUNNING", "FAULT" };
static const char *const event_name[EV_COUNT] = { "START", "STOP", "OVERCURRENT", "RESET" };

/* Rows = current state, columns = event. Designated initialisers make it readable.
 * Every cell is written explicitly, so "nothing happens" is a decision, not an accident. */
static const uint8_t next_state[ST_COUNT][EV_COUNT] = {
    [ST_STOPPED] = { [EV_START] = ST_RUNNING, [EV_STOP] = ST_STOPPED,
                     [EV_OVERCURRENT] = ST_FAULT, [EV_RESET] = ST_STOPPED },
    [ST_RUNNING] = { [EV_START] = ST_RUNNING, [EV_STOP] = ST_STOPPED,
                     [EV_OVERCURRENT] = ST_FAULT, [EV_RESET] = ST_RUNNING },
    [ST_FAULT]   = { [EV_START] = ST_FAULT,   [EV_STOP] = ST_FAULT,
                     [EV_OVERCURRENT] = ST_FAULT, [EV_RESET] = ST_STOPPED },
};

/* Static check: the table really has one row per state. */
_Static_assert(sizeof next_state / sizeof next_state[0] == ST_COUNT, "row count mismatch");

static state_t dispatch(state_t s, event_t e)
{
    if ((unsigned)s >= ST_COUNT || (unsigned)e >= EV_COUNT) return ST_FAULT;  /* guard */
    state_t n = (state_t)next_state[s][e];                /* the whole machine in one line */
    if ((unsigned)n >= ST_COUNT) return ST_FAULT;         /* corrupted table cell */
    return n;
}

int main(void)
{
    /* Print the table as a grid: it IS the specification. */
    printf("%-9s", "state");
    for (unsigned e = 0; e < EV_COUNT; e++) printf(" %-12s", event_name[e]);
    putchar('\n');
    for (unsigned s = 0; s < ST_COUNT; s++) {
        printf("%-9s", state_name[s]);
        for (unsigned e = 0; e < EV_COUNT; e++) printf(" %-12s", state_name[next_state[s][e]]);
        putchar('\n');
    }
    printf("(table size: %zu bytes)\n\n", sizeof next_state);

    /* Drive the machine with a fixed event sequence (buttons / current sensor / reset). */
    static const event_t script[] = {
        EV_START, EV_START, EV_STOP, EV_START, EV_OVERCURRENT,
        EV_START, EV_STOP, EV_RESET, EV_START, EV_STOP,
    };
    state_t s = ST_STOPPED;
    for (unsigned i = 0; i < sizeof script / sizeof script[0]; i++) {
        state_t n = dispatch(s, script[i]);
        printf("step %2u: %-8s --%-11s--> %-8s%s\n", i + 1U, state_name[s],
               event_name[script[i]], state_name[n], (n == s) ? "  (no change)" : "");
        s = n;
    }

    printf("dispatch with a bad event number lands in: %s\n",
           state_name[dispatch(ST_RUNNING, (event_t)99)]);
    return 0;
}
