/*
 * ============================================================================
 *  Topic   : 19 Array of Array (2-D arrays)
 *  Example : 06 - OLED page buffer: gfb[page][column], 8 vertical pixels per byte
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Some displays are not "one byte per pixel". An SSD1306 OLED is organised in
 *            PAGES: page p is a strip 8 pixels tall, and each byte holds 8 vertical
 *            pixels of one column. So pixel (x, y) is bit (y % 8) of gfb[y / 8][x].
 *            The 2-D array shape mirrors the hardware: [pages][columns].
 *  Embedded use : a 128x64 OLED needs only 8 x 128 = 1024 bytes of RAM, not 8192. The driver
 *            sends the buffer page by page over I2C/SPI.
 *  Real STM32F4 : ssd1306 driver: for each page { send(0xB0 + page); send(row data[128]); }
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_oled_page_buffer.c -o ex06
 *  Output  : a 32x16 mini-screen (2 pages x 32 columns) with a frame, a diagonal line and
 *            a filled box, followed by the raw bytes of page 0 as an I2C burst
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Draw a pixel at (16, 9): which byte of which page changes, and which bit?
 *            2) Change PAGES to 4 (HEIGHT follows): how tall is the frame, how big is gfb?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define WIDTH   32U
#define PAGES   2U
#define HEIGHT  (PAGES * 8U)

static uint8_t gfb[PAGES][WIDTH];             /* PAGES*WIDTH bytes = 64 bytes for 512 pixels */

static void pixel_set(unsigned x, unsigned y)
{
    if (x >= WIDTH || y >= HEIGHT) return;                /* clip: ignore off-screen pixels */
    gfb[y / 8U][x] |= (uint8_t)(1U << (y % 8U));          /* page = y/8, bit = y%8          */
}

static int pixel_get(unsigned x, unsigned y)
{
    if (x >= WIDTH || y >= HEIGHT) return 0;
    return (gfb[y / 8U][x] >> (y % 8U)) & 1U;
}

static void draw_hline(unsigned x0, unsigned x1, unsigned y)
{
    for (unsigned x = x0; x <= x1; x++) pixel_set(x, y);
}

static void draw_vline(unsigned x, unsigned y0, unsigned y1)
{
    for (unsigned y = y0; y <= y1; y++) pixel_set(x, y);
}

static void fill_rect(unsigned x0, unsigned y0, unsigned w, unsigned h)
{
    for (unsigned y = y0; y < y0 + h; y++)
        for (unsigned x = x0; x < x0 + w; x++) pixel_set(x, y);
}

static void show(void)
{
    printf("+");
    for (unsigned x = 0; x < WIDTH; x++) putchar('-');
    printf("+\n");
    for (unsigned y = 0; y < HEIGHT; y++) {               /* rows top to bottom */
        putchar('|');
        for (unsigned x = 0; x < WIDTH; x++) putchar(pixel_get(x, y) ? '#' : ' ');
        printf("|\n");
    }
    printf("+");
    for (unsigned x = 0; x < WIDTH; x++) putchar('-');
    printf("+\n");
}

int main(void)
{
    memset(gfb, 0, sizeof gfb);                           /* clear screen */
    draw_hline(0U, WIDTH - 1U, 0U);                       /* frame */
    draw_hline(0U, WIDTH - 1U, HEIGHT - 1U);
    draw_vline(0U, 0U, HEIGHT - 1U);
    draw_vline(WIDTH - 1U, 0U, HEIGHT - 1U);
    for (unsigned i = 0; i < HEIGHT; i++) pixel_set(2U + i, i);   /* diagonal line */
    fill_rect(22U, 5U, 6U, 6U);                           /* box crossing the page boundary */
    pixel_set(100U, 100U);                                /* off-screen: clipped, no overflow */

    show();

    printf("pixel (3,3) is on page %u, bit %u; pixel (3,12) is on page %u, bit %u\n",
           3U / 8U, 3U % 8U, 12U / 8U, 12U % 8U);
    printf("sizeof(gfb) = %zu bytes; one page = %zu bytes\n", sizeof gfb, sizeof gfb[0]);

    /* What the driver would clock out over I2C for page 0 (first 12 columns). */
    printf("page 0, columns 0..11 (bit 0 = top pixel):");
    for (unsigned x = 0; x < 12U; x++) printf(" %02X", (unsigned)gfb[0][x]);
    putchar('\n');
    return 0;
}
