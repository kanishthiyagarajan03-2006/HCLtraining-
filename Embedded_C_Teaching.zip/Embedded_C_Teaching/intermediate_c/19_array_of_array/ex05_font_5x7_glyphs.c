/*
 * ============================================================================
 *  Topic   : 19 Array of Array (2-D arrays)
 *  Example : 05 - 5x7 dot-matrix font: a const table font[glyph][5 columns]
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A 2-D array of bytes is a compact font: font[g] is glyph g, font[g][col]
 *            is one column of 7 pixels (bit 0 = top row). Rendering text means
 *            three nested loops: pixel row, character, column.
 *  Embedded use : LCD/OLED/LED-matrix text without a graphics library. The font is 'const'
 *            so it stays in flash (5 bytes per character instead of a bitmap in RAM).
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_font_5x7_glyphs.c -o ex05
 *  Output  : the words "HELLO" and "MCU 25" drawn in big ASCII-art letters, plus the flash
 *            cost of the font table
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add the glyph for 'A' (0x7E,0x11,0x11,0x11,0x7E) and print "HELLO A".
 *            2) Print the pixels with the top row at bit 6 instead (flip the shift).
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define GLYPH_W 5U
#define GLYPH_H 7U

/* Two parallel tables: the characters we support, and one 5-byte glyph for each. */
static const char font_chars[] = " HELOMCU2501";
static const uint8_t font[][GLYPH_W] = {
    { 0x00, 0x00, 0x00, 0x00, 0x00 },     /* ' ' */
    { 0x7F, 0x08, 0x08, 0x08, 0x7F },     /* 'H' */
    { 0x7F, 0x49, 0x49, 0x49, 0x41 },     /* 'E' */
    { 0x7F, 0x40, 0x40, 0x40, 0x40 },     /* 'L' */
    { 0x3E, 0x41, 0x41, 0x41, 0x3E },     /* 'O' */
    { 0x7F, 0x02, 0x0C, 0x02, 0x7F },     /* 'M' */
    { 0x3E, 0x41, 0x41, 0x41, 0x22 },     /* 'C' */
    { 0x3F, 0x40, 0x40, 0x40, 0x3F },     /* 'U' */
    { 0x42, 0x61, 0x51, 0x49, 0x46 },     /* '2' */
    { 0x3E, 0x51, 0x49, 0x45, 0x3E },     /* '0' */
    { 0x27, 0x45, 0x45, 0x45, 0x39 },     /* '5' */
    { 0x00, 0x42, 0x7F, 0x40, 0x00 },     /* '1' */
};

#define N_GLYPHS (sizeof font / sizeof font[0])
_Static_assert(sizeof font_chars - 1U == N_GLYPHS, "font_chars and font[] must match");

/* Look up the glyph row for a character; unknown characters become a blank. */
static const uint8_t *glyph_for(char ch)
{
    const char *hit = strchr(font_chars, ch);
    if (ch == '\0' || hit == NULL) return font[0];
    return font[hit - font_chars];                  /* index = position in font_chars */
}

static void draw_text(const char *text)
{
    for (unsigned row = 0; row < GLYPH_H; row++) {              /* 1) each pixel row      */
        for (const char *p = text; *p != '\0'; p++) {           /* 2) each character      */
            const uint8_t *g = glyph_for(*p);
            for (unsigned col = 0; col < GLYPH_W; col++)        /* 3) each glyph column   */
                putchar(((g[col] >> row) & 1U) ? '#' : ' ');
            putchar(' ');                                       /* 1-pixel letter gap     */
        }
        putchar('\n');
    }
}

int main(void)
{
    printf("font table: %zu glyphs x %u bytes = %zu bytes of flash\n", N_GLYPHS, GLYPH_W,
           sizeof font);
    draw_text("HELLO");
    putchar('\n');
    draw_text("MCU 25");
    putchar('\n');

    /* A character that is not in the table falls back to a blank glyph. */
    printf("glyph for '?' is blank: %s\n",
           (glyph_for('?')[0] == 0U && glyph_for('?')[2] == 0U) ? "yes" : "no");
    return 0;
}
