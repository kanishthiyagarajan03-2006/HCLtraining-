# Topic 21 - Call by Value vs Call by Address
**Suggested session:** 60 min | **Prerequisite topics:** 10 Functions, 15 Arrays, 17 Pointers

Students should leave knowing that C passes every argument by value (a copy), and that "call by address" simply means
passing a pointer by value so the callee can reach the caller's object. The examples start with a classic swap, move to
hardware-style APIs (register block, config struct, status + data out-parameter), then show the cost of copying big
structs, the RTOS `void *arg` lifetime trap, and finally Linux system calls that fill the caller's variables.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_swap_value_vs_address.c` | MCU | Swapping PWM duties: a by-value swap changes only copies, `swap(&a, &b)` works; NULL check |
| 02 | `ex02_gpio_init_register_block.c` | MCU | `gpio_init(GPIO_TypeDef *, const cfg *)`: a register block passed by value configures a throw-away copy; config by value vs by pointer |
| 03 | `ex03_adc_read_out_param.c` | MCU | `status = adc_read(&value)`: return status, deliver data through an out-parameter, do not touch `*out` on failure |
| 04 | `ex04_big_struct_value_vs_pointer.c` | MCU | `sizeof` cost of passing a 52-byte frame by value, `const T *` vs `T *const`, callee editing its own copy |
| 05 | `ex05_rtos_arg_value_vs_ptr.c` | RTOS | Task `void *arg` carrying a value vs pointing at a shared struct that another task edits; dangling local (`DEMO_BUG`) |
| 06 | `ex06_linux_pipe_read_wait_outparams.c` | LINUX | `pipe(fds)`, `read(fd, buf, n)`, `waitpid(pid, &status, 0)`: the kernel writes into your variables |

## Teaching notes
* Say it plainly: C has only call by value. `&x` is a value (an address) that gets copied; what the callee can do with it is the difference.
* Ask: "why does `scanf("%d", &x)` need the `&` but `printf("%d", x)` does not?" Link it to the swap.
* Out-parameter conventions worth drilling: check for `NULL`, return a status, and leave `*out` untouched when the call fails (ex03).
* `const` on a pointer parameter is documentation the compiler enforces ("I only read this"); contrast `const T *p` with `T *const p` (ex04).
* RTOS tasks live longer than the function that creates them. A pointer to a local variable of the creator is a time bomb; use static (or heap) storage (ex05). A local in `main()` happens to survive on this PC demo, but on a real Cortex-M FreeRTOS port starting the scheduler discards `main`'s stack frame, so do not rely on it.
* Common mistake: expecting `p = something;` inside a function to change the caller's pointer. That needs a pointer to pointer (topic 24).

## Live-demo tips
* ex04: `gcc -DDEMO_BUG ...` shows the two compile errors the `const` qualifiers produce.
* ex05: `gcc -DDEMO_BUG -fsanitize=address -I../../common ...` makes AddressSanitizer report `stack-use-after-return` for the dangling task argument.
* ex02: print `sizeof(GPIO_TypeDef)` first; students see why nobody passes a register block by value.
