/*
 * ============================================================================
 *  Topic   : 21 Call by Value vs Call by Address
 *  Example : 02 - gpio_init(GPIO_TypeDef *, const cfg *): why HAL takes pointers
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A peripheral is a block of registers at ONE fixed address. A function
 *            must receive that address to touch the hardware: pass the register
 *            block by value and you configure a throw-away copy. A small config
 *            struct can go by value (callee edits its own copy) or by pointer
 *            (callee edits the caller's struct, e.g. to clamp a bad pin number).
 *  Embedded use : GPIO/UART/SPI drivers are all "pointer to peripheral" + "pointer
 *            to config". Marking the config pointer const says "I only read it".
 *  Real STM32F4 : HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_gpio_init_register_block.c -o ex02
 *  Output  : MODER stays 0 after the by-value call, becomes 0x00000400 after the
 *            pointer call; an out-of-range pin is clamped in the caller's struct
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Make gpio_init() take cfg by value - does the program still work? Why?
 *            2) Remove const from cfg and write cfg->pin = 0; in gpio_init(). What changes?
 * ============================================================================
 */
#include "hw_sim.h"

enum { MODE_INPUT = 0, MODE_OUTPUT = 1 };

typedef struct {
    uint8_t pin;        /* 0..15 */
    uint8_t mode;       /* MODE_INPUT / MODE_OUTPUT */
} gpio_cfg_t;

/* WRONG: "port" is a copy of all 40 bytes of the register block.
 * The write lands in the copy, which vanishes when the function returns.   */
static void gpio_init_on_copy(GPIO_TypeDef port, const gpio_cfg_t *cfg)
{
    port.MODER &= ~(3U << (cfg->pin * 2U));
    port.MODER |= ((uint32_t)cfg->mode << (cfg->pin * 2U));
}

/* RIGHT: the pointer designates the real hardware; cfg is read-only input. */
static void gpio_init(GPIO_TypeDef *port, const gpio_cfg_t *cfg)
{
    port->MODER &= ~(3U << (cfg->pin * 2U));
    port->MODER |= ((uint32_t)cfg->mode << (cfg->pin * 2U));
}

/* By value: the callee may tidy up its OWN copy; the caller never sees it. */
static uint8_t pin_clamped_copy(gpio_cfg_t cfg)
{
    if (cfg.pin > 15U) {
        cfg.pin = 15U;
    }
    return cfg.pin;
}

/* By pointer: the fix is written back into the caller's struct. */
static void cfg_validate(gpio_cfg_t *cfg)
{
    if (cfg->pin > 15U) {
        cfg->pin = 15U;
    }
}

static void show_moder(const char *label)
{
    printf("%-26s GPIOA.MODER = 0x%08X\n", label, (unsigned)GPIOA->MODER);
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    printf("sizeof(GPIO_TypeDef) = %zu bytes (copied on every by-value call!)\n",
           sizeof(GPIO_TypeDef));
    show_moder("simulated start value:");     /* real GPIOA resets to 0xA8000000 (SWD pins) */

    gpio_cfg_t led = { 5U, MODE_OUTPUT };           /* PA5 as output */

    gpio_init_on_copy(*GPIOA, &led);                /* *GPIOA = the whole struct, copied */
    show_moder("after init on a COPY:");

    gpio_init(GPIOA, &led);                         /* GPIOA = address of the real ports */
    show_moder("after init via pointer:");

    gpio_cfg_t bad = { 99U, MODE_OUTPUT };          /* typo in the configuration */
    uint8_t fixed = pin_clamped_copy(bad);
    printf("pin_clamped_copy returned %u, caller's bad.pin is still %u\n",
           (unsigned)fixed, (unsigned)bad.pin);
    cfg_validate(&bad);
    printf("cfg_validate(&bad)  made  bad.pin = %u\n", (unsigned)bad.pin);
    return 0;
}
