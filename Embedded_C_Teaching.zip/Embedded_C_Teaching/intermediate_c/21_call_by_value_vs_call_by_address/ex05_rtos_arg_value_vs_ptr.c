/*
 * ============================================================================
 *  Topic   : 21 Call by Value vs Call by Address
 *  Example : 05 - RTOS task argument: a value in the void* or a pointer to shared data
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A task receives ONE void *arg. Either the number itself is packed into
 *            the pointer (call by value: a private snapshot) or arg points at a
 *            struct (call by address: owner and task see the SAME memory). The
 *            pointed-to object must outlive the task: never point at a local
 *            variable of a function that returns before the task has run.
 *  Embedded use : xTaskCreate(fn, "name", stack, pvParameters, prio, &handle)
 *            - pvParameters is exactly this void *arg. Config structs normally
 *            live in static storage so the pointer stays valid forever.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_rtos_arg_value_vs_ptr.c -o ex05
 *  Output  : the by-value task keeps its 200 ms period; the by-pointer task switches to
 *            50 ms at its next wake-up after the tuner edits the shared struct (t=250 ms)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Make "tuner" change period_ms at t=100 ms - who notices, and when?
 *            2) Build with -DDEMO_BUG to see a task given a pointer to a dead local.
 * ============================================================================
 */
#include "mini_rtos.h"

typedef struct {
    uint32_t period_ms;
    uint32_t blinks;
} blink_cfg_t;

static blink_cfg_t shared_cfg = { 200U, 5U };     /* static: lives for the whole program */

/* arg carries the PERIOD ITSELF. uintptr_t is as wide as a pointer, so the cast never truncates
 * (it works on every common ABI, but it is a convention, not guaranteed by the C standard). */
static void task_by_value(void *arg)
{
    uint32_t period = (uint32_t)(uintptr_t)arg;   /* private copy, nobody can change it */
    for (int i = 0; i < 5; i++) {
        rtos_log("by-value   blink %d, period=%u ms (private copy)", i, (unsigned)period);
        rtos_delay(period);
    }
}

/* arg points at a struct that somebody else owns: we read it LIVE on each loop. */
static void task_by_pointer(void *arg)
{
    const blink_cfg_t *cfg = (const blink_cfg_t *)arg;   /* read-only view */
    for (uint32_t i = 0; i < cfg->blinks; i++) {
        rtos_log("by-pointer blink %u, period=%u ms (live shared struct)", (unsigned)i,
                 (unsigned)cfg->period_ms);
        rtos_delay(cfg->period_ms);
    }
}

/* Same pointer type, but non-const: this task may WRITE through it. */
static void task_tuner(void *arg)
{
    blink_cfg_t *cfg = (blink_cfg_t *)arg;
    rtos_delay(250U);
    cfg->period_ms = 50U;
    rtos_log("tuner      wrote period_ms = 50 into the shared struct");
}

#ifdef DEMO_BUG
/* BUG: "local" is destroyed when spawn_dangling() returns, but the task starts later
 * and reads that dead stack slot (use-after-return: garbage period or a crash). */
static void spawn_dangling(void)
{
    blink_cfg_t local = { 100U, 2U };
    rtos_task_create("dangling", task_by_pointer, &local, 1, 0U);
}
#endif

int main(void)
{
    /* Copy the current period into the pointer value. Changing shared_cfg later
     * does not affect this task: it already has its own number. */
    rtos_task_create("val_task", task_by_value, (void *)(uintptr_t)shared_cfg.period_ms, 1, 0U);
    rtos_task_create("ptr_task", task_by_pointer, &shared_cfg, 1, 0U);
    rtos_task_create("tuner", task_tuner, &shared_cfg, 2, 0U);
#ifdef DEMO_BUG
    spawn_dangling();
#endif

    rtos_start(1500U);
    rtos_shutdown();
    return 0;
}
