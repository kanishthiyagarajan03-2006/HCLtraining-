/*
 * ============================================================================
 *  Topic   : 21 Call by Value vs Call by Address
 *  Example : 03 - Returning status AND data: adc_read(uint16_t *out)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A C function returns only ONE value. When it must hand back a status
 *            code plus a result (or several results), the result travels through
 *            an OUT-PARAMETER: the caller passes the address of its variable and
 *            the callee writes through it. Check for NULL, and do not touch *out
 *            when the call fails.
 *  Embedded use : "status = driver_read(&value)" is the standard shape of HAL and
 *            RTOS APIs, so a timeout can be told apart from a valid reading of 0.
 *  Real STM32F4 : HAL_StatusTypeDef HAL_ADC_PollForConversion(&hadc1, timeout);
 *                 uint32_t v = HAL_ADC_GetValue(&hadc1);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_adc_read_out_param.c -o ex03
 *  Output  : three good readings, then a timeout that leaves the caller's value
 *            untouched, then min/max/average returned through three out-params
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Make adc_read() store 0 into *out on timeout: which output line changes,
 *               and why is that worse than leaving *out alone?
 *            2) Change adc_read_stats() to also return the number of valid samples.
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

/* ---- fake ADC peripheral (file-local registers, no real hardware) -------- */
#define ADC_SR_EOC (1U << 1)                /* end-of-conversion flag */
static volatile uint32_t FAKE_ADC_SR;       /* status register  */
static volatile uint32_t FAKE_ADC_DR;       /* 12-bit data register */

static const uint16_t feed[] = { 1500, 2048, 4095, 300, 2700, 1200 };
static size_t feed_pos;

/* On real silicon the ADC does this by itself after SWSTART. */
static int fake_adc_start_conversion(void)
{
    if (feed_pos >= sizeof feed / sizeof feed[0]) {
        return 0;                           /* input dried up: EOC never comes */
    }
    FAKE_ADC_DR = feed[feed_pos++];
    FAKE_ADC_SR |= ADC_SR_EOC;
    return 1;
}

typedef enum { ADC_OK = 0, ADC_ERR_TIMEOUT, ADC_ERR_NULL } adc_status_t;

static const char *adc_status_text(adc_status_t s)
{
    static const char *const text[] = { "OK", "TIMEOUT", "NULL pointer" };
    return text[s];
}

/* Return value = status, *out = the data. (The HAL splits this into PollForConversion +
 * GetValue; xQueueReceive(q, &item, ticks) uses exactly this shape.) */
static adc_status_t adc_read(uint16_t *out)
{
    if (out == NULL) {
        return ADC_ERR_NULL;
    }
    uint32_t spins = 100U;
    while ((FAKE_ADC_SR & ADC_SR_EOC) == 0U) {
        if (spins-- == 0U) {
            return ADC_ERR_TIMEOUT;         /* *out deliberately NOT written */
        }
    }
    *out = (uint16_t)(FAKE_ADC_DR & 0x0FFFU);
    FAKE_ADC_SR &= ~ADC_SR_EOC;             /* reading DR clears EOC on real hardware */
    return ADC_OK;
}

/* Three results at once: three out-parameters, one status return. */
static adc_status_t adc_read_stats(size_t n, uint16_t *min, uint16_t *max, uint16_t *avg)
{
    if (min == NULL || max == NULL || avg == NULL || n == 0U) {
        return ADC_ERR_NULL;
    }
    uint32_t sum = 0U;
    uint16_t lo = 0xFFFFU, hi = 0U;
    for (size_t i = 0; i < n; i++) {
        uint16_t v;
        (void)fake_adc_start_conversion();
        adc_status_t st = adc_read(&v);
        if (st != ADC_OK) {
            return st;                      /* caller's min/max/avg stay unchanged */
        }
        sum += v;
        if (v < lo) lo = v;
        if (v > hi) hi = v;
    }
    *min = lo;
    *max = hi;
    *avg = (uint16_t)(sum / n);
    return ADC_OK;
}

int main(void)
{
    uint16_t sample = 0xFFFFU;              /* sentinel: "no valid data yet" */

    for (int i = 0; i < 3; i++) {
        (void)fake_adc_start_conversion();
        adc_status_t st = adc_read(&sample);
        printf("read %d: status=%-7s sample=%4u (%u mV at 3.3 V)\n", i, adc_status_text(st),
               (unsigned)sample, (unsigned)(((uint32_t)sample * 3300U) / 4095U));
    }

    /* No conversion was started, so EOC never rises -> timeout. */
    sample = 0xFFFFU;
    adc_status_t st = adc_read(&sample);
    printf("no start : status=%-7s sample=0x%04X  <- *out untouched on failure\n",
           adc_status_text(st), (unsigned)sample);

    printf("adc_read(NULL) -> %s\n", adc_status_text(adc_read(NULL)));

    /* Reset the fake feed and ask for min/max/avg of 6 samples in one call. */
    feed_pos = 0;
    uint16_t lo = 0, hi = 0, mean = 0;
    st = adc_read_stats(6, &lo, &hi, &mean);
    printf("stats(6) : status=%s min=%u max=%u avg=%u\n", adc_status_text(st),
           (unsigned)lo, (unsigned)hi, (unsigned)mean);

    /* The feed is now empty: a 7th conversion cannot complete. */
    st = adc_read_stats(1, &lo, &hi, &mean);
    printf("stats(1) : status=%s (min/max/avg keep %u/%u/%u)\n", adc_status_text(st),
           (unsigned)lo, (unsigned)hi, (unsigned)mean);
    return 0;
}
