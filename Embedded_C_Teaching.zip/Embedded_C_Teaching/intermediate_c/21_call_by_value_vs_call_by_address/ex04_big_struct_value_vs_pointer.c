/*
 * ============================================================================
 *  Topic   : 21 Call by Value vs Call by Address
 *  Example : 04 - Passing a big sensor frame: copy cost and const pointers
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Passing a struct by value copies every byte onto the stack on every
 *            call, and the callee works on that private copy. Passing its address
 *            costs one pointer (4 bytes on Cortex-M). "const T *p" promises the
 *            callee will not change the data; "T *const p" fixes the pointer.
 *  Embedded use : MCU stacks are 512-2048 bytes. A 100-byte frame passed by value
 *            at 1 kHz wastes CPU cycles and can overflow a small task stack.
 *  Real STM32F4 : HAL passes handles by pointer: HAL_SPI_Transmit(&hspi1, buf, n, 10);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_big_struct_value_vs_pointer.c -o ex04
 *  Output  : sizeof numbers, the by-value copy leaving the original untouched,
 *            and the by-pointer call really clearing the caller's flags
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add 32 more samples to imu_frame_t - how does the by-value cost change?
 *            2) Build with -DDEMO_BUG and read the compile error the const pointer gives.
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define FLAG_VALID 0x01U
#define FLAG_ALARM 0x80U

typedef struct {
    uint32_t timestamp_ms;
    int16_t  accel[3];
    int16_t  gyro[3];
    uint16_t adc[16];
    uint8_t  flags;
} imu_frame_t;

/* Callee gets its own full copy; "f.flags |= ..." touches only that copy. */
static uint32_t checksum_by_value(imu_frame_t f)
{
    uint32_t sum = f.timestamp_ms;
    for (size_t i = 0; i < 16; i++) {
        sum += f.adc[i];
    }
    f.flags |= FLAG_ALARM;                   /* lost when the function returns */
    return sum;
}

/* Callee gets 4 or 8 bytes (an address) and may only READ the frame. */
static uint32_t checksum_by_pointer(const imu_frame_t *f)
{
    uint32_t sum = f->timestamp_ms;
    for (size_t i = 0; i < 16; i++) {
        sum += f->adc[i];
    }
#ifdef DEMO_BUG
    f->flags |= FLAG_ALARM;      /* compile error: assignment of member in read-only object */
#endif
    return sum;
}

/* Non-const pointer: the callee is ALLOWED (and expected) to change the original. */
static void frame_clear_flags(imu_frame_t *f)
{
    f->flags = 0U;
}

/* "T *const p": p itself cannot be re-pointed, but the frame it names can change. */
static void frame_mark_valid(imu_frame_t *const f)
{
    f->flags |= FLAG_VALID;
#ifdef DEMO_BUG
    f = NULL;                    /* compile error: assignment of read-only parameter */
#endif
}

int main(void)
{
    imu_frame_t frame = { .timestamp_ms = 1000U, .flags = FLAG_VALID | FLAG_ALARM };
    for (size_t i = 0; i < 16; i++) {
        frame.adc[i] = (uint16_t)(100U + i);
    }

    printf("sizeof(imu_frame_t)  = %zu bytes copied per by-value call\n", sizeof frame);
    printf("sizeof(imu_frame_t*) = %zu bytes passed per by-pointer call\n", sizeof(&frame));
    printf("At 1 kHz the by-value style copies %zu bytes every second just for the call.\n",
           sizeof frame * 1000U);

    uint32_t a = checksum_by_value(frame);
    printf("by value  : checksum=%u, caller flags still 0x%02X (callee changed only its copy)\n",
           (unsigned)a, (unsigned)frame.flags);

    uint32_t b = checksum_by_pointer(&frame);
    printf("by pointer: checksum=%u, same answer without copying %zu bytes\n",
           (unsigned)b, sizeof frame);

    frame_clear_flags(&frame);               /* needs the address: it must edit the original */
    printf("frame_clear_flags(&frame) -> flags = 0x%02X\n", (unsigned)frame.flags);
    frame_mark_valid(&frame);
    printf("frame_mark_valid(&frame)  -> flags = 0x%02X\n", (unsigned)frame.flags);
    return 0;
}
