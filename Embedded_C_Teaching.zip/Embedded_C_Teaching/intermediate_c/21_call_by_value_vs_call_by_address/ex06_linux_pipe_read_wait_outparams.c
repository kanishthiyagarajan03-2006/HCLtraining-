/*
 * ============================================================================
 *  Topic   : 21 Call by Value vs Call by Address
 *  Example : 06 - Linux system calls that fill YOUR variables: pipe, read, wait
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Most POSIX calls report results through addresses you hand in:
 *              pipe(fds)         fills BOTH ints of your int[2]
 *              read(fd, buf, n)  fills your buffer, returns how many bytes
 *              waitpid(p, &st,0) writes the child's exit status into your int
 *            The kernel can only change your variables because it has their
 *            ADDRESSES. Return value = success/count, out-parameters = the data.
 *  Embedded use : an embedded-Linux daemon forks a helper (sensor reader), gets its
 *            readings through a pipe and its exit code through wait().
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex06_linux_pipe_read_wait_outparams.c -o ex06
 *  Output  : the child sends "temp=23.5C" through a pipe, the parent prints it, then
 *            prints the child's exit code 7 obtained through waitpid(&status)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Make the child exit with code 42 and watch WEXITSTATUS follow.
 *            2) Shrink buf to 4 bytes: what does the parent get, and how would you read the rest?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

/* Out-parameter again: "got" returns the byte count, the return value says ok/error. */
static int read_message(int fd, char *buf, size_t cap, size_t *got)
{
    size_t total = 0;
    while (total + 1 < cap) {
        ssize_t n = read(fd, buf + total, cap - 1 - total);   /* kernel fills buf */
        if (n < 0) {
            return -1;
        }
        if (n == 0) {
            break;                      /* writer closed its end: end of data */
        }
        total += (size_t)n;
    }
    buf[total] = '\0';                  /* read() does not add a terminator */
    *got = total;
    return 0;
}

int main(void)
{
    int fds[2];                         /* fds[0] = read end, fds[1] = write end */
    if (pipe(fds) != 0) {               /* pass the ARRAY (its address): pipe fills both */
        perror("pipe");
        return 1;
    }
    printf("pipe() filled the array: read end and write end are different descriptors: %s\n",
           (fds[0] != fds[1]) ? "yes" : "no");

    fflush(stdout);                     /* otherwise the child would inherit buffered text */
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return 1;
    }
    if (pid == 0) {                     /* ---- child: pretend to be a sensor reader ---- */
        close(fds[0]);
        const char *msg = "temp=23.5C";
        if (write(fds[1], msg, strlen(msg)) < 0) {
            _exit(1);
        }
        close(fds[1]);
        _exit(7);                       /* exit code the parent will collect */
    }

    close(fds[1]);                      /* parent: close the unused write end */
    char buf[32];
    size_t got = 0;
    if (read_message(fds[0], buf, sizeof buf, &got) != 0) {
        perror("read");
        return 1;
    }
    close(fds[0]);
    printf("parent read %zu bytes into its own buffer: \"%s\"\n", got, buf);

    int status = 0;                     /* waitpid writes through &status */
    if (waitpid(pid, &status, 0) < 0) {
        perror("waitpid");
        return 1;
    }
    if (WIFEXITED(status)) {
        printf("child exited normally, exit code = %d (decoded from the int waitpid filled)\n",
               WEXITSTATUS(status));
    } else {
        printf("child did not exit normally\n");
    }
    return 0;
}
