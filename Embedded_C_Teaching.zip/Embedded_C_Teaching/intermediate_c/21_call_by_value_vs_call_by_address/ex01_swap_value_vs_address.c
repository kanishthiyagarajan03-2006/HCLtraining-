/*
 * ============================================================================
 *  Topic   : 21 Call by Value vs Call by Address
 *  Example : 01 - Swapping two PWM duty values: copies versus addresses
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : C always passes arguments BY VALUE: the callee gets a private copy.
 *            To let a function change the caller's variable, pass its ADDRESS
 *            (&var) and write through the pointer (*ptr). A swap shows both.
 *  Embedded use : every HAL call that fills or updates your data takes a pointer
 *            (handles, config structs, receive buffers). Passing a value would
 *            silently change only a copy and the hardware code "does nothing".
 *  Real STM32F4 : HAL_ADC_Start(&hadc1);   // the HAL needs the ADDRESS of your handle
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_swap_value_vs_address.c -o ex01
 *  Output  : the by-value swap leaves both duties unchanged; the by-address swap
 *            really exchanges them; array elements can be swapped the same way
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a third value and write rotate3(&a, &b, &c) (a<-b, b<-c, c<-a).
 *            2) Call swap_by_address(&red_duty, &red_duty) - what do you expect?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

static const void *caller_addr;     /* where the caller's variable really lives */

/* a and b are COPIES. Swapping them changes nothing outside this function. */
static void swap_by_value(uint16_t a, uint16_t b)
{
    uint16_t tmp = a;
    a = b;
    b = tmp;
    printf("  inside swap_by_value  : a=%u b=%u  (swapped, but only the copies)\n",
           (unsigned)a, (unsigned)b);
    printf("  parameter a lives at the caller's address? %s\n",
           ((const void *)&a == caller_addr) ? "yes" : "no - it is a separate copy");
}

/* a and b hold ADDRESSES. *a and *b are the caller's real variables. */
static void swap_by_address(uint16_t *a, uint16_t *b)
{
    if (a == NULL || b == NULL) {
        return;                     /* never dereference an unchecked pointer */
    }
    uint16_t tmp = *a;
    *a = *b;
    *b = tmp;
}

int main(void)
{
    uint16_t red_duty = 80;         /* PWM compare values in percent */
    uint16_t blue_duty = 20;

    printf("start                 : red=%u%% blue=%u%%\n", (unsigned)red_duty, (unsigned)blue_duty);

    caller_addr = &red_duty;
    swap_by_value(red_duty, blue_duty);          /* values are copied onto the stack */
    printf("after swap_by_value   : red=%u%% blue=%u%%   <- NOT swapped\n",
           (unsigned)red_duty, (unsigned)blue_duty);

    swap_by_address(&red_duty, &blue_duty);      /* addresses are copied; data is shared */
    printf("after swap_by_address : red=%u%% blue=%u%%   <- swapped\n",
           (unsigned)red_duty, (unsigned)blue_duty);

    /* Any lvalue has an address, so array elements work exactly the same way. */
    uint16_t fade[4] = { 10, 20, 30, 40 };
    swap_by_address(&fade[0], &fade[3]);
    printf("fade[] after swapping first and last element: %u %u %u %u\n",
           (unsigned)fade[0], (unsigned)fade[1], (unsigned)fade[2], (unsigned)fade[3]);

    /* The pointer itself is also passed by value: swap_by_address(NULL, ...) is safe. */
    swap_by_address(NULL, &blue_duty);
    printf("NULL argument ignored, blue still %u%%\n", (unsigned)blue_duty);
    return 0;
}
