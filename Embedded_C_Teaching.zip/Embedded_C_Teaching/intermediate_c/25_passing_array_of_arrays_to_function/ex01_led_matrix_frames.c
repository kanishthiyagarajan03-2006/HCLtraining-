/*
 * ============================================================================
 *  Topic   : 25 Passing an Array of Arrays to a Function
 *  Example : 01 - 8x8 LED matrix animation: const uint8_t frames[][8]
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : anim[3][8] is an array of 3 arrays of 8 bytes. Passed to a function it
 *            decays to a pointer to ONE ROW: const uint8_t (*)[8]. The first
 *            dimension may be omitted (frames[]), the others may NOT: the compiler
 *            needs the row length (8) to compute where frames[1] starts. Pass the
 *            number of frames separately. frames[f] is itself a row you can hand
 *            to a function that expects a plain 1-D array.
 *  Embedded use : MAX7219 / HT1632 LED drivers, OLED page buffers and font tables are
 *            arrays of fixed-size rows sent to the display over SPI/I2C.
 *  Real STM32F4 : HAL_SPI_Transmit(&hspi1, pair, 2, 10);   // {register, data} per row
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_led_matrix_frames.c -o ex01
 *  Output  : three frames (small heart, big heart, dark) printed side by side, the row
 *            stride and sizeof facts, and the SPI byte count of "playing" the animation
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a 4th frame to anim[] - what must you change in main()? (nothing else!)
 *            2) Change the prototype to frames[][7]. What does the compiler say, and why?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define ROWS 8U
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

/* One byte per matrix row, bit 7 = left-most LED. */
static const uint8_t anim[][ROWS] = {
    { 0x00, 0x00, 0x24, 0x7E, 0x7E, 0x3C, 0x18, 0x00 },     /* small heart */
    { 0x00, 0x66, 0xFF, 0xFF, 0x7E, 0x3C, 0x18, 0x00 },     /* big heart   */
    { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },     /* all dark    */
};

static size_t spi_bytes;                                    /* what the fake SPI has carried */

/* Plain 1-D parameter: receives a pointer to the first byte of ONE frame. */
static void display_frame(const uint8_t rows[ROWS])
{
    for (size_t r = 0; r < ROWS; r++) {
        /* MAX7219: send {register address 1..8, row data}. Real code calls HAL_SPI_Transmit. */
        spi_bytes += 2U;
        (void)rows[r];
    }
}

/* 2-D parameter: the column count (8) is part of the type; the row count is not. */
static void play(const uint8_t frames[][ROWS], size_t nframes)
{
    for (size_t f = 0; f < nframes; f++) {
        display_frame(frames[f]);                           /* frames[f] is a row: decays again */
    }
}

/* Same parameter type as play(), spelled the way the compiler sees it: pointer to a row. */
static void report_decay(const uint8_t (*frames)[ROWS])
{
    printf("inside the callee: sizeof(frames) = %zu (a pointer), sizeof(*frames) = %zu (one row)\n",
           sizeof(frames), sizeof(*frames));
}

static void print_row_bits(uint8_t bits)
{
    for (int b = 7; b >= 0; b--) {
        putchar(((bits >> b) & 1U) ? '#' : '.');
    }
}

/* Row-major walk: for each LED row, print that row of every frame. frames[f][r]. */
static void preview(const uint8_t frames[][ROWS], size_t nframes)
{
    for (size_t f = 0; f < nframes; f++) {
        printf("frame %zu   ", f);
    }
    printf("\n");
    for (size_t r = 0; r < ROWS; r++) {
        for (size_t f = 0; f < nframes; f++) {
            print_row_bits(frames[f][r]);
            printf("   ");
        }
        printf("\n");
    }
}

int main(void)
{
    printf("main: sizeof(anim) = %zu, sizeof(anim[0]) = %zu, frames = %zu\n", sizeof(anim),
           sizeof(anim[0]), ARRAY_SIZE(anim));
    printf("distance from anim[0] to anim[1] = %zu bytes (the row length)\n",
           (size_t)((uintptr_t)anim[1] - (uintptr_t)anim[0]));

    report_decay(anim);
    preview(anim, ARRAY_SIZE(anim));

    play(anim, ARRAY_SIZE(anim));
    printf("SPI traffic: %zu frames x %u rows x 2 bytes = %zu bytes\n", ARRAY_SIZE(anim), ROWS,
           spi_bytes);
    return 0;
}
