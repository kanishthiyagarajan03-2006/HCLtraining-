/*
 * ============================================================================
 *  Topic   : 25 Passing an Array of Arrays to a Function
 *  Example : 03 - Any-size sensor grid: m[rows][cols] parameter vs flat index math
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : To write ONE function for grids of different sizes you have two options:
 *              a) variably-modified parameter  int16_t g[rows][cols]  - the sizes must
 *                 be declared BEFORE the array in the parameter list (C99);
 *              b) a flat pointer plus index math  g[r * cols + c]  - works in every C.
 *            Both read the same memory: row-major means row r starts at r * cols.
 *  Embedded use : thermal-imager (AMG8833 8x8), touch-panel or ADC-channel grids whose
 *            dimensions differ between board variants.
 *  Real STM32F4 : HAL_I2C_Mem_Read(&hi2c1, addr, reg, 1, (uint8_t *)grid, sizeof grid, 100);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_vla_param_and_flat_buffer.c -o ex03
 *  Output  : hottest cell and its position for a 3x4 and a 4x4 grid found with both
 *            methods (same answers), plus the index arithmetic spelled out
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a 2x6 grid and call both functions - what must change in them? (nothing)
 *            2) Swap the order of the parameters (g before cols) - what does gcc say?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define IDX(r, c, cols) ((r) * (cols) + (c))         /* row-major index into a flat buffer */

/* Option a) rows and cols come first so they can appear in the array type. */
static int16_t hottest_vla(size_t rows, size_t cols, const int16_t g[rows][cols],
                           size_t *hot_r, size_t *hot_c)
{
    int16_t best = g[0][0];
    *hot_r = 0U;
    *hot_c = 0U;
    for (size_t r = 0; r < rows; r++) {
        for (size_t c = 0; c < cols; c++) {
            if (g[r][c] > best) {
                best = g[r][c];
                *hot_r = r;
                *hot_c = c;
            }
        }
    }
    return best;
}

/* Option b) the callee sees only an address; the caller passes the shape. */
static int16_t hottest_flat(const int16_t *g, size_t rows, size_t cols,
                            size_t *hot_r, size_t *hot_c)
{
    size_t best_i = 0U;
    for (size_t i = 1; i < rows * cols; i++) {
        if (g[i] > g[best_i]) {
            best_i = i;
        }
    }
    *hot_r = best_i / cols;                          /* undo r * cols + c */
    *hot_c = best_i % cols;
    return g[best_i];
}

static int32_t mean_flat(const int16_t *g, size_t rows, size_t cols)
{
    int32_t sum = 0;
    for (size_t r = 0; r < rows; r++) {
        for (size_t c = 0; c < cols; c++) {
            sum += g[IDX(r, c, cols)];               /* same cell as g[r][c] would be */
        }
    }
    return sum / (int32_t)(rows * cols);
}

int main(void)
{
    /* Temperatures in 0.01 degC. */
    const int16_t small[3][4] = {
        { 2310, 2335, 2290, 2301 },
        { 2322, 3150, 2745, 2299 },
        { 2308, 2511, 2330, 2297 },
    };
    const int16_t big[4][4] = {
        { 2200, 2210, 2225, 2190 },
        { 2215, 2230, 2240, 2205 },
        { 2220, 2235, 4120, 2212 },
        { 2198, 2207, 2219, 2201 },
    };

    size_t r, c;
    int16_t t = hottest_vla(3, 4, small, &r, &c);
    printf("3x4 vla : hottest %d.%02d C at row %zu col %zu\n", t / 100, t % 100, r, c);
    t = hottest_flat(&small[0][0], 3, 4, &r, &c);        /* &g[0][0]: address of first cell */
    printf("3x4 flat: hottest %d.%02d C at row %zu col %zu\n", t / 100, t % 100, r, c);

    t = hottest_vla(4, 4, big, &r, &c);
    printf("4x4 vla : hottest %d.%02d C at row %zu col %zu\n", t / 100, t % 100, r, c);
    t = hottest_flat(&big[0][0], 4, 4, &r, &c);
    printf("4x4 flat: hottest %d.%02d C at row %zu col %zu\n", t / 100, t % 100, r, c);

    int32_t m = mean_flat(&big[0][0], 4, 4);
    printf("4x4 mean: %d.%02d C\n", (int)(m / 100), (int)(m % 100));

    printf("index math: big[2][2] is flat index %zu, big[2][2] = %d, flat[10] = %d\n",
           (size_t)IDX(2U, 2U, 4U), big[2][2], (&big[0][0])[10]);
    return 0;
}
