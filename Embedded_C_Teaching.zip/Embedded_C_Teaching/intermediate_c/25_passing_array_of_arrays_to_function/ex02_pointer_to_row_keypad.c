/*
 * ============================================================================
 *  Topic   : 25 Passing an Array of Arrays to a Function
 *  Example : 02 - 4x4 keypad map and the pointer-to-array type const char (*)[4]
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A 2-D array is NOT an array of pointers. keymap[4][4] is 16 chars laid out
 *            row after row; its name decays to "pointer to an array of 4 chars":
 *            const char (*map)[4]. Adding 1 to that pointer skips a whole ROW (4 bytes),
 *            while a plain char * skips one byte. map[r][c] means *(*(map + r) + c).
 *            It is NOT compatible with char ** (an array of pointers).
 *  Embedded use : matrix keypads, LED/segment maps and font tables are 2-D constant
 *            tables; the scan routine takes the table as a (*map)[COLS] parameter.
 *  Real STM32F4 : GPIOA->ODR = (1U << row);  cols = GPIOB->IDR & 0xF;   // drive/read
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_pointer_to_row_keypad.c -o ex02
 *  Output  : the keymap walked with a row pointer (byte offsets 0,4,8,12), then three
 *            simulated key presses decoded to '8', '*' and 'A', then "no key"
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Swap two rows in keymap[] - which presses decode differently now?
 *            2) Build with -DDEMO_BUG: why does gcc reject  const char **bad = keymap ?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define KEY_ROWS 4U
#define KEY_COLS 4U

static const char keymap[KEY_ROWS][KEY_COLS] = {
    { '1', '2', '3', 'A' },
    { '4', '5', '6', 'B' },
    { '7', '8', '9', 'C' },
    { '*', '0', '#', 'D' },
};

/* ---- fake keypad wiring: row lines out, column lines in ---------------------- */
static volatile uint32_t ROW_OUT;            /* driven by the MCU (like GPIOA->ODR) */
static volatile uint32_t COL_IN;             /* read back by the MCU (like GPIOB->IDR) */
static int finger_row = -1, finger_col = -1; /* which key is held down, -1 = none */

static void fake_keypad_wire(void)           /* the switch connects a row to a column */
{
    COL_IN = 0U;
    if (finger_row >= 0 && (ROW_OUT & (1U << finger_row)) != 0U) {
        COL_IN = 1U << finger_col;
    }
}

/* The table arrives as a pointer to rows of KEY_COLS chars. */
static char keypad_scan(const char (*map)[KEY_COLS])
{
    for (unsigned r = 0; r < KEY_ROWS; r++) {
        ROW_OUT = 1U << r;                   /* drive one row high ... */
        fake_keypad_wire();
        uint32_t cols = COL_IN & 0xFU;       /* ... and see which column answers */
        if (cols != 0U) {
            unsigned c = 0U;
            while (((cols >> c) & 1U) == 0U) {
                c++;
            }
            ROW_OUT = 0U;
            return map[r][c];                /* same as *(*(map + r) + c) */
        }
    }
    ROW_OUT = 0U;
    return '\0';
}

static void dump_with_row_pointer(const char (*map)[KEY_COLS])
{
    const char (*row)[KEY_COLS] = map;       /* row points at a whole row of 4 chars */
    for (size_t r = 0; r < KEY_ROWS; r++, row++) {       /* row++ skips sizeof(*row) bytes */
        printf("  row %zu at byte offset %2zu:", r, (size_t)((uintptr_t)row - (uintptr_t)map));
        for (size_t c = 0; c < KEY_COLS; c++) {
            printf(" %c", (*row)[c]);
        }
        printf("\n");
    }
}

int main(void)
{
    printf("sizeof(keymap[0]) = %zu bytes = one row; row_ptr + 1 moves exactly that far.\n",
           sizeof(keymap[0]));
    dump_with_row_pointer(keymap);

    /* Same memory seen as one flat run of 16 chars through a plain char pointer. */
    const char *flat = &keymap[0][0];
    printf("flat[5] = '%c' and keymap[1][1] = '%c' (row 1, col 1 -> index 1*4+1)\n", flat[5],
           keymap[1][1]);
    printf("*(*(keymap + 2) + 1) = '%c' equals keymap[2][1] = '%c'\n", *(*(keymap + 2) + 1),
           keymap[2][1]);

#ifdef DEMO_BUG
    /* BUG: char ** means "pointer to a char pointer". keymap holds characters, not pointers;
     * bad[1] would read '4','5','6','B' as the bytes of an ADDRESS. gcc rejects the types. */
    const char **bad = keymap;
    printf("%c\n", bad[0][0]);
#endif

    static const int presses[][2] = { { 2, 1 }, { 3, 0 }, { 0, 3 }, { -1, -1 } };
    for (size_t i = 0; i < sizeof presses / sizeof presses[0]; i++) {
        finger_row = presses[i][0];
        finger_col = presses[i][1];
        char key = keypad_scan(keymap);
        if (key != '\0') {
            printf("finger at row %d col %d -> key '%c'\n", finger_row, finger_col, key);
        } else {
            printf("no finger -> no key\n");
        }
    }
    return 0;
}
