/*
 * ============================================================================
 *  Topic   : 25 Passing an Array of Arrays to a Function
 *  Example : 05 - 3x3 calibration matrix in Q15 fixed point (multiply, transpose)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Matrices are passed as "const int16_t m[3][3]" (input) and "int16_t out[3][3]"
 *            (output); a vector is a plain 1-D array. Q15 fixed point stores a value in
 *            [-1, 1) as value * 32768 in an int16_t; the product of two Q15 numbers is
 *            Q30 in an int32_t accumulator and is shifted right by 15 to get Q15 back.
 *            Checks: (R * cal) * v ~ R * (cal * v) (1 LSB apart: rounding), R * R^T ~ identity.
 *  Embedded use : correcting accelerometer / magnetometer axis misalignment on a Cortex-M
 *            without an FPU: a 3x3 integer multiply per sample.
 *  Real STM32F4 : CMSIS-DSP arm_mat_mult_q15() does the same job (64-bit accumulator + saturation)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_calibration_matrix_q15.c -o ex05
 *  Output  : the calibration and rotation matrices, a raw and corrected accelerometer
 *            vector, the combined-matrix result (1 LSB off), and R * R^T (near identity)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change one off-diagonal calibration term to 0.05 - how does the output move?
 *            2) Why is the int32_t accumulator safe here? When would it overflow?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* Compile-time conversion of a constant in [-1, 1) to Q15 (rounded to nearest). */
#define Q15(x) ((int16_t)((x) * 32768.0 + ((x) >= 0 ? 0.5 : -0.5)))

#define M 3U

static void mat3_mul_vec(const int16_t m[M][M], const int16_t v[M], int16_t out[M])
{
    for (size_t r = 0; r < M; r++) {
        int32_t acc = 0;                             /* Q30 accumulator */
        for (size_t c = 0; c < M; c++) {
            acc += (int32_t)m[r][c] * v[c];
        }
        out[r] = (int16_t)(acc >> 15);               /* back to the input's scale */
    }
}

static void mat3_mul(const int16_t a[M][M], const int16_t b[M][M], int16_t out[M][M])
{
    for (size_t r = 0; r < M; r++) {
        for (size_t c = 0; c < M; c++) {
            int32_t acc = 0;
            for (size_t k = 0; k < M; k++) {
                acc += (int32_t)a[r][k] * b[k][c];
            }
            out[r][c] = (int16_t)(acc >> 15);
        }
    }
}

static void mat3_transpose(const int16_t m[M][M], int16_t out[M][M])
{
    for (size_t r = 0; r < M; r++) {
        for (size_t c = 0; c < M; c++) {
            out[c][r] = m[r][c];
        }
    }
}

/* Print a Q15 number as a decimal using integers only (no float printf on small MCUs). */
static void print_q15(int16_t q)
{
    int32_t scaled = ((int32_t)q * 10000) / 32768;   /* four decimals */
    printf(" %s%d.%04d", scaled < 0 ? "-" : " ", (int)abs((int)(scaled / 10000)),
           (int)abs((int)(scaled % 10000)));
}

static void print_mat3(const char *name, const int16_t m[M][M])
{
    printf("%s\n", name);
    for (size_t r = 0; r < M; r++) {
        printf("  [");
        for (size_t c = 0; c < M; c++) {
            print_q15(m[r][c]);
        }
        printf(" ]\n");
    }
}

static void print_vec3(const char *name, const int16_t v[M])
{
    printf("%-26s %6d %6d %6d\n", name, v[0], v[1], v[2]);
}

int main(void)
{
    /* Sensor misalignment and gain error found during factory calibration. */
    const int16_t cal[M][M] = {
        { Q15(0.998),  Q15(0.010), Q15(-0.005) },
        { Q15(-0.008), Q15(0.990), Q15(0.004)  },
        { Q15(0.003),  Q15(-0.006), Q15(0.995) },
    };
    /* Board is mounted turned 90 degrees about Z: x' = -y, y' = x, z' = z.
     * +1.0 does not fit in Q15 (max is 32767 = 0.99997), so 32767 stands in for 1.0. */
    const int16_t rot[M][M] = {
        { 0,     -32767, 0     },
        { 32767, 0,      0     },
        { 0,     0,      32767 },
    };

    print_mat3("calibration matrix:", cal);
    print_mat3("rotation matrix R:", rot);

    const int16_t raw[M] = { 512, -256, 16000 };        /* 16384 LSB = 1 g */
    int16_t fixed[M], board[M], combined_m[M][M], combined[M];

    mat3_mul_vec(cal, raw, fixed);
    mat3_mul_vec(rot, fixed, board);
    print_vec3("raw (sensor axes):", raw);
    print_vec3("after calibration:", fixed);
    print_vec3("after rotation to board:", board);

    mat3_mul(rot, cal, combined_m);                     /* precompute R * cal once ... */
    mat3_mul_vec(combined_m, raw, combined);            /* ... then one multiply per sample */
    print_vec3("combined matrix result:", combined);

    int16_t rt[M][M], ident[M][M];
    mat3_transpose(rot, rt);
    mat3_mul(rot, rt, ident);
    print_mat3("R * transpose(R) (about identity):", ident);
    return 0;
}
