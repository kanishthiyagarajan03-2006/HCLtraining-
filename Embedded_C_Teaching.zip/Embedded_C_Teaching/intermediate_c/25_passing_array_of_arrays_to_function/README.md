# Topic 25 - Passing an Array of Arrays to a Function
**Suggested session:** 75 min | **Prerequisite topics:** 15 Arrays, 17 Pointers, 19 Array of Array, 22 Passing an Array to a Function

Students should leave knowing that a 2-D array is a flat run of rows, that the parameter is a pointer to ONE ROW
(`T (*)[COLS]`), why the column count must be part of the type, and what alternatives exist (variable-length array
parameters, flat buffer plus index math). The examples go from LED animation frames and a keypad table, through generic grids
and bitmap rotation, to a fixed-point calibration matrix, an RTOS schedule table and a PGM image filter on Linux.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_led_matrix_frames.c` | MCU | `const uint8_t frames[][8]`: omit only the first dimension, row stride, `frames[f]` is a row you can pass on |
| 02 | `ex02_pointer_to_row_keypad.c` | MCU | `const char (*map)[4]`, row pointer arithmetic, `map[r][c] == *(*(map+r)+c)`, why `char **` is wrong |
| 03 | `ex03_vla_param_and_flat_buffer.c` | MCU | `g[rows][cols]` parameter (sizes first) vs flat `g[r*cols + c]` for any grid size |
| 04 | `ex04_rotate_bitmap_8x8.c` | MCU | `src[8][8]` in / `dst[8][8]` out, 3-D array planes, transpose + mirror = rotate (checked with `memcmp`) |
| 05 | `ex05_calibration_matrix_q15.c` | MCU | 3x3 Q15 matrix times vector, matrix product and transpose with `int32_t` accumulators |
| 06 | `ex06_rtos_schedule_table.c` | RTOS | A `uint16_t table[][3]` handed to `scheduler_init()`; each task receives a pointer to its own row |
| 07 | `ex07_linux_pgm_filter.c` | LINUX | Load a PGM file into `img[][MAXW]`, then threshold / invert filters on the same parameter type |

## Teaching notes
* Start from the memory picture: `int m[3][4]` is 12 ints in a row; `m[r][c]` is `*(base + r*4 + c)`. The compiler needs `4` to find row `r`.
* Common mistakes: writing `uint8_t m[][]` (error), `uint8_t **m` (wrong type, crashes), or trusting `sizeof(m)` inside the callee.
* VLA parameters (ex03) are C99 and optional in C11; MSVC does not support them. The flat buffer works everywhere, and is how most MCU libraries (CMSIS-DSP) do it.
* The flat walk over `&m[0][0]` for the whole 2-D object is universally used, although a strict reading of the C standard only blesses indexing within one row.
* Return to the DMA ping-pong of topic 22: `uint16_t buf[2][HALF]` would give the same two halves as `buf[0]` and `buf[1]`.
* Q15 arithmetic (ex05): multiply in 32 bits, shift right by 15, and always ask "can the accumulator overflow?".

## Live-demo tips
* ex02: build with `-DDEMO_BUG` to read gcc's `incompatible pointer type` message for `const char **bad = keymap`.
* ex04: change the glyph rows in `glyph_f[]` to the students' initials and rotate them live.
* ex06: raise the logger priority to 3 and watch the timeline change (ties are served round-robin).
