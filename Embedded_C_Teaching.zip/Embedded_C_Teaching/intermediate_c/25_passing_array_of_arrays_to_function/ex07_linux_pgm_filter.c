/*
 * ============================================================================
 *  Topic   : 25 Passing an Array of Arrays to a Function
 *  Example : 07 - Load a PGM image into img[][16] and run threshold / invert filters
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : An image is a 2-D array. With a fixed maximum width the parameter is
 *            "uint8_t img[][MAXW]": the column count is part of the type, the row
 *            count and the real used width/height travel as separate size_t values.
 *            Loaders write INTO the caller's array; filters modify it in place; the
 *            printer only reads it (const). All use the same parameter type.
 *  Embedded use : an embedded-Linux camera or thermal sensor board loads/saves small
 *            frames and applies cheap filters before sending them upstream.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex07_linux_pgm_filter.c -o ex07
 *  Output  : a 12x8 gradient image written as an ASCII PGM file in a temp dir, loaded
 *            back, then shown raw, thresholded and inverted as ASCII art
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the threshold from 128 to 200 - which parts of the image survive?
 *            2) Write threshold_roi() that filters only a rectangle of the image.
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#define MAXW 16U                                     /* column count = part of the type */
#define MAXH 16U
#define IMG_W 12U
#define IMG_H 8U

/* Writes the used w x h part of img as an ASCII "P2" PGM file. */
static int pgm_save(const char *path, const uint8_t img[][MAXW], size_t w, size_t h)
{
    FILE *fp = fopen(path, "w");
    if (fp == NULL) {
        return -1;
    }
    fprintf(fp, "P2\n%zu %zu\n255\n", w, h);
    for (size_t y = 0; y < h; y++) {
        for (size_t x = 0; x < w; x++) {
            fprintf(fp, "%u%c", (unsigned)img[y][x], x + 1U < w ? ' ' : '\n');
        }
    }
    return fclose(fp);
}

/* Fills the caller's array; reports the size it found through w and h (out-parameters). */
static int pgm_load(const char *path, uint8_t img[][MAXW], size_t *w, size_t *h)
{
    FILE *fp = fopen(path, "r");
    if (fp == NULL) {
        return -1;
    }
    char magic[3] = { 0 };
    unsigned maxval = 0;
    int ok = fscanf(fp, "%2s %zu %zu %u", magic, w, h, &maxval) == 4 &&
             strcmp(magic, "P2") == 0 && maxval == 255U && *w <= MAXW && *h <= MAXH;
    for (size_t y = 0; ok && y < *h; y++) {
        for (size_t x = 0; ok && x < *w; x++) {
            unsigned v = 0U;
            ok = fscanf(fp, "%u", &v) == 1 && v <= 255U;
            img[y][x] = (uint8_t)v;
        }
    }
    fclose(fp);
    return ok ? 0 : -1;
}

static void threshold(uint8_t img[][MAXW], size_t w, size_t h, uint8_t level)
{
    for (size_t y = 0; y < h; y++) {
        for (size_t x = 0; x < w; x++) {
            img[y][x] = (img[y][x] >= level) ? 255U : 0U;
        }
    }
}

static void invert(uint8_t img[][MAXW], size_t w, size_t h)
{
    for (size_t y = 0; y < h; y++) {
        for (size_t x = 0; x < w; x++) {
            img[y][x] = (uint8_t)(255U - img[y][x]);
        }
    }
}

static void show(const char *title, const uint8_t img[][MAXW], size_t w, size_t h)
{
    static const char ramp[] = " .:-=+*#%@";            /* dark ... bright */
    printf("%s (%zux%zu)\n", title, w, h);
    for (size_t y = 0; y < h; y++) {
        printf("  ");
        for (size_t x = 0; x < w; x++) {
            putchar(ramp[img[y][x] * 9U / 255U]);
        }
        printf("\n");
    }
}

int main(void)
{
    uint8_t img[MAXH][MAXW] = { { 0 } };                /* static-size storage, partly used */
    for (size_t y = 0; y < IMG_H; y++) {
        for (size_t x = 0; x < IMG_W; x++) {
            img[y][x] = (uint8_t)(x * 255U / (IMG_W - 1U));       /* left-to-right gradient */
        }
    }
    for (size_t y = 2; y < 5; y++) {
        for (size_t x = 2; x < 5; x++) {
            img[y][x] = 220U;                                     /* bright box, dark side  */
        }
    }
    img[6][9] = 30U;                                          /* dark pixel, bright side */

    char dir[] = "/tmp/ex07_XXXXXX";
    if (mkdtemp(dir) == NULL) {
        perror("mkdtemp");
        return 1;
    }
    char path[64];
    snprintf(path, sizeof path, "%s/frame.pgm", dir);

    uint8_t loaded[MAXH][MAXW] = { { 0 } };
    size_t w = 0, h = 0;
    int rc = 1;
    if (pgm_save(path, img, IMG_W, IMG_H) != 0 || pgm_load(path, loaded, &w, &h) != 0) {
        fprintf(stderr, "PGM save/load failed\n");
    } else {
        printf("saved and reloaded frame.pgm: found %zux%zu pixels, round trip %s\n", w, h,
               memcmp(img, loaded, sizeof img) == 0 ? "identical" : "DIFFERENT");
        show("raw", loaded, w, h);
        threshold(loaded, w, h, 128U);
        show("threshold at 128", loaded, w, h);
        invert(loaded, w, h);
        show("inverted", loaded, w, h);
        rc = 0;
    }

    unlink(path);
    rmdir(dir);
    return rc;
}
