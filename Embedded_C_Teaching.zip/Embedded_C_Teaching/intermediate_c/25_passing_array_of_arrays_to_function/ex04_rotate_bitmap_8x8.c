/*
 * ============================================================================
 *  Topic   : 25 Passing an Array of Arrays to a Function
 *  Example : 04 - Rotate an 8x8 bitmap: src[8][8] in, dst[8][8] out
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Functions take 2-D arrays as "uint8_t m[N][N]" (really a pointer to a row
 *            of N bytes). Input is const, output is a writable array the caller owns.
 *            A 3-D array rot[4][8][8] is just four 8x8 planes: rot[k] is a normal 2-D
 *            array you can pass on. A transpose swaps across the diagonal in place;
 *            rotate-90 = transpose + mirror (verified with memcmp over sizeof).
 *  Embedded use : screen-orientation changes on small OLED/LED-matrix displays, and
 *            re-mapping sensor tiles, are rotations of fixed-size pixel buffers.
 *  Real STM32F4 : (SSD1306 page buffer: uint8_t fb[8][128], sent with HAL_I2C_Mem_Write)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_rotate_bitmap_8x8.c -o ex04
 *  Output  : the letter F at 0, 90, 180 and 270 degrees side by side, then two checks:
 *            rotate == transpose + mirror, and four quarter turns restore the original
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add bmp_rotate_ccw() (counter-clockwise) and print it next to 270.
 *            2) Draw your own 8x8 glyph in the packed rows[] table and rotate it.
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define N 8U

/* Packed form (one byte per row, bit 7 = left) -> one byte per pixel. */
static void bmp_unpack(const uint8_t rows[N], uint8_t px[N][N])
{
    for (size_t r = 0; r < N; r++) {
        for (size_t c = 0; c < N; c++) {
            px[r][c] = (uint8_t)((rows[r] >> (7U - c)) & 1U);
        }
    }
}

/* Clockwise quarter turn: the top row of src becomes the right column of dst. */
static void bmp_rotate_cw(const uint8_t src[N][N], uint8_t dst[N][N])
{
    for (size_t r = 0; r < N; r++) {
        for (size_t c = 0; c < N; c++) {
            dst[c][N - 1U - r] = src[r][c];
        }
    }
}

static void bmp_transpose(uint8_t m[N][N])           /* in place: swap across the diagonal */
{
    for (size_t r = 0; r < N; r++) {
        for (size_t c = r + 1U; c < N; c++) {
            uint8_t tmp = m[r][c];
            m[r][c] = m[c][r];
            m[c][r] = tmp;
        }
    }
}

static void bmp_mirror(uint8_t m[N][N])              /* flip left <-> right in place */
{
    for (size_t r = 0; r < N; r++) {
        for (size_t c = 0; c < N / 2U; c++) {
            uint8_t tmp = m[r][c];
            m[r][c] = m[r][N - 1U - c];
            m[r][N - 1U - c] = tmp;
        }
    }
}

/* imgs is a pointer to 8x8 planes: each imgs[k] is one whole bitmap. */
static void show_strip(const uint8_t imgs[][N][N], size_t count, const char *const labels[])
{
    for (size_t k = 0; k < count; k++) {
        printf("%-10s", labels[k]);
    }
    printf("\n");
    for (size_t r = 0; r < N; r++) {
        for (size_t k = 0; k < count; k++) {
            for (size_t c = 0; c < N; c++) {
                putchar(imgs[k][r][c] ? '#' : '.');
            }
            printf("  ");
        }
        printf("\n");
    }
}

int main(void)
{
    static const uint8_t glyph_f[N] = { 0x7E, 0x60, 0x60, 0x7C, 0x60, 0x60, 0x60, 0x00 };
    static const char *const labels[4] = { "0 deg", "90 deg", "180 deg", "270 deg" };

    uint8_t rot[4][N][N];                            /* four 8x8 planes: 256 bytes */
    bmp_unpack(glyph_f, rot[0]);                     /* rot[0] is an 8x8 array: passes as such */
    for (size_t k = 0; k < 3U; k++) {
        bmp_rotate_cw(rot[k], rot[k + 1U]);          /* output plane is the next one */
    }
    show_strip(rot, 4U, labels);

    /* Check 1: rotate-90 equals transpose followed by a left-right mirror. */
    uint8_t check[N][N];
    memcpy(check, rot[0], sizeof check);             /* sizeof check = 64: it is a real array */
    bmp_transpose(check);
    bmp_mirror(check);
    printf("rotate_cw == transpose + mirror : %s\n",
           memcmp(check, rot[1], sizeof check) == 0 ? "yes" : "NO");

    /* Check 2: four quarter turns bring the picture back. */
    uint8_t again[N][N];
    bmp_rotate_cw(rot[3], again);
    printf("four quarter turns == original  : %s\n",
           memcmp(again, rot[0], sizeof again) == 0 ? "yes" : "NO");
    return 0;
}
