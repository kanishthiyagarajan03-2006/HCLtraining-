/*
 * ============================================================================
 *  Topic   : 25 Passing an Array of Arrays to a Function
 *  Example : 06 - A 2-D schedule table handed to scheduler_init()
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A table with one ROW per periodic job and one COLUMN per attribute is an
 *            array of arrays: const uint16_t table[][3]. scheduler_init() receives it as
 *            a pointer to a row of 3 values plus the row count, creates one task per
 *            row and gives each task a pointer to ITS row (table[i] decays to a plain
 *            1-D pointer). Column numbers come from an enum, never from magic digits.
 *  Embedded use : static, table-driven task configuration (period, priority, work) keeps
 *            all timing in one reviewable place - common in safety-critical firmware.
 *  Real FreeRTOS use : xTaskCreate(fn, name, stack, (void *)table[i], priority, NULL) per row
 *            and vTaskDelayUntil(&last_wake, period) inside every task.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_rtos_schedule_table.c -o ex06
 *  Output  : three periodic jobs (20/50/100 ms); the long low-priority logger is
 *            preempted by the control loop, visible in the timestamps
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a fourth row to the table: does scheduler_init() need any change?
 *            2) Raise the logger to priority 3. Who gets delayed now, and by how much?
 * ============================================================================
 */
#include "mini_rtos.h"

enum { COL_PERIOD_MS, COL_PRIO, COL_WORK_MS, NUM_COLS };

/* One row per job: { period_ms, priority, work_ms }. Bigger priority number wins. */
static const uint16_t sched_table[][NUM_COLS] = {
    { 20U,  3U,  2U },       /* control loop: short, urgent, frequent */
    { 50U,  2U, 10U },       /* sensor read */
    { 100U, 1U, 30U },       /* logger: long job, lowest priority */
};

static const char *const job_names[] = { "control", "sensor", "logger" };

/* arg points at ONE ROW of the table: a plain const uint16_t * with NUM_COLS values. */
static void periodic_task(void *arg)
{
    const uint16_t *row = (const uint16_t *)arg;
    uint32_t last_wake = 0U;             /* common release time: every period counts from tick 0 */
    for (;;) {
        rtos_log("start (needs %u ms of CPU)", (unsigned)row[COL_WORK_MS]);
        rtos_busy(row[COL_WORK_MS]);                     /* preemptible "computation" */
        rtos_log("done");
        rtos_delay_until(&last_wake, row[COL_PERIOD_MS]);
    }
}

/* The 2-D table arrives as a pointer to rows of NUM_COLS entries; njobs is the row count. */
static void scheduler_init(const uint16_t table[][NUM_COLS], const char *const names[],
                           size_t njobs)
{
    for (size_t i = 0; i < njobs; i++) {
        /* table[i] is row i. RTOS APIs take void *, so the const is cast away here and
         * restored inside the task (it only reads). */
        rtos_task_create(names[i], periodic_task, (void *)table[i], (int)table[i][COL_PRIO], 0U);
        printf("created task %-8s period=%3u ms prio=%u work=%2u ms\n", names[i],
               (unsigned)table[i][COL_PERIOD_MS], (unsigned)table[i][COL_PRIO],
               (unsigned)table[i][COL_WORK_MS]);
    }
}

int main(void)
{
    size_t njobs = sizeof sched_table / sizeof sched_table[0];
    printf("schedule table: %zu rows x %u columns, %zu bytes\n", njobs, (unsigned)NUM_COLS,
           sizeof sched_table);

    scheduler_init(sched_table, job_names, njobs);
    rtos_start(100U);
    rtos_shutdown();
    return 0;
}
