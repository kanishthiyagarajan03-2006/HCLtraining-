/*
 * ============================================================================
 *  Topic   : 22 Passing an Array to a Function
 *  Example : 02 - ADC buffer: read-only (const) analysis vs in-place calibration
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : An array parameter is a pointer, so the callee can read OR write the
 *            caller's elements. "const uint16_t *buf" promises read-only access
 *            (compiler enforced); a plain "uint16_t *buf" says "I will modify it".
 *            A pointer into the middle (&buf[4]) hands over a window of the array.
 *  Embedded use : filtering an ADC buffer in place saves RAM; marking analysis
 *            helpers const lets you pass a lookup table that lives in flash.
 *  Real STM32F4 : HAL_ADC_Start_DMA(&hadc1, (uint32_t *)adc_buf, ADC_BUF_LEN);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_const_readonly_vs_inplace.c -o ex02
 *  Output  : min/max/average of 12 samples, an average of each 4-sample window (made
 *            with sub-array pointers), then offset removal and mV conversion in place
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the window size from 4 to 6 - how many averages are printed?
 *            2) Build with -DDEMO_BUG: why does passing a const table to adc_remove_offset fail?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define WINDOW 4U

/* Tiny deterministic noise source so every run prints the same numbers. */
static uint32_t lcg_next(void)
{
    static uint32_t state = 12345U;
    state = state * 1103515245U + 12345U;       /* unsigned wrap-around is well defined */
    return (state >> 16) & 0x7FFFU;
}

/* ---- read-only helpers: const protects the caller's data ------------------ */
static uint16_t buf_min(const uint16_t *buf, size_t n)
{
    uint16_t m = 0xFFFFU;
    for (size_t i = 0; i < n; i++) {
        if (buf[i] < m) m = buf[i];
    }
    return m;
}

static uint16_t buf_max(const uint16_t *buf, size_t n)
{
    uint16_t m = 0U;
    for (size_t i = 0; i < n; i++) {
        if (buf[i] > m) m = buf[i];
    }
    return m;
}

static uint16_t buf_avg(const uint16_t *buf, size_t n)
{
    if (n == 0U) {
        return 0U;                              /* guard: never divide by zero */
    }
    uint32_t sum = 0U;                          /* 32-bit: 16-bit sums overflow quickly */
    for (size_t i = 0; i < n; i++) {
        sum += buf[i];
    }
    return (uint16_t)(sum / n);
}

/* ---- in-place helpers: no const, the buffer is modified ------------------- */
static void adc_remove_offset(uint16_t *buf, size_t n, uint16_t offset)
{
    for (size_t i = 0; i < n; i++) {
        buf[i] = (buf[i] > offset) ? (uint16_t)(buf[i] - offset) : 0U;   /* saturate at 0 */
    }
}

static void adc_to_mv(uint16_t *buf, size_t n)          /* 12-bit, Vref = 3300 mV */
{
    for (size_t i = 0; i < n; i++) {
        buf[i] = (uint16_t)(((uint32_t)buf[i] * 3300U) / 4095U);
    }
}

static void print_buf(const char *label, const uint16_t *buf, size_t n)
{
    printf("%-14s", label);
    for (size_t i = 0; i < n; i++) {
        printf(" %4u", (unsigned)buf[i]);
    }
    printf("\n");
}

int main(void)
{
    uint16_t adc[12];
    for (size_t i = 0; i < ARRAY_SIZE(adc); i++) {
        adc[i] = (uint16_t)(2000U + lcg_next() % 100U);      /* about 2000..2099 counts */
    }
    adc[5] = 20U;                                            /* one glitch low sample */

    print_buf("raw counts:", adc, ARRAY_SIZE(adc));
    printf("min=%u max=%u avg=%u  (const functions: buffer unchanged)\n",
           (unsigned)buf_min(adc, ARRAY_SIZE(adc)), (unsigned)buf_max(adc, ARRAY_SIZE(adc)),
           (unsigned)buf_avg(adc, ARRAY_SIZE(adc)));

    /* &adc[i] is the address of element i, so the callee sees a WINDOW of the array. */
    printf("average of each %u-sample window:", WINDOW);
    for (size_t i = 0; i + WINDOW <= ARRAY_SIZE(adc); i += WINDOW) {
        printf(" %u", (unsigned)buf_avg(&adc[i], WINDOW));
    }
    printf("\n");

    adc_remove_offset(adc, ARRAY_SIZE(adc), 1900U);          /* zero offset: in place */
    print_buf("minus offset:", adc, ARRAY_SIZE(adc));
    adc_to_mv(adc, ARRAY_SIZE(adc));
    print_buf("in mV:", adc, ARRAY_SIZE(adc));

#ifdef DEMO_BUG
    /* A table in flash is const. Passing it where a writable pointer is expected is
     * flagged by gcc ("discards 'const' qualifier"): the compiler protects your flash. */
    static const uint16_t cal_table[4] = { 1, 2, 3, 4 };
    adc_remove_offset(cal_table, ARRAY_SIZE(cal_table), 1U);
#endif
    static const uint16_t cal_table_ok[4] = { 100, 200, 300, 400 };
    printf("const table accepted by read-only helper: avg=%u\n",
           (unsigned)buf_avg(cal_table_ok, ARRAY_SIZE(cal_table_ok)));
    return 0;
}
