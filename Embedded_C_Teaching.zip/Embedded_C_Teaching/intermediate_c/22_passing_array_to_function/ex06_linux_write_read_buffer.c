/*
 * ============================================================================
 *  Topic   : 22 Passing an Array to a Function
 *  Example : 06 - write(fd, buf, len) / read / fread: arrays as (pointer, length)
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : The POSIX I/O calls are the classic (pointer, byte-count) interface:
 *            the kernel only sees an address, so YOU compute the size with
 *            sizeof where the array is still an array, and you pass it along.
 *            write() may write less than asked, so wrap it in a loop; read()
 *            returns how many bytes it really stored in your array.
 *  Embedded use : an embedded-Linux data logger stores raw sensor samples as a
 *            binary file and later reads them back into a fixed array.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex06_linux_write_read_buffer.c -o ex06
 *  Output  : 8 samples written with write(), read back with read() (compared with memcmp),
 *            then fread() into a smaller array returns only 4 elements; temp files removed
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Pass sizeof(samples) / 2 to write_all() - what does the file contain?
 *            2) Write only 10 bytes and make 'again' 8 elements: what does fread return,
 *               and what does feof() say?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

/* write() can be short (pipe full, signal). Loop until every byte is out. */
static int write_all(int fd, const void *buf, size_t len)
{
    const uint8_t *p = (const uint8_t *)buf;
    while (len > 0U) {
        ssize_t n = write(fd, p, len);
        if (n < 0) {
            if (errno == EINTR) {
                continue;
            }
            return -1;
        }
        p += n;                         /* advance the pointer, shrink the length */
        len -= (size_t)n;
    }
    return 0;
}

int main(void)
{
    uint16_t samples[8] = { 100, 200, 300, 400, 500, 600, 700, 800 };

    char dir[] = "/tmp/ex06_XXXXXX";
    if (mkdtemp(dir) == NULL) {
        perror("mkdtemp");
        return 1;
    }
    char path[64];
    snprintf(path, sizeof path, "%s/samples.bin", dir);

    /* ---- write: sizeof(samples) is correct HERE because samples is a real array ---- */
    int rc = 1;
    int fd = open(path, O_CREAT | O_WRONLY | O_TRUNC, 0600);
    if (fd < 0 || write_all(fd, samples, sizeof samples) != 0) {
        perror("write");
        if (fd >= 0) {
            close(fd);
        }
        goto cleanup;
    }
    close(fd);

    struct stat st;
    if (stat(path, &st) == 0) {
        printf("wrote %zu bytes = %zu samples x %zu bytes\n", (size_t)st.st_size,
               ARRAY_SIZE(samples), sizeof samples[0]);
    }

    /* ---- read(): the kernel fills OUR array and tells us how many bytes it stored ---- */
    uint16_t back[8] = { 0 };
    fd = open(path, O_RDONLY);
    if (fd < 0) {
        perror("open");
        goto cleanup;
    }
    ssize_t got = read(fd, back, sizeof back);
    close(fd);
    printf("read()  returned %zd bytes -> %s\n", got,
           (got == (ssize_t)sizeof back && memcmp(samples, back, sizeof back) == 0)
               ? "identical to the original" : "DIFFERENT");

    /* ---- fread(buf, element_size, count, fp): size and count are separate arguments ---- */
    uint16_t again[4] = { 0 };
    FILE *fp = fopen(path, "rb");
    if (fp == NULL) {
        perror("fopen");
        goto cleanup;
    }
    size_t items = fread(again, sizeof again[0], ARRAY_SIZE(again), fp);
    fclose(fp);
    printf("fread() returned %zu elements: %u %u %u %u (array has room for only %zu)\n", items,
           (unsigned)again[0], (unsigned)again[1], (unsigned)again[2], (unsigned)again[3],
           ARRAY_SIZE(again));

    rc = 0;
cleanup:
    unlink(path);                       /* temp file and directory always disappear */
    rmdir(dir);
    return rc;
}
