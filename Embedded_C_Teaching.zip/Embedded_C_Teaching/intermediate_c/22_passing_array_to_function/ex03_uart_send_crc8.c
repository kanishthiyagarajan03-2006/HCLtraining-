/*
 * ============================================================================
 *  Topic   : 22 Passing an Array to a Function
 *  Example : 03 - uart_send(const uint8_t *buf, size_t n) and a CRC-8 packet
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : The (pointer, length) pair works for any slice of any array: a whole
 *            buffer, a payload inside a packet (&pkt[2]) or a string literal.
 *            Functions that only read take "const uint8_t *"; the one that builds
 *            a packet takes a writable output buffer AND its capacity.
 *  Embedded use : UART/SPI/CAN drivers move byte buffers; a CRC over the payload
 *            slice detects corrupted frames on a noisy wire.
 *  Real STM32F4 : HAL_UART_Transmit(&huart2, pkt, len, 100);
 *                 while (!(USART2->SR & USART_SR_TXE)) {}  USART2->DR = byte;
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_uart_send_crc8.c -o ex03
 *  Output  : CRC-8 self-test (0xF4), a hex dump of the frame "on the wire", an
 *            accepted packet, then a rejected one after one bit is flipped
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Flip a bit in the CRC byte itself, then in pkt[0]: is each frame rejected,
 *               and by which test inside packet_check()?
 *            2) Call packet_build() with a 4-byte output buffer - what status comes back?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define SOF 0x7EU
#define USART_SR_TXE (1U << 7)

/* ---- fake USART: a wire log stands in for the TX pin ---------------------- */
static volatile uint32_t FAKE_USART_SR = USART_SR_TXE;   /* transmit register empty */
static volatile uint32_t FAKE_USART_DR;
static uint8_t wire[64];
static size_t wire_len;

/* Real hardware shifts DR out by itself and sets TXE again. */
static void fake_usart_shift_out(void)
{
    if (wire_len < sizeof wire) {
        wire[wire_len++] = (uint8_t)FAKE_USART_DR;
    }
    FAKE_USART_SR |= USART_SR_TXE;
}

static void uart_putc(uint8_t c)
{
    while ((FAKE_USART_SR & USART_SR_TXE) == 0U) { }     /* wait: TXE */
    FAKE_USART_SR &= ~USART_SR_TXE;
    FAKE_USART_DR = c;
    fake_usart_shift_out();
}

/* Read-only buffer, explicit length: works on arrays, slices and literals. */
static void uart_send(const uint8_t *buf, size_t n)
{
    for (size_t i = 0; i < n; i++) {
        uart_putc(buf[i]);
    }
}

/* CRC-8, polynomial 0x07, init 0x00 (CRC-8/SMBUS). Check value of "123456789" is 0xF4. */
static uint8_t crc8(const uint8_t *buf, size_t n)
{
    uint8_t crc = 0U;
    for (size_t i = 0; i < n; i++) {
        crc ^= buf[i];
        for (int bit = 0; bit < 8; bit++) {
            crc = (crc & 0x80U) ? (uint8_t)((crc << 1) ^ 0x07U) : (uint8_t)(crc << 1);
        }
    }
    return crc;
}

/* Frame: SOF | LEN | payload[LEN] | CRC(LEN+payload). Returns bytes written, 0 on error. */
static size_t packet_build(uint8_t *out, size_t cap, const uint8_t *payload, size_t n)
{
    if (n > 255U || cap < n + 3U) {
        return 0U;                                       /* never overrun the caller's buffer */
    }
    out[0] = SOF;
    out[1] = (uint8_t)n;
    for (size_t i = 0; i < n; i++) {
        out[2 + i] = payload[i];
    }
    out[2 + n] = crc8(&out[1], n + 1U);                  /* slice: starts at LEN, n+1 bytes */
    return n + 3U;
}

static int packet_check(const uint8_t *pkt, size_t n)
{
    if (n < 3U || pkt[0] != SOF || (size_t)pkt[1] + 3U != n) {
        return 0;
    }
    return crc8(&pkt[1], (size_t)pkt[1] + 1U) == pkt[n - 1U];
}

static void hex_dump(const char *label, const uint8_t *buf, size_t n)
{
    printf("%s", label);
    for (size_t i = 0; i < n; i++) {
        printf(" %02X", (unsigned)buf[i]);
    }
    printf("\n");
}

int main(void)
{
    const uint8_t check[] = { '1', '2', '3', '4', '5', '6', '7', '8', '9' };
    printf("crc8(\"123456789\") = 0x%02X (expected 0xF4)\n", (unsigned)crc8(check, sizeof check));

    const uint8_t payload[] = { 0x01, 0x17, 0x2A };      /* e.g. cmd, temperature, humidity */
    uint8_t pkt[16];
    size_t len = packet_build(pkt, sizeof pkt, payload, sizeof payload);
    hex_dump("packet built  :", pkt, len);

    uart_send(pkt, len);                                 /* whole array */
    hex_dump("on the wire   :", wire, wire_len);

    printf("packet_check on the clean frame : %s\n", packet_check(pkt, len) ? "ACCEPT" : "REJECT");
    pkt[3] ^= 0x04U;                                     /* one bit flipped by line noise */
    printf("packet_check after 1 bit flip   : %s\n", packet_check(pkt, len) ? "ACCEPT" : "REJECT");

    printf("packet_build into a 4-byte buffer returns %zu (refused, no overrun)\n",
           packet_build(pkt, 4U, payload, sizeof payload));

    uart_send((const uint8_t *)"OK\r\n", 4U);             /* a string literal is an array too */
    hex_dump("after literal :", &wire[len], wire_len - len);   /* slice of the wire log */
    return 0;
}
