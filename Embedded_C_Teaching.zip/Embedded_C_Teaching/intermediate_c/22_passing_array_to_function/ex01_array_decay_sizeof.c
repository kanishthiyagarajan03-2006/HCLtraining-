/*
 * ============================================================================
 *  Topic   : 22 Passing an Array to a Function
 *  Example : 01 - Array decay: sizeof outside vs inside, and why you pass the length
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : When an array name is passed to a function it "decays" into a pointer
 *            to its first element. The callee gets an address only: no size, and
 *            sizeof(param) is the size of a POINTER. Pass the element count as a
 *            second argument. Writing buf[] or buf[8] in a parameter list changes
 *            nothing - all three prototypes mean "const uint16_t *buf".
 *  Embedded use : every driver that takes a buffer (uart_send, spi_transfer,
 *            adc_read_dma) has a (pointer, length) pair for exactly this reason.
 *  Real STM32F4 : HAL_UART_Transmit(&huart2, tx_buf, sizeof tx_buf, 100);
 *                 (sizeof is taken where the real array is visible, not in the HAL)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_array_decay_sizeof.c -o ex01
 *  Output  : sizeof(samples)=16 in main but only the pointer size inside the callee;
 *            a callee writes into the caller's array; a struct-wrapped array is copied
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Call sum_ptr(samples, 4) - which elements are added?
 *            2) Build with -DDEMO_BUG and read the gcc warning about sizeof of a pointer.
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))   /* valid ONLY on a real array */

/* These three prototypes are the same function type to the compiler. */
static uint32_t sum_ptr(const uint16_t *buf, size_t n);
static uint32_t sum_open(const uint16_t buf[], size_t n);
static uint32_t sum_sized(const uint16_t buf[8], size_t n);   /* the 8 is ignored */

static uint32_t sum_ptr(const uint16_t *buf, size_t n)
{
    uint32_t sum = 0;
    for (size_t i = 0; i < n; i++) {
        sum += buf[i];
    }
    return sum;
}

static uint32_t sum_open(const uint16_t buf[], size_t n) { return sum_ptr(buf, n); }
static uint32_t sum_sized(const uint16_t buf[8], size_t n) { return sum_ptr(buf, n); }

/* What does the callee know about the array it was given? Only an address. */
static void report_inside(const uint16_t *buf, size_t n)
{
    printf("  inside callee: sizeof(buf)  = %zu (just a pointer; 4 on Cortex-M)\n", sizeof(buf));
    printf("  inside callee: sizeof(*buf) = %zu (one element)\n", sizeof(*buf));
    printf("  inside callee: n from the caller = %zu\n", n);
#ifdef DEMO_BUG
    /* BUG: the "element count" of a pointer is 8/2 = 4 on a PC (2 on a 32-bit MCU), not 8.
     * gcc flags it with -Wsizeof-pointer-div; ignoring the warning silently skips samples. */
    printf("  wrong ARRAY_SIZE inside callee = %zu\n", ARRAY_SIZE(buf));
#endif
}

/* The callee writes through the decayed pointer: the CALLER's array changes. */
static void clear_first_half(uint16_t buf[], size_t n)
{
    for (size_t i = 0; i < n / 2; i++) {
        buf[i] = 0;
    }
}

/* An array wrapped in a struct is NOT decayed: the whole thing is copied. */
typedef struct {
    uint16_t v[8];
} block_t;

static void zero_block_copy(block_t b)       /* changes only its private copy */
{
    for (size_t i = 0; i < ARRAY_SIZE(b.v); i++) {
        b.v[i] = 0;
    }
}

int main(void)
{
    uint16_t samples[8] = { 10, 20, 30, 40, 50, 60, 70, 80 };

    printf("main: sizeof(samples) = %zu bytes, ARRAY_SIZE = %zu elements\n",
           sizeof(samples), ARRAY_SIZE(samples));
    printf("samples == &samples[0]? %s\n", (void *)samples == (void *)&samples[0] ? "yes" : "no");
    report_inside(samples, ARRAY_SIZE(samples));

    printf("sum via three prototypes: %u %u %u\n",
           (unsigned)sum_ptr(samples, ARRAY_SIZE(samples)),
           (unsigned)sum_open(samples, ARRAY_SIZE(samples)),
           (unsigned)sum_sized(samples, ARRAY_SIZE(samples)));
    printf("sum of first 4 only (same array, smaller n): %u\n", (unsigned)sum_ptr(samples, 4));

    clear_first_half(samples, ARRAY_SIZE(samples));
    printf("after clear_first_half (caller's array changed): ");
    for (size_t i = 0; i < ARRAY_SIZE(samples); i++) {
        printf("%u ", (unsigned)samples[i]);
    }
    printf("\n");

    block_t blk = { { 1, 2, 3, 4, 5, 6, 7, 8 } };
    zero_block_copy(blk);
    printf("struct-wrapped array after zero_block_copy: blk.v[0] = %u (only the copy was zeroed)\n",
           (unsigned)blk.v[0]);
    printf("sizeof(block_t) = %zu bytes were copied for that call\n", sizeof(blk));
    return 0;
}
