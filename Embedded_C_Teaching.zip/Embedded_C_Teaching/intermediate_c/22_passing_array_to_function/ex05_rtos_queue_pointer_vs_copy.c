/*
 * ============================================================================
 *  Topic   : 22 Passing an Array to a Function
 *  Example : 05 - RTOS queue: send the array by COPY or send a POINTER to it
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A queue copies the item you give it. If the item is the whole sample
 *            block, the receiver gets a stable private copy (safe, costs bytes).
 *            If the item is just a POINTER to the block, nothing is copied - but
 *            both tasks now share the array, so ownership must be handed over
 *            explicitly (a free-buffer queue) or the sender will overwrite it.
 *  Embedded use : FreeRTOS xQueueSend() always copies. For big buffers (audio,
 *            camera lines, packets) real code queues pointers to buffers from a pool.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_rtos_queue_pointer_vs_copy.c -o ex05
 *  Output  : part A: the copy keeps frame N while the pointer shows the OVERWRITTEN
 *            data; part B: the free/full pool gives correct frames every time
 * ----------------------------------------------------------------------------
 *  Try it  : 1) In part A, increase rtos_delay(50) in the producer - does the bug go away?
 *            2) Put only ONE buffer in free_q (loop bound 2 -> 1) - how does the log change?
 * ============================================================================
 */
#include "mini_rtos.h"

#define N 16U                                     /* samples per block */

typedef struct {
    uint16_t s[N];
} block_t;

static block_t shared;                            /* part A: ONE buffer reused by the sender */
static block_t pool[2];                           /* part B: two buffers that change owners */
static rtos_queue_t *copy_q, *ptr_q, *free_q, *full_q;

static void fill(block_t *b, uint16_t frame)      /* pretend DMA: 100*frame + index */
{
    for (size_t i = 0; i < N; i++) {
        b->s[i] = (uint16_t)(100U * frame + i);
    }
}

static void producer(void *arg)
{
    (void)arg;
    /* ---- Part A: the dangerous way to share a single buffer ---- */
    for (uint16_t f = 1; f <= 2; f++) {
        fill(&shared, f);
        rtos_queue_send(copy_q, &shared, RTOS_WAIT_FOREVER);        /* copies the whole block */
        const block_t *p = &shared;
        rtos_queue_send(ptr_q, &p, RTOS_WAIT_FOREVER);              /* copies one POINTER     */
        fill(&shared, (uint16_t)(f + 1U));                          /* DMA restarts at once   */
        rtos_log("A: sent frame %u by copy and by pointer, buffer already refilled", f);
        rtos_delay(50);
    }
    /* ---- Part B: ownership hand-over with a free queue and a full queue ---- */
    for (uint16_t f = 10; f < 13; f++) {
        block_t *b;
        rtos_queue_recv(free_q, &b, RTOS_WAIT_FOREVER);             /* blocks until one is free */
        fill(b, f);
        rtos_log("B: filled pool buffer %d with frame %u", (int)(b - pool), f);
        rtos_queue_send(full_q, &b, RTOS_WAIT_FOREVER);             /* ownership moves away */
    }
}

static void consumer(void *arg)
{
    (void)arg;
    for (int i = 0; i < 2; i++) {
        block_t copy;
        const block_t *p;
        rtos_queue_recv(copy_q, &copy, RTOS_WAIT_FOREVER);
        rtos_queue_recv(ptr_q, &p, RTOS_WAIT_FOREVER);
        rtos_log("A: copy[0]=%u pointer[0]=%u  %s", copy.s[0], p->s[0],
                 copy.s[0] == p->s[0] ? "same" : "MISMATCH - the pointer saw the new frame");
    }
    for (int i = 0; i < 3; i++) {
        block_t *b;
        rtos_queue_recv(full_q, &b, RTOS_WAIT_FOREVER);
        rtos_log("B: processing pool buffer %d, s[0]=%u (still intact)", (int)(b - pool), b->s[0]);
        rtos_busy(20);                                              /* pretend to crunch data */
        rtos_queue_send(free_q, &b, RTOS_WAIT_FOREVER);             /* give the buffer back */
    }
}

int main(void)
{
    copy_q = rtos_queue_create(2, sizeof(block_t));                 /* item = whole block */
    ptr_q = rtos_queue_create(2, sizeof(block_t *));                /* item = one pointer */
    free_q = rtos_queue_create(2, sizeof(block_t *));
    full_q = rtos_queue_create(2, sizeof(block_t *));
    if (copy_q == NULL || ptr_q == NULL || free_q == NULL || full_q == NULL) {
        return 1;
    }
    printf("queue item sizes: copy_q = %zu bytes, ptr_q = %zu bytes (4 on Cortex-M)\n",
           sizeof(block_t), sizeof(block_t *));
    for (size_t i = 0; i < 2; i++) {
        block_t *b = &pool[i];
        rtos_queue_send(free_q, &b, RTOS_NO_WAIT);                  /* both buffers start free */
    }

    rtos_task_create("producer", producer, NULL, 2, 0U);
    rtos_task_create("consumer", consumer, NULL, 1, 0U);
    rtos_start(1000U);

    rtos_queue_delete(copy_q);
    rtos_queue_delete(ptr_q);
    rtos_queue_delete(free_q);
    rtos_queue_delete(full_q);
    rtos_shutdown();
    return 0;
}
