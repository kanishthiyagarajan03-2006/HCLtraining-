# Topic 22 - Passing an Array to a Function
**Suggested session:** 60 min | **Prerequisite topics:** 15 Arrays, 17 Pointers, 21 Call by Value vs Call by Address

Students should leave knowing that an array argument becomes a pointer to its first element, so the callee has no size
information and can modify the caller's data; therefore every buffer API is a (pointer, length) pair and read-only
buffers are `const`. The examples move from the decay rules to analysis vs in-place processing, then to realistic
driver code (UART send with CRC), DMA double buffering, RTOS queues and Linux file I/O.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_array_decay_sizeof.c` | MCU | `sizeof` outside vs inside a function, three equal prototypes, callee writes into the caller's array, struct-wrapped array is copied |
| 02 | `ex02_const_readonly_vs_inplace.c` | MCU | `const uint16_t *` analysis helpers vs in-place offset/scale, passing `&buf[i]` windows, const tables in flash |
| 03 | `ex03_uart_send_crc8.c` | MCU | `uart_send(const uint8_t *, size_t)`, building a framed packet with a capacity check, CRC-8 over a sub-slice |
| 04 | `ex04_dma_ping_pong_halves.c` | MCU | Half/full-transfer callbacks receive a pointer to one half of a circular DMA buffer |
| 05 | `ex05_rtos_queue_pointer_vs_copy.c` | RTOS | Queue of whole blocks (copy) vs queue of pointers (zero copy), the overwrite hazard and a free/full buffer pool |
| 06 | `ex06_linux_write_read_buffer.c` | LINUX | `write(fd, buf, len)` loop, `read` into an array, `fread(buf, size, count, fp)` with partial results |

## Teaching notes
* Draw the call: the array stays in the caller's frame, only an address crosses the boundary. `sizeof(param)` is the pointer size (4 bytes on Cortex-M, 8 on the PC).
* `void f(int a[8])`, `void f(int a[])` and `void f(int *a)` are the same declaration. The 8 is documentation only.
* `ARRAY_SIZE(x)` is only correct where `x` is a real array. gcc catches the misuse with `-Wsizeof-pointer-div` (ex01 `DEMO_BUG`).
* Always pass the length as `size_t` and check capacity before writing (ex03 `packet_build` returns 0 instead of overrunning).
* A sub-array is just `&buf[k]` plus a smaller length: windows, payload slices and DMA halves all use this.
* Sharing a buffer by pointer also shares its lifetime and ownership: ex05 shows the writer overwriting data the reader still needs.

## Live-demo tips
* ex01: compile once normally, once with `-DDEMO_BUG` (without `-Werror`) to show the warning text.
* ex02: `-DDEMO_BUG` passes a `const` table to a writable parameter - read the "discards const qualifier" message together.
* ex04: change `HALF` to 4 or move the spike (sample 21) and ask which callback reports it.
