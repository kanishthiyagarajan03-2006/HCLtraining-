/*
 * ============================================================================
 *  Topic   : 22 Passing an Array to a Function
 *  Example : 04 - DMA ping-pong buffer: callbacks receive a pointer to one HALF
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : One big array is split in two halves. While the DMA fills one half,
 *            the CPU processes the other. The callback is handed a pointer to the
 *            start of the finished half (&buf[0] or &buf[HALF]) plus the half
 *            length - a slice of the array passed without any copying.
 *  Embedded use : continuous ADC / I2S / UART-RX capture with no gaps and no
 *            per-sample interrupts (circular DMA with half- and full-transfer IRQs).
 *  Real STM32F4 : HAL_ADC_Start_DMA(&hadc1, (uint32_t *)dma_buf, 2 * HALF);
 *                 HAL_ADC_ConvHalfCpltCallback() and HAL_ADC_ConvCpltCallback()
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_dma_ping_pong_halves.c -o ex04
 *  Output  : five callbacks alternating between half 0 and half 1, each printing
 *            average and peak of its 8 samples; a spike in the 3rd half is flagged
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change HALF to 4 and predict how many callbacks you will see.
 *            2) Move the spike to sample 5 - which callback reports it?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define HALF 8U                                   /* samples per half buffer */
#define TOTAL_SAMPLES 40U                         /* how long the fake ADC runs */

typedef void (*half_cb_t)(const uint16_t *half, size_t n);

static uint16_t dma_buf[2U * HALF];               /* the circular DMA target */

/* Fake analog input: slow ramp plus a spike so the callbacks have something to find. */
static uint16_t fake_adc_input(uint32_t i)
{
    uint16_t v = (uint16_t)(1000U + 10U * (i % 16U));
    if (i == 21U) {
        v = 4000U;                                /* glitch in the 3rd half */
    }
    return v;
}

/* Models the DMA controller: writes samples, raises half/full callbacks (the IRQs). */
static void fake_dma_run(half_cb_t on_half, half_cb_t on_full)
{
    size_t pos = 0U;
    for (uint32_t i = 0U; i < TOTAL_SAMPLES; i++) {
        dma_buf[pos++] = fake_adc_input(i);       /* DMA writes with no CPU involvement */
        if (pos == HALF) {
            on_half(&dma_buf[0], HALF);           /* half 0 is complete, DMA now fills half 1 */
        } else if (pos == 2U * HALF) {
            on_full(&dma_buf[HALF], HALF);        /* half 1 is complete, DMA wraps to half 0 */
            pos = 0U;
        }
    }
}

static unsigned callbacks;

/* Same processing for both halves: it only sees "a pointer and a length". */
static void process_half(const uint16_t *half, size_t n)
{
    uint32_t sum = 0U;
    uint16_t peak = 0U;
    for (size_t i = 0; i < n; i++) {
        sum += half[i];
        if (half[i] > peak) peak = half[i];
    }
    /* Pointer subtraction gives the element offset inside dma_buf: 0 or HALF. */
    unsigned which = (unsigned)(half - dma_buf) / HALF;
    printf("callback %u: half %u (dma_buf[%2zu..%2zu]) avg=%4u peak=%4u%s\n", ++callbacks, which,
           (size_t)(half - dma_buf), (size_t)(half - dma_buf) + n - 1U, (unsigned)(sum / n),
           (unsigned)peak, peak > 3000U ? "  <-- spike!" : "");
}

/* The two "interrupt" entry points just forward the right half to the shared worker. */
static void half_transfer_cb(const uint16_t *half, size_t n) { process_half(half, n); }
static void full_transfer_cb(const uint16_t *half, size_t n) { process_half(half, n); }

int main(void)
{
    printf("dma_buf holds %u samples = 2 halves of %u\n", 2U * HALF, HALF);
    fake_dma_run(half_transfer_cb, full_transfer_cb);
    printf("done: %u callbacks for %u samples\n", callbacks, TOTAL_SAMPLES);
    return 0;
}
