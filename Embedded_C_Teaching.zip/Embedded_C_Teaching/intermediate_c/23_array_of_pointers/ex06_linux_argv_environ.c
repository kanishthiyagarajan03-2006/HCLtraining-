/*
 * ============================================================================
 *  Topic   : 23 Array of Pointers
 *  Example : 06 - argv and environ: two NULL-terminated arrays of char pointers
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : main(int argc, char *argv[]) receives an ARRAY OF POINTERS to strings.
 *            argv[0] is the program name, argv[argc] is NULL, so you can walk it
 *            with a pointer ("for (char **p = argv; *p; p++)"). The environment
 *            (environ) is the same shape: char *environ[] = { "NAME=value", ..., NULL }.
 *            "char *argv[]" and "char **argv" are the same parameter type.
 *  Embedded use : an embedded-Linux tool takes its settings from the command line and
 *            from environment variables ("flash_tool --port /dev/ttyUSB0 --baud 115200").
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex06_linux_argv_environ.c -o ex06
 *            then try:  ./ex06 --port /dev/ttyUSB1 --baud 9600 -v
 *  Output  : the real command line (or a simulated one when none is given) parsed into
 *            options, plus the BOARD_* variables found by scanning environ
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Run  BOARD_ID=custom ./ex06 -v  - which value does getenv() return?
 *            2) Pass --baud abc - how does the program notice the bad number?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern char **environ;                       /* array of "NAME=value" strings, NULL at the end */

typedef struct {
    const char *port;
    long        baud;
    int         verbose;
} opts_t;

/* argv is an array of pointers: each argv[i] points at one argument string. */
static int parse_args(int argc, char *argv[], opts_t *o)
{
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-v") == 0) {
            o->verbose = 1;
        } else if (strcmp(argv[i], "--port") == 0 && i + 1 < argc) {
            o->port = argv[++i];             /* just copy the pointer, no string copy */
        } else if (strcmp(argv[i], "--baud") == 0 && i + 1 < argc) {
            char *end;
            long b = strtol(argv[++i], &end, 10);
            if (*end != '\0' || b <= 0) {
                printf("bad baud rate \"%s\"\n", argv[i]);
                return -1;
            }
            o->baud = b;
        } else {
            printf("unknown argument \"%s\"\n", argv[i]);
            return -1;
        }
    }
    return 0;
}

int main(int argc, char *argv[])
{
    const char *slash = strrchr(argv[0], '/');
    printf("argc = %d, program = %s\n", argc, slash ? slash + 1 : argv[0]);
    printf("argv[argc] is NULL: %s\n", argv[argc] == NULL ? "yes" : "no");

    /* No arguments given (for example under an automatic test)? Use a canned line. */
    char *demo_argv[] = { "flash_tool", "--port", "/dev/ttyUSB0", "--baud", "115200", "-v", NULL };
    char **args = argv;
    int nargs = argc;
    if (argc == 1) {
        printf("(no arguments - using simulated command line)\n");
        args = demo_argv;
        nargs = (int)(sizeof demo_argv / sizeof demo_argv[0]) - 1;
    }

    int idx = 0;
    for (char **p = args; *p != NULL; p++) {      /* walk the array until the NULL sentinel */
        printf("  args[%d] = \"%s\"\n", idx++, *p);
    }

    opts_t opt = { "/dev/ttyUSB0", 9600L, 0 };    /* defaults */
    if (parse_args(nargs, args, &opt) != 0) {
        return 1;                                 /* exit status 1 = usage error */
    }
    printf("port=%s baud=%ld verbose=%d\n", opt.port, opt.baud, opt.verbose);

    /* The environment is a second array of pointers. Add two entries, then scan for them. */
    if (setenv("BOARD_ID", "nucleo-f401", 0) != 0 || setenv("BOARD_REV", "C", 0) != 0) {
        return 1;                                 /* 0 = do not overwrite a value from the shell */
    }
    for (char **e = environ; *e != NULL; e++) {
        if (strncmp(*e, "BOARD_", 6) == 0) {
            printf("  environ entry: %s\n", *e);
        }
    }

    const char *id = getenv("BOARD_ID");          /* getenv returns a pointer into environ */
    const char *none = getenv("SURELY_NOT_SET_12345");
    printf("getenv(BOARD_ID) = %s\n", id ? id : "(not set)");
    printf("getenv(SURELY_NOT_SET_12345) = %s\n", none ? none : "(not set)");
    return 0;
}
