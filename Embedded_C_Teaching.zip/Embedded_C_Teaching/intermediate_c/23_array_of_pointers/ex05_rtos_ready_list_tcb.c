/*
 * ============================================================================
 *  Topic   : 23 Array of Pointers
 *  Example : 05 - RTOS ready lists: an array of TCB pointers indexed by priority
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : ready_list[p] is a pointer to the first task control block (TCB) that
 *            is ready at priority p; TCBs at the same priority are chained with
 *            "next". An array of pointers indexed by priority turns "find the
 *            runnable task" into an array lookup. A bitmap of non-empty lists plus
 *            a count-leading-zeros instruction finds the top priority in O(1).
 *  Embedded use : the core of every preemptive scheduler: the head of the highest
 *            non-empty list runs; same-priority tasks rotate at every tick. FreeRTOS
 *            has "List_t pxReadyTasksLists[configMAX_PRIORITIES]" and picks the top
 *            priority with uxTopReadyPriority (+ CLZ on Cortex-M).
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_rtos_ready_list_tcb.c -o ex05
 *  Output  : ready lists printed as arrays of chains, then ten ticks showing which task
 *            runs while uart (prio 2) and sensor (prio 3) become ready and block again
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a third prio-1 task "logger2" at tick 0 - how does the rotation change?
 *            2) Make the sensor ready at tick 1 instead of 4 - who is starved, and why?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define NUM_PRIO 4U                       /* priorities 0 (idle) .. 3 (highest) */

typedef struct tcb {
    const char *name;
    uint8_t     prio;
    struct tcb *next;                     /* next ready task at the same priority */
} tcb_t;

static tcb_t   *ready_list[NUM_PRIO];     /* ARRAY OF POINTERS: head of each priority's chain */
static uint32_t ready_bitmap;             /* bit p set  <=>  ready_list[p] != NULL */

static void ready_add(tcb_t *t)           /* append at the tail: FIFO inside one priority */
{
    t->next = NULL;
    if (ready_list[t->prio] == NULL) {
        ready_list[t->prio] = t;
    } else {
        tcb_t *last = ready_list[t->prio];
        while (last->next != NULL) {
            last = last->next;
        }
        last->next = t;
    }
    ready_bitmap |= (1U << t->prio);
}

static void ready_remove(tcb_t *t)        /* the task blocks (delay, queue, semaphore) */
{
    tcb_t *prev = NULL;
    tcb_t *cur = ready_list[t->prio];
    while (cur != NULL && cur != t) {
        prev = cur;
        cur = cur->next;
    }
    if (cur == NULL) {
        return;                           /* was not ready */
    }
    if (prev == NULL) {
        ready_list[t->prio] = cur->next;
    } else {
        prev->next = cur->next;
    }
    cur->next = NULL;
    if (ready_list[t->prio] == NULL) {
        ready_bitmap &= ~(1U << t->prio);
    }
}

/* Highest set bit = highest non-empty priority. Cortex-M has a CLZ instruction for this. */
static tcb_t *pick_next(void)
{
    if (ready_bitmap == 0U) {
        return NULL;
    }
    unsigned top = 31U - (unsigned)__builtin_clz(ready_bitmap);
    return ready_list[top];               /* head of the list = next to run */
}

static void rotate(unsigned prio)         /* round robin: head goes to the back */
{
    tcb_t *head = ready_list[prio];
    if (head != NULL && head->next != NULL) {
        ready_remove(head);
        ready_add(head);
    }
}

static void dump_lists(void)
{
    for (unsigned p = NUM_PRIO; p-- > 0U; ) {
        printf("  ready_list[%u] -> ", p);
        if (ready_list[p] == NULL) {
            printf("NULL");
        }
        for (const tcb_t *t = ready_list[p]; t != NULL; t = t->next) {
            printf("%s%s", t->name, t->next ? " -> " : "");
        }
        printf("\n");
    }
}

static void print_bits(uint32_t v)
{
    for (unsigned b = NUM_PRIO; b-- > 0U; ) {
        putchar(((v >> b) & 1U) ? '1' : '0');
    }
}

static tcb_t idle   = { "idle",   0U, NULL };
static tcb_t blink  = { "blink",  1U, NULL };
static tcb_t logger = { "logger", 1U, NULL };
static tcb_t uart   = { "uart",   2U, NULL };
static tcb_t sensor = { "sensor", 3U, NULL };

/* Things that happen in the system: interrupts wake tasks, tasks block themselves. */
static void system_events(unsigned tick)
{
    switch (tick) {
    case 0:
        ready_add(&idle);
        ready_add(&blink);
        ready_add(&logger);
        printf("tick 0: boot, three tasks ready\n");
        dump_lists();
        break;
    case 2:
        ready_add(&uart);
        printf("tick 2: UART RX interrupt makes uart ready\n");
        break;
    case 4:
        ready_add(&sensor);
        printf("tick 4: sensor timer expired, sensor ready\n");
        dump_lists();
        break;
    case 5:
        ready_remove(&sensor);
        printf("tick 5: sensor finished and blocks\n");
        break;
    case 7:
        ready_remove(&uart);
        printf("tick 7: uart queue empty, uart blocks\n");
        break;
    default:
        break;
    }
}

int main(void)
{
    for (unsigned tick = 0U; tick < 10U; tick++) {
        system_events(tick);

        tcb_t *run = pick_next();
        printf("  tick %u  bitmap=", tick);
        print_bits(ready_bitmap);
        printf("  runs: %-6s (prio %u)\n", run->name, (unsigned)run->prio);
        rotate(run->prio);                /* equal-priority peers take turns */
    }
    return 0;
}
