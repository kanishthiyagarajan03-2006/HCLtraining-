/*
 * ============================================================================
 *  Topic   : 23 Array of Pointers
 *  Example : 03 - LED bar spread over three ports using arrays of register pointers
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Instead of copy-pasting GPIOB->ODR, GPIOC->ODR, GPIOD->ODR, keep their
 *            ADDRESSES in an array and loop over it. "volatile uint32_t *const odr[]"
 *            reads: an array of constant pointers to volatile 32-bit registers.
 *            An array of pointers can be passed to a function like any other array.
 *  Embedded use : boards route LEDs, chip-selects or relays to pins on DIFFERENT
 *            ports; a table of port pointers plus a pin table gives one driver loop.
 *  Real STM32F4 : static GPIO_TypeDef *const ports[] = { GPIOB, GPIOC, GPIOD };
 *                 (on hardware GPIOx are constant addresses, so the table sits in flash)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_array_of_register_pointers.c -o ex03
 *  Output  : a back-and-forth chaser on LEDs PB0, PC13, PD12; PB5 (not an LED) stays high
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a fourth LED on PA5 (extend all three tables) - does the loop change?
 *            2) Print the three register addresses with %p - how far apart are they?
 * ============================================================================
 */
#include "hw_sim.h"

#define NUM_LEDS 3U

static const uint8_t led_pin[NUM_LEDS] = { 0U, 13U, 12U };    /* PB0, PC13, PD12 */

/* Array parameter = pointer to the first element, so this is "pointer to const pointer". */
static void leds_write(volatile uint32_t *const odr[], size_t n, uint32_t pattern)
{
    for (size_t i = 0; i < n; i++) {
        if ((pattern >> i) & 1U) {
            *odr[i] |= (1U << led_pin[i]);      /* *odr[i] is the register itself */
        } else {
            *odr[i] &= ~(1U << led_pin[i]);
        }
    }
}

int main(void)
{
    /* Local arrays: in the simulator GPIOB is a function call, not a constant.
     * On a real STM32 these two lines could be 'static const' and live in flash. */
    GPIO_TypeDef *const ports[NUM_LEDS] = { GPIOB, GPIOC, GPIOD };
    volatile uint32_t *const odr[NUM_LEDS] = { &GPIOB->ODR, &GPIOC->ODR, &GPIOD->ODR };
    const uint32_t clock_bit[NUM_LEDS] = { RCC_AHB1ENR_GPIOBEN, RCC_AHB1ENR_GPIOCEN,
                                           RCC_AHB1ENR_GPIODEN };

    /* One loop configures all three ports: clock on, pin as push-pull output. */
    for (size_t i = 0; i < NUM_LEDS; i++) {
        RCC->AHB1ENR |= clock_bit[i];
        ports[i]->MODER &= ~(3U << (led_pin[i] * 2U));
        ports[i]->MODER |=  (1U << (led_pin[i] * 2U));
    }

    GPIOB->ODR |= (1U << 5);                    /* bystander pin: must never change */
    leds_write(odr, NUM_LEDS, 0U);

    /* Back-and-forth chaser: bit i of the pattern drives LED i. */
    static const uint8_t order[] = { 0, 1, 2, 1, 0, 1, 2, 1 };
    for (size_t step = 0; step < sizeof order; step++) {
        leds_write(odr, NUM_LEDS, 1U << order[step]);
        sim_delay_ms(200);
        uint32_t seen = 0U;                     /* read the LEDs back through the same table */
        for (size_t i = 0; i < NUM_LEDS; i++) {
            seen |= ((*odr[i] >> led_pin[i]) & 1U) << i;
        }
        sim_show_leds("PD12 PC13 PB0  ", seen, NUM_LEDS);
    }

    leds_write(odr, NUM_LEDS, 0U);
    printf("LEDs off. Register view through the pointer table:\n");
    sim_show_port("GPIOB", ports[0]);
    sim_show_port("GPIOC", ports[1]);
    sim_show_port("GPIOD", ports[2]);
    printf("PB5 bystander still high: %s\n", (GPIOB->ODR & (1U << 5)) ? "yes" : "NO!");
    return 0;
}
