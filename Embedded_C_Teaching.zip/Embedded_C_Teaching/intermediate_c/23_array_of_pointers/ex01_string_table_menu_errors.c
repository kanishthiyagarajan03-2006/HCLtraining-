/*
 * ============================================================================
 *  Topic   : 23 Array of Pointers
 *  Example : 01 - Menu and error-text tables: const char *const names[]
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : An array of pointers to strings is a "ragged" table: each slot holds
 *            only an address, and every string is exactly as long as it needs to
 *            be. A 2-D char array wastes the unused tail of every row. Writing
 *            "const char *const" makes both the characters and the table itself
 *            read-only, so the compiler can place it in flash.
 *  Embedded use : LCD menus, UART help text, error-code-to-text and language tables
 *            cost flash only; indexing by an enum keeps them fast and readable.
 *  Real STM32F4 : static const char *const menu[] = { "LED", "ADC", ... };  // .rodata in flash
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_string_table_menu_errors.c -o ex01
 *  Output  : the menu printed with ARRAY_SIZE, error texts looked up by enum with a
 *            bounds check, and a flash-size comparison of pointer table vs char[][]
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add an item "5) Calibrate" to the menu - must the loop change? Why not?
 *            2) Make err_text() return the table entry for code 99. Why is the check needed?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

/* Each element is a pointer to a string literal; the two const keywords mean:
 *   const char  *const  menu[]
 *   ^^^^^^^^^^  ^^^^^^   - characters are read-only, and the pointers cannot be re-pointed. */
static const char *const menu[] = {
    "1) Set LED",
    "2) Read ADC",
    "3) Show firmware version",
    "4) Reboot",
};

typedef enum { ERR_NONE, ERR_TIMEOUT, ERR_CRC, ERR_BUSY, ERR_COUNT } err_t;

/* Designated initialisers tie each text to its enum value: reordering stays safe. */
static const char *const err_names[ERR_COUNT] = {
    [ERR_NONE]    = "no error",
    [ERR_TIMEOUT] = "peripheral timeout",
    [ERR_CRC]     = "CRC mismatch",
    [ERR_BUSY]    = "bus busy",
};

static const char *err_text(int code)
{
    if (code < 0 || code >= (int)ERR_COUNT) {
        return "unknown error";                     /* never index outside the table */
    }
    return err_names[code];
}

int main(void)
{
    printf("--- menu (%zu items) ---\n", ARRAY_SIZE(menu));
    for (size_t i = 0; i < ARRAY_SIZE(menu); i++) {
        printf("  %s\n", menu[i]);
    }

    printf("--- error texts ---\n");
    int codes[] = { ERR_NONE, ERR_CRC, ERR_BUSY, 99 };
    for (size_t i = 0; i < ARRAY_SIZE(codes); i++) {
        printf("  code %2d -> %s\n", codes[i], err_text(codes[i]));
    }

    /* Flash cost of the same four strings stored two different ways. The pointer table
     * pays one pointer per row but no padding: it wins more as string lengths differ. */
    size_t chars = 0;
    size_t longest = 0;
    for (size_t i = 0; i < ARRAY_SIZE(menu); i++) {
        size_t len = strlen(menu[i]) + 1U;           /* +1 for the '\0' terminator */
        chars += len;
        if (len > longest) longest = len;
    }
    size_t ptr_table = ARRAY_SIZE(menu) * sizeof(char *) + chars;
    size_t fixed_2d = ARRAY_SIZE(menu) * longest;
    printf("--- flash cost ---\n");
    printf("  pointer table: %zu pointers x %zu bytes + %zu chars = %zu bytes\n",
           ARRAY_SIZE(menu), sizeof(char *), chars, ptr_table);
    printf("  char[%zu][%zu]  : every row padded to the longest string = %zu bytes\n",
           ARRAY_SIZE(menu), longest, fixed_2d);
    printf("  (with 4-byte Cortex-M pointers the table costs %zu bytes)\n",
           ARRAY_SIZE(menu) * 4U + chars);

    /* Lengths differ per row: the table is "ragged" but every access is still menu[i]. */
    printf("  strlen of each item:");
    for (size_t i = 0; i < ARRAY_SIZE(menu); i++) {
        printf(" %zu", strlen(menu[i]));
    }
    printf("\n");
    return 0;
}
