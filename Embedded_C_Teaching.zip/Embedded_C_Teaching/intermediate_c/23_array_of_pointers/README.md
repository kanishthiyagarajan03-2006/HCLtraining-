# Topic 23 - Array of Pointers
**Suggested session:** 60 min | **Prerequisite topics:** 15 Arrays, 16 Strings, 17 Pointers

Students should leave knowing that an array of pointers is a table of addresses: to strings, to functions, to registers
or to records. The examples go from read-only string tables in flash, through the interrupt vector table (array of
function pointers) and tables of register pointers, to sorting pointers instead of big structs, an RTOS ready list and the
`argv`/`environ` arrays every Linux program receives.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_string_table_menu_errors.c` | MCU | `const char *const names[]`, designated initialisers by enum, bounds-checked lookup, pointer table vs `char[][N]` size |
| 02 | `ex02_isr_vector_table.c` | MCU | `void (*const vectors[N])(void)`, NULL slots, `Default_Handler`, dispatch by IRQ number |
| 03 | `ex03_array_of_register_pointers.c` | MCU | `GPIO_TypeDef *const ports[]` and `volatile uint32_t *const odr[]`: one loop drives LEDs on three ports |
| 04 | `ex04_sort_pointers_not_structs.c` | MCU | Sort an array of pointers to records: multiple sorted views, table untouched, bytes moved compared |
| 05 | `ex05_rtos_ready_list_tcb.c` | RTOS | `tcb_t *ready_list[NUM_PRIO]`, priority bitmap + CLZ, round-robin rotation (plain-C model of a scheduler) |
| 06 | `ex06_linux_argv_environ.c` | LINUX | `argv` and `environ` as NULL-terminated pointer arrays; simple option parser with `strtol` |

## Teaching notes
* Read the declarations out loud: `const char *const menu[]` = "menu is an array of constant pointers to constant chars".
* Contrast a 2-D `char names[4][25]` (rectangular, padded) with `const char *names[4]` (ragged, one pointer per row). Which is smaller depends on the data - ex01 prints both numbers.
* A function name decays to its address, so a table of handlers is an array of pointers like any other. Always guard against an empty (NULL) slot before calling it (ex02).
* On a real STM32 the peripheral addresses are compile-time constants, so the tables can be `static const` in flash. In the simulator `GPIOB` is a function call, hence the local arrays in ex03.
* Sorting pointers keeps the data in place - important when the records are in flash or very large (ex04).
* ex05 is a model, not a real kernel: ask students what changes when a task blocks (it moves from `ready_list` to a delayed list - see topic 24 ex06).

## Live-demo tips
* ex02: add `TIM2_IRQHandler` to the table and show the `Default_Handler` line disappear.
* ex04: print `sizeof(sensor_rec_t)` vs `sizeof(void *)` on the board and discuss RAM write cost.
* ex06: run it as `./ex06 --port /dev/ttyUSB1 --baud 9600 -v` and then with `BOARD_ID=custom` in front.
