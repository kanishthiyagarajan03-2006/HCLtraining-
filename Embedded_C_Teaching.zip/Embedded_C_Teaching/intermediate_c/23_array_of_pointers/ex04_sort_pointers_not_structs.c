/*
 * ============================================================================
 *  Topic   : 23 Array of Pointers
 *  Example : 04 - Sort an array of POINTERS to records instead of the records
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Records are big, pointers are small. To present the same table in
 *            several orders, keep the records where they are and sort an array
 *            of pointers to them. Each swap moves one pointer, the original table
 *            is untouched (it may even be const in flash), and several differently
 *            sorted "views" can coexist.
 *  Embedded use : sorted sensor lists, log entries by timestamp, menu entries - all
 *            without shuffling hundreds of bytes through a slow, small RAM.
 *  Real STM32F4 : none - a plain C idiom, equally useful on any MCU or PC
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_sort_pointers_not_structs.c -o ex04
 *  Output  : the table in original order, two sorted views (by temperature and by name),
 *            the table unchanged afterwards, and bytes moved: pointers vs whole records
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a view sorted by id (write a third comparator) and print it.
 *            2) Change the comparator to sort hottest first - which line decides the order?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))

typedef struct {
    char     name[12];
    uint16_t id;
    int16_t  temp_c10;            /* temperature in tenths of a degree C */
    uint16_t history[16];         /* recent raw samples: makes the record big */
} sensor_rec_t;

/* Designated initialisers: unnamed fields (history) are zero, and gcc stays quiet. */
#define REC(n, i, t) { .name = (n), .id = (i), .temp_c10 = (t) }
static const sensor_rec_t table[] = {
    REC("ambient", 101U,  253),
    REC("motor",   102U,  874),
    REC("battery", 103U,  311),
    REC("outdoor", 104U,  -52),
    REC("coolant", 105U,  652),
    REC("exhaust", 106U, 1210),
};
#define N ARRAY_SIZE(table)

typedef int (*cmp_fn)(const sensor_rec_t *a, const sensor_rec_t *b);

static int by_temp(const sensor_rec_t *a, const sensor_rec_t *b)
{
    return (a->temp_c10 > b->temp_c10) - (a->temp_c10 < b->temp_c10);
}

static int by_name(const sensor_rec_t *a, const sensor_rec_t *b)
{
    return strcmp(a->name, b->name);
}

/* Insertion sort on the POINTER array. Returns how many element moves it needed. */
static size_t sort_view(const sensor_rec_t *view[], size_t n, cmp_fn cmp)
{
    size_t moves = 0;
    for (size_t i = 1; i < n; i++) {
        const sensor_rec_t *key = view[i];
        size_t j = i;
        while (j > 0 && cmp(view[j - 1], key) > 0) {
            view[j] = view[j - 1];                  /* moves ONE pointer (4-8 bytes) */
            j--;
            moves++;
        }
        view[j] = key;
    }
    return moves;
}

/* Same algorithm on a copy of the records: every move copies the whole struct. */
static size_t sort_records(sensor_rec_t *rec, size_t n, cmp_fn cmp)
{
    size_t moves = 0;
    for (size_t i = 1; i < n; i++) {
        sensor_rec_t key = rec[i];
        size_t j = i;
        while (j > 0 && cmp(&rec[j - 1], &key) > 0) {
            rec[j] = rec[j - 1];                    /* moves sizeof(sensor_rec_t) bytes */
            j--;
            moves++;
        }
        rec[j] = key;
    }
    return moves;
}

static void show(const char *title, const sensor_rec_t *const view[], size_t n)
{
    printf("%s\n", title);
    for (size_t i = 0; i < n; i++) {
        int t = view[i]->temp_c10;
        printf("  %-8s id=%u temp=%s%d.%d C\n", view[i]->name, (unsigned)view[i]->id,
               t < 0 ? "-" : "", abs(t) / 10, abs(t) % 10);
    }
}

int main(void)
{
    const sensor_rec_t *view_temp[N];
    const sensor_rec_t *view_name[N];
    for (size_t i = 0; i < N; i++) {
        view_temp[i] = &table[i];                   /* both views start in table order */
        view_name[i] = &table[i];
    }

    show("original table (never modified):", view_temp, N);

    size_t pm = sort_view(view_temp, N, by_temp);
    show("view sorted by temperature:", view_temp, N);
    (void)sort_view(view_name, N, by_name);
    show("view sorted by name:", view_name, N);

    /* The table itself is const, so it cannot have been touched. Prove the order is intact. */
    printf("table[0] is still %s, table[5] is still %s\n", table[0].name, table[5].name);

    sensor_rec_t copy[N];
    memcpy(copy, table, sizeof copy);
    size_t rm = sort_records(copy, N, by_temp);

    printf("moves needed: %zu (same for both methods: %zu)\n", pm, rm);
    printf("bytes moved sorting pointers: %zu x %zu = %zu\n", pm, sizeof(void *),
           pm * sizeof(void *));
    printf("bytes moved sorting records : %zu x %zu = %zu\n", rm, sizeof(sensor_rec_t),
           rm * sizeof(sensor_rec_t));
    return 0;
}
