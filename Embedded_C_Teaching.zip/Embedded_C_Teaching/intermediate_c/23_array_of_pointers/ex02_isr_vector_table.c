/*
 * ============================================================================
 *  Topic   : 23 Array of Pointers
 *  Example : 02 - An interrupt vector table: an array of function pointers
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A function name is an address, so an array of function pointers is an
 *            array of pointers like any other: "void (*table[N])(void)". Calling
 *            table[i]() jumps to the i-th handler. Designated initialisers place
 *            each handler at its IRQ number; empty slots are NULL and must be
 *            replaced by a safe default.
 *  Embedded use : the Cortex-M vector table is exactly this array, stored at the
 *            start of flash. When an interrupt fires the core fetches its entry. (Real
 *            layout: entry 0 = initial SP, 1 = Reset, SysTick = 15, device IRQ n = 16+n;
 *            the numbering below is simplified.)
 *  Real STM32F4 : void (*const g_pfnVectors[])(void) __attribute__((section(".isr_vector")))
 *                   = { Reset_Handler, NMI_Handler, ..., EXTI0_IRQHandler, ... };
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_isr_vector_table.c -o ex02
 *  Output  : four simulated IRQs are dispatched through the table; TIM2 has no handler
 *            and lands in Default_Handler instead of jumping to address 0
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Write TIM2_IRQHandler and add it to the table - what changes in the output?
 *            2) Raise IRQ number 9 (outside the table). What does nvic_dispatch() do?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

typedef void (*isr_t)(void);

typedef enum { IRQ_SYSTICK, IRQ_EXTI0, IRQ_USART2, IRQ_TIM2, IRQ_COUNT } irq_t;

static volatile uint32_t tick_count;        /* written by ISRs, read by main: volatile */
static volatile uint8_t  button_event;
static volatile uint8_t  rx_byte;
static volatile uint32_t spurious_count;

static void SysTick_Handler(void)
{
    tick_count++;
    printf("  SysTick: tick=%u\n", (unsigned)tick_count);
}

static void EXTI0_IRQHandler(void)
{
    button_event = 1U;
    printf("  EXTI0  : button pressed\n");
}

static void USART2_IRQHandler(void)
{
    rx_byte = 'A';
    printf("  USART2 : received '%c'\n", rx_byte);
}

static void Default_Handler(void)
{
    spurious_count++;
    printf("  Default_Handler: no handler installed\n");
}

/* const: lives in flash. Slots not listed (IRQ_TIM2) are zero = NULL. */
static isr_t const vector_table[IRQ_COUNT] = {
    [IRQ_SYSTICK] = SysTick_Handler,
    [IRQ_EXTI0]   = EXTI0_IRQHandler,
    [IRQ_USART2]  = USART2_IRQHandler,
};

static volatile uint32_t nvic_pending;      /* bit n set = IRQ n is waiting */

static void nvic_raise(unsigned irq) { nvic_pending |= (1U << irq); }   /* "hardware" event */

/* The hardware's job, written in C: fetch the pointer, call it. */
static void nvic_dispatch(unsigned irq)
{
    isr_t handler = (irq < IRQ_COUNT) ? vector_table[irq] : NULL;
    if (handler == NULL) {
        handler = Default_Handler;          /* real startup files alias empty slots to this */
    }
    handler();                              /* an indirect call through the table */
}

static void nvic_run_pending(void)
{
    for (unsigned irq = 0U; irq < 32U; irq++) {
        if ((nvic_pending & (1U << irq)) != 0U) {
            nvic_pending &= ~(1U << irq);   /* clear pending before the handler runs */
            printf("IRQ %u fires\n", irq);
            nvic_dispatch(irq);
        }
    }
}

int main(void)
{
    printf("vector table: %zu entries x %zu bytes = %zu bytes\n", (size_t)IRQ_COUNT, sizeof(isr_t),
           sizeof vector_table);

    nvic_raise(IRQ_SYSTICK);
    nvic_raise(IRQ_EXTI0);
    nvic_run_pending();

    nvic_raise(IRQ_USART2);
    nvic_raise(IRQ_TIM2);                   /* no handler written for this one */
    nvic_run_pending();

    nvic_raise(IRQ_SYSTICK);
    nvic_run_pending();

    printf("main sees: ticks=%u button=%u rx='%c' spurious=%u\n", (unsigned)tick_count,
           (unsigned)button_event, rx_byte, (unsigned)spurious_count);
    return 0;
}
