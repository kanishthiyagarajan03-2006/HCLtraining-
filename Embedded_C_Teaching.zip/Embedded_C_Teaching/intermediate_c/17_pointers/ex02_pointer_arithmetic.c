/*
 * ============================================================================
 *  Topic   : 17 Pointers
 *  Example : 02 - Pointer arithmetic over an ADC sample buffer
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : p + n moves n ELEMENTS (not n bytes); p[n] is just *(p + n).
 *            Subtracting two pointers gives a count of elements (ptrdiff_t).
 *            A pointer may point one past the last element, but must never
 *            be dereferenced there.
 *  Embedded use : DMA buffers, UART receive buffers and sample windows are all
 *            walked with "start pointer / end pointer" loops, which compile
 *            to tight code (LDRH r0,[r1],#2 on Cortex-M).
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_pointer_arithmetic.c -o ex02
 *  Output  : element/byte distances, a sum+average loop, a max search that
 *            returns a pointer, and an in-place reverse using two pointers
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the buffer to uint32_t. Which printed numbers change?
 *            2) Write a function that returns a pointer to the MIN sample.
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define N_SAMPLES 8U

/* 12-bit ADC readings (0..4095), pretend they came from a DMA transfer. */
static const uint16_t adc_raw[N_SAMPLES] = { 1020, 1034, 990, 2048, 1011, 1005, 3999, 1027 };

/* Returns a pointer INTO the buffer (or NULL for an empty one). */
static const uint16_t *find_max(const uint16_t *begin, const uint16_t *end)
{
    if (begin == end) return NULL;
    const uint16_t *best = begin;
    for (const uint16_t *p = begin + 1; p < end; p++) {
        if (*p > *best) best = p;
    }
    return best;
}

static void reverse_u16(uint16_t *first, uint16_t *last)   /* last = one past the end */
{
    last--;                                  /* now points at the final element */
    while (first < last) {
        uint16_t tmp = *first;
        *first++ = *last;                    /* write, then advance             */
        *last-- = tmp;
    }
}

int main(void)
{
    const uint16_t *begin = adc_raw;                 /* array name decays to &adc_raw[0] */
    const uint16_t *end   = adc_raw + N_SAMPLES;     /* one past the last: legal, no '*'  */

    /* ---- distances: elements versus bytes -------------------------------- */
    printf("elements between begin and end : %td\n", end - begin);
    printf("bytes    between begin and end : %td\n",
           (const uint8_t *)end - (const uint8_t *)begin);
    printf("(begin + 3) - begin = %td element, but %zu bytes apart (sizeof element = %zu)\n",
           (begin + 3) - begin, 3U * sizeof *begin, sizeof *begin);
    printf("*(begin + 3) = %u   begin[3] = %u   (identical: p[n] is *(p+n))\n",
           (unsigned)*(begin + 3), (unsigned)begin[3]);

    /* ---- walk with start/end pointers ------------------------------------ */
    uint32_t sum = 0U;
    for (const uint16_t *p = begin; p < end; p++) sum += *p;
    printf("sum = %u, average = %u\n", (unsigned)sum, (unsigned)(sum / N_SAMPLES));

    /* ---- a function that returns a pointer into the array ---------------- */
    const uint16_t *hi = find_max(begin, end);
    if (hi != NULL)
        printf("max = %u at index %td\n", (unsigned)*hi, hi - begin);

#ifdef DEMO_BUG
    /* BUG: 'end' is a valid pointer VALUE but not a valid OBJECT. This read goes one
     * element past the array: undefined behaviour (AddressSanitizer reports it).  */
    printf("past the end = %u\n", (unsigned)*end);
#endif

    /* ---- in-place edit: needs a writable copy (adc_raw lives in flash) ---- */
    uint16_t work[N_SAMPLES];
    for (size_t i = 0; i < N_SAMPLES; i++) work[i] = adc_raw[i];
    reverse_u16(work, work + N_SAMPLES);
    printf("reversed:");
    for (const uint16_t *p = work; p < work + N_SAMPLES; p++) printf(" %u", (unsigned)*p);
    putchar('\n');
    return 0;
}
