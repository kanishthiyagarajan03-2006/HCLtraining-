/*
 * ============================================================================
 *  Topic   : 17 Pointers
 *  Example : 08 - mmap an anonymous page and use it as a pretend peripheral
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : mmap() returns a void * to a page of memory. Cast it to
 *            'volatile uint32_t *' and the page behaves like a block of 32-bit
 *            hardware registers: regs[REG_CTRL] = 1; while (!(regs[REG_STATUS] & 1)) {}
 *            Always check for MAP_FAILED (not NULL) and munmap() when done.
 *  Embedded use : on embedded Linux (Raspberry Pi, i.MX, Zynq) user space maps a
 *            peripheral's physical address through /dev/mem or /dev/gpiomem and
 *            then talks to it with exactly this pointer pattern.
 *  Real Linux   : fd = open("/dev/mem", O_RDWR | O_SYNC);
 *                 regs = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, PHYS_BASE);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex08_mmap_pretend_peripheral.c -o ex08
 *  Output  : page-alignment check, a CTRL/STATUS/DATA handshake with a simulated
 *            device, and the final register values
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a REG_COUNT register that the device increments each step.
 *            2) Why can the page start with zeroes, with no memset by us?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stdint.h>
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>

enum { REG_CTRL = 0, REG_STATUS = 1, REG_DATA = 2 };      /* word indexes, 4 bytes each */
#define CTRL_START   (1U << 0)
#define STATUS_READY (1U << 0)

/* This function plays the SILICON: on a real board the hardware does this by itself. */
static void fake_device_step(volatile uint32_t *regs)
{
    if (regs[REG_CTRL] & CTRL_START) {
        regs[REG_DATA]    = 0x1234U;            /* "ADC result"            */
        regs[REG_STATUS] |= STATUS_READY;       /* conversion finished     */
        regs[REG_CTRL]   &= ~CTRL_START;        /* start bit is self-clearing */
    }
}

int main(void)
{
    long page = sysconf(_SC_PAGESIZE);
    void *base = mmap(NULL, (size_t)page, PROT_READ | PROT_WRITE,
                      MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (base == MAP_FAILED) {                   /* NOT "== NULL": mmap fails with (void *)-1 */
        perror("mmap");
        return 1;
    }
    printf("mapped %ld bytes, page aligned: %s\n", page,
           ((uintptr_t)base % (uintptr_t)page == 0U) ? "yes" : "no");

    /* void * -> volatile uint32_t *: now each regs[i] is a 32-bit "register". */
    volatile uint32_t *regs = (volatile uint32_t *)base;
    printf("fresh page reads CTRL=0x%X STATUS=0x%X DATA=0x%X (anonymous pages start zeroed)\n",
           (unsigned)regs[REG_CTRL], (unsigned)regs[REG_STATUS], (unsigned)regs[REG_DATA]);
    printf("&regs[REG_DATA] - &regs[REG_CTRL] = %td bytes\n",
           (volatile char *)&regs[REG_DATA] - (volatile char *)&regs[REG_CTRL]);

    /* Driver code: start a conversion, then poll STATUS with a timeout. */
    regs[REG_CTRL] = CTRL_START;
    unsigned polls = 0U;
    while (!(regs[REG_STATUS] & STATUS_READY) && polls < 10U) {
        printf("poll %u: not ready yet\n", polls);
        fake_device_step(regs);                 /* real HW would finish by itself */
        polls++;
    }
    if (regs[REG_STATUS] & STATUS_READY)
        printf("ready after %u poll(s): DATA = 0x%04X\n", polls, (unsigned)regs[REG_DATA]);
    else
        printf("timeout waiting for the device\n");

    printf("final CTRL=0x%X STATUS=0x%X\n", (unsigned)regs[REG_CTRL], (unsigned)regs[REG_STATUS]);
    if (munmap(base, (size_t)page) != 0) {      /* give the page back */
        perror("munmap");
        return 1;
    }
    return 0;
}
