/*
 * ============================================================================
 *  Topic   : 17 Pointers
 *  Example : 05 - void * (any data) and function pointers (any code)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : void *  holds the address of ANY object but cannot be dereferenced
 *            until cast back to the real type. A function pointer holds the
 *            address of CODE; calling through it lets the caller choose
 *            behaviour at run time (a callback).
 *  Embedded use : HAL callbacks, timer/ISR hooks and RTOS APIs pass a function
 *            pointer plus a 'void *ctx' so one generic driver can serve many
 *            clients (HAL_TIM_PeriodElapsedCallback, xTimerCreate(..., pvTimerID, cb)).
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_void_and_function_pointers.c -o ex05
 *  Output  : a generic swap on two types, then a soft timer that calls a LED-toggle
 *            callback every 100 ms and an event-counter callback every 250 ms
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Register a third timer that calls count_event every 500 ms.
 *            2) Set a timer's callback to NULL. Which line protects the program?
 * ============================================================================
 */
#include <string.h>
#include "hw_sim.h"

/* ---- void *: one function, any type ------------------------------------- */
/* size_t says how many bytes to swap; void * hides the type, so we work in bytes. */
static int swap_any(void *a, void *b, size_t size)
{
    unsigned char tmp[16];                       /* small scratch, no malloc on an MCU */
    if (a == NULL || b == NULL || size > sizeof tmp) return -1;
    memcpy(tmp, a, size);
    memcpy(a, b, size);
    memcpy(b, tmp, size);
    return 0;
}

typedef struct { uint16_t id; uint16_t level; } sensor_t;

/* ---- function pointers: a software timer with a callback ------------------ */
typedef void (*timer_cb_t)(void *ctx);           /* "pointer to function(void *) returning void" */

typedef struct {
    const char *name;
    uint32_t    period_ms;
    uint32_t    elapsed_ms;
    timer_cb_t  callback;                        /* what to run */
    void       *ctx;                             /* what to run it on */
} soft_timer_t;

typedef struct { GPIO_TypeDef *port; uint8_t pin; } led_ctx_t;

static void toggle_led(void *ctx)                /* ctx really is a led_ctx_t * */
{
    led_ctx_t *led = (led_ctx_t *)ctx;
    led->port->ODR ^= (1U << led->pin);
}

static void count_event(void *ctx)               /* ctx really is a uint32_t * */
{
    uint32_t *counter = (uint32_t *)ctx;
    (*counter)++;
}

/* Called from the SysTick ISR every millisecond on a real MCU. */
static void soft_timer_tick(soft_timer_t *t)
{
    if (++t->elapsed_ms >= t->period_ms) {
        t->elapsed_ms = 0U;
        if (t->callback != NULL)                 /* never call a NULL function pointer */
            t->callback(t->ctx);
    }
}

int main(void)
{
    /* swap_any works for an int, a struct, anything up to 16 bytes. */
    uint16_t x = 111U, y = 222U;
    sensor_t s1 = { 1U, 500U }, s2 = { 2U, 900U };
    swap_any(&x, &y, sizeof x);
    swap_any(&s1, &s2, sizeof s1);
    printf("after swap: x=%u y=%u | s1={id %u,level %u} s2={id %u,level %u}\n",
           (unsigned)x, (unsigned)y, (unsigned)s1.id, (unsigned)s1.level,
           (unsigned)s2.id, (unsigned)s2.level);
    printf("swap_any(NULL,..) returns %d\n", swap_any(NULL, &x, sizeof x));

    /* A plain function pointer: the function name IS its address. */
    timer_cb_t cb = count_event;
    uint32_t direct = 0U;
    cb(&direct);                                  /* same as (*cb)(&direct) */
    printf("direct call through 'cb': counter = %u\n", (unsigned)direct);

#ifdef DEMO_BUG
    /* BUG: a void * can be converted to ANY pointer type without a diagnostic. Treating
     * a uint16_t as a led_ctx_t reads garbage and crashes. The compiler cannot help. */
    toggle_led(&x);
#endif

    /* Two timers, same tick function, different callbacks and contexts. */
    led_ctx_t green = { GPIOA, 5U };
    uint32_t events = 0U;
    soft_timer_t timers[2] = {
        { "blink",  100U, 0U, toggle_led,  &green  },
        { "events", 250U, 0U, count_event, &events },
    };

    GPIOA->MODER |= (1U << (5U * 2U));
    for (uint32_t ms = 1U; ms <= 500U; ms++) {
        for (unsigned i = 0U; i < 2U; i++) soft_timer_tick(&timers[i]);
        sim_delay_ms(1U);
        if (ms % 100U == 0U) {
            printf("t=%3u ms  PA5=%u  events=%u\n", (unsigned)ms,
                   (unsigned)((GPIOA->ODR >> 5) & 1U), (unsigned)events);
        }
    }
    return 0;
}
