/*
 * ============================================================================
 *  Topic   : 17 Pointers
 *  Example : 04 - const pointers, pointers to const, and NULL checks
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Read a declaration from the NAME outwards:
 *              const uint8_t *p        pointer to const : cannot change *p, may move p
 *              uint8_t *const p        const pointer    : may change *p, cannot move p
 *              const uint8_t *const p  both frozen
 *            A pointer that may be NULL must be tested before it is dereferenced.
 *  Embedded use : tables in flash are 'const' (writing = fault); a register
 *            pointer is a fixed address ('volatile uint32_t *const'); read-only
 *            function parameters ('const uint8_t *buf') document intent.
 *  Real STM32F4 : static volatile uint32_t *const LED_ODR = (volatile uint32_t *)0x40020014U;
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_const_and_null_pointers.c -o ex04
 *  Output  : which pointer variants may move or write, a checksum with NULL
 *            guards, and a fixed register pointer that drives an LED bit
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Compile with -DDEMO_BUG and read the compiler errors out loud.
 *            2) Pass a 'const uint8_t *' to a function that wants 'uint8_t *'.
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

static const uint8_t flash_table[4] = { 0x10, 0x20, 0x30, 0x40 };  /* lives in flash */
static uint8_t ram_buf[4] = { 1, 2, 3, 4 };
static uint8_t other_buf[4] = { 9, 9, 9, 9 };

static volatile uint32_t FAKE_ODR;
/* const pointer to volatile data: the address never changes, the value may. */
static volatile uint32_t *const LED_ODR = &FAKE_ODR;

/* 'const uint8_t *data' promises not to modify the buffer; the caller can pass
 * flash tables AND RAM buffers. Returns 0 and fills *out, or -1 on bad input.  */
static int checksum8(const uint8_t *data, size_t len, uint8_t *out)
{
    if (data == NULL || out == NULL) return -1;       /* NULL guard */
    uint8_t sum = 0U;
    for (size_t i = 0; i < len; i++) sum = (uint8_t)(sum + data[i]);
    *out = (uint8_t)(0U - sum);                       /* two's-complement checksum */
    return 0;
}

int main(void)
{
    /* 1) pointer to const: the DATA is read-only through this pointer. */
    const uint8_t *view = flash_table;
    view = ram_buf;                                   /* OK: the pointer may move */
    printf("view -> ram_buf, first byte %u (read only through 'view')\n", (unsigned)view[0]);

    /* 2) const pointer: the POINTER is fixed, the data is writable. */
    uint8_t *const fixed = ram_buf;
    fixed[0] = 42U;                                   /* OK: data is writable     */
    printf("fixed[0] changed to %u; 'fixed' can never point elsewhere\n", (unsigned)ram_buf[0]);

    /* 3) both const: fully frozen. */
    const uint8_t *const frozen = flash_table;
    printf("frozen[3] = 0x%02X\n", (unsigned)frozen[3]);

#ifdef DEMO_BUG
    /* Each line below is a COMPILE ERROR, which is exactly the point of const. */
    *view = 7U;                    /* error: assignment of read-only location '*view'  */
    fixed = other_buf;             /* error: assignment of read-only variable 'fixed'  */
    *frozen = 1U;                  /* error: read-only location                        */
    frozen = other_buf;            /* error: read-only variable                        */
    uint8_t *writable = view;      /* warning: discards 'const' qualifier              */
    (void)writable;
#endif
    (void)other_buf;               /* only used by the DEMO_BUG lines */

    /* NULL checks: bad input becomes an error code instead of a hard fault. */
    uint8_t cs = 0U;
    int rc_flash = checksum8(flash_table, sizeof flash_table, &cs);
    printf("checksum8(flash_table) rc=%d cs=0x%02X (sum + cs wraps to 0)\n", rc_flash,
           (unsigned)cs);
    printf("checksum8(NULL buffer) rc=%d\n", checksum8(NULL, 4U, &cs));
    printf("checksum8(NULL out)    rc=%d\n", checksum8(ram_buf, 4U, NULL));

    /* The fixed volatile register pointer in action. */
    *LED_ODR |= (1U << 5);
    printf("LED_ODR -> 0x%08X after setting bit 5\n", (unsigned)*LED_ODR);
    *LED_ODR &= ~(1U << 5);
    printf("LED_ODR -> 0x%08X after clearing bit 5\n", (unsigned)*LED_ODR);
    return 0;
}
