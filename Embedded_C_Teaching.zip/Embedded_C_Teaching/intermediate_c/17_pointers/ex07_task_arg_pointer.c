/*
 * ============================================================================
 *  Topic   : 17 Pointers
 *  Example : 07 - The void *arg task parameter: one task function, many configs
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : RTOS task functions all have the shape  void task(void *arg).
 *            'arg' is a void * that the creator points at a struct; the task casts
 *            it back and uses it. The pointed-to data must outlive the task:
 *            use static/global storage, never a local of a function that returns.
 *  Embedded use : one blink_task() code image drives three LEDs; a shared stats
 *            struct is updated through a pointer by several tasks.
 *  Real FreeRTOS: xTaskCreate(blink_task, "RED", 256, (void *)&cfg[0], 2, NULL);
 *                 const blink_cfg_t *cfg = (const blink_cfg_t *)pvParameters;
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_task_arg_pointer.c -o ex07
 *  Output  : RED and GREEN toggle at different rates using the same task code;
 *            a monitor task prints the toggle counters kept in a shared struct
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a BLUE LED with a 500 ms period - only the table changes.
 *            2) Build with -DDEMO_BUG -fsanitize=address and run with
 *               ASAN_OPTIONS=detect_stack_use_after_return=1: why is a pointer to
 *               a local struct handed to a task dangerous?
 * ============================================================================
 */
#include "mini_rtos.h"

typedef struct {
    uint32_t red_toggles;
    uint32_t green_toggles;
} stats_t;

typedef struct {
    const char       *name;
    volatile uint32_t *odr;          /* which fake port register to drive    */
    uint8_t           pin;
    uint32_t          period_ms;
    uint32_t         *counter;       /* where to count: points into stats_t  */
} blink_cfg_t;

static volatile uint32_t PORTA_ODR;
static volatile uint32_t PORTB_ODR;
static stats_t stats;                /* static storage: lives for the whole program */

/* Static const table: lives in flash on a real MCU, outlives every task. */
static const blink_cfg_t cfgs[2] = {
    { "RED",   &PORTA_ODR, 5U, 200U, &stats.red_toggles   },
    { "GREEN", &PORTB_ODR, 0U, 300U, &stats.green_toggles },
};

/* ONE task body; the behaviour comes from what 'arg' points at. */
static void blink_task(void *arg)
{
    const blink_cfg_t *cfg = (const blink_cfg_t *)arg;   /* void * -> typed pointer */
    for (;;) {
        *cfg->odr ^= (1U << cfg->pin);
        (*cfg->counter)++;                               /* write through a pointer member */
        rtos_log("pin %u -> %s", (unsigned)cfg->pin,
                 ((*cfg->odr >> cfg->pin) & 1U) ? "ON" : "OFF");
        rtos_delay(cfg->period_ms);
    }
}

static void monitor_task(void *arg)
{
    const stats_t *s = (const stats_t *)arg;             /* read-only view of the stats */
    for (;;) {
        rtos_delay(500);
        rtos_log("MONITOR red=%u green=%u", (unsigned)s->red_toggles,
                 (unsigned)s->green_toggles);
    }
}

#ifdef DEMO_BUG
/* BUG: 'local' dies when this function returns, but the task keeps the pointer. */
static void create_dangling_task(void)
{
    blink_cfg_t local = { "BAD", &PORTA_ODR, 1U, 100U, &stats.red_toggles };
    rtos_task_create("BAD", blink_task, &local, 1, 0);
}
#endif

int main(void)
{
    for (size_t i = 0; i < sizeof cfgs / sizeof cfgs[0]; i++) {
        /* cfgs is const but task_create wants a plain void *: the cast drops const here,
         * and blink_task puts it back (const blink_cfg_t *) when it casts arg back.   */
        rtos_task_create(cfgs[i].name, blink_task, (void *)&cfgs[i], 2, 0);
    }
    rtos_task_create("MONITOR", monitor_task, &stats, 1, 0);
#ifdef DEMO_BUG
    create_dangling_task();
#endif

    rtos_start(1000);
    printf("done: red toggled %u times, green %u times\n", (unsigned)stats.red_toggles,
           (unsigned)stats.green_toggles);
    rtos_shutdown();
    return 0;
}
