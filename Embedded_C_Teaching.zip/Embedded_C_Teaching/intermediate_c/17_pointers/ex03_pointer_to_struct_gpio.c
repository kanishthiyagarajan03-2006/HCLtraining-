/*
 * ============================================================================
 *  Topic   : 17 Pointers
 *  Example : 03 - Pointer to struct: GPIO_TypeDef * and the -> operator
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A struct laid over the register block lets us write port->ODR instead
 *            of address arithmetic. p->m is shorthand for (*p).m. Passing the
 *            POINTER lets one driver function serve every port (GPIOA, GPIOB...).
 *  Embedded use : HAL/CMSIS drivers take 'GPIO_TypeDef *' as their first argument;
 *            a 'led_t' struct that stores the port pointer + pin is a common
 *            way to describe board LEDs once and reuse them everywhere.
 *  Real STM32F4 : HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
 *                 // GPIOA is defined as ((GPIO_TypeDef *)0x40020000UL)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_pointer_to_struct_gpio.c -o ex03
 *  Output  : register offsets from offsetof(), then a green LED on GPIOA and a relay
 *            on GPIOB switched by the same driver functions
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a third led_t (PC13 on GPIOC) next to green and relay and switch it on.
 *            2) Delete 'port == NULL ||' from gpio_write() and run again: what happens at
 *               the last printf, and what did that guard cost you?
 * ============================================================================
 */
#include <stddef.h>
#include "hw_sim.h"

typedef struct {
    GPIO_TypeDef *port;      /* which port: a POINTER, so we share, not copy   */
    uint8_t       pin;       /* which bit on that port                         */
} led_t;

/* Driver functions take the port by pointer. Return 0 on success, -1 on error. */
static int gpio_set_output(GPIO_TypeDef *port, uint8_t pin)
{
    if (port == NULL || pin > 15U) return -1;          /* guard first, use later */
    port->MODER &= ~(3U << (pin * 2U));                /* clear the 2-bit field  */
    port->MODER |=  (1U << (pin * 2U));                /* 01 = general output    */
    return 0;
}

static int gpio_write(GPIO_TypeDef *port, uint8_t pin, uint8_t level)
{
    if (port == NULL || pin > 15U) return -1;
    port->BSRR = level ? (1U << pin) : (1U << (pin + 16U));   /* atomic set/reset */
    return 0;
}

static int gpio_read(const GPIO_TypeDef *port, uint8_t pin)    /* const: read only */
{
    if (port == NULL || pin > 15U) return -1;
    return (int)((port->IDR >> pin) & 1U);
}

static int led_on(const led_t *led)  { return gpio_write(led->port, led->pin, 1U); }
static int led_off(const led_t *led) { return gpio_write(led->port, led->pin, 0U); }

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN;

    /* The struct is only a *template* laid over memory: offsets match the manual. */
    printf("offsetof(MODER) = 0x%02zX, offsetof(IDR) = 0x%02zX, offsetof(ODR) = 0x%02zX\n",
           offsetof(GPIO_TypeDef, MODER), offsetof(GPIO_TypeDef, IDR),
           offsetof(GPIO_TypeDef, ODR));
    printf("&GPIOA->ODR - GPIOA = %zu bytes; (*GPIOA).ODR and GPIOA->ODR are the same object: %s\n",
           (size_t)((uintptr_t)&GPIOA->ODR - (uintptr_t)GPIOA),
           (&(*GPIOA).ODR == &GPIOA->ODR) ? "yes" : "no");

    /* Two devices on two different ports, one set of driver functions. */
    /* GPIOA expands to a function call here, so these are initialised at run time
     * (on real silicon it is a constant address and the table could live in flash). */
    const led_t green = { GPIOA, 5U };
    const led_t relay = { GPIOB, 0U };

    gpio_set_output(green.port, green.pin);
    gpio_set_output(relay.port, relay.pin);

    led_on(&green);
    sim_show_port("GPIOA", GPIOA);
    led_on(&relay);
    sim_show_port("GPIOB", GPIOB);
    led_off(&green);
    sim_show_port("GPIOA", GPIOA);

    sim_sync();                                    /* real hardware does this for free */
    printf("relay pin reads back %d, green LED reads back %d\n",
           gpio_read(relay.port, relay.pin), gpio_read(green.port, green.pin));

    /* A NULL port is rejected instead of dereferencing address 0 (undefined behaviour:
     * a crash on a PC, a fault or silent corruption on an MCU). */
    printf("gpio_write(NULL, ...) returns %d\n", gpio_write(NULL, 5U, 1U));
    return 0;
}
