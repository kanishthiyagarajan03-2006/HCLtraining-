/*
 * ============================================================================
 *  Topic   : 17 Pointers
 *  Example : 06 - Looking at a uint32_t as bytes through a uint8_t * (endianness)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Any object may be inspected byte by byte through an unsigned char /
 *            uint8_t pointer. The byte ORDER of a multi-byte value depends on the
 *            CPU: little-endian stores the least significant byte first.
 *            Casting a pointer to a different non-char type (e.g. float * to
 *            uint32_t *) breaks strict aliasing - use memcpy for that.
 *  Embedded use : writing one byte of a 32-bit register, building UART/CAN frames,
 *            reading a network (big-endian) header on a little-endian Cortex-M.
 *  Real STM32F4 : *(volatile uint8_t *)&GPIOA->ODR = 0xFFU;   // low byte only (LE)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_bytes_view_endianness.c -o ex06
 *  Output  : the four bytes of 0x12345678, an endianness verdict, a byte-wide
 *            register write, a hex dump, and a float's bit pattern via memcpy
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the value to 0xAABBCCDD and predict the dump first.
 *            2) Write a function that swaps the byte order of a uint32_t.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

/* Print n bytes starting at p, lowest address first. */
static void hex_dump(const void *p, size_t n)
{
    const uint8_t *b = (const uint8_t *)p;       /* void * -> byte pointer: always legal */
    for (size_t i = 0; i < n; i++) printf("%02X ", (unsigned)b[i]);
    putchar('\n');
}

/* Portable, endianness-independent: build the bytes with shifts, not with a cast. */
static void put_be32(uint8_t *out, uint32_t v)
{
    out[0] = (uint8_t)(v >> 24);
    out[1] = (uint8_t)(v >> 16);
    out[2] = (uint8_t)(v >> 8);
    out[3] = (uint8_t)v;
}

static volatile uint32_t FAKE_ODR;               /* pretend GPIOA->ODR */

int main(void)
{
    uint32_t word = 0x12345678U;
    const uint8_t *b = (const uint8_t *)&word;

    printf("word = 0x%08X lives at one address; its bytes in memory order:\n", (unsigned)word);
    for (size_t i = 0; i < sizeof word; i++)
        printf("  byte[%zu] = 0x%02X\n", i, (unsigned)b[i]);

    int little = (b[0] == 0x78U);
    printf("this CPU is %s-endian (Cortex-M and x86 are little-endian)\n",
           little ? "little" : "big");

    /* A byte-wide write to a 32-bit register touches only its low byte (little-endian). */
    FAKE_ODR = 0xAABBCC00U;
    volatile uint8_t *low_byte = (volatile uint8_t *)&FAKE_ODR;
    low_byte[0] = 0xFFU;
    printf("after low_byte[0] = 0xFF: FAKE_ODR = 0x%08X\n", (unsigned)FAKE_ODR);

    /* Hex dump helper works on any object because it takes a void *. */
    printf("dump of word       : ");
    hex_dump(&word, sizeof word);

    uint8_t frame[4];
    put_be32(frame, word);
    printf("big-endian on wire : ");
    hex_dump(frame, sizeof frame);

    /* Reading a float's bits: memcpy is the safe, optimiser-friendly way. */
    float temp = 1.0f;
    uint32_t bits;
    memcpy(&bits, &temp, sizeof bits);
    printf("float 1.0f has bit pattern 0x%08X\n", (unsigned)bits);
#ifdef DEMO_BUG
    /* BUG: strict-aliasing violation. A float object is read through a uint32_t lvalue;
     * with -O2 the compiler may reorder or drop this read and give a stale value. */
    uint32_t wrong = *(uint32_t *)&temp;
    printf("via pointer cast: 0x%08X (undefined behaviour)\n", (unsigned)wrong);
#endif
    return 0;
}
