# Topic 17 - Pointers
**Suggested session:** 90 min | **Prerequisite topics:** 03 Constants and Variable Types, 04 Expressions and Operators, 15 Arrays, 16 Strings

Students should leave knowing that a pointer is just an address with a type: `&` takes one, `*` follows one, and `p + n` moves in whole elements. The examples start with the embedded reason pointers exist (registers live at addresses), then build up arithmetic over buffers, pointers to structs (`GPIO_TypeDef *`), `const` and NULL discipline, generic `void *` and function pointers, byte-level views of memory, and finally the `void *arg` of an RTOS task and a pointer into an `mmap` page on embedded Linux.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_pointer_to_register.c` | MCU | `&`, `*`, `volatile uint32_t *`; the `REG32(addr)` base-plus-offset idiom |
| 02 | `ex02_pointer_arithmetic.c` | MCU | `p + n` scaling, `p[n]` = `*(p+n)`, element vs byte distance, start/end loops, returning a pointer |
| 03 | `ex03_pointer_to_struct_gpio.c` | MCU | `GPIO_TypeDef *`, `->`, `offsetof`, one driver for many ports, NULL guards |
| 04 | `ex04_const_and_null_pointers.c` | MCU | pointer to const vs const pointer, `volatile uint32_t *const`, NULL checks on parameters |
| 05 | `ex05_void_and_function_pointers.c` | MCU | `void *` generic swap, function-pointer callbacks with a `void *ctx` (soft timer) |
| 06 | `ex06_bytes_view_endianness.c` | MCU | viewing a `uint32_t` through `uint8_t *`, endianness, `memcpy` vs aliasing casts |
| 07 | `ex07_task_arg_pointer.c` | RTOS | `void *arg` carrying a config struct pointer, shared stats via pointer members, lifetime rule |
| 08 | `ex08_mmap_pretend_peripheral.c` | LINUX | `mmap` page used as registers through a `volatile uint32_t *`, `MAP_FAILED` check |

## Teaching notes
* Draw memory as numbered boxes and show `&x`, `p`, `*p` on the board before any code; most pointer confusion is a missing picture.
* Ask: "what is `sizeof(p)` on a Cortex-M?" (4) versus this PC (8). A pointer's size depends on the machine, never on what it points to.
* The reading rule for `const`: read the declaration right to left. `const uint8_t *p` is a pointer to const; `uint8_t *const p` is a const pointer.
* Common mistakes: forgetting `volatile` on register pointers, dereferencing NULL or a pointer one past the end, and casting between unrelated pointer types instead of using `memcpy`.
* Stress that the `REG32(addr)` macro is exactly what vendor headers hide; students should recognise `(*(volatile uint32_t *)0x40020014U)` when they see it.

## Live-demo tips
* ex02: compile with `-DDEMO_BUG -fsanitize=address` to show AddressSanitizer catching the read one past the array end. `gcc -std=gnu11 -fsanitize=address -DDEMO_BUG -I../../common ex02_pointer_arithmetic.c`
* ex04: build with `-DDEMO_BUG` and read the compiler errors aloud; this is the best demonstration of what `const` buys.
* ex06: compile with `-O2 -DDEMO_BUG` to discuss strict aliasing; the safe `memcpy` version compiles to a single move on ARM.
