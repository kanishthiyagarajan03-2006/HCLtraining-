/*
 * ============================================================================
 *  Topic   : 17 Pointers
 *  Example : 01 - A pointer to a (fake) hardware register: &, * and volatile
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A pointer is a variable that holds an ADDRESS.
 *              &x  = "address of x"          *p = "the object p points to"
 *            Writing through *p changes the original object. A register
 *            at a fixed address is reached by turning an integer into a pointer.
 *  Embedded use : every peripheral register is just memory at a known address;
 *            firmware talks to hardware by dereferencing pointers to it.
 *            'volatile' stops the compiler caching or deleting register accesses.
 *  Real STM32F4 : #define GPIOA_ODR (*(volatile uint32_t *)0x40020014U)
 *                 GPIOA_ODR |= (1U << 5);          // PA5 = LED
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_pointer_to_register.c -o ex01
 *  Output  : counter changed through a pointer, an LED bit set/cleared through a
 *            volatile pointer, then three registers reached by base + offset
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Remove 'volatile' from FAKE_ODR and from 'odr', compile with -O2 -S.
 *               Can the compiler now merge two writes? Why is that deadly here?
 *            2) Grow FAKE_BLOCK to 4 words, add REG_BSRR at offset 0x0C, write it via REG32().
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

/* On a PC there is no GPIO, so ordinary variables play the hardware. */
static volatile uint32_t FAKE_ODR;       /* stands for GPIOA->ODR              */
static volatile uint32_t FAKE_BLOCK[3];  /* stands for a peripheral: MODER/IDR/ODR */

/* The classic idiom: integer address -> volatile pointer -> dereference.
 * On the real chip FAKE_BASE would simply be 0x40020000U.                    */
#define FAKE_BASE     ((uintptr_t)&FAKE_BLOCK[0])
#define REG32(addr)   (*(volatile uint32_t *)(addr))
#define REG_MODER     REG32(FAKE_BASE + 0x00U)
#define REG_IDR       REG32(FAKE_BASE + 0x04U)
#define REG_ODR       REG32(FAKE_BASE + 0x08U)

#define LED_PIN 5U

int main(void)
{
    /* ---- Part 1: pointer to an ordinary variable ------------------------- */
    uint32_t counter = 41U;
    uint32_t *pc = &counter;              /* pc stores the address of counter */
    *pc += 1U;                            /* write THROUGH the pointer        */
    printf("counter = %u, *pc = %u, pc == &counter: %s\n",
           (unsigned)counter, (unsigned)*pc, (pc == &counter) ? "yes" : "no");
    printf("pc holds %p, sizeof(pc) = %zu bytes (4 on a Cortex-M)\n", (void *)pc, sizeof pc);

    /* ---- Part 2: pointer to a volatile register -------------------------- */
    volatile uint32_t *odr = &FAKE_ODR;   /* 'volatile' travels with the type */
    *odr = 0U;
    *odr |= (1U << LED_PIN);              /* LED on  */
    printf("LED on : FAKE_ODR = 0x%08X\n", (unsigned)FAKE_ODR);
    *odr &= ~(1U << LED_PIN);             /* LED off */
    printf("LED off: FAKE_ODR = 0x%08X\n", (unsigned)FAKE_ODR);

    /* ---- Part 3: registers reached by base address + byte offset --------- */
    REG_MODER = 0x00000400U;              /* PA5 as output: 01 in bits [11:10] */
    REG_IDR   = 0x00000001U;
    REG_ODR   = 1U << LED_PIN;
    printf("MODER at base+0x%02X = 0x%08X\n", 0x00U, (unsigned)FAKE_BLOCK[0]);
    printf("IDR   at base+0x%02X = 0x%08X\n", 0x04U, (unsigned)FAKE_BLOCK[1]);
    printf("ODR   at base+0x%02X = 0x%08X\n", 0x08U, (unsigned)FAKE_BLOCK[2]);

    /* The pointer and the array element are the SAME memory. */
    int same = ((uintptr_t)&REG_ODR == (uintptr_t)&FAKE_BLOCK[2]);
    printf("REG_ODR is FAKE_BLOCK[2]: %s\n", same ? "yes" : "NO!");
    return same ? 0 : 1;
}
