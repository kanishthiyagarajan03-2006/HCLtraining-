# Topic 20 - String Handling Functions
**Suggested session:** 90 min | **Prerequisite topics:** 16 Strings, 17 Pointers, 15 Arrays

Students should know what each `<string.h>` and `<stdlib.h>` helper really does, which ones are dangerous because they ignore buffer sizes, and the safe pattern for each job: copy, append, compare, search, split and convert. The examples progress from hand-written `strlen`/`strcpy`, through the `strncpy` trap and comparison/search functions, to a UART command parser, a tokenizer, raw-byte functions for frames, a command queue between RTOS tasks, and a Linux config-file parser.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_own_strlen_strcpy.c` | MCU | own `strlen/strcpy/strcat`, `sizeof` vs `strlen`, checking room before `strcat` |
| 02 | `ex02_strncpy_pitfall_safe_copy.c` | MCU | `strncpy` leaving no `'\0'`, `safe_copy`, `snprintf` truncation detection, correct `strncat` |
| 03 | `ex03_compare_and_search.c` | MCU | `strcmp/strncmp/strchr/strrchr/strstr`, return-value meaning, `memcmp` vs `strcmp` on binary data |
| 04 | `ex04_uart_command_parser.c` | MCU | `LED ON` / `PWM 50` / `STATUS` parser with `strcspn`, `strncmp`, `strtol` and error replies |
| 05 | `ex05_tokenize_and_convert.c` | MCU | `strtok` on a copy, merged delimiters, `atoi` vs `strtol`, `sscanf` return value |
| 06 | `ex06_mem_functions_frame_buffer.c` | MCU | `memset/memcpy/memmove/memchr/memcmp` on a UART frame, overlap rule, `0x00` inside data |
| 07 | `ex07_rtos_command_queue.c` | RTOS | fixed-size command strings through a queue, safe truncation, width-limited `sscanf` |
| 08 | `ex08_parse_config_and_meminfo.c` | LINUX | `key=value` file parsing with trim/`strchr`/`strtol`, `sscanf("%31[^:]: %lu kB")` on `/proc/meminfo` |

## Teaching notes
* Core message: C strings carry no length, so every function that writes needs the destination size from YOU. Ask the class which functions in this topic check it by themselves (answer: none of the classic ones; `snprintf` does).
* `strcmp` returns 0 for "equal"; write `== 0` explicitly in code reviews.
* `strncpy` is not "safe strcpy": it may leave the array unterminated (ex02) and it pads with zeros, which is wasteful on large buffers.
* `strtok` writes into the string and keeps hidden state; never use it on a literal, never in two RTOS tasks, and remember it swallows empty fields (ex05). `strtok_r` is the re-entrant version on POSIX systems.
* Always prefer `strtol` over `atoi` for anything that comes from outside the program: `atoi("abc")` and `atoi("0")` are indistinguishable.

## Live-demo tips
* ex01 and ex06 have DEMO_BUG switches that AddressSanitizer reports instantly: `gcc -std=gnu11 -g -fsanitize=address -DDEMO_BUG -I../../common ex01_own_strlen_strcpy.c -o ex01 && ./ex01`
* ex02: run it, then change the long name to exactly 7 characters and re-run to find the boundary where the field becomes terminated.
* ex04 is a good "type commands" demo: copy the `rx_lines[]` table and add your own invalid inputs; every one should get a clean `ERR` reply and never crash.
