/*
 * ============================================================================
 *  Topic   : 20 String Handling Functions
 *  Example : 04 - UART command parser: "LED ON", "PWM 50", "STATUS"
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Combine a few string functions into a small, safe parser:
 *            strcspn trims CR/LF, strncmp matches the command word, strcmp
 *            matches the argument, strtol converts a number AND reports bad
 *            input through its end pointer. Every error gets a reply, never a crash.
 *  Embedded use : the serial console of nearly every board: type a line, the firmware acts and
 *            answers "OK" or "ERR <reason>". Lines arrive from a UART RX interrupt.
 *  Real STM32F4 : HAL_UART_Receive_IT(&huart2, &rx_byte, 1);  // collects the line, then parse()
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_uart_command_parser.c -o ex04
 *  Output  : eight simulated input lines, each with the device's reply; the LED pin and
 *            the PWM duty variable change only for valid commands
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a "PWM +10" relative form (hint: look at the first character).
 *            2) Make commands case-insensitive (hint: a small my_toupper loop).
 * ============================================================================
 */
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "hw_sim.h"

#define LED_PIN 5U

static uint8_t pwm_duty;                       /* stands for TIMx->CCRy scaled 0..100 % */

/* Returns the reply text for one command line. 'line' may be edited (CR/LF removed). */
static const char *handle_command(char *line, char *reply, size_t reply_size)
{
    line[strcspn(line, "\r\n")] = '\0';        /* cut at the first CR or LF (or do nothing) */

    if (strcmp(line, "STATUS") == 0) {
        snprintf(reply, reply_size, "OK led=%u pwm=%u",
                 (unsigned)((GPIOA->ODR >> LED_PIN) & 1U), (unsigned)pwm_duty);
    } else if (strncmp(line, "LED ", 4) == 0) {
        const char *arg = line + 4;            /* text after the command word */
        if (strcmp(arg, "ON") == 0) {
            GPIOA->ODR |= (1U << LED_PIN);
            snprintf(reply, reply_size, "OK");
        } else if (strcmp(arg, "OFF") == 0) {
            GPIOA->ODR &= ~(1U << LED_PIN);
            snprintf(reply, reply_size, "OK");
        } else {
            snprintf(reply, reply_size, "ERR bad LED argument");
        }
    } else if (strncmp(line, "PWM ", 4) == 0) {
        char *end = NULL;
        errno = 0;
        long v = strtol(line + 4, &end, 10);   /* end points at the first unparsed char */
        if (end == line + 4 || *end != '\0')   /* nothing parsed, or trailing junk */
            snprintf(reply, reply_size, "ERR not a number");
        else if (errno == ERANGE || v < 0 || v > 100)
            snprintf(reply, reply_size, "ERR range 0..100");
        else {
            pwm_duty = (uint8_t)v;
            snprintf(reply, reply_size, "OK");
        }
    } else {
        snprintf(reply, reply_size, "ERR unknown command");
    }
    return reply;
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->MODER |= (1U << (LED_PIN * 2U));

    /* What the UART would deliver, one line at a time (note the \r\n line endings). */
    static const char *const rx_lines[] = {
        "LED ON\r\n", "PWM 50\r\n", "STATUS\r\n", "PWM 250\r\n", "PWM abc\r\n",
        "PWM 7x\r\n", "led on\r\n", "LED OFF\r\n",
    };

    for (size_t i = 0; i < sizeof rx_lines / sizeof rx_lines[0]; i++) {
        char line[24];                         /* the RX line buffer: fixed size, on the stack */
        char reply[40];
        snprintf(line, sizeof line, "%s", rx_lines[i]);       /* copy: parser edits its input */
        handle_command(line, reply, sizeof reply);
        printf("> %-8s  -> %s\n", line, reply);   /* 'line' was trimmed by the parser */
    }

    char line[24] = "STATUS";
    char reply[40];
    printf("final state: %s\n", handle_command(line, reply, sizeof reply));
    return 0;
}
