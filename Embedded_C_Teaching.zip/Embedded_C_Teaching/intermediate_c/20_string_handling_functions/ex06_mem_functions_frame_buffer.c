/*
 * ============================================================================
 *  Topic   : 20 String Handling Functions
 *  Example : 06 - memset, memcpy, memmove, memcmp and memchr on a UART frame buffer
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : The mem* functions work on raw bytes with an explicit length - they ignore '\0'.
 *            memset fills, memcpy copies (source and destination must NOT overlap),
 *            memmove copies correctly even when they overlap, memcmp compares
 *            bytes, memchr searches for a byte.
 *  Embedded use : clearing a DMA buffer, assembling a protocol frame (header + payload + CRC),
 *            shifting data inside a ring/work buffer, searching a byte stream for the
 *            0x7E sync marker, checking a received frame against an expected one.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_mem_functions_frame_buffer.c -o ex06
 *  Output  : a 12-byte frame built step by step (hex dumps), a header inserted with
 *            memmove, a sync-byte search with memchr, and a memcmp verdict
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -DDEMO_BUG -fsanitize=address: what does it say about memcpy?
 *            2) Change the bit flip to 0x80 on a different byte: does the memcmp sign change?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define FRAME_SIZE 12U
#define SYNC       0x7EU

static void dump(const char *label, const uint8_t *buf, size_t n)
{
    printf("%-22s", label);
    for (size_t i = 0; i < n; i++) printf(" %02X", (unsigned)buf[i]);
    putchar('\n');
}

static uint8_t checksum(const uint8_t *buf, size_t n)       /* simple 8-bit sum */
{
    uint8_t sum = 0U;
    for (size_t i = 0; i < n; i++) sum = (uint8_t)(sum + buf[i]);
    return sum;
}

int main(void)
{
    uint8_t frame[FRAME_SIZE];

    /* 1) memset: start from a known state (here 0x00; 0xFF is common for flash). */
    memset(frame, 0x00, sizeof frame);
    dump("after memset 0x00:", frame, sizeof frame);

    /* 2) memcpy: copy a header and a payload into place. Fixed offsets, no overlap. */
    const uint8_t header[3]  = { SYNC, 0x05U, 0x01U };      /* sync, length, command */
    const uint8_t payload[5] = { 0x10U, 0x00U, 0x20U, 0x00U, 0x30U };   /* contains 0x00! */
    memcpy(&frame[0], header, sizeof header);
    memcpy(&frame[3], payload, sizeof payload);
    frame[8] = checksum(frame, 8U);
    dump("after memcpy + sum:", frame, 9U);

    /* strlen would stop at the first 0x00; mem* functions use the length we give. */
    printf("strlen(payload) = %zu, but the payload really has %zu bytes\n",
           strlen((const char *)payload), sizeof payload);

    /* 3) memmove: shift the whole frame right by one byte to insert a 0xAA preamble. The
     * source and destination ranges overlap, so memcpy would be undefined behaviour. */
    memmove(&frame[1], &frame[0], 9U);
#ifdef DEMO_BUG
    /* BUG: memcpy with overlapping ranges is undefined; it may copy from the front and
     * smear the first byte over the whole buffer. Always use memmove when they overlap. */
    memcpy(&frame[1], &frame[0], 9U);
#endif
    frame[0] = 0xAAU;
    dump("after memmove (+0xAA):", frame, 10U);

    /* 4) memchr: find the sync byte inside a stream that starts with noise. */
    const uint8_t *sync = memchr(frame, SYNC, sizeof frame);
    if (sync != NULL)
        printf("memchr found sync 0x%02X at index %td\n", SYNC, sync - frame);

    /* 5) memcmp: does the received frame equal the expected one? */
    uint8_t expected[FRAME_SIZE];
    memcpy(expected, frame, sizeof expected);
    printf("memcmp(frame, expected) = %d (0 = identical)\n",
           memcmp(frame, expected, sizeof frame));
    frame[6] ^= 0x01U;                                      /* simulate a bit error on the line */
    int diff = memcmp(frame, expected, sizeof frame);
    printf("after flipping one bit: memcmp is %s\n", diff == 0 ? "0" : (diff < 0 ? "<0" : ">0"));
    return 0;
}
