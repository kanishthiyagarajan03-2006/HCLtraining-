/*
 * ============================================================================
 *  Topic   : 20 String Handling Functions
 *  Example : 08 - Parse a key=value config file and a /proc/meminfo line with sscanf
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Real files are messy: comments, blank lines, spaces around '=', unknown keys.
 *            fgets reads a line, strchr splits at '=', a small trim helper removes
 *            spaces, strcmp selects the key, strtol converts. sscanf with a
 *            scan-set ("%31[^:]") pulls "Key: value kB" lines apart. Always check the
 *            return value and bound every %s / %[ with a width.
 *  Embedded use : daemons on embedded Linux read /etc/<app>.conf at start-up; health monitors
 *            read /proc/meminfo, /proc/uptime and /sys values the same way.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex08_parse_config_and_meminfo.c -o ex08
 *  Output  : a generated config parsed into a struct (with a warning for an unknown key
 *            and an invalid value), then MemTotal read from /proc/meminfo
 *            (canned line if the file is missing)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a "name = ..." key stored in a char[16] field (use a safe copy).
 *            2) Also print MemAvailable from /proc/meminfo.
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct {
    long baud;
    long sample_ms;
    int  led_enabled;
} config_t;

/* Remove leading and trailing whitespace in place; returns the start of the trimmed text. */
static char *trim(char *s)
{
    while (isspace((unsigned char)*s)) s++;
    size_t n = strlen(s);
    while (n > 0U && isspace((unsigned char)s[n - 1U])) s[--n] = '\0';
    return s;
}

static int to_long(const char *s, long *out)
{
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (end == s || *end != '\0' || errno == ERANGE) return -1;
    *out = v;
    return 0;
}

static void apply_setting(config_t *cfg, const char *key, const char *val, unsigned lineno)
{
    long n = 0;
    if (strcmp(key, "baud") == 0) {
        if (to_long(val, &n) == 0 && n > 0) cfg->baud = n;
        else printf("  line %u: invalid baud \"%s\" ignored\n", lineno, val);
    } else if (strcmp(key, "sample_ms") == 0) {
        if (to_long(val, &n) == 0 && n > 0) cfg->sample_ms = n;
        else printf("  line %u: invalid sample_ms \"%s\" ignored\n", lineno, val);
    } else if (strcmp(key, "led") == 0) {
        cfg->led_enabled = (strcmp(val, "on") == 0 || strcmp(val, "1") == 0);
    } else {
        printf("  line %u: unknown key \"%s\" ignored\n", lineno, key);
    }
}

int main(void)
{
    /* 1) Write a config file into a private temp directory. */
    char dir[] = "/tmp/cfgdemo_XXXXXX";
    if (mkdtemp(dir) == NULL) { perror("mkdtemp"); return 1; }
    char path[64];
    snprintf(path, sizeof path, "%s/device.conf", dir);
    FILE *f = fopen(path, "w");
    if (f == NULL) { perror("fopen"); rmdir(dir); return 1; }
    fputs("# device configuration\n"
          "baud = 115200\n"
          "\n"
          "sample_ms=250   \n"
          "  led = on\n"
          "colour = blue\n"
          "baud = fast\n", f);
    fclose(f);

    /* 2) Parse it. Defaults first, so missing keys are never uninitialised. */
    config_t cfg = { 9600, 1000, 0 };
    f = fopen(path, "r");
    if (f == NULL) { perror("fopen"); unlink(path); rmdir(dir); return 1; }
    printf("parsing device.conf:\n");
    char line[80];
    unsigned lineno = 0U;
    while (fgets(line, sizeof line, f) != NULL) {
        lineno++;
        char *text = trim(line);
        if (*text == '\0' || *text == '#') continue;      /* blank line or comment */
        char *eq = strchr(text, '=');
        if (eq == NULL) { printf("  line %u: no '=' found\n", lineno); continue; }
        *eq = '\0';                                       /* split into key and value */
        apply_setting(&cfg, trim(text), trim(eq + 1), lineno);
    }
    fclose(f);
    unlink(path);                                         /* clean up what we created */
    rmdir(dir);
    printf("config: baud=%ld sample_ms=%ld led=%s\n", cfg.baud, cfg.sample_ms,
           cfg.led_enabled ? "on" : "off");

    /* 3) sscanf a /proc/meminfo-style line: "MemTotal:       16314412 kB". */
    char buf[96] = "MemTotal:       2048000 kB";          /* canned fallback */
    FILE *mi = fopen("/proc/meminfo", "r");
    if (mi != NULL) {
        char first[96];
        if (fgets(first, sizeof first, mi) != NULL) snprintf(buf, sizeof buf, "%s", first);
        fclose(mi);
    } else {
        printf("(/proc/meminfo not available - using canned line)\n");
    }
    char key[32];
    unsigned long kb = 0UL;
    /* %31[^:] = up to 31 chars that are not ':'  (scan-set, bounded to fit key[32]) */
    int got = sscanf(buf, "%31[^:]: %lu kB", key, &kb);
    if (got == 2)
        printf("parsed \"%s\" = %lu kB (about %lu MB)\n", key, kb, kb / 1024UL);
    else
        printf("could not parse the meminfo line (sscanf returned %d)\n", got);
    return 0;
}
