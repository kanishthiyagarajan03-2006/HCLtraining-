/*
 * ============================================================================
 *  Topic   : 20 String Handling Functions
 *  Example : 05 - strtok, strtol (vs atoi) and sscanf for sensor frames
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : strtok splits a string at delimiters by WRITING '\0' into it, so work on a
 *            copy; it keeps hidden state (not re-entrant) and merges adjacent delimiters
 *            (an empty field disappears). atoi cannot report errors; strtol can,
 *            through its end pointer. sscanf parses a fixed format and returns how
 *            many fields it converted.
 *  Embedded use : GPS NMEA sentences, "T=250;H=45" telemetry, CSV from a sensor module.
 *            On an RTOS never share strtok between tasks - it is not thread-safe.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_tokenize_and_convert.c -o ex05
 *  Output  : a "T=250;H=45;P=1013" frame split into key/value pairs, atoi vs strtol on
 *            bad input, the lost empty field of "10,,30", and sscanf with a check
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a fourth field "V=3300" to the frame and print it too.
 *            2) What does sscanf return for the frame "$12,34" and for ""? Predict, then test.
 * ============================================================================
 */
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* Convert text to a long and say whether it was a clean number. Returns 0 on success. */
static int parse_long(const char *s, long *out)
{
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (end == s || *end != '\0' || errno == ERANGE) return -1;   /* none / junk / overflow */
    *out = v;
    return 0;
}

int main(void)
{
    /* ---- 1) strtok on a copy: split "KEY=VALUE" pairs at ';' ------------------ */
    const char *frame = "T=250;H=45;P=1013";
    char work[32];
    snprintf(work, sizeof work, "%s", frame);   /* strtok edits its input: work on a copy */

    printf("frame: \"%s\"\n", frame);
    for (char *tok = strtok(work, ";"); tok != NULL; tok = strtok(NULL, ";")) {
        char *eq = strchr(tok, '=');                 /* split the pair at '=' */
        long value = 0;
        if (eq == NULL) { printf("  token \"%s\" has no '='\n", tok); continue; }
        *eq = '\0';                                  /* tok is now the key, eq+1 the value */
        if (parse_long(eq + 1, &value) == 0)
            printf("  key %-2s value %ld\n", tok, value);
        else
            printf("  key %-2s has a bad value \"%s\"\n", tok, eq + 1);
    }
    printf("original frame still intact: \"%s\"  (work was damaged by strtok)\n", frame);

    /* ---- 2) atoi cannot tell "0" from garbage; strtol can ---------------------- */
    const char *inputs[] = { "42", "0", "abc", "12x" };
    for (size_t i = 0; i < sizeof inputs / sizeof inputs[0]; i++) {
        long v = -1;
        int ok = parse_long(inputs[i], &v);
        printf("input \"%s\": atoi=%d, strtol check=%s", inputs[i], atoi(inputs[i]),
               ok == 0 ? "ok" : "REJECTED");
        if (ok == 0) printf(" value=%ld", v);
        putchar('\n');
    }

    /* ---- 3) strtok merges delimiters: an empty field vanishes ------------------ */
    char csv[] = "10,,30";                           /* three fields, the middle one is empty */
    int fields = 0;
    for (char *t = strtok(csv, ","); t != NULL; t = strtok(NULL, ",")) fields++;
    printf("\"10,,30\" has 3 fields, strtok found %d (the empty one was skipped)\n", fields);

    /* ---- 4) sscanf: fixed format, always check the return value --------------- */
    int a = 0, b = 0, c = 0;
    int n = sscanf("$12,34,56", "$%d,%d,%d", &a, &b, &c);
    printf("sscanf converted %d fields: a=%d b=%d c=%d\n", n, a, b, c);
    n = sscanf("$12,xx,7", "$%d,%d,%d", &a, &b, &c);
    printf("sscanf on a damaged frame converted only %d field(s) -> reject the frame\n", n);
    return 0;
}
