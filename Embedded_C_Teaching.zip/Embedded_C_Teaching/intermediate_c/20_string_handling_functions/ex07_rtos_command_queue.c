/*
 * ============================================================================
 *  Topic   : 20 String Handling Functions
 *  Example : 07 - A queue of fixed-size command strings between two RTOS tasks
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A queue copies items by value, so a string must travel in a FIXED-SIZE char
 *            array inside a struct (never a pointer to a buffer that may change).
 *            The sender truncates safely with snprintf; the receiver parses with
 *            sscanf (width-limited %7s) and strcmp, and answers errors politely.
 *  Embedded use : a UART-RX task pushes complete lines to a command-handler task so the slow
 *            parsing never runs in (or blocks) the interrupt or the receiver.
 *  Real FreeRTOS: xQueueSend(q, &msg, pdMS_TO_TICKS(10)); xQueueReceive(q, &msg, portMAX_DELAY);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_rtos_command_queue.c -o ex07
 *  Output  : the UART-RX task queues 6 command strings (one too long, truncated); the
 *            handler task parses and executes them and prints the final LED/PWM state
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Shorten CMD_LEN to 8: which commands now arrive truncated?
 *            2) Add a "DELAY <ms>" command that the handler logs.
 * ============================================================================
 */
#include "mini_rtos.h"

#define CMD_LEN 16U

typedef struct {
    char text[CMD_LEN];               /* fixed size: copied into the queue by value */
} cmd_msg_t;

static rtos_queue_t *q_cmd;
static int led_on;
static int pwm_percent;

/* Task 1: plays the UART receive task; canned lines stand for what arrives on the wire. */
static void uart_rx_task(void *arg)
{
    (void)arg;
    static const char *const wire[] = {
        "LED ON", "PWM 40", "BOGUS 1", "PWM 120", "SET PWM 1234567890", "LED OFF",
    };
    for (size_t i = 0; i < sizeof wire / sizeof wire[0]; i++) {
        cmd_msg_t m;
        int wanted = snprintf(m.text, sizeof m.text, "%s", wire[i]);   /* always terminated */
        if ((size_t)wanted >= sizeof m.text)
            rtos_log("line \"%s\" too long, truncated to \"%s\"", wire[i], m.text);
        if (!rtos_queue_send(q_cmd, &m, 20U))
            rtos_log("queue full, command lost");
        else
            rtos_log("queued \"%s\"", m.text);
        rtos_delay(50);
    }
}

/* Task 2: parses and executes. Higher priority, so it reacts as soon as a command arrives. */
static void handler_task(void *arg)
{
    (void)arg;
    cmd_msg_t m;
    while (rtos_queue_recv(q_cmd, &m, 200U)) {
        char verb[8];
        char word[8];
        int num = 0;
        /* %7s reads at most 7 characters, leaving room for '\0' in the 8-byte arrays. */
        int n = sscanf(m.text, "%7s %7s", verb, word);
        if (n == 2 && strcmp(verb, "LED") == 0) {
            if (strcmp(word, "ON") == 0)       { led_on = 1; rtos_log("-> LED switched on"); }
            else if (strcmp(word, "OFF") == 0) { led_on = 0; rtos_log("-> LED switched off"); }
            else rtos_log("-> ERR LED needs ON or OFF");
        } else if (n == 2 && strcmp(verb, "PWM") == 0 && sscanf(word, "%d", &num) == 1) {
            if (num < 0 || num > 100) rtos_log("-> ERR PWM %d out of range 0..100", num);
            else { pwm_percent = num; rtos_log("-> PWM set to %d%%", num); }
        } else {
            rtos_log("-> ERR unknown command \"%s\"", m.text);
        }
    }
    rtos_log("queue idle for 200 ms, handler exits");
}

int main(void)
{
    q_cmd = rtos_queue_create(4U, sizeof(cmd_msg_t));     /* xQueueCreate(4, sizeof(cmd_msg_t)) */
    if (q_cmd == NULL) {
        printf("out of memory\n");
        return 1;
    }
    rtos_task_create("uart_rx", uart_rx_task, NULL, 2, 0);
    rtos_task_create("handler", handler_task, NULL, 3, 0);
    rtos_start(2000);

    printf("final state: LED %s, PWM %d%%\n", led_on ? "on" : "off", pwm_percent);
    rtos_queue_delete(q_cmd);
    rtos_shutdown();
    return 0;
}
