/*
 * ============================================================================
 *  Topic   : 20 String Handling Functions
 *  Example : 03 - strcmp, strncmp, memcmp, strchr, strrchr and strstr
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : strcmp returns 0 when strings are EQUAL (so  if (strcmp(a,b))  means "different").
 *            strncmp compares a prefix. strchr/strrchr find a character, strstr a
 *            substring, each returning a pointer into the original (or NULL).
 *            strcmp stops at the first '\0', so it cannot compare binary data:
 *            use memcmp with an explicit length for packets.
 *  Embedded use : matching "AT+" command prefixes, finding '=' in "BAUD=9600", spotting "OK" in a
 *            modem reply, and comparing binary frames that contain 0x00 bytes.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_compare_and_search.c -o ex03
 *  Output  : strcmp sign results, prefix and substring searches on AT-style text, and a
 *            binary packet pair that strcmp wrongly calls equal while memcmp does not
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Predict the sign of strcmp("LED2", "LED10") before you run it.
 *            2) Use strrchr to print only the file extension of "fw_v2.1.bin".
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

static const char *sign_name(int v)
{
    return v == 0 ? "equal" : (v < 0 ? "less" : "greater");
}

int main(void)
{
    /* ---- strcmp: 0 means equal, sign gives alphabetical order ---------------- */
    printf("strcmp(\"ON\", \"ON\")      -> %s\n", sign_name(strcmp("ON", "ON")));
    printf("strcmp(\"ON\", \"OFF\")     -> %s\n", sign_name(strcmp("ON", "OFF")));
    printf("strcmp(\"abc\", \"abd\")    -> %s\n", sign_name(strcmp("abc", "abd")));
    printf("strcmp(\"LED2\", \"LED10\") -> %s  (character by character, not by number)\n",
           sign_name(strcmp("LED2", "LED10")));

    const char *cmd = "LED ON";
    if (strcmp(cmd, "LED ON") == 0)       /* write == 0 explicitly: it reads as "equal" */
        printf("command matched exactly\n");

    /* ---- strncmp: compare only the first n characters (prefix test) ---------- */
    const char *line = "AT+BAUD=9600";
    if (strncmp(line, "AT+", 3) == 0)
        printf("\"%s\" starts with \"AT+\"\n", line);

    /* ---- strchr / strrchr: find one character, get a pointer into the string -- */
    const char *eq = strchr(line, '=');
    if (eq != NULL) {
        printf("key = \"%.*s\", value = \"%s\"  (key length %td)\n", (int)(eq - line), line,
               eq + 1, eq - line);
    }
    const char *file = "fw_v2.1.bin";
    const char *dot = strrchr(file, '.');                 /* LAST dot, not the first */
    printf("extension of \"%s\" is \"%s\", first dot is at index %td\n", file,
           dot ? dot : "(none)", strchr(file, '.') - file);
    printf("strchr(line, '#') = %s\n", strchr(line, '#') == NULL ? "NULL (not found)" : "found");

    /* ---- strstr: find a substring (modem reply check) ------------------------ */
    const char *reply = "\r\n+CSQ: 21,99\r\n\r\nOK\r\n";
    printf("reply contains \"OK\": %s,  contains \"ERROR\": %s\n",
           strstr(reply, "OK") ? "yes" : "no", strstr(reply, "ERROR") ? "yes" : "no");
    const char *csq = strstr(reply, "+CSQ:");
    int rssi = 0;
    if (csq != NULL && sscanf(csq, "+CSQ: %d", &rssi) == 1)
        printf("signal quality parsed from the reply: %d\n", rssi);

    /* ---- memcmp vs strcmp on BINARY data ------------------------------------ */
    const uint8_t pkt_a[6] = { 0x7E, 0x00, 0x10, 0x20, 0x30, 0x40 };
    const uint8_t pkt_b[6] = { 0x7E, 0x00, 0x99, 0x20, 0x30, 0x40 };   /* differs at index 2 */
    int by_strcmp = strcmp((const char *)pkt_a, (const char *)pkt_b);
    int by_memcmp = memcmp(pkt_a, pkt_b, sizeof pkt_a);
    printf("binary packets: strcmp says %s (stopped at the 0x00!), memcmp says %s\n",
           sign_name(by_strcmp), sign_name(by_memcmp));
    return 0;
}
