/*
 * ============================================================================
 *  Topic   : 20 String Handling Functions
 *  Example : 02 - The strncpy / strncat traps and a safe copy helper
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : strncpy(dst, src, n) copies AT MOST n chars, pads with zeros if src is
 *            shorter, but if src has n or more chars it does NOT write a '\0'.
 *            The result is an unterminated array, not a string. strncat's 'n' is
 *            the number of chars to APPEND (not the buffer size). Safe pattern:
 *            leave room for '\0', terminate yourself, or use snprintf.
 *  Embedded use : device names, topic strings and file names are stored in fixed-size
 *            struct fields. One over-long name from a UART or a config file must be
 *            truncated cleanly instead of running into the next field.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_strncpy_pitfall_safe_copy.c -o ex02
 *  Output  : an 8-byte field filled by a long name: no '\0' found (the trap), then
 *            safe_copy truncating cleanly, plus a correct strncat
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the long name to "ABCDEFG" (7 chars): is the field terminated?
 *            2) Make safe_copy return the number of characters that were cut off.
 * ============================================================================
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

#define NAME_LEN 8U

/* The next three helpers truncate ON PURPOSE. GCC recognises these bugs and would refuse to
 * build them quietly, so its truncation warnings are switched off for this block only.   */
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wstringop-truncation"
#pragma GCC diagnostic ignored "-Wformat-truncation"
#endif
static void raw_strncpy(char *dst, size_t n, const char *src)
{
    strncpy(dst, src, n);               /* n == sizeof dst: no room for '\0' if src is long */
}

static int copy_snprintf(char *dst, size_t cap, const char *src)
{
    return snprintf(dst, cap, "%s", src);   /* returns the length it WANTED to write */
}

static void append_strncat(char *dst, size_t cap, const char *src)
{
    size_t room = cap - strlen(dst) - 1U;   /* strncat's n = chars to ADD; -1 keeps the '\0' */
    strncat(dst, src, room);
}
#if defined(__GNUC__) && !defined(__clang__)
#pragma GCC diagnostic pop
#endif

/* Safe copy: always terminates; returns 1 if the text was truncated, else 0. */
static int safe_copy(char *dst, size_t cap, const char *src)
{
    if (cap == 0U) return 1;
    size_t n = strlen(src);
    if (n >= cap) n = cap - 1U;                      /* keep one byte for '\0'           */
    memcpy(dst, src, n);
    dst[n] = '\0';                                   /* WE terminate, never trust strncpy */
    return strlen(src) > n;
}

static void show_field(const char *label, const char *field, size_t cap)
{
    int terminated = memchr(field, '\0', cap) != NULL;
    printf("%-18s [%.*s]  terminated: %s\n", label, (int)cap, field, terminated ? "yes" : "NO");
}

int main(void)
{
    const char *long_name = "TEMPERATURE_SENSOR";    /* 18 chars, field holds 8 */

    /* 1) The trap: fill the field with 0xAA first so a missing '\0' cannot hide by luck. */
    char field[NAME_LEN];
    memset(field, 0xAA, sizeof field);
    raw_strncpy(field, sizeof field, long_name);
    show_field("strncpy(n=sizeof):", field, sizeof field);
#ifdef DEMO_BUG
    /* BUG: printing an unterminated array with %s reads past the end of 'field'. */
    printf("as a string: %s\n", field);
#endif

    /* 2) Short names are fine: strncpy pads the rest with '\0'. */
    memset(field, 0xAA, sizeof field);
    raw_strncpy(field, sizeof field, "ADC");
    show_field("strncpy short name:", field, sizeof field);

    /* 3) The safe helper truncates AND terminates, and tells us it did. */
    memset(field, 0xAA, sizeof field);
    int cut = safe_copy(field, sizeof field, long_name);
    show_field("safe_copy:", field, sizeof field);
    printf("strlen(field) = %zu, truncated = %s\n", strlen(field), cut ? "yes" : "no");

    /* 4) Same idea with snprintf: it always terminates and returns the wanted length. */
    memset(field, 0xAA, sizeof field);
    int wanted = copy_snprintf(field, sizeof field, long_name);
    show_field("snprintf:", field, sizeof field);
    printf("snprintf wanted %d chars, %zu fit -> truncation detected: %s\n", wanted,
           sizeof field - 1U, (size_t)wanted >= sizeof field ? "yes" : "no");

    /* 5) strncat: n is how many chars to ADD, so compute the remaining room. */
    char path[16] = "/dev/";
    append_strncat(path, sizeof path, "ttyUSB0_and_more");
    printf("strncat with room computed -> \"%s\" (%zu chars of %zu, still terminated)\n", path,
           strlen(path), sizeof path - 1U);
    return 0;
}
