/*
 * ============================================================================
 *  Topic   : 20 String Handling Functions
 *  Example : 01 - Write your own strlen / strcpy / strcat, then compare with <string.h>
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A C string is a char array ended by '\0'. strlen counts characters BEFORE
 *            the terminator; sizeof gives the whole array. strcpy and strcat copy up
 *            to and including '\0' and have NO idea how big the destination is,
 *            so the programmer must check the room first.
 *  Embedded use : small MCUs sometimes ship without a full libc (or with a tiny one), so
 *            my_strlen/my_strcpy are written by hand; either way, every copy into a
 *            fixed device-name or message buffer needs a length check.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_own_strlen_strcpy.c -o ex01
 *  Output  : sizeof vs strlen of one buffer, own functions giving the same answers as
 *            libc, and a message built with strcat after a capacity check
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Shrink msg to 12 bytes: which append is refused first, and why?
 *            2) Write my_strcmp() and test it against strcmp for 3 string pairs.
 * ============================================================================
 */
#include <stddef.h>
#include <stdio.h>
#include <string.h>

/* Walk until the terminator; the count of characters seen is the length. */
static size_t my_strlen(const char *s)
{
    const char *p = s;
    while (*p != '\0') p++;
    return (size_t)(p - s);                         /* pointer difference = length */
}

/* Copy characters including the final '\0'. Classic one-line idiom, explained:
 *   *d++ = *s++   copies one char and moves both pointers; the value of the
 *   assignment is the char copied, so the loop ends right after '\0' is copied. */
static char *my_strcpy(char *dst, const char *src)
{
    char *d = dst;
    while ((*d++ = *src++) != '\0') {
        /* empty body */
    }
    return dst;
}

static char *my_strcat(char *dst, const char *src)
{
    my_strcpy(dst + my_strlen(dst), src);           /* append at the old terminator */
    return dst;
}

/* The check strcat does NOT do: will 'add' fit, including the new '\0'? */
static int fits(size_t capacity, const char *current, const char *add)
{
    return my_strlen(current) + my_strlen(add) + 1U <= capacity;
}

int main(void)
{
    char name[16] = "STM32";
    printf("name = \"%s\"  sizeof = %zu  strlen = %zu  (sizeof counts the whole array)\n", name,
           sizeof name, strlen(name));
    printf("my_strlen = %zu, strlen = %zu: %s\n", my_strlen(name), strlen(name),
           my_strlen(name) == strlen(name) ? "same" : "DIFFERENT");

    /* Copy: own version vs libc, into two separate buffers. */
    char a[16], b[16];
    my_strcpy(a, "NUCLEO-F446");
    strcpy(b, "NUCLEO-F446");                       /* fine: 12 bytes into 16 */
    printf("my_strcpy -> \"%s\"   strcpy -> \"%s\"   strcmp says %s\n", a, b,
           strcmp(a, b) == 0 ? "equal" : "different");

    /* Build a message piece by piece. Check capacity BEFORE every strcat. */
    char msg[24] = "BOARD:";
    const char *parts[] = { name, "/", a, "/REV-C" };
    for (size_t i = 0; i < sizeof parts / sizeof parts[0]; i++) {
        if (!fits(sizeof msg, msg, parts[i])) {
            printf("refused to append \"%s\": would need %zu bytes, buffer has %zu\n", parts[i],
                   my_strlen(msg) + my_strlen(parts[i]) + 1U, sizeof msg);
            continue;
        }
        my_strcat(msg, parts[i]);
        printf("appended \"%s\" -> \"%s\" (%zu/%zu bytes used)\n", parts[i], msg,
               my_strlen(msg) + 1U, sizeof msg);
    }

#ifdef DEMO_BUG
    /* BUG: msg already holds 23 of its 24 bytes; appending 33 more characters + '\0' makes
     * strcat write past the end (stack buffer overflow: corrupts neighbours or the
     * return address).                                                              */
    strcat(msg, "/THIS-TEXT-IS-FAR-TOO-LONG-FOR-IT");
#endif
    return 0;
}
