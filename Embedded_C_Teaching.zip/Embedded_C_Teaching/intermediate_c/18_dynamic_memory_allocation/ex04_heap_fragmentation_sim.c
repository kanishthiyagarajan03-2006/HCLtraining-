/*
 * ============================================================================
 *  Topic   : 18 Dynamic Memory Allocation
 *  Example : 04 - Why MCUs avoid the heap: a visible fragmentation experiment
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A general-purpose heap hands out variable-sized blocks. After many
 *            alloc/free cycles the free space is split into small holes. The TOTAL
 *            free memory can be large and yet a request for a bigger block fails.
 *            This program uses a tiny first-fit allocator over a 32-slot "heap"
 *            so you can SEE the holes (each letter = one 16-byte slot).
 *  Embedded use : firmware that must run for years cannot risk this. Rules such as
 *            MISRA C:2012 Dir 4.12 ban the heap; designers use static allocation
 *            or fixed-block pools (see ex05) so allocation never fragments.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_heap_fragmentation_sim.c -o ex04
 *  Output  : a map of the heap after each step; a request for 8 slots fails while
 *            12 slots are free, and succeeds again after neighbours are freed
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Free neighbours C and D instead of B, D, F - does 8 slots fit now?
 *            2) If EVERY block is 1 slot, can a request for 1 slot ever fail while free > 0?
 * ============================================================================
 */
#include <stdio.h>

#define HEAP_SLOTS 32U
#define FREE_SLOT  '.'

static char owner[HEAP_SLOTS];           /* which block owns each slot, or '.' */

static void heap_init(void)
{
    for (unsigned i = 0U; i < HEAP_SLOTS; i++) owner[i] = FREE_SLOT;
}

/* First-fit: scan for the first run of 'n' free slots. Returns start index or -1. */
static int heap_alloc(char id, unsigned n)
{
    unsigned run = 0U;
    for (unsigned i = 0U; i < HEAP_SLOTS; i++) {
        run = (owner[i] == FREE_SLOT) ? run + 1U : 0U;
        if (run == n) {
            unsigned start = i + 1U - n;
            for (unsigned k = start; k <= i; k++) owner[k] = id;
            return (int)start;
        }
    }
    return -1;                                       /* malloc() would return NULL */
}

static void heap_free(char id)
{
    for (unsigned i = 0U; i < HEAP_SLOTS; i++)
        if (owner[i] == id) owner[i] = FREE_SLOT;
}

static unsigned total_free(void)
{
    unsigned n = 0U;
    for (unsigned i = 0U; i < HEAP_SLOTS; i++) n += (owner[i] == FREE_SLOT);
    return n;
}

static unsigned largest_hole(void)
{
    unsigned best = 0U, run = 0U;
    for (unsigned i = 0U; i < HEAP_SLOTS; i++) {
        run = (owner[i] == FREE_SLOT) ? run + 1U : 0U;
        if (run > best) best = run;
    }
    return best;
}

static void show(const char *what)
{
    printf("|%.*s|  free=%2u largest hole=%2u  %s\n", (int)HEAP_SLOTS, owner, total_free(),
           largest_hole(), what);
}

int main(void)
{
    heap_init();
    show("empty heap");

    /* Eight 4-slot blocks A..H fill the whole heap (think: eight message buffers). */
    for (char id = 'A'; id <= 'H'; id++) heap_alloc(id, 4U);
    show("A..H allocated (heap full)");

    /* Free every other block: four 4-slot holes appear. */
    heap_free('B');
    heap_free('D');
    heap_free('F');
    show("freed B, D, F");

    /* The killer request: 8 contiguous slots. 12 are free, but only in pieces. */
    int at = heap_alloc('X', 8U);
    printf("request 8 slots: %s although %u slots are free in total!\n",
           at < 0 ? "FAILED (NULL)" : "ok", total_free());

    /* Free the block between two holes: all three merge into one bigger hole ("coalescing"). */
    heap_free('C');
    show("freed C (B, C, D merge)");
    at = heap_alloc('X', 8U);
    printf("request 8 slots again: %s", at < 0 ? "FAILED" : "ok, placed at slot ");
    if (at >= 0) printf("%d", at);
    putchar('\n');
    show("after allocating X");

    printf("Lesson: free bytes != usable bytes. A fixed-block pool never has this problem.\n");
    return 0;
}
