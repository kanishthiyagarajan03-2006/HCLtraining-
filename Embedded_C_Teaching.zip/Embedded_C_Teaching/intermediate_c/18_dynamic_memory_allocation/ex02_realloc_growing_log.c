/*
 * ============================================================================
 *  Topic   : 18 Dynamic Memory Allocation
 *  Example : 02 - realloc: a log buffer that grows by doubling
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : realloc(p, n) resizes a block and may MOVE it, so the old pointer is
 *            invalid afterwards. Never write  p = realloc(p, n);  - if realloc
 *            fails it returns NULL and the original block leaks. Assign to a
 *            temporary first. Growing by doubling keeps the number of calls small.
 *  Embedded use : a debug/event log whose final size is unknown at compile time.
 *            (On a safety-critical MCU you would use a fixed array instead; this
 *            pattern is common on embedded Linux gateways and in test tools.)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_realloc_growing_log.c -o ex02
 *  Output  : twelve log lines appended; the capacity grows 16 -> 32 -> 64 -> 128 ...
 *            and the whole log is printed at the end
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Start at capacity 8 instead of 16 - how many reallocs now happen?
 *            2) Add a MAX_CAP limit so the log refuses to grow past 256 bytes.
 * ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char  *data;       /* heap block, NUL-terminated text */
    size_t len;        /* bytes used, not counting the terminator */
    size_t cap;        /* bytes allocated */
} log_t;

#define LOG_START_CAP 16U

static int log_init(log_t *lg)
{
    lg->data = malloc(LOG_START_CAP);
    if (lg->data == NULL) return -1;
    lg->data[0] = '\0';
    lg->len = 0U;
    lg->cap = LOG_START_CAP;
    return 0;
}

static void log_free(log_t *lg)
{
    free(lg->data);
    lg->data = NULL;
    lg->len = lg->cap = 0U;
}

/* Append text (and a newline); grow the block first if it will not fit. */
static int log_append(log_t *lg, const char *text)
{
    size_t n = strlen(text);
    size_t need = lg->len + n + 1U /* '\n' */ + 1U /* '\0' */;
    if (need > lg->cap) {
        size_t new_cap = lg->cap;
        while (new_cap < need) new_cap *= 2U;           /* doubling policy */

        char *tmp = realloc(lg->data, new_cap);         /* NOT lg->data = realloc(...) */
        if (tmp == NULL) return -1;                     /* old block is still valid and owned */
        printf("  [realloc: capacity %zu -> %zu bytes]\n", lg->cap, new_cap);
#ifdef DEMO_BUG
        /* BUG: after a successful realloc the OLD pointer may be dangling. */
        char *stale = lg->data;
        lg->data = tmp;
        stale[0] = 'X';                                 /* use-after-free if the block moved */
#else
        lg->data = tmp;
#endif
        lg->cap = new_cap;
    }
    memcpy(lg->data + lg->len, text, n);
    lg->len += n;
    lg->data[lg->len++] = '\n';
    lg->data[lg->len] = '\0';
    return 0;
}

int main(void)
{
    static const char *const events[] = {
        "boot ok", "uart1 init 115200", "adc calibrated", "i2c scan: 0x48 0x68",
        "sensor online", "temp=24C", "temp=25C", "temp=26C", "fan on",
        "temp=24C", "fan off", "shutdown requested",
    };

    log_t lg;
    if (log_init(&lg) != 0) {
        printf("out of memory\n");
        return 1;
    }
    for (size_t i = 0; i < sizeof events / sizeof events[0]; i++) {
        printf("append \"%s\" (len=%zu cap=%zu)\n", events[i], lg.len, lg.cap);
        if (log_append(&lg, events[i]) != 0) {
            printf("log full: message dropped\n");
            break;
        }
    }
    printf("---- log (%zu bytes used of %zu allocated) ----\n%s", lg.len, lg.cap, lg.data);
    log_free(&lg);
    return 0;
}
