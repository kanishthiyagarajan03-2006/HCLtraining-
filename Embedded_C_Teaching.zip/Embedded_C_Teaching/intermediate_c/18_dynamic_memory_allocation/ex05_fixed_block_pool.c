/*
 * ============================================================================
 *  Topic   : 18 Dynamic Memory Allocation
 *  Example : 05 - Fixed-block memory pool over a static array (no malloc, no fragmentation)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Instead of malloc, reserve N equally sized blocks in a static array and
 *            chain the free ones into a linked list. alloc = pop the list head,
 *            free = push it back: both take constant time and the pool can never
 *            fragment. Freeing is validated (inside the pool? aligned? in use?).
 *  Embedded use : message buffers passed from an ISR to a task, CAN frames, network
 *            packets. Same idea as FreeRTOS+TCP buffers or the Zephyr k_mem_slab /
 *            CMSIS-RTOS osMemoryPool.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_fixed_block_pool.c -o ex05
 *  Output  : 4-block pool: ISR-style allocations, exhaustion returning NULL, a
 *            double free that is DETECTED and refused, then all blocks returned
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Increase POOL_BLOCKS to 6 - when does the first NULL appear now?
 *            2) Add a 'high-water mark' counter: the most blocks ever in use.
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define POOL_BLOCKS 4U

typedef struct {
    uint8_t  id;
    uint8_t  len;
    uint8_t  payload[14];
} msg_t;                                     /* 16-byte message buffer */

/* A free block stores the 'next' pointer INSIDE itself - no extra bookkeeping RAM. */
typedef union block {
    union block *next;
    msg_t        msg;
} block_t;

static block_t pool[POOL_BLOCKS];            /* the whole "heap", in .bss */
static block_t *free_head;
static uint8_t  in_use[POOL_BLOCKS];         /* catches double free */

static void pool_init(void)
{
    for (size_t i = 0; i < POOL_BLOCKS; i++) {
        pool[i].next = (i + 1U < POOL_BLOCKS) ? &pool[i + 1U] : NULL;
        in_use[i] = 0U;
    }
    free_head = &pool[0];
}

static msg_t *pool_alloc(void)
{
    block_t *b = free_head;
    if (b == NULL) return NULL;              /* pool exhausted: caller must cope */
    free_head = b->next;
    in_use[b - pool] = 1U;                   /* pointer difference = block index */
    memset(b, 0, sizeof *b);
    return &b->msg;
}

/* Returns 0 if released, -1 if the pointer was not a live block of this pool. */
static int pool_free(msg_t *m)
{
    uintptr_t lo = (uintptr_t)pool;
    uintptr_t p  = (uintptr_t)m;
    if (p < lo || p >= lo + sizeof pool || (p - lo) % sizeof pool[0] != 0U) return -1;
    size_t idx = (p - lo) / sizeof pool[0];
    if (!in_use[idx]) return -1;             /* double free: refuse instead of corrupting */
    in_use[idx] = 0U;
    block_t *b = &pool[idx];
    b->next = free_head;
    free_head = b;
    return 0;
}

static size_t blocks_used(void)
{
    size_t n = 0U;
    for (size_t i = 0; i < POOL_BLOCKS; i++) n += in_use[i];
    return n;
}

int main(void)
{
    pool_init();
    printf("pool: %u blocks x %zu bytes = %zu bytes of static RAM\n", POOL_BLOCKS,
           sizeof(block_t), sizeof pool);

    /* "ISR" grabs buffers as frames arrive. */
    msg_t *held[POOL_BLOCKS + 1U];
    size_t got = 0U;
    for (uint8_t id = 1U; id <= POOL_BLOCKS + 1U; id++) {
        msg_t *m = pool_alloc();
        if (m == NULL) {
            printf("alloc for frame %u: NULL (pool empty, frame dropped)\n", (unsigned)id);
            continue;
        }
        m->id = id;
        m->len = 3U;
        memcpy(m->payload, "abc", 3U);
        held[got++] = m;
        printf("alloc for frame %u: block %td, used=%zu/%u\n", (unsigned)id,
               (block_t *)m - pool, blocks_used(), POOL_BLOCKS);
    }

    /* A task consumes and frees the oldest buffer, which makes room again. */
    unsigned first_id = held[0]->id;         /* read it BEFORE freeing: the block gets reused */
    printf("free frame %u -> rc=%d\n", first_id, pool_free(held[0]));
    printf("free the same pointer again -> rc=%d (double free detected)\n", pool_free(held[0]));

    int bogus = 0;
    printf("free a stack address -> rc=%d (not part of the pool)\n", pool_free((msg_t *)&bogus));

    msg_t *again = pool_alloc();
    printf("alloc after free: %s, reuses block %td\n", again ? "ok" : "NULL",
           again ? (block_t *)again - pool : (ptrdiff_t)-1);

    /* Return everything: the pool is fully available again. */
    for (size_t i = 1U; i < got; i++) pool_free(held[i]);
    if (again != NULL) pool_free(again);
    printf("all returned: used=%zu/%u\n", blocks_used(), POOL_BLOCKS);
    return 0;
}
