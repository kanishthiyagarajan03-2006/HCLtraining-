/*
 * ============================================================================
 *  Topic   : 18 Dynamic Memory Allocation
 *  Example : 08 - Lazy allocation: watch VmRSS around malloc, memset and mmap
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : On Linux, malloc(8 MB) only reserves ADDRESS SPACE. Physical RAM (the
 *            resident set, VmRSS in /proc/self/status) is assigned page by page
 *            when the memory is first TOUCHED. mmap() is the system call under
 *            big mallocs; it also gives zero-filled pages and can be returned
 *            to the kernel at once with munmap().
 *  Embedded use : embedded Linux boxes have little RAM; knowing that "allocated" is not
 *            "used" explains surprising `free` numbers and OOM-killer events.
 *            Check a daemon's footprint with: grep VmRSS /proc/<pid>/status
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex08_vmrss_malloc_vs_mmap.c -o ex08
 *  Output  : RSS growth (in MB) after malloc, after touching it, and after an
 *            mmap/munmap pair; absolute RSS values vary, the pattern does not
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Touch only the first half of the block - how much does RSS grow?
 *            2) Use calloc(1, BIG) instead of malloc+memset: when does RSS rise?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>

#define BIG_BYTES (8UL * 1024UL * 1024UL)       /* 8 MB */

/* Read the VmRSS line (in kB) from /proc/self/status. Returns -1 if unavailable. */
static long read_rss_kb(void)
{
    FILE *f = fopen("/proc/self/status", "r");
    if (f == NULL) return -1;
    char line[128];
    long kb = -1;
    while (fgets(line, sizeof line, f) != NULL) {
        if (sscanf(line, "VmRSS: %ld kB", &kb) == 1) break;
    }
    fclose(f);
    return kb;
}

/* Round a kB difference to whole megabytes so the printout is stable. */
static long delta_mb(long after_kb, long before_kb)
{
    long d = after_kb - before_kb;
    return (d + (d >= 0 ? 512 : -512)) / 1024;
}

int main(void)
{
    long r0 = read_rss_kb();
    if (r0 < 0) {
        printf("/proc/self/status not readable here - nothing to measure (skipping)\n");
        return 0;
    }

    /* Step 1: malloc only reserves address space. */
    unsigned char *p = malloc(BIG_BYTES);
    if (p == NULL) { printf("malloc failed\n"); return 1; }
    long r1 = read_rss_kb();
    printf("malloc(8 MB), not touched : RSS change = %+ld MB  (pages not yet resident)\n",
           delta_mb(r1, r0));

    /* Step 2: touching every page forces the kernel to supply real RAM. */
    memset(p, 0xA5, BIG_BYTES);
    long r2 = read_rss_kb();
    printf("after memset of all 8 MB  : RSS change = %+ld MB  (every page was touched)\n",
           delta_mb(r2, r1));
    free(p);

    /* Step 3: mmap/munmap directly: the kernel gets the pages back immediately. */
    unsigned char *m = mmap(NULL, BIG_BYTES, PROT_READ | PROT_WRITE,
                            MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (m == MAP_FAILED) { perror("mmap"); return 1; }
    int zeroed = (m[0] == 0U && m[BIG_BYTES - 1U] == 0U);   /* anonymous memory starts at 0 */
    printf("mmap(8 MB) first/last byte zero: %s (malloc gives no such promise)\n",
           zeroed ? "yes" : "no");
    long r3 = read_rss_kb();
    memset(m, 0x5A, BIG_BYTES);
    long r4 = read_rss_kb();
    munmap(m, BIG_BYTES);
    long r5 = read_rss_kb();
    printf("mmap + touch              : RSS change = %+ld MB\n", delta_mb(r4, r3));
    printf("after munmap              : RSS change = %+ld MB  (pages returned at once)\n",
           delta_mb(r5, r4));

    printf("Embedded Linux tip: watch VmRSS, not just the size you asked malloc for.\n");
    return 0;
}
