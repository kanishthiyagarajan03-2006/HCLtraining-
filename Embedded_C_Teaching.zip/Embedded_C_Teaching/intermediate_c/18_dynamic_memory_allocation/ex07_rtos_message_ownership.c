/*
 * ============================================================================
 *  Topic   : 18 Dynamic Memory Allocation
 *  Example : 07 - Dynamic RTOS objects and heap messages whose ownership moves
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Queue and semaphore objects are created dynamically and must be deleted.
 *            A queue can carry POINTERS to heap messages: the producer allocates,
 *            sends the pointer (ownership transfers) and must not touch it again;
 *            the consumer becomes the owner and is the one that frees it.
 *            Counting allocs and frees proves nothing leaked.
 *  Embedded use : pass large payloads (sensor records, network packets) by pointer to
 *            avoid copying them through the queue; one owner at a time avoids both
 *            leaks and double frees.
 *  Real FreeRTOS: xQueueCreate(2, sizeof(msg_t *)); pvPortMalloc / vPortFree;
 *                 xSemaphoreCreateBinary(); vQueueDelete(); vSemaphoreDelete();
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_rtos_message_ownership.c -o ex07
 *  Output  : the producer allocates 8 messages faster than the consumer can handle;
 *            one is dropped (and freed by the producer), the rest are freed by the
 *            consumer, the reporter prints allocs == frees, objects are deleted
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Comment out 'free(m); n_free++;' in the consumer: what does the reporter print?
 *            2) Make the queue length 1 - how many samples are dropped now?
 * ============================================================================
 */
#include "mini_rtos.h"

typedef struct {
    uint16_t seq;
    uint16_t adc;
} msg_t;

static rtos_queue_t *q_msgs;         /* queue of msg_t * (pointer-sized items) */
static rtos_sem_t   *sem_done;
static unsigned      n_alloc, n_free;

#define N_MESSAGES 8U

static void producer_task(void *arg)
{
    (void)arg;
    for (uint16_t i = 1U; i <= N_MESSAGES; i++) {
        msg_t *m = malloc(sizeof *m);                 /* heap message (FreeRTOS: pvPortMalloc) */
        if (m == NULL) {
            rtos_log("out of memory, sample %u dropped", (unsigned)i);
            continue;
        }
        n_alloc++;
        m->seq = i;
        m->adc = (uint16_t)(2000U + 25U * i);
        if (!rtos_queue_send(q_msgs, &m, 10U)) {      /* the queue stores the POINTER value */
            rtos_log("queue full, sample %u dropped", (unsigned)i);
            free(m);                                  /* send failed: we still own it */
            n_free++;
        } else {
            rtos_log("allocated msg %u and handed it over", (unsigned)i);
            /* m now belongs to the consumer: do NOT read or free it here. */
        }
        rtos_delay(25);                               /* producer is faster than the consumer */
    }
    rtos_log("producer finished");
}

static void consumer_task(void *arg)
{
    (void)arg;
    msg_t *m;
    while (rtos_queue_recv(q_msgs, &m, 300U)) {       /* wait up to 300 ms for work */
        rtos_busy(45);                                 /* slow "processing": 45 ms per message */
        rtos_log("got msg %u adc=%u -> freeing it", (unsigned)m->seq, (unsigned)m->adc);
        free(m);                                      /* the consumer is the final owner */
        n_free++;
    }
    rtos_log("no more messages, consumer signals done");
    rtos_sem_give(sem_done);
}

static void reporter_task(void *arg)
{
    (void)arg;
    rtos_sem_take(sem_done, RTOS_WAIT_FOREVER);       /* sleep until the consumer is done */
    rtos_log("allocs=%u frees=%u -> %s", n_alloc, n_free,
             n_alloc == n_free ? "no leak" : "LEAK!");
}

int main(void)
{
    q_msgs   = rtos_queue_create(2U, sizeof(msg_t *));   /* xQueueCreate */
    sem_done = rtos_sem_create(1U, 0U);                  /* xSemaphoreCreateBinary */
    if (q_msgs == NULL || sem_done == NULL) {
        printf("could not create RTOS objects\n");
        rtos_queue_delete(q_msgs);
        rtos_sem_delete(sem_done);
        return 1;
    }

    rtos_task_create("producer", producer_task, NULL, 3, 0);
    rtos_task_create("consumer", consumer_task, NULL, 2, 0);
    rtos_task_create("reporter", reporter_task, NULL, 1, 0);

    rtos_start(2000);

    /* Anything still queued would be leaked by deleting the queue: drain it first. */
    msg_t *left;
    while (rtos_queue_count(q_msgs) > 0U && rtos_queue_recv(q_msgs, &left, RTOS_NO_WAIT)) {
        free(left);
        n_free++;
    }
    rtos_queue_delete(q_msgs);                           /* vQueueDelete */
    rtos_sem_delete(sem_done);                           /* vSemaphoreDelete */
    rtos_shutdown();
    printf("objects deleted; final allocs=%u frees=%u\n", n_alloc, n_free);
    return 0;
}
