/*
 * ============================================================================
 *  Topic   : 18 Dynamic Memory Allocation
 *  Example : 03 - Catching leaks with a counting allocator (and the cleanup idiom)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : The three classic heap bugs are the leak (no free), the double free
 *            and the use-after-free. A thin wrapper that counts live blocks turns
 *            an invisible leak into a number you can print or assert in a test.
 *            A single 'cleanup:' exit path makes sure every error path frees.
 *  Embedded use : an MCU that leaks 32 bytes per message runs fine for hours, then
 *            dies in the field. Firmware often ships a debug allocator like this
 *            (FreeRTOS: xPortGetFreeHeapSize() / xPortGetMinimumEverFreeHeapSize()).
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_leak_tracking_allocator.c -o ex03
 *  Output  : live-block count after a correct handler (0) and after a leaky one (1),
 *            then the leak is released so the program itself exits clean
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Make handle_packet() return early without 'goto cleanup' - what does
 *               the live count show?
 *            2) Build with -DDEMO_BUG and read what AddressSanitizer says.
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---- counting allocator: a small header hidden in front of every block ---- */
typedef union {
    size_t     size;          /* bytes the caller asked for                  */
    max_align_t align;        /* forces the user block to be well aligned    */
} hdr_t;

static size_t live_blocks;
static size_t live_bytes;

static void *trk_alloc(size_t n)
{
    hdr_t *h = malloc(sizeof *h + n);
    if (h == NULL) return NULL;
    h->size = n;
    live_blocks++;
    live_bytes += n;
    return h + 1;             /* the caller's memory starts just after the header */
}

static void trk_free(void *p)
{
    if (p == NULL) return;
    hdr_t *h = (hdr_t *)p - 1;               /* step back to the header */
    live_blocks--;
    live_bytes -= h->size;
    free(h);
}

static void report(const char *when)
{
    printf("%-34s live blocks=%zu bytes=%zu%s\n", when, live_blocks, live_bytes,
           live_blocks ? "   <-- LEAK" : "");
}

/* ---- two versions of a packet handler ------------------------------------ */
#define PKT_MAX 32U

/* GOOD: every path leaves through 'cleanup', so the buffer is always freed. */
static int handle_packet(const uint8_t *raw, size_t len)
{
    int rc = -1;
    uint8_t *copy = trk_alloc(PKT_MAX);
    if (copy == NULL) return -1;
    if (len > PKT_MAX) goto cleanup;               /* error path: still frees */
    memcpy(copy, raw, len);
    rc = (copy[0] == 0x7EU) ? 0 : -2;              /* 0x7E = frame start byte */
cleanup:
    trk_free(copy);
    return rc;
}

/* BAD (kept safe for the demo): returns early on the error path and "forgets" to free.
 * The forgotten pointer is handed back through *orphan ONLY so main() can release it;
 * a real leaky function would simply lose it.                                        */
static int leaky_handle_packet(const uint8_t *raw, size_t len, void **orphan)
{
    uint8_t *copy = trk_alloc(PKT_MAX);
    if (copy == NULL) return -1;
    if (len > PKT_MAX) {
        *orphan = copy;                            /* in real code: just "return -1;" */
        return -1;                                 /* BUG: no free on this path */
    }
    memcpy(copy, raw, len);
    trk_free(copy);
    return 0;
}

int main(void)
{
    const uint8_t good[4] = { 0x7E, 1, 2, 3 };
    uint8_t oversized[PKT_MAX + 8U];
    memset(oversized, 0x55, sizeof oversized);

    report("start:");
    printf("handle_packet(good)      -> %d\n", handle_packet(good, sizeof good));
    printf("handle_packet(oversized) -> %d\n", handle_packet(oversized, sizeof oversized));
    report("after correct handler x2:");

    void *orphan = NULL;
    printf("leaky_handle_packet(oversized) -> %d\n",
           leaky_handle_packet(oversized, sizeof oversized, &orphan));
    report("after leaky handler:");

    trk_free(orphan);                              /* clean up so this demo exits clean */
    report("after releasing the orphan:");

#ifdef DEMO_BUG
    /* BUG 1: leak - the block is never freed (LeakSanitizer reports it at exit). */
    uint8_t *lost = trk_alloc(8U);
    lost[0] = 1U;
    /* BUG 2: use-after-free - the memory was returned, but we still write to it. */
    uint8_t *dead = trk_alloc(8U);
    trk_free(dead);
    dead[0] = 2U;
    /* BUG 3: double free - free() on a block that is already free. */
    trk_free(dead);
#endif
    return 0;
}
