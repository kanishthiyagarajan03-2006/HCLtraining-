/*
 * ============================================================================
 *  Topic   : 18 Dynamic Memory Allocation
 *  Example : 01 - malloc, calloc and free for a sample buffer (always check NULL)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : malloc(n) gives n UNINITIALISED bytes; calloc(count, size) gives zeroed
 *            memory and guards count*size against overflow. Both return NULL on
 *            failure. Every allocation needs exactly one free(), after which the
 *            pointer is set to NULL so it cannot be used or freed again by mistake.
 *  Embedded use : a driver may allocate its sample buffer once at start-up, once
 *            the number of channels is known. An MCU heap is tiny (a few KB), so a
 *            failed allocation is a NORMAL event that the code must handle.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_malloc_calloc_free.c -o ex01
 *  Output  : a zeroed 8-sample buffer filled and summed, a failed allocation handled
 *            gracefully (budget exceeded), and free(NULL) shown to be harmless
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Set HEAP_BUDGET_BYTES to 15 - which message appears, and why is the
 *               exit code now 1?
 *            2) Replace calloc with malloc: why must you now fill the buffer first?
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define HEAP_BUDGET_BYTES 64U       /* pretend the MCU can spare only 64 bytes for the heap */

/* Wrapper that makes failure easy to demonstrate on a PC with gigabytes of RAM.
 * The budget test is written as a division so that count * size can never wrap around. */
static void *try_calloc(size_t count, size_t size)
{
    if (size != 0U && count > HEAP_BUDGET_BYTES / size) return NULL;  /* "out of memory" */
    return calloc(count, size);
}

typedef struct {
    uint16_t *data;
    size_t    len;
} sample_buf_t;

/* Returns 0 on success, -1 on failure. On failure the struct is left empty and safe. */
static int sample_buf_init(sample_buf_t *b, size_t n)
{
    b->data = try_calloc(n, sizeof *b->data);      /* sizeof *ptr follows the type */
    b->len  = (b->data != NULL) ? n : 0U;
    return (b->data != NULL) ? 0 : -1;
}

static void sample_buf_free(sample_buf_t *b)
{
    free(b->data);
    b->data = NULL;                                 /* dangling pointer -> NULL */
    b->len  = 0U;
}

int main(void)
{
    sample_buf_t buf;

    /* 1) Allocate: 8 x 2 bytes = 16 bytes, well inside the 64-byte budget. */
    if (sample_buf_init(&buf, 8U) != 0) {
        printf("out of memory\n");
        return 1;
    }
    size_t zeros = 0U;
    for (size_t i = 0; i < buf.len; i++) zeros += (buf.data[i] == 0U);
    printf("calloc'd %zu samples (%zu bytes), %zu of them already zero\n", buf.len,
           buf.len * sizeof buf.data[0], zeros);

    /* 2) Use it like any array. */
    uint32_t sum = 0U;
    for (size_t i = 0; i < buf.len; i++) {
        buf.data[i] = (uint16_t)(1000U + 10U * i);
        sum += buf.data[i];
    }
    printf("filled: first=%u last=%u sum=%u\n", (unsigned)buf.data[0],
           (unsigned)buf.data[buf.len - 1U], (unsigned)sum);

    /* 3) Free exactly once; the helper nulls the pointer. */
    sample_buf_free(&buf);
    printf("after free: data=%s len=%zu\n", buf.data == NULL ? "NULL" : "dangling!", buf.len);
    sample_buf_free(&buf);        /* safe: free(NULL) does nothing, so a 2nd call is harmless */
    printf("second sample_buf_free() was harmless because the pointer was NULL\n");

#ifdef DEMO_BUG
    /* BUG: freeing a non-NULL pointer twice corrupts the heap (undefined behaviour).
     * This is why we NULL the pointer after free().                              */
    uint16_t *p = malloc(16U);
    free(p);
    free(p);                      /* double free: gcc warns, AddressSanitizer aborts */
#endif

    /* 4) Failure is normal on an MCU: a 100-sample buffer needs 200 bytes > budget. */
    sample_buf_t big;
    if (sample_buf_init(&big, 100U) != 0)
        printf("request for 100 samples (200 bytes) refused: budget is %u bytes\n",
               HEAP_BUDGET_BYTES);
    sample_buf_free(&big);        /* still safe to call after a failed init */
    return 0;
}
