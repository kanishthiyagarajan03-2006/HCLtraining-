/*
 * ============================================================================
 *  Topic   : 18 Dynamic Memory Allocation
 *  Example : 06 - A FreeRTOS heap_1-style bump allocator (allocate at boot, never free)
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : The simplest "malloc": a static byte array and an offset that only moves
 *            forward. Each request is rounded up to the alignment, the offset
 *            advances, and nothing is ever freed. It is fast, deterministic and
 *            cannot fragment - ideal when all objects live as long as the firmware.
 *  Embedded use : FreeRTOS heap_1.c does exactly this for tasks, queues and semaphores
 *            created before vTaskStartScheduler(). configTOTAL_HEAP_SIZE is the array.
 *  Real FreeRTOS: pvPortMalloc(), xPortGetFreeHeapSize(), configTOTAL_HEAP_SIZE
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_bump_allocator_heap1.c -o ex06
 *  Output  : four boot-time "objects" carved out of a 256-byte heap, the used/free
 *            counters after each, and a final request refused when the heap is full
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change ALIGN to 16 and compare the 'used' column with this output.
 *            2) What would the 'free' function of this allocator have to do?
 *               (Why is heap_1's vPortFree only a stub that asserts?)
 * ============================================================================
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define HEAP_SIZE 256U
#define ALIGN     8U                    /* Cortex-M wants 8-byte stack/heap alignment */

static _Alignas(ALIGN) uint8_t heap[HEAP_SIZE];   /* configTOTAL_HEAP_SIZE */
static size_t next_free;                       /* the "bump pointer" as an offset */

static void *heap_alloc(size_t n)
{
    size_t rounded = (n + (ALIGN - 1U)) & ~(size_t)(ALIGN - 1U);   /* round UP to ALIGN */
    if (rounded < n || rounded > HEAP_SIZE - next_free)            /* overflow or no room */
        return NULL;
    void *p = &heap[next_free];
    next_free += rounded;
    return p;
}

static size_t heap_free_bytes(void) { return HEAP_SIZE - next_free; }

/* Pretend kernel objects, created by "xQueueCreate / xTaskCreate" before the scheduler. */
typedef struct { uint8_t  items[10]; uint8_t head, tail; }  queue_t;    /* 12 bytes */
typedef struct { uint32_t regs[4]; const char *name; }      tcb_t;      /* 24 here, 20 on ARM */
typedef struct { uint8_t  count; }                         bsem_t;     /* 1 byte  */

static void report(const char *what, const void *p, size_t n)
{
    if (p == NULL) {
        printf("%-14s request %3zu bytes -> NULL   (heap full)\n", what, n);
        return;
    }
    printf("%-14s request %3zu bytes -> offset %3zu, aligned to %u: %s | used=%3zu free=%3zu\n",
           what, n, (size_t)((const uint8_t *)p - heap), ALIGN,
           ((uintptr_t)p % ALIGN == 0U) ? "yes" : "NO", (size_t)(HEAP_SIZE - heap_free_bytes()),
           heap_free_bytes());
}

int main(void)
{
    printf("heap: %u bytes, alignment %u\n", HEAP_SIZE, ALIGN);

    queue_t *q = heap_alloc(sizeof *q);
    report("uart_queue", q, sizeof *q);

    tcb_t *t = heap_alloc(sizeof *t);
    report("task TCB", t, sizeof *t);

    bsem_t *s = heap_alloc(sizeof *s);                   /* 1 byte still costs ALIGN bytes */
    report("semaphore", s, sizeof *s);

    uint8_t *stack = heap_alloc(128U);
    report("task stack", stack, 128U);

    /* Use the objects normally. */
    if (q != NULL && t != NULL && s != NULL) {
        memset(q, 0, sizeof *q);
        t->name = "blink";
        s->count = 1U;
        printf("objects usable: TCB name=\"%s\", sem count=%u\n", t->name, (unsigned)s->count);
    }

    /* The heap is nearly full: a big request is simply refused. */
    uint8_t *big = heap_alloc(100U);
    report("log buffer", big, 100U);

    /* Small one still fits in what is left. */
    uint8_t *small = heap_alloc(16U);
    report("small buf", small, 16U);

    printf("final: %zu of %u bytes used; there is no free() - reboot to recycle\n",
           (size_t)(HEAP_SIZE - heap_free_bytes()), HEAP_SIZE);
    return 0;
}
