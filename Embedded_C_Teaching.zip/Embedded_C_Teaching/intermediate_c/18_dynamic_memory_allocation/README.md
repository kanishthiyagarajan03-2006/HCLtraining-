# Topic 18 - Dynamic Memory Allocation
**Suggested session:** 90 min | **Prerequisite topics:** 12 Memory Map, 17 Pointers

Students should understand `malloc`, `calloc`, `realloc` and `free`, the three classic heap bugs, and - just as important in embedded work - why microcontroller firmware often avoids the heap. The first three examples teach correct use and bug detection. The next three show the embedded alternatives (fragmentation, fixed-block pool, `heap_1`-style bump allocator). The last two show dynamic memory in an RTOS and on embedded Linux.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_malloc_calloc_free.c` | MCU | checked `malloc/calloc`, `sizeof *p`, free then set to NULL, failure as a normal event |
| 02 | `ex02_realloc_growing_log.c` | MCU | `realloc` growth by doubling, never `p = realloc(p, n)`, pointer may move |
| 03 | `ex03_leak_tracking_allocator.c` | MCU | counting allocator header trick, `goto cleanup` idiom, a leak made visible as a number |
| 04 | `ex04_heap_fragmentation_sim.c` | MCU | first-fit heap map: 12 slots free yet an 8-slot request fails |
| 05 | `ex05_fixed_block_pool.c` | MCU | static fixed-block pool with free list, validated free, double-free detection |
| 06 | `ex06_bump_allocator_heap1.c` | MCU | FreeRTOS `heap_1`-style allocator: alignment rounding, no free, exhaustion |
| 07 | `ex07_rtos_message_ownership.c` | RTOS | dynamic queue/semaphore create+delete, pointer messages, single-owner rule, alloc == free |
| 08 | `ex08_vmrss_malloc_vs_mmap.c` | LINUX | lazy allocation: VmRSS around malloc, memset and mmap/munmap |

## Teaching notes
* Rule to repeat: every allocation has exactly one owner, and the owner frees it exactly once. ex07 makes ownership transfer through a queue concrete.
* `p = realloc(p, n)` leaks the old block if realloc fails (ex02 shows the safe temporary-pointer form).
* Ask: "free memory is 12 slots, why did the request fail?" (ex04) - this is the key argument for MISRA-style bans on the heap and for pools (ex05).
* A failed allocation on an MCU is normal, not exceptional; compare ex01 (budget) with ex05 (pool returns NULL and the frame is dropped).
* ex08 explains why `top`/`free` on an embedded Linux board does not match what the code "allocated".

## Live-demo tips
* Every DEMO_BUG switch is meant for AddressSanitizer: `gcc -std=gnu11 -g -fsanitize=address -DDEMO_BUG -I../../common ex03_leak_tracking_allocator.c -o ex03 && ./ex03` stops at the first error (the use-after-free); comment the three bug blocks out one at a time to see the leak report and the double-free report as well.
* ex01 with `-DDEMO_BUG`: GCC even warns about the double free at compile time; show it, then show AddressSanitizer at run time.
* ex08: run it twice and note that the absolute RSS differs between runs but the +8 MB / -8 MB pattern never does. Under AddressSanitizer a plain `free()` does not return memory at once, which is why the example uses `munmap`.
