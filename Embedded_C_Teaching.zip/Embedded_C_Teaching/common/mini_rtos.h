/*
 * ============================================================================
 *  mini_rtos.h  -  A tiny teaching RTOS that runs on a Linux PC
 * ============================================================================
 *  Purpose
 *    Lets students write tasks that look exactly like FreeRTOS tasks
 *    (infinite loops that block on delays, queues and semaphores) and see
 *    the scheduler interleave them - no board and no RTOS install needed.
 *
 *  How it maps to FreeRTOS
 *    FreeRTOS                          mini_rtos
 *    -------------------------------   -----------------------------------
 *    xTaskCreate(fn,name,stack,arg,p)  rtos_task_create(name,fn,arg,p,stack)
 *    vTaskStartScheduler()             rtos_start(run_ms)
 *    vTaskDelay(ticks)                 rtos_delay(ms)       (1 tick = 1 ms)
 *    vTaskDelayUntil()                 rtos_delay_until()
 *    taskYIELD()                       rtos_yield()
 *    xQueueCreate(length,item_size)    rtos_queue_create(length, item_size)
 *    xQueueSend / xQueueReceive        rtos_queue_send / rtos_queue_recv
 *    xSemaphoreCreateBinary/Give/Take  rtos_sem_create / give / take
 *    uxTaskGetStackHighWaterMark()     rtos_stack_high_water()
 *    xTaskGetTickCount()               rtos_ticks()
 *    Bigger number = higher priority (same as FreeRTOS).
 *
 *  How it works (so you can explain it in class)
 *    * Every task owns its own stack and CPU context (ucontext / swapcontext),
 *      exactly what a real RTOS saves and restores on a context switch.
 *    * Time is SIMULATED: when every task is blocked the kernel jumps the
 *      clock to the next wake-up time, so demos finish instantly.
 *    * The highest-priority READY task always runs; equal priorities are
 *      served round-robin.
 *    * Tasks switch when they block (delay / queue / semaphore), yield, or
 *      call rtos_busy(ms). rtos_busy() models CPU work and IS preemptible:
 *      if a higher-priority task becomes ready, it runs immediately.
 *    * Giving a semaphore, sending to / receiving from a queue, or creating a
 *      task from inside a task also preempts at once when that wakes a
 *      higher-priority task (same as a real RTOS).
 *
 *  Differences from a real RTOS (good discussion points)
 *    * Equal-priority tasks are NOT time-sliced by a tick interrupt: they take
 *      turns only when a task blocks, yields or finishes. Tasks are started in
 *      creation order.
 *    * A semaphore created with max = 1, initial = 1 can be used as a mutex,
 *      but it has no owner and no priority inheritance (a real FreeRTOS mutex
 *      from xSemaphoreCreateMutex() does).
 *    * Time is simulated and 1 tick = 1 ms; there is no tick interrupt.
 *
 *  Rules for task code
 *    * A task must block or call rtos_busy() regularly. A bare while(1){}
 *      would hang the demo (just like a real un-yielding task starves others).
 *    * Call rtos_shutdown() at the end of main() to free everything.
 *
 *  Needs Linux (glibc). On Windows use WSL, GitHub Codespaces or an online
 *  Linux VM. Compile:  gcc -std=gnu11 -Wall -Wextra -I../../common prog.c -o prog
 * ============================================================================
 */
#ifndef MINI_RTOS_H
#define MINI_RTOS_H

#ifndef __linux__
#  error "mini_rtos.h needs Linux (glibc ucontext). Use WSL, GitHub Codespaces or an online Linux VM."
#endif

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ucontext.h>

#define RTOS_WAIT_FOREVER 0xFFFFFFFFu
#define RTOS_NO_WAIT      0u
#define RTOS_MAX_TASKS    16
#define RTOS_MIN_STACK    32768u     /* PC stacks need room for printf; real MCUs use 256-1024 bytes */
#define RTOS_STACK_FILL   0xA5u      /* pattern used to measure stack high-water mark */

typedef enum {
    RTOS_READY,
    RTOS_DELAYED,
    RTOS_BLOCKED_RECV,
    RTOS_BLOCKED_SEND,
    RTOS_BLOCKED_SEM,
    RTOS_DONE
} rtos_state_t;

typedef struct rtos_task {
    const char    *name;
    void         (*fn)(void *);
    void          *arg;
    int            prio;
    rtos_state_t   state;
    uint32_t       wake_tick;     /* wake time for delay or for a blocking timeout */
    int            timed;         /* 1 if the blocking call has a timeout          */
    void          *wait_obj;      /* queue or semaphore the task waits on          */
    ucontext_t     ctx;
    unsigned char *stack;
    size_t         stack_size;
    uint32_t       run_ticks;     /* CPU ticks consumed through rtos_busy()        */
} rtos_task_t;

typedef struct rtos_queue {
    unsigned char *buf;
    size_t item_size, length, head, tail, count;
} rtos_queue_t;

typedef struct rtos_sem {
    unsigned count, max;
} rtos_sem_t;

typedef struct {
    rtos_task_t tasks[RTOS_MAX_TASKS];
    int         ntasks;
    int         last;             /* index of last task that ran (round-robin) */
    rtos_task_t *current;
    ucontext_t  sched_ctx;
    uint32_t    now;
    uint32_t    end;
} rtos_kernel_t;

static inline rtos_kernel_t *rtos_k(void)
{
    static rtos_kernel_t k;
    return &k;
}

/* ------------------------------ helpers ---------------------------------- */
static inline uint32_t rtos_ticks(void) { return rtos_k()->now; }

static inline const char *rtos_task_name(void)
{
    rtos_task_t *t = rtos_k()->current;
    return t ? t->name : "kernel";
}

static inline void rtos_log(const char *fmt, ...)
{
    va_list ap;
    printf("[%5u ms] %-9s| ", (unsigned)rtos_ticks(), rtos_task_name());
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    putchar('\n');
}

static inline int rtos_is_runnable(const rtos_task_t *t)
{
    const rtos_kernel_t *k = rtos_k();
    switch (t->state) {
    case RTOS_READY:        return 1;
    case RTOS_DELAYED:      return k->now >= t->wake_tick;
    case RTOS_BLOCKED_RECV: return ((const rtos_queue_t *)t->wait_obj)->count > 0u ||
                                   (t->timed && k->now >= t->wake_tick);
    case RTOS_BLOCKED_SEND: return ((const rtos_queue_t *)t->wait_obj)->count <
                                   ((const rtos_queue_t *)t->wait_obj)->length ||
                                   (t->timed && k->now >= t->wake_tick);
    case RTOS_BLOCKED_SEM:  return ((const rtos_sem_t *)t->wait_obj)->count > 0u ||
                                   (t->timed && k->now >= t->wake_tick);
    default:                return 0;
    }
}

/* Highest-priority runnable task; ties go round-robin after the last runner. */
static inline rtos_task_t *rtos_pick(void)
{
    rtos_kernel_t *k = rtos_k();
    rtos_task_t *best = NULL;
    int best_idx = -1;
    for (int i = 0; i < k->ntasks; i++) {
        int idx = (k->last + 1 + i) % k->ntasks;
        rtos_task_t *t = &k->tasks[idx];
        if (rtos_is_runnable(t) && (best == NULL || t->prio > best->prio)) {
            best = t;
            best_idx = idx;
        }
    }
    if (best) k->last = best_idx;
    return best;
}

/* Give the CPU back to the scheduler (this is the "context switch"). */
static inline void rtos_switch_to_scheduler(void)
{
    rtos_kernel_t *k = rtos_k();
    rtos_task_t *t = k->current;
    swapcontext(&t->ctx, &k->sched_ctx);
}

/* True if some OTHER task with a higher priority than `me` could run right now. */
static inline int rtos_higher_runnable(const rtos_task_t *me)
{
    const rtos_kernel_t *k = rtos_k();
    for (int j = 0; j < k->ntasks; j++) {
        const rtos_task_t *o = &k->tasks[j];
        if (o != me && o->prio > me->prio && rtos_is_runnable(o)) return 1;
    }
    return 0;
}

/* Call after anything that may have woken a higher-priority task: preempt at once. */
static inline void rtos_preempt_check(void)
{
    rtos_task_t *me = rtos_k()->current;
    if (me != NULL && rtos_higher_runnable(me)) {   /* me == NULL: called from main() */
        me->state = RTOS_READY;
        rtos_switch_to_scheduler();
    }
}

/* ------------------------------ tasks ------------------------------------ */
static inline void rtos_trampoline(void)
{
    rtos_task_t *t = rtos_k()->current;
    t->fn(t->arg);
    t->state = RTOS_DONE;          /* task function returned: delete the task */
}                                  /* uc_link resumes the scheduler           */

static inline rtos_task_t *rtos_task_create(const char *name, void (*fn)(void *),
                                            void *arg, int prio, size_t stack_bytes)
{
    rtos_kernel_t *k = rtos_k();
    if (k->ntasks >= RTOS_MAX_TASKS) {
        fprintf(stderr, "rtos: too many tasks\n");
        return NULL;
    }
    if (stack_bytes < RTOS_MIN_STACK) stack_bytes = RTOS_MIN_STACK;
    if (k->ntasks == 0) k->last = -1;      /* so equal-priority tasks start in creation order */
    rtos_task_t *t = &k->tasks[k->ntasks++];
    memset(t, 0, sizeof *t);
    t->name = name;
    t->fn = fn;
    t->arg = arg;
    t->prio = prio;
    t->state = RTOS_READY;
    t->stack_size = stack_bytes;
    t->stack = (unsigned char *)malloc(stack_bytes);
    if (t->stack == NULL) { k->ntasks--; return NULL; }
    memset(t->stack, RTOS_STACK_FILL, stack_bytes);
    getcontext(&t->ctx);
    t->ctx.uc_stack.ss_sp = t->stack;
    t->ctx.uc_stack.ss_size = stack_bytes;
    t->ctx.uc_link = &k->sched_ctx;
    makecontext(&t->ctx, rtos_trampoline, 0);
    rtos_preempt_check();                  /* a new higher-priority task runs immediately */
    return t;
}

/* Bytes of stack the task has never touched (like uxTaskGetStackHighWaterMark). */
static inline size_t rtos_stack_high_water(const rtos_task_t *t)
{
    size_t i = 0;
    while (i < t->stack_size && t->stack[i] == RTOS_STACK_FILL) i++;
    return i;
}

/* ------------------------------ scheduler -------------------------------- */
/* Run the system for run_ms of simulated time (or until every task ends). */
static inline void rtos_start(uint32_t run_ms)
{
    rtos_kernel_t *k = rtos_k();
    k->end = k->now + run_ms;
    while (k->now < k->end) {
        rtos_task_t *t = rtos_pick();
        if (t == NULL) {
            /* idle: jump the clock to the next time something can wake up */
            uint32_t next = 0xFFFFFFFFu;
            int alive = 0;
            for (int i = 0; i < k->ntasks; i++) {
                rtos_task_t *x = &k->tasks[i];
                if (x->state == RTOS_DONE) continue;
                alive = 1;
                if ((x->state == RTOS_DELAYED || x->timed) && x->wake_tick < next)
                    next = x->wake_tick;
            }
            if (!alive) {
                printf("[%5u ms] kernel   | all tasks finished\n", (unsigned)k->now);
                break;
            }
            if (next == 0xFFFFFFFFu) {
                printf("[%5u ms] kernel   | every task is blocked forever (deadlock)\n",
                       (unsigned)k->now);
                break;
            }
            k->now = (next < k->end) ? next : k->end;
            continue;
        }
        t->state = RTOS_READY;
        t->timed = 0;
        k->current = t;
        swapcontext(&k->sched_ctx, &t->ctx);
        k->current = NULL;
    }
}

static inline void rtos_yield(void)
{
    rtos_task_t *t = rtos_k()->current;
    t->state = RTOS_READY;
    rtos_switch_to_scheduler();
}

static inline void rtos_delay(uint32_t ms)
{
    rtos_task_t *t = rtos_k()->current;
    t->state = RTOS_DELAYED;
    t->wake_tick = rtos_k()->now + ms;
    rtos_switch_to_scheduler();
}

/* Periodic wake-up with no drift: last_wake starts as rtos_ticks(). */
static inline void rtos_delay_until(uint32_t *last_wake, uint32_t period_ms)
{
    rtos_task_t *t = rtos_k()->current;
    *last_wake += period_ms;
    if (*last_wake <= rtos_k()->now) return;      /* deadline already missed */
    t->state = RTOS_DELAYED;
    t->wake_tick = *last_wake;
    rtos_switch_to_scheduler();
}

/* Burn CPU for ms ticks. Preempted at once if a higher-priority task wakes. */
static inline void rtos_busy(uint32_t ms)
{
    rtos_kernel_t *k = rtos_k();
    rtos_task_t *me = k->current;
    for (uint32_t i = 0; i < ms; i++) {
        k->now++;
        me->run_ticks++;
        if (k->now >= k->end || rtos_higher_runnable(me)) {
            me->state = RTOS_READY;
            rtos_switch_to_scheduler();
        }
    }
}

/* ------------------------------ queues ----------------------------------- */
/* Same argument order as FreeRTOS xQueueCreate(uxQueueLength, uxItemSize). */
static inline rtos_queue_t *rtos_queue_create(size_t length, size_t item_size)
{
    rtos_queue_t *q = (rtos_queue_t *)calloc(1, sizeof *q);
    if (q == NULL) return NULL;
    q->buf = (unsigned char *)malloc(item_size * length);
    if (q->buf == NULL) { free(q); return NULL; }
    q->item_size = item_size;
    q->length = length;
    return q;
}

static inline void rtos_queue_delete(rtos_queue_t *q)
{
    if (q) { free(q->buf); free(q); }
}

/* Returns 1 on success, 0 on timeout (queue full). */
static inline int rtos_queue_send(rtos_queue_t *q, const void *item, uint32_t timeout_ms)
{
    rtos_kernel_t *k = rtos_k();
    rtos_task_t *t = k->current;
    int forever = (timeout_ms == RTOS_WAIT_FOREVER);
    uint32_t deadline = forever ? 0u : k->now + timeout_ms;
    while (q->count == q->length) {
        if (!forever && k->now >= deadline) return 0;
        t->state = RTOS_BLOCKED_SEND;
        t->wait_obj = q;
        t->timed = !forever;
        t->wake_tick = deadline;
        rtos_switch_to_scheduler();
    }
    memcpy(q->buf + q->tail * q->item_size, item, q->item_size);
    q->tail = (q->tail + 1u) % q->length;
    q->count++;
    rtos_preempt_check();                  /* may have woken a higher-priority receiver */
    return 1;
}

/* Returns 1 on success, 0 on timeout (queue empty). */
static inline int rtos_queue_recv(rtos_queue_t *q, void *item, uint32_t timeout_ms)
{
    rtos_kernel_t *k = rtos_k();
    rtos_task_t *t = k->current;
    int forever = (timeout_ms == RTOS_WAIT_FOREVER);
    uint32_t deadline = forever ? 0u : k->now + timeout_ms;
    while (q->count == 0u) {
        if (!forever && k->now >= deadline) return 0;
        t->state = RTOS_BLOCKED_RECV;
        t->wait_obj = q;
        t->timed = !forever;
        t->wake_tick = deadline;
        rtos_switch_to_scheduler();
    }
    memcpy(item, q->buf + q->head * q->item_size, q->item_size);
    q->head = (q->head + 1u) % q->length;
    q->count--;
    rtos_preempt_check();                  /* may have freed room for a higher-priority sender */
    return 1;
}

static inline size_t rtos_queue_count(const rtos_queue_t *q) { return q->count; }

/* ----------------------------- semaphores -------------------------------- */
/* max = 1 gives a binary semaphore; initial = 1 makes it a ready-to-take mutex. */
static inline rtos_sem_t *rtos_sem_create(unsigned max, unsigned initial)
{
    rtos_sem_t *s = (rtos_sem_t *)calloc(1, sizeof *s);
    if (s) { s->max = max; s->count = initial > max ? max : initial; }
    return s;
}

static inline void rtos_sem_delete(rtos_sem_t *s) { free(s); }

static inline void rtos_sem_give(rtos_sem_t *s)
{
    if (s->count < s->max) s->count++;
    rtos_preempt_check();                  /* may have woken a higher-priority waiter */
}

/* Returns 1 if taken, 0 on timeout. */
static inline int rtos_sem_take(rtos_sem_t *s, uint32_t timeout_ms)
{
    rtos_kernel_t *k = rtos_k();
    rtos_task_t *t = k->current;
    int forever = (timeout_ms == RTOS_WAIT_FOREVER);
    uint32_t deadline = forever ? 0u : k->now + timeout_ms;
    while (s->count == 0u) {
        if (!forever && k->now >= deadline) return 0;
        t->state = RTOS_BLOCKED_SEM;
        t->wait_obj = s;
        t->timed = !forever;
        t->wake_tick = deadline;
        rtos_switch_to_scheduler();
    }
    s->count--;
    return 1;
}

/* Free the stacks of all tasks. Call once at the end of main(). */
static inline void rtos_shutdown(void)
{
    rtos_kernel_t *k = rtos_k();
    for (int i = 0; i < k->ntasks; i++) {
        free(k->tasks[i].stack);
        k->tasks[i].stack = NULL;
    }
    k->ntasks = 0;
}

#endif /* MINI_RTOS_H */
