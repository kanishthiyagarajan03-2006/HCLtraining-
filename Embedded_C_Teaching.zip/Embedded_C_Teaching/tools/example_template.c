/*
 * ============================================================================
 *  Topic   : NN Topic Name
 *  Example : NN - One-line title of what this program shows
 *  Flavour : MCU                      <- exactly one of: MCU | RTOS | LINUX
 *  Level   : Basic                    <- Basic | Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : 2-4 lines: the C idea this program teaches.
 *  Embedded use : 1-3 lines: why this matters on a real board / RTOS / Linux box.
 *  Real STM32F4 : the real register or HAL line this mimics, e.g. GPIOA->ODR ^= (1U << 5);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common example_template.c -o example_template
 *  Output  : 1-2 lines describing what the student will see
 * ----------------------------------------------------------------------------
 *  Try it  : 1) a "change X, predict Y" exercise
 *            2) a second short exercise
 * ============================================================================
 *
 *  To add your own example: copy this file into a topic folder as exNN_name.c, edit the
 *  header, run  tools/check.sh <your file>  and then  python3 tools/gen_index.py.
 */
#include "hw_sim.h"

#define LED_PIN 5U

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;              /* clock on                     */
    GPIOA->MODER &= ~(3U << (LED_PIN * 2U));          /* clear the 2-bit mode field   */
    GPIOA->MODER |=  (1U << (LED_PIN * 2U));          /* 01 = output                  */

    for (int i = 0; i < 4; i++) {
        GPIOA->ODR ^= (1U << LED_PIN);                /* toggle                       */
        sim_delay_ms(500);
        sim_show_port("GPIOA", GPIOA);
    }
    return 0;
}
