#!/usr/bin/env bash
# ============================================================================
#  check.sh - compile and run every example, report PASS / FAIL
# ----------------------------------------------------------------------------
#  Usage:   tools/check.sh                       # whole project
#           tools/check.sh basic_c/07_*          # one or more topic folders
#           tools/check.sh path/to/file.c        # one file
#           tools/check.sh path/to/ex03_project  # one multi-file project
#
#  A "program" is either a single .c file, or a multi-file project: a folder
#  named ex*/ that contains main.c (all .c files in it are built together).
#
#  For every program it:
#    1. compiles with  -Wall -Wextra -Werror  (zero warnings allowed)
#       plus AddressSanitizer + UndefinedBehaviorSanitizer
#    2. runs it from an empty scratch folder, stdin = /dev/null, 10 s limit
#    3. requires exit code 0, some output, and no sanitizer report
#    4. checks the header comment has Topic / Example / Flavour lines
#  Needs Linux (or WSL / Codespaces).   Example:  CC=clang tools/check.sh
# ============================================================================
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/build/check"
CC="${CC:-gcc}"
FLAGS="-std=gnu11 -Wall -Wextra -Werror -g -O0 -fsanitize=address,undefined -fno-omit-frame-pointer"
export ASAN_OPTIONS="detect_leaks=1:abort_on_error=0"
export UBSAN_OPTIONS="print_stacktrace=1:halt_on_error=1"

rm -rf "$OUT"; mkdir -p "$OUT"
STAMP="$OUT/.stamp"; touch "$STAMP"; sleep 1

is_project() { [ -f "$1/main.c" ] && [[ "$(basename "$1")" == ex* ]]; }

# expand an argument (file, project dir, or any folder) into program paths
expand() {
    local a="$1"
    if [ -f "$a" ]; then echo "$a"; return; fi
    if is_project "$a"; then echo "$a"; return; fi
    find "$a" -name '*.c' | sort | while read -r f; do
        d="$(dirname "$f")"
        if is_project "$d"; then echo "$d"; else echo "$f"; fi
    done | awk '!seen[$0]++'
}

units=()
if [ $# -eq 0 ]; then
    for base in "$ROOT/basic_c" "$ROOT/intermediate_c"; do
        [ -d "$base" ] || continue
        while IFS= read -r u; do units+=("$u"); done < <(expand "$base")
    done
else
    for a in "$@"; do
        a="$(cd "$(dirname "$a")" && pwd)/$(basename "$a")"
        while IFS= read -r u; do units+=("$u"); done < <(expand "$a")
    done
fi

pass=0; fail=0
declare -A per_topic_total per_topic_pass flavour_count
for u in "${units[@]}"; do
    rel="${u#$ROOT/}"
    topic="$(echo "$rel" | cut -d/ -f1-2)"
    if [ -d "$u" ]; then main_src="$u/main.c"; exe="$OUT/$rel/prog"; srcs=("$u"/*.c); inc="-I$u"
    else main_src="$u"; exe="$OUT/${rel%.c}"; srcs=("$u"); inc=""; fi
    mkdir -p "$(dirname "$exe")"
    per_topic_total[$topic]=$(( ${per_topic_total[$topic]:-0} + 1 ))
    reason=""

    # header metadata
    fl="$(grep -m1 -oE 'Flavour[[:space:]]*:[[:space:]]*(MCU|RTOS|LINUX)' "$main_src" | sed -E 's/.*:[[:space:]]*//')"
    [ -z "$fl" ] && reason="missing or invalid 'Flavour : MCU|RTOS|LINUX' header line"
    grep -q -E 'Topic[[:space:]]*:'   "$main_src" || reason="${reason:+$reason; }missing 'Topic :' header line"
    grep -q -E 'Example[[:space:]]*:' "$main_src" || reason="${reason:+$reason; }missing 'Example :' header line"

    # compile
    if [ -z "$reason" ]; then
        # shellcheck disable=SC2086
        if ! $CC $FLAGS -I"$ROOT/common" $inc "${srcs[@]}" -lm -pthread -o "$exe" 2> "$exe.cerr"; then
            reason="compile error: $(head -n 6 "$exe.cerr" | tr '\n' '|' | cut -c1-600)"
        fi
    fi
    # run
    if [ -z "$reason" ]; then
        run="$exe.run"; mkdir -p "$run"
        ( cd "$run" && timeout 10 "$exe" < /dev/null > "$exe.out" 2> "$exe.err" )
        rc=$?
        grep -v "ASan doesn't fully support makecontext" "$exe.err" > "$exe.err2" || true
        if [ $rc -eq 124 ]; then reason="timeout (>10 s)"
        elif [ $rc -ne 0 ]; then reason="exit code $rc; stderr: $(head -n 4 "$exe.err2" | tr '\n' '|' | cut -c1-500)"
        elif grep -q -E 'Sanitizer|runtime error' "$exe.err2"; then reason="sanitizer: $(head -n 4 "$exe.err2" | tr '\n' '|' | cut -c1-500)"
        elif [ ! -s "$exe.out" ]; then reason="program printed nothing"
        fi
    fi

    if [ -z "$reason" ]; then
        pass=$((pass+1)); per_topic_pass[$topic]=$(( ${per_topic_pass[$topic]:-0} + 1 ))
        flavour_count[$fl]=$(( ${flavour_count[$fl]:-0} + 1 ))
        echo "PASS  $rel  [$fl]"
    else
        fail=$((fail+1))
        echo "FAIL  $rel"; echo "        -> $reason"
    fi
done

echo
echo "================ per-topic summary ================"
for t in $(printf '%s\n' "${!per_topic_total[@]}" | sort); do
    printf "%-52s %2d / %2d passed\n" "$t" "${per_topic_pass[$t]:-0}" "${per_topic_total[$t]}"
done
echo "---------------------------------------------------"
echo "Flavours (passing): MCU=${flavour_count[MCU]:-0} RTOS=${flavour_count[RTOS]:-0} LINUX=${flavour_count[LINUX]:-0}"
echo "TOTAL: $pass passed, $fail failed, $((pass+fail)) programs"

# programs must not litter the source tree
stray="$(find "$ROOT" -newer "$STAMP" -type f -not -path "$ROOT/build/*" 2>/dev/null)"
[ -n "$stray" ] && { echo "WARNING: files created inside the project during run:"; echo "$stray"; }
[ $fail -eq 0 ]
