#!/usr/bin/env bash
# ============================================================================
#  run.sh - build one example and run it (Linux / WSL / macOS / Codespaces)
#
#  Usage:  tools/run.sh basic_c/04_expressions_and_operators/ex01_set_clear_toggle_pin.c
#          tools/run.sh basic_c/11_working_with_header_files/ex01_led_module   # a project folder
#          tools/run.sh <file.c> arg1 arg2                                     # pass program arguments
#  Extra compiler flags:   EXTRA_CFLAGS="-DSIM_REALTIME" tools/run.sh <file.c>
#                          EXTRA_CFLAGS="-DDEMO_BUG"     tools/run.sh <file.c>
# ============================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
[ $# -ge 1 ] || { sed -n '2,10p' "$0"; exit 1; }
target="$1"; shift
[ -e "$target" ] || { echo "not found: $target" >&2; exit 1; }

if [ -d "$target" ]; then
    srcs=("$target"/*.c); name="$(basename "$target")"; inc="$target"
else
    srcs=("$target");     name="$(basename "${target%.c}")"; inc="$(dirname "$target")"
fi

mkdir -p "$ROOT/build"
# shellcheck disable=SC2086
gcc -std=gnu11 -g -O0 -Wall -Wextra ${EXTRA_CFLAGS:-} \
    -I"$ROOT/common" -I"$inc" "${srcs[@]}" -lm -pthread -o "$ROOT/build/$name"
echo "--- running $name ---"
cd "$ROOT/build" && "./$name" "$@"
