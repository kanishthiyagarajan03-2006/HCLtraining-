/*
 * ============================================================================
 *  Topic   : 06 Format Specifiers
 *  Example : 04 - Hex dump of a buffer and printing binary (there is no %b in C11)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : %02X prints one byte as two hex digits (zero padded), %04zX a size_t offset.
 *            C11 has no binary conversion (C23 adds %b), so we write a tiny helper that
 *            tests bit i with (v >> i) & 1U. Combine both to build a debugger-style hex
 *            dump and a register decoder - the two most useful debug prints in firmware.
 *  Embedded use : dumping a received UART/CAN/SPI packet in hex, and decoding a control
 *            register bit by bit, is how you find protocol and configuration bugs.
 *  Real STM32F4 : printf("CR1=0x%04X\n", (unsigned)USART2->CR1);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_hex_dump_and_binary.c -o ex04
 *  Output  : a 37-byte packet as a 16-bytes-per-line hex dump with an ASCII column, then a
 *            USART control register in hex, binary and decoded bit names
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the bytes-per-line from 16 to 8. What else must you change?
 *            2) Add the bit "OVER8" (bit 15) to the flag table and set it in cr1.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define BYTES_PER_LINE 16U

/* offset | hex bytes | printable ASCII, like `xxd` or a debugger memory view */
static void hex_dump(const uint8_t *buf, size_t len)
{
    for (size_t off = 0; off < len; off += BYTES_PER_LINE) {
        printf("%04zX: ", off);                        /* %zX: size_t in hex */
        for (size_t i = 0; i < BYTES_PER_LINE; i++) {
            if (off + i < len) {
                printf("%02X ", (unsigned)buf[off + i]);   /* always two digits */
            } else {
                printf("   ");                         /* keep the ASCII column aligned */
            }
            if (i == 7U) {
                putchar(' ');                          /* gap in the middle */
            }
        }
        printf(" |");
        for (size_t i = 0; i < BYTES_PER_LINE && off + i < len; i++) {
            uint8_t c = buf[off + i];
            putchar((c >= 0x20U && c < 0x7FU) ? (int)c : '.');   /* non-printable -> '.' */
        }
        puts("|");
    }
}

/* Print the low nbits of v, MSB first, a space between nibbles: 0010 0000 */
static void print_bin(uint32_t v, unsigned nbits)
{
    for (unsigned i = nbits; i > 0U; i--) {
        putchar(((v >> (i - 1U)) & 1U) ? '1' : '0');
        if (((i - 1U) % 4U) == 0U && i > 1U) {
            putchar(' ');
        }
    }
}

typedef struct {
    unsigned    bit;
    const char *name;
} flag_t;

/* A few real USART_CR1 bits (STM32F4 reference manual). */
static const flag_t cr1_flags[] = {
    { 13U, "UE (usart enable)" },
    { 12U, "M (9-bit word)" },
    {  5U, "RXNEIE (rx interrupt)" },
    {  3U, "TE (transmitter on)" },
    {  2U, "RE (receiver on)" },
};

int main(void)
{
    /* A packet as it might arrive on a UART: header, text, binary tail with a CR LF. */
    const uint8_t packet[] = {
        0xAA, 0x55, 0x21, 'T', 'E', 'M', 'P', '=', '2', '5', '.', '3', ' ', 'C', 0x00, 0x1F,
        'O', 'K', 0xFF, 0x7F, 0x80, 'e', 'n', 'd', '!', 0x01, 0x02, 0x03, 0x04, 0x05, 0x06,
        0x07, 0x08, 0x0D, 0x0A, 0xDE, 0xAD
    };

    puts("-- hex dump --");
    hex_dump(packet, sizeof packet);
    printf("(%zu bytes, last line is short on purpose)\n", sizeof packet);

    puts("-- register decoder --");
    uint32_t cr1 = (1U << 13) | (1U << 3) | (1U << 2);   /* USART on, TX and RX enabled */
    printf("CR1 = 0x%08X = ", (unsigned)cr1);
    print_bin(cr1, 16U);
    putchar('\n');
    for (size_t i = 0; i < sizeof cr1_flags / sizeof cr1_flags[0]; i++) {
        const flag_t *f = &cr1_flags[i];
        printf("  bit %2u %-22s : %s\n", f->bit, f->name,
               ((cr1 >> f->bit) & 1U) ? "SET" : "clear");
    }
    return 0;
}
