/*
 * ============================================================================
 *  Topic   : 06 Format Specifiers
 *  Example : 07 - Printing POSIX typedef types (off_t, mode_t, time_t, ssize_t) portably
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : size_t has %zu and ptrdiff_t has %td, but pid_t, off_t, time_t, mode_t, uid_t
 *            have NO dedicated specifier - their width differs between systems. Portable
 *            rule: cast to the widest type (intmax_t / uintmax_t) and print with %jd / %ju.
 *            Use %o for permission bits and snprintf(NULL, 0, ...) to measure a string.
 *  Embedded use : embedded Linux code prints file sizes, permissions and timestamps all day
 *            (logging, OTA update checks, config files). A wrong specifier is silent on
 *            x86-64 and wrong on a 32-bit ARM board - the same source, a different ABI.
 *  Real Linux   : stat("/etc/passwd", &st);  printf("%jd\n", (intmax_t)st.st_size);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_linux_posix_typedef_types.c -o ex07
 *  Output  : size, permission bits, link count and a timestamp of a temp file printed with
 *            %jd %o %ju and a broken-down UTC time; sizes of the typedefs; a measured string
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the file mode from 0640 to 0755 (open AND fchmod). Predict the %04o text.
 *            2) Print st.st_size with %d. Does gcc warn? Would it be correct for a 5 GB file?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <fcntl.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

int main(void)
{
    char dir[] = "/tmp/ex07_XXXXXX";
    if (mkdtemp(dir) == NULL) {
        perror("mkdtemp");
        return 1;
    }
    char path[64];
    snprintf(path, sizeof path, "%s/data.bin", dir);

    /* Create a 100-byte file with mode 0640 (rw-r-----). */
    int fd = open(path, O_CREAT | O_WRONLY | O_TRUNC, 0640);
    if (fd < 0) {
        perror("open");
        rmdir(dir);
        return 1;
    }
    char block[100];
    memset(block, 'A', sizeof block);
    ssize_t written = write(fd, block, sizeof block);
    fchmod(fd, 0640);                           /* make the mode independent of umask */
    close(fd);

    struct stat st;
    if (stat(path, &st) == 0) {
        puts("-- struct stat fields: typedef types need a cast --");
        printf("write() returned (ssize_t) : %zd\n", written);           /* %zd = ssize_t */
        printf("st_size  (off_t)           : %jd bytes\n", (intmax_t)st.st_size);
        printf("st_mode  (mode_t) in octal : %04o  = rw-r-----\n",
               (unsigned)(st.st_mode & 07777U));
        printf("st_nlink (nlink_t)         : %ju\n", (uintmax_t)st.st_nlink);
        printf("is a regular file          : %s\n", S_ISREG(st.st_mode) ? "yes" : "no");
    }

    puts("-- time_t: print the number, then a broken-down UTC time --");
    time_t stamp = 1700000000;                   /* fixed value keeps the output repeatable */
    struct tm tm;
    gmtime_r(&stamp, &tm);
    printf("time_t %jd = %04d-%02d-%02d %02d:%02d:%02d UTC\n", (intmax_t)stamp,
           tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);

    puts("-- sizes of the typedefs on this machine (%zu) --");
    printf("pid_t=%zu off_t=%zu time_t=%zu mode_t=%zu uid_t=%zu\n", sizeof(pid_t),
           sizeof(off_t), sizeof(time_t), sizeof(mode_t), sizeof(uid_t));

    puts("-- snprintf(NULL, 0, ...) measures before you allocate --");
    int need = snprintf(NULL, 0, "%s: %jd bytes, mode %04o", path, (intmax_t)st.st_size, 0640U);
    char *msg = (need >= 0) ? malloc((size_t)need + 1U) : NULL;
    if (msg != NULL) {
        snprintf(msg, (size_t)need + 1U, "%s: %jd bytes, mode %04o", path,
                 (intmax_t)st.st_size, 0640U);
        printf("the message needs %d chars + 1 for '\\0'\n", need);   /* same length every run */
        free(msg);
    }

    unlink(path);                                /* clean up the temp file and directory */
    rmdir(dir);
    return 0;
}
