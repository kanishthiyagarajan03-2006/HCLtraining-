/*
 * ============================================================================
 *  Topic   : 06 Format Specifiers
 *  Example : 02 - Width, precision and flags: a neat ADC telemetry table
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : % [flags] [width] [.precision] type
 *            flags: '-' left-align, '0' zero-pad, '+' always show sign, ' ' space for plus
 *            width : minimum field size    (%8s, %5d)
 *            .prec : digits after the point for floats (%.2f), minimum digits for integers
 *                    (%.3d), max characters for strings (%.3s)
 *            '*'   : take the width or precision from an argument  (%*d, %.*f)
 *  Embedded use : fixed-width columns make serial logs readable and parseable;
 *            %08X / %04X is how register values are normally printed.
 *  Real STM32F4 : printf("PA%-2u 0x%04X\n", pin, (unsigned)GPIOA->IDR);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_width_precision_flags.c -o ex02
 *  Output  : a four-row ADC table with aligned columns, then a cheat-sheet that prints each
 *            format string next to its result between | bars
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change %-6s to %6s. Which side of the column moves?
 *            2) Add a fifth channel with a 9-letter name. Which format would clip it safely?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

typedef struct {
    const char *name;
    uint16_t    raw;        /* 12-bit ADC code, 0..4095 */
    int16_t     delta;      /* change since the last sample */
} channel_t;

static const channel_t chans[] = {
    { "VBAT",  3102,  12 },
    { "TEMP",  1024,  -3 },
    { "LIGHT",   40,   0 },
    { "POT",   4095,   7 },
};

/* Show the format string itself (stringified with #) next to what it prints. Handy in class.
 * Adjacent string literals are joined by the compiler, so gcc can still check the format. */
#define SHOW(fmt, ...) printf("  %-9s -> |" fmt "|\n", #fmt, __VA_ARGS__)

int main(void)
{
    int w = 7;                                  /* a column width chosen at run time */

    printf("%-6s|%6s|%8s|%6s|%6s\n", "NAME", "RAW", "VOLT", "DELTA", "HEX");
    for (size_t i = 0; i < sizeof chans / sizeof chans[0]; i++) {
        const channel_t *c = &chans[i];
        double volts = (double)c->raw * 3.3 / 4095.0;
        printf("%-6s|%6u|%8.3f|%+6d|0x%04X\n", c->name, (unsigned)c->raw, volts,
               (int)c->delta, (unsigned)c->raw);
    }
    printf("(\"%%+6d\" always shows the sign: +12, -3, +0, +7)\n\n");

    puts("-- cheat sheet: format string -> result --");
    SHOW("%d", 42);
    SHOW("%5d", 42);
    SHOW("%-5d", 42);
    SHOW("%05d", 42);
    SHOW("%+d", 42);
    SHOW("% d", 42);
    SHOW("%.3d", 7);
    SHOW("%x", 255U);
    SHOW("%08X", 0xBEEFU);
    SHOW("%#06x", 42U);
    SHOW("%8.3f", 3.14159);
    SHOW("%08.3f", 3.14159);
    SHOW("%.2f", 2.71828);
    SHOW("%10s", "UART");
    SHOW("%-10s", "UART");
    SHOW("%.3s", "ABCDEFG");
    SHOW("%*d", w, 42);
    SHOW("%.*f", 1, 3.14159);
    return 0;
}
