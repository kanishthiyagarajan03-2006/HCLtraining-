# Topic 06 - Format Specifiers
**Suggested session:** 60 min | **Prerequisite topics:** 03 Variable types, 05 Formatted and unformatted I/O

Students learn to pick the right `printf` conversion for every type they meet in firmware, to
control layout with flags/width/precision, and to print without `%f` when the MCU cannot afford it.
The examples progress from the basic integer/char/string set, through layout control and portable
fixed-width printing, to practical debug tools (hex dump, binary, fixed-point values) and finally
two "real report" programs for an RTOS and for embedded Linux.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_integer_and_char_specifiers.c` | MCU | `%d %u %x %X %o %c %s %%`, `%#x`, signed vs unsigned bits, `DEMO_BUG` mismatch |
| 02 | `ex02_width_precision_flags.c` | MCU | `%-6s %8.3f %+d %05d %08X %.3s %*d`, a `SHOW()` cheat-sheet macro |
| 03 | `ex03_inttypes_sizes_pointers.c` | MCU | `PRIu32`/`PRIX8`/`PRIu64`, `%zu`, `%td`, `%p` vs `PRIXPTR`, type sizes |
| 04 | `ex04_hex_dump_and_binary.c` | MCU | hex dump with ASCII column, `%02X`, `%04zX`, binary helper, register decoder |
| 05 | `ex05_fixed_point_printing.c` | MCU | `%f %e %g`, printing `%d.%02d` instead of `%f`, the negative-number trap |
| 06 | `ex06_rtos_task_table.c` | RTOS | a `vTaskList`-style table mixing `%-8s %3d PRIu32 %5.1f%% %zu` |
| 07 | `ex07_linux_posix_typedef_types.c` | LINUX | `off_t`/`mode_t`/`time_t` via `%jd`, `%o` permissions, `snprintf(NULL, 0, ...)` |

## Teaching notes
* The specifier describes the ARGUMENT TYPE, not how you want it to look. Mismatch is undefined
  behaviour; `-Wall` catches most of it, so never ignore `-Wformat`.
* `uint32_t` is `unsigned int` on a PC but `unsigned long` on arm-none-eabi: that is why `PRIu32`
  exists (ex03). Ask: what would `%d` do with a 32-bit tick count on a 16-bit MCU?
* Narrow types are promoted to `int` when passed to `printf`, so `%d`/`%02X` are safe for
  `uint8_t`/`uint16_t` (ex01). Signed values passed to `%x` should be cast to `unsigned`.
* C11 has no `%b`; show the helper in ex04 (C23 adds it). `%p` output is implementation-defined.
* ex05: `v % 100` is negative for negative `v`. Ask the class to find which naive row is wrong.
* Float `printf` is big and slow on Cortex-M0/M3 (newlib-nano needs `-u _printf_float`).

## Live-demo tips
* ex01 and ex03: `gcc -DDEMO_BUG ...` (without `-Werror`) and read the `-Wformat` warnings aloud.
* ex02: edit one format string in the `SHOW(...)` list and rebuild to predict the output live.
* ex06: change a task's `rtos_busy()` time and watch the CPU share column change.
