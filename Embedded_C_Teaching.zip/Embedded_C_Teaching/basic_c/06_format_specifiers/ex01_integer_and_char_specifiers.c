/*
 * ============================================================================
 *  Topic   : 06 Format Specifiers
 *  Example : 01 - Integer and character specifiers: %d %u %x %X %o %c %s %%
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Every % conversion must match the TYPE of the argument it consumes:
 *            %d signed int, %u unsigned int, %x/%X hex, %o octal, %c one character,
 *            %s a string (char *), %% a literal percent sign. The bits stay the same;
 *            only the text changes. A mismatch is undefined behaviour (gcc -Wall warns).
 *  Embedded use : registers are read in hex, counters in decimal, bytes from a UART as
 *            characters. Printing a signed value with %x or a char with %s gives garbage.
 *  Real STM32F4 : printf("ODR = 0x%04X\n", (unsigned)GPIOA->ODR);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_integer_and_char_specifiers.c -o ex01
 *  Output  : one GPIO register value in decimal, hex, octal and binary, then characters,
 *            negative numbers seen as unsigned, strings and a literal percent sign
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Predict the %o output for 0xA5 before running (hint: group bits in threes).
 *            2) Build with -DDEMO_BUG and read the gcc warnings. What does each one say?
 * ============================================================================
 */
#include "hw_sim.h"

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->ODR = 0x00A5U;                       /* LEDs on PA0, PA2, PA5 and PA7 */
    unsigned odr = (unsigned)GPIOA->ODR;        /* %x/%u/%o want unsigned int */

    puts("-- one register value, many spellings (GPIOA->ODR = 0x00A5) --");
    printf("%%d   signed decimal : %d\n", (int)odr);
    printf("%%u   unsigned       : %u\n", odr);
    printf("%%x   hex lowercase  : %x\n", odr);
    printf("%%X   hex UPPERCASE  : %X\n", odr);
    printf("%%o   octal          : %o\n", odr);
    printf("%%#x  with 0x prefix : %#x\n", odr);
    printf("%%#o  with 0 prefix  : %#o\n", odr);
    printf("binary (no %%b in C11): ");
    sim_print_bits(odr, 8U);
    putchar('\n');

    puts("-- characters: the same byte as a letter and as a number --");
    char c = 'A';
    printf("%%c prints the glyph: %c, %%d prints the ASCII code: %d, %%x: %x\n",
           c, (int)c, (unsigned)c);
    for (char ch = 'A'; ch <= 'E'; ch++) {
        printf("%c=%d%s", ch, (int)ch, ch < 'E' ? "  " : "\n");
    }

    puts("-- negative values: same bits, different text --");
    int32_t neg = -1;
    printf("%%d: %d   %%u: %u   %%x: %x\n", (int)neg, (unsigned)neg, (unsigned)neg);
    int8_t  s8 = -3;
    uint8_t u8 = (uint8_t)s8;                   /* same 8 bits, read as unsigned */
    printf("int8_t -3 -> %%d: %d   as uint8_t -> %%u: %u   %%x: %x\n",
           (int)s8, (unsigned)u8, (unsigned)u8);
    uint8_t big = 200U;                         /* 8-bit args are promoted to int, so %d is safe */
    printf("uint8_t 200 with %%d: %d\n", (int)big);

    puts("-- strings and the percent sign --");
    const char *port = "UART2";
    printf("port %s, baud %d, duty %d%%\n", port, 115200, 75);

#ifdef DEMO_BUG
    /* Undefined behaviour: the format promises an int, the caller passes a double that
     * lives in a different register/stack slot, so the output is garbage.
     * Likewise printf("%s", 65) would treat 65 as an address and crash.
     * gcc -Wall reports both as -Wformat warnings. Never ignore them.            */
    printf("BUG: %d\n", 3.14);
    printf("BUG: %s\n", 65);
#endif
    return 0;
}
