/*
 * ============================================================================
 *  Topic   : 06 Format Specifiers
 *  Example : 05 - Printing decimals without %f: %d.%02d fixed point (and the sign trap)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : %f %e %g print double values. On a small MCU the float printf is large and slow,
 *            so firmware stores values as integers in fixed units (hundredths of a degree,
 *            millivolts) and prints  whole = v / 100  and  frac = v % 100  with "%d.%02d".
 *            Negative numbers need care: v % 100 is negative in C, and -0.50 has whole = 0.
 *  Embedded use : newlib-nano drops %f support unless you link with -u _printf_float (+10 KB).
 *            Cortex-M0 has no FPU at all, so a float printf can take thousands of cycles.
 *  Real STM32F4 : printf("T=%d.%02d C\n", t / 100, t % 100);   // works for t >= 0 only!
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_fixed_point_printing.c -o ex05
 *  Output  : %f %e %g of one number, a table where two naive versions print wrong text for
 *            negative values next to the correct one, then ADC codes printed as volts
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Which rows in the table are wrong for "naive A", and which for "naive B"?
 *            2) Change centi_to_str to thousandths (mv / 1000, mv % 1000, "%03"). Test 1999.
 * ============================================================================
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

/* Write a value given in hundredths as [-]whole.ff into buf. Correct for negative values:
 * take the magnitude first (0U - x is well defined even for INT32_MIN), print the sign
 * separately, then print magnitude / 100 and magnitude % 100 as unsigned numbers.     */
static void centi_to_str(char *buf, size_t cap, int32_t v)
{
    uint32_t mag = (v < 0) ? (0U - (uint32_t)v) : (uint32_t)v;
    snprintf(buf, cap, "%s%" PRIu32 ".%02" PRIu32, (v < 0) ? "-" : "", mag / 100U, mag % 100U);
}

int main(void)
{
    puts("-- the float family (fine on a PC, heavy on a small MCU) --");
    double x = 12345.6789;
    printf("%%f    : %f\n", x);                 /* 6 digits after the point by default */
    printf("%%.2f  : %.2f\n", x);
    printf("%%e    : %e\n", x);                 /* scientific: mantissa and exponent   */
    printf("%%g    : %g\n", x);                 /* shortest of %f / %e, 6 significant  */
    printf("%%g    : %g and %g\n", 0.000012345, 123456789.0);

    puts("-- fixed point: temperature stored in hundredths of a degree --");
    static const int32_t temps[] = { 2537, 5, 0, -50, -1250, -2599 };
    printf("%8s | %-9s | %-9s | %-9s | %s\n", "centi-C", "naive A", "naive B", "correct", "%.2f");
    for (size_t i = 0; i < sizeof temps / sizeof temps[0]; i++) {
        int32_t v = temps[i];
        char a[24], b[24], c[24];
        int frac = (int)(v % 100);
        snprintf(a, sizeof a, "%d.%02d", (int)(v / 100), frac);               /* sign trap  */
        snprintf(b, sizeof b, "%d.%02d", (int)(v / 100), frac < 0 ? -frac : frac);  /* -0.xx */
        centi_to_str(c, sizeof c, v);
        printf("%8" PRId32 " | %-9s | %-9s | %-9s | %.2f\n", v, a, b, c, (double)v / 100.0);
    }
    puts("naive A prints '0.-50' and '-12.-50'; naive B loses the sign when whole == 0.");

    puts("-- 12-bit ADC code to volts, integers only --");
    static const uint16_t codes[] = { 0U, 1U, 2048U, 4095U };
    for (size_t i = 0; i < sizeof codes / sizeof codes[0]; i++) {
        uint32_t mv = ((uint32_t)codes[i] * 3300U + 2047U) / 4095U;   /* +2047 rounds to nearest */
        printf("code %4u -> %" PRIu32 ".%03" PRIu32 " V\n", (unsigned)codes[i],
               mv / 1000U, mv % 1000U);
    }
    return 0;
}
