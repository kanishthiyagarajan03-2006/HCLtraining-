/*
 * ============================================================================
 *  Topic   : 06 Format Specifiers
 *  Example : 06 - A vTaskList-style task table (%-8s %2d %5" PRIu32 " %5.1f%% %zu)
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A realistic report mixes many specifiers: strings with %-8s, small ints with %2d,
 *            a uint32_t with PRIu32, a size_t with %zu, a percentage with %5.1f and a literal
 *            percent sign with %%. The type of each field decides its specifier; the width
 *            decides the column alignment.
 *  Embedded use : vTaskList() and vTaskGetRunTimeStats() print exactly this kind of table so
 *            you can see which task eats the CPU and which one is near a stack overflow.
 *  Real FreeRTOS: vTaskList(buf); vTaskGetRunTimeStats(buf);  uxTaskGetStackHighWaterMark(h);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_rtos_task_table.c -o ex06
 *  Output  : three "started" log lines, then a table with priority, state, CPU time, CPU
 *            share and stack use per task for a 1000 ms run (stack numbers depend on gcc flags)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Make control_task busy for 60 ms. What happens to its CPU share and to logger?
 *            2) Use %6.2f for the CPU column. Which other widths must change to stay aligned?
 * ============================================================================
 */
#include <inttypes.h>
#include "mini_rtos.h"

/* Each task burns CPU with rtos_busy() (preemptible) and then sleeps with rtos_delay(). */
static void sensor_task(void *arg)
{
    (void)arg;
    rtos_log("started: 10 ms of work every 100 ms");
    for (;;) {
        rtos_busy(10);
        rtos_delay(90);
    }
}

static void control_task(void *arg)
{
    (void)arg;
    rtos_log("started: 30 ms of work every 100 ms");
    for (;;) {
        rtos_busy(30);
        rtos_delay(70);
    }
}

static void logger_task(void *arg)
{
    (void)arg;
    rtos_log("started: 15 ms of work every 200 ms");
    for (;;) {
        rtos_busy(15);
        rtos_delay(185);
    }
}

static const char *state_name(rtos_state_t s)
{
    switch (s) {                            /* no default: gcc warns if a state is missing */
    case RTOS_READY:        return "READY";
    case RTOS_DELAYED:      return "DELAYED";
    case RTOS_BLOCKED_RECV: return "BLK-RECV";
    case RTOS_BLOCKED_SEND: return "BLK-SEND";
    case RTOS_BLOCKED_SEM:  return "BLK-SEM";
    case RTOS_DONE:         return "DELETED";
    }
    return "?";
}

int main(void)
{
    rtos_task_create("sensor", sensor_task, NULL, 3, RTOS_MIN_STACK);
    rtos_task_create("control", control_task, NULL, 2, RTOS_MIN_STACK);
    rtos_task_create("logger", logger_task, NULL, 1, RTOS_MIN_STACK);

    const uint32_t run_ms = 1000U;
    rtos_start(run_ms);

    rtos_kernel_t *k = rtos_k();
    uint32_t busy_total = 0U;

    printf("\n%-8s %3s %-9s %7s %7s %10s\n", "Task", "Pri", "State", "CPU ms", "CPU %",
           "Stack used");
    for (int i = 0; i < k->ntasks; i++) {
        const rtos_task_t *t = &k->tasks[i];
        size_t used = t->stack_size - rtos_stack_high_water(t);
        printf("%-8s %3d %-9s %7" PRIu32 " %6.1f%% %7zu B\n", t->name, t->prio,
               state_name(t->state), t->run_ticks,
               100.0 * (double)t->run_ticks / (double)run_ms, used);
        busy_total += t->run_ticks;
    }
    printf("%-8s %3s %-9s %7" PRIu32 " %6.1f%%\n", "(idle)", "-", "-", run_ms - busy_total,
           100.0 * (double)(run_ms - busy_total) / (double)run_ms);

    rtos_shutdown();
    return 0;
}
