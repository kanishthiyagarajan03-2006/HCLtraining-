/*
 * ============================================================================
 *  Topic   : 06 Format Specifiers
 *  Example : 03 - Fixed-width types need PRIu32/PRIx8, sizes need %zu, addresses %p
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : uint32_t is NOT always "unsigned int". With arm-none-eabi-gcc (newlib) it is
 *            "unsigned long", so printf("%u", ticks) compiles on a PC but warns (and is
 *            wrong) on the real MCU. <inttypes.h> gives portable macros: PRIu32, PRId16,
 *            PRIX8, PRIu64 ... Use %zu for size_t (sizeof), %td for ptrdiff_t,
 *            %p with a (void *) cast for addresses, PRIXPTR for an address as a number.
 *  Embedded use : the same source must build for 8/16/32-bit MCUs and for a PC unit test.
 *            On AVR/MSP430 an int is only 16 bits, so %d with a 32-bit value truncates.
 *  Real STM32F4 : printf("tick=%" PRIu32 "\n", HAL_GetTick());   // uint32_t on newlib
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_inttypes_sizes_pointers.c -o ex03
 *  Output  : fixed-width values printed with PRI macros, a table of type sizes with %zu,
 *            pointer difference with %td, and a peripheral address with %p and PRIXPTR
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Which types have a different size on a 64-bit PC than on a Cortex-M4?
 *            2) Build with -DDEMO_BUG and read what gcc says about printing a uint64_t with %u.
 * ============================================================================
 */
#include <inttypes.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

int main(void)
{
    uint8_t  status = 0x9CU;
    int16_t  temp   = -1250;                    /* hundredths of a degree */
    uint32_t ticks  = 4000000000U;              /* 4e9 does not fit in a signed 32-bit int */
    uint64_t usec   = 5000000000ULL;            /* a 32-bit us counter wraps after 71 minutes */

    puts("-- fixed-width values: use the PRI macros --");
    printf("status = 0x%02" PRIX8 "  (uint8_t)\n", status);
    printf("temp   = %" PRId16 "      (int16_t)\n", temp);
    printf("ticks  = %" PRIu32 "  = 0x%08" PRIX32 "  (uint32_t)\n", ticks, ticks);
    printf("usec   = %" PRIu64 "  (uint64_t)\n", usec);
    /* The macro expands to a string literal, e.g. "u" or "lu". The compiler glues
     * "ticks  = %" "u" "\n" into one format string for you.                       */

    puts("-- sizes: %zu is for size_t --");
    printf("sizeof(char)=%zu short=%zu int=%zu long=%zu long long=%zu\n",
           sizeof(char), sizeof(short), sizeof(int), sizeof(long), sizeof(long long));
    printf("sizeof(void *)=%zu size_t=%zu float=%zu double=%zu\n",
           sizeof(void *), sizeof(size_t), sizeof(float), sizeof(double));
    printf("(Cortex-M4: long=4 and void *=4.  64-bit PC: long=8 and void *=8.)\n");

    puts("-- pointers --");
    uint16_t samples[16];
    ptrdiff_t gap = &samples[9] - &samples[2];     /* counted in ELEMENTS, not bytes */
    printf("&samples[9] - &samples[2] = %td elements = %zu bytes\n",
           gap, (size_t)gap * sizeof samples[0]);

    /* A peripheral register address. We only PRINT it: dereferencing it on a PC would crash. */
    volatile uint32_t *const odr = (volatile uint32_t *)(uintptr_t)0x40020014UL;
    printf("GPIOA ODR address with %%p     : %p\n", (void *)odr);
    printf("GPIOA ODR address as a number : 0x%08" PRIXPTR "\n", (uintptr_t)odr);
    printf("(%%p layout is implementation-defined; PRIXPTR always gives plain hex.)\n");

#ifdef DEMO_BUG
    /* %u reads 32 bits but a uint64_t was passed: undefined behaviour (garbage or the
     * wrong half). gcc -Wall: "format '%u' expects 'unsigned int', but argument has type
     * 'uint64_t'". Same family of bug: %d with a uint32_t on a 16-bit MCU.           */
    printf("BUG: %u\n", usec);
#endif
    return 0;
}
