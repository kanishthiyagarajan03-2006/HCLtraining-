/*
 * ============================================================================
 *  Topic   : 07 Conditional Statements
 *  Example : 06 - Error-code handling: nested ifs vs guard clauses (early return)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Driver functions return a status code (0 = OK, other values = what went wrong)
 *            and hand the real result back through a pointer. The caller tests
 *            if (status != ST_OK). Guard clauses check each failure first and return
 *            early, so the happy path stays flat at one indentation level instead of
 *            a pyramid of nested ifs. Both versions below behave identically.
 *  Embedded use : I2C/SPI sensors NACK, time out or return garbage. Ignoring a status code is
 *            how a dead sensor turns into "temperature = 0 C" and a frozen heater.
 *  Real STM32F4 : if (HAL_I2C_Mem_Read(&hi2c1, addr, reg, 1, buf, 2, 10) != HAL_OK) { ... }
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_error_codes_guard_clauses.c -o ex06
 *  Output  : five sensor reads (good, NACK, timeout, bad data, NULL argument) done by both
 *            coding styles, with the status name and the value
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a retry: if the status is ST_ERR_TIMEOUT, try once more before giving up.
 *            2) Add a new status ST_ERR_BUSY. Which switch statement must you update?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

typedef enum {
    ST_OK = 0,
    ST_ERR_ARG,
    ST_ERR_NACK,
    ST_ERR_TIMEOUT,
    ST_ERR_DATA
} status_t;

static const char *status_name(status_t s)
{
    switch (s) {
    case ST_OK:          return "OK";
    case ST_ERR_ARG:     return "ERR_ARG";
    case ST_ERR_NACK:    return "ERR_NACK";
    case ST_ERR_TIMEOUT: return "ERR_TIMEOUT";
    case ST_ERR_DATA:    return "ERR_DATA";
    }
    return "ERR_UNKNOWN";
}

/* Fake I2C bus: 0x48 answers, 0x49 is not fitted, 0x4A hangs the bus,
 * 0x4B answers with 0xFFFF (what a floating bus reads as).                      */
static status_t i2c_read16(uint8_t addr, uint16_t *out)
{
    if (addr == 0x4AU) {
        return ST_ERR_TIMEOUT;
    }
    if (addr == 0x4BU) {
        *out = 0xFFFFU;
        return ST_OK;                   /* the transfer worked; the DATA is bad */
    }
    if (addr != 0x48U) {
        return ST_ERR_NACK;
    }
    *out = 0x1A80U;                     /* upper byte = whole degrees: 0x1A = 26 C */
    return ST_OK;
}

/* Version A: "pyramid of doom" - every success opens one more level of indentation. */
static status_t read_temp_nested(uint8_t addr, int *deg_c)
{
    status_t st = ST_ERR_ARG;
    if (deg_c != NULL) {
        uint16_t raw = 0U;
        st = i2c_read16(addr, &raw);
        if (st == ST_OK) {
            if (raw != 0xFFFFU) {
                *deg_c = (int)(raw >> 8);
            } else {
                st = ST_ERR_DATA;
            }
        }
    }
    return st;
}

/* Version B: guard clauses - reject bad cases first, the happy path reads straight down. */
static status_t read_temp_guarded(uint8_t addr, int *deg_c)
{
    if (deg_c == NULL) {
        return ST_ERR_ARG;
    }
    uint16_t raw = 0U;
    status_t st = i2c_read16(addr, &raw);
    if (st != ST_OK) {
        return st;                      /* pass the driver's error upwards unchanged */
    }
    if (raw == 0xFFFFU) {
        return ST_ERR_DATA;
    }
    *deg_c = (int)(raw >> 8);
    return ST_OK;
}

static void report(const char *label, uint8_t addr, int use_null)
{
    int a = -999, b = -999;                             /* sentinels: untouched on error */
    status_t sa = read_temp_nested(addr, use_null ? NULL : &a);
    status_t sb = read_temp_guarded(addr, use_null ? NULL : &b);

    printf("%-9s nested: %-11s guarded: %-11s", label, status_name(sa), status_name(sb));
    if (sb != ST_OK) {                                  /* always test before using b */
        printf("  value unused\n");
    } else {
        printf("  temp = %d C%s\n", b, (sa == sb && a == b) ? "  (same)" : "  (DIFFERENT!)");
    }
}

int main(void)
{
    report("good", 0x48U, 0);
    report("no device", 0x49U, 0);
    report("hung bus", 0x4AU, 0);
    report("bad data", 0x4BU, 0);
    report("NULL arg", 0x48U, 1);
    return 0;
}
