/*
 * ============================================================================
 *  Topic   : 07 Conditional Statements
 *  Example : 07 - An RTOS task dispatching events with switch (queue + timeout)
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A typical RTOS application task blocks on a queue and then runs
 *            switch (event.type) to decide what to do. Inside a case, ordinary if / else
 *            handles the details (here: automatic mode reacts to temperature, manual mode
 *            ignores it). A queue-receive TIMEOUT is just another "event": the else branch.
 *  Embedded use : "event loop" firmware: ISRs and other tasks post events (button, sensor,
 *            timer), one task owns the logic. No shared flags, no races, easy to log.
 *  Real FreeRTOS: if (xQueueReceive(q, &ev, pdMS_TO_TICKS(400)) == pdTRUE) { switch (ev.type) ... }
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_rtos_event_switch.c -o ex07
 *  Output  : a time-stamped log: temperature samples every 300 ms (fan ON at 38 C, OFF at
 *            28 C), two button presses toggling AUTO/MANUAL, and idle events after 400 ms
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add EV_FAULT with a case that stops the fan whatever the mode is.
 *            2) Change the receive timeout from 400 to 250 ms. How many IDLE events now?
 * ============================================================================
 */
#include "mini_rtos.h"

typedef enum { EV_IDLE, EV_BUTTON, EV_TEMP } app_event_type_t;
typedef enum { MODE_AUTO, MODE_MANUAL } app_mode_t;

typedef struct {
    app_event_type_t type;
    int          value;                 /* temperature in C for EV_TEMP */
} app_event_t;

static rtos_queue_t *events;

static void sensor_task(void *arg)
{
    (void)arg;
    static const int temps[] = { 24, 31, 38, 45, 33, 28 };
    for (size_t i = 0; i < sizeof temps / sizeof temps[0]; i++) {
        app_event_t ev = { EV_TEMP, temps[i] };
        rtos_queue_send(events, &ev, RTOS_WAIT_FOREVER);
        rtos_delay(300);
    }
}   /* mini_rtos lets a task return; a FreeRTOS task must end with vTaskDelete(NULL) */

static void button_task(void *arg)
{
    (void)arg;
    app_event_t ev = { EV_BUTTON, 0 };
    rtos_delay(700);
    rtos_queue_send(events, &ev, RTOS_WAIT_FOREVER);    /* press 1 at 700 ms: go MANUAL */
    rtos_delay(400);
    rtos_queue_send(events, &ev, RTOS_WAIT_FOREVER);    /* press 2 at 1100 ms: back to AUTO */
}

static void app_task(void *arg)
{
    (void)arg;
    app_mode_t mode = MODE_AUTO;
    int fan_on = 0;

    for (;;) {
        app_event_t ev;
        if (!rtos_queue_recv(events, &ev, 400)) {
            ev.type = EV_IDLE;          /* timeout: nothing happened for 400 ms */
            ev.value = 0;
        }
        switch (ev.type) {
        case EV_BUTTON:
            mode = (mode == MODE_AUTO) ? MODE_MANUAL : MODE_AUTO;
            rtos_log("button: mode is now %s", mode == MODE_AUTO ? "AUTO" : "MANUAL");
            break;
        case EV_TEMP:
            if (mode == MODE_MANUAL) {
                rtos_log("temp %d C ignored (manual mode, fan %s)", ev.value,
                         fan_on ? "on" : "off");
            } else if (ev.value > 35 && !fan_on) {
                fan_on = 1;
                rtos_log("temp %d C too high -> fan ON", ev.value);
            } else if (ev.value <= 30 && fan_on) {
                fan_on = 0;
                rtos_log("temp %d C ok -> fan OFF", ev.value);
            } else {
                rtos_log("temp %d C, no change (fan %s)", ev.value, fan_on ? "on" : "off");
            }
            break;
        case EV_IDLE:
            rtos_log("idle: no event for 400 ms");
            break;
        default:                        /* defensive; note a default hides -Wswitch (ex04) */
            rtos_log("unknown event %d", (int)ev.type);
            break;
        }
    }
}

int main(void)
{
    /* FreeRTOS: xQueueCreate(4, sizeof(app_event_t)) - length FIRST, item size second. */
    events = rtos_queue_create(4, sizeof(app_event_t));
    if (events == NULL) {
        return 1;
    }
    rtos_task_create("app", app_task, NULL, 3, RTOS_MIN_STACK);
    rtos_task_create("sensor", sensor_task, NULL, 2, RTOS_MIN_STACK);
    rtos_task_create("button", button_task, NULL, 2, RTOS_MIN_STACK);

    rtos_start(2400);

    rtos_queue_delete(events);
    rtos_shutdown();
    return 0;
}
