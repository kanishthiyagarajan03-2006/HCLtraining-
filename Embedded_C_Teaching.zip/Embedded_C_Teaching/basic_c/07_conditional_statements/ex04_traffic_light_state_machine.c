/*
 * ============================================================================
 *  Topic   : 07 Conditional Statements
 *  Example : 04 - Traffic light as a state machine (switch on an enum)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A state machine keeps a "current state" variable and uses switch (state) to run
 *            the code for that state only. Each case tests its own exit condition (elapsed
 *            time, button) and returns the NEXT state. Switching on an enum WITHOUT a
 *            default lets gcc (-Wswitch) tell you when you forgot a state.
 *  Embedded use : almost every device is a state machine: UART protocol parsers, motor
 *            start-up sequences, charger modes, menus. Keeping next_state() a pure function
 *            (no printing, no hardware) makes it easy to test.
 *  Real STM32F4 : GPIOB->ODR = lamp_pattern(state);   // called from the 100 ms timer tick
 *            (a whole-port write: fine only while nothing else on GPIOB is an output)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_traffic_light_state_machine.c -o ex04
 *  Output  : one line per state change with the lamps R Y G; a pedestrian request at 4.0 s
 *            shortens the green phase
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a LIGHT_RED_YELLOW state (UK style) between red and green.
 *            2) Delete a case from lamp_pattern() and rebuild with -Wall. What does gcc say?
 * ============================================================================
 */
#include "hw_sim.h"

typedef enum { LIGHT_RED, LIGHT_GREEN, LIGHT_YELLOW } light_t;

#define LAMP_R (1U << 2)
#define LAMP_Y (1U << 1)
#define LAMP_G (1U << 0)

#define RED_MS        3000U
#define GREEN_MS      4000U
#define GREEN_MIN_MS  1500U             /* a pedestrian can shorten green, but not below this */
#define YELLOW_MS     1000U
#define TICK_MS       100U
#define PED_PIN       0U                /* PC0: pedestrian push button (active high here) */

/* Pure function: current state + inputs in, next state out. */
static light_t next_state(light_t s, uint32_t in_state_ms, int ped_request)
{
    light_t next = s;
    switch (s) {
    case LIGHT_RED:
        if (in_state_ms >= RED_MS) {
            next = LIGHT_GREEN;
        }
        break;
    case LIGHT_GREEN:
        if (in_state_ms >= GREEN_MS || (ped_request && in_state_ms >= GREEN_MIN_MS)) {
            next = LIGHT_YELLOW;
        }
        break;
    case LIGHT_YELLOW:
        if (in_state_ms >= YELLOW_MS) {
            next = LIGHT_RED;
        }
        break;
    }                                   /* no default: -Wswitch checks every enum value */
    return next;
}

static uint32_t lamp_pattern(light_t s)
{
    switch (s) {
    case LIGHT_RED:    return LAMP_R;
    case LIGHT_GREEN:  return LAMP_G;
    case LIGHT_YELLOW: return LAMP_Y;
    }
    return LAMP_R;                      /* corrupted state: fail safe with red */
}

static const char *state_name(light_t s)
{
    static const char *const names[] = { "RED", "GREEN", "YELLOW" };
    return names[s];
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOCEN;
    GPIOB->MODER |= (1U << 0) | (1U << 2) | (1U << 4);        /* PB0..PB2 outputs */

    light_t state = LIGHT_RED;
    uint32_t in_state_ms = 0U;

    GPIOB->ODR = lamp_pattern(state);
    printf("start in %s:\n", state_name(state));
    sim_show_leds("R Y G", GPIOB->ODR, 3U);

    for (uint32_t t = 0U; t < 13000U; t += TICK_MS) {
        sim_delay_ms(TICK_MS);
        in_state_ms += TICK_MS;
        if (sim_millis() == 4000U) {
            sim_press(GPIOC, PED_PIN);                       /* someone pushes the button */
        }
        int ped = (GPIOC->IDR & (1U << PED_PIN)) != 0U;

        light_t next = next_state(state, in_state_ms, ped);
        if (next != state) {
            const char *why = (state == LIGHT_GREEN && in_state_ms < GREEN_MS)
                                  ? "pedestrian request" : "timer";
            printf("%s -> %s (%s, after %u ms):\n", state_name(state), state_name(next), why,
                   (unsigned)in_state_ms);
            state = next;
            in_state_ms = 0U;
            if (state == LIGHT_RED) {
                sim_release(GPIOC, PED_PIN);                 /* request served */
            }
            GPIOB->ODR = lamp_pattern(state);
            sim_show_leds("R Y G", GPIOB->ODR, 3U);
        }
    }
    return 0;
}
