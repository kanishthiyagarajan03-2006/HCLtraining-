/*
 * ============================================================================
 *  Topic   : 07 Conditional Statements
 *  Example : 01 - Temperature bands select fan speed (if / else-if ladder)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : An if / else-if ladder tests conditions top to bottom and runs the FIRST branch
 *            that is true, then skips the rest. So the order of the tests matters, and
 *            the final else catches everything left over. && and || combine conditions
 *            (|| stops as soon as one side is true), and ?: picks one of two values.
 *  Embedded use : thermostats, battery gauges, motor protection: sensor value in, discrete
 *            action out. Test your boundary values (24, 25, 29, 30 ...) - bugs live there.
 *  Real STM32F4 : if (temp_c >= 85) { GPIOB->BSRR = (1U << 1); }   // alarm LED on PB1
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_fan_speed_if_ladder.c -o ex01
 *  Output  : a table of nine temperatures with fan duty, relay and alarm state
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -DDEMO_BUG: the ladder tests the widest band first. Why does the
 *               fan never go above 30 %?
 *            2) Add a hysteresis rule so the fan stays on until 3 C below the switch-on point.
 * ============================================================================
 */
#include "hw_sim.h"

#define PIN_FAN_RELAY 0U
#define PIN_ALARM     1U

static uint8_t fan_duty(int temp_c)
{
    uint8_t duty;
#ifndef DEMO_BUG
    if (temp_c < 25) {                  /* cool: fan off                         */
        duty = 0U;
    } else if (temp_c < 30) {           /* here temp_c is already >= 25          */
        duty = 30U;
    } else if (temp_c < 35) {           /* ... and >= 30, so no need to retest   */
        duty = 60U;
    } else if (temp_c < 40) {
        duty = 80U;
    } else {                            /* everything left: 40 C and above       */
        duty = 100U;
    }
#else
    /* BUG: the widest test is first. 29, 34 and 85 C all match "temp_c >= 25" and the
     * ladder stops right there, so the fan never exceeds 30 %.                      */
    if (temp_c >= 25) {
        duty = 30U;
    } else if (temp_c >= 30) {
        duty = 60U;
    } else if (temp_c >= 35) {
        duty = 80U;
    } else if (temp_c >= 40) {
        duty = 100U;
    } else {
        duty = 0U;
    }
#endif
    return duty;
}

static void pin_write(unsigned pin, int on)
{
    if (on) {
        GPIOB->ODR |= (1U << pin);
    } else {
        GPIOB->ODR &= ~(1U << pin);
    }
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    GPIOB->MODER |= (1U << (PIN_FAN_RELAY * 2U)) | (1U << (PIN_ALARM * 2U));   /* outputs */

    static const int readings[] = { -5, 24, 25, 29, 30, 34, 39, 40, 85 };

    puts("temp(C)  duty  relay  alarm");
    for (size_t i = 0; i < sizeof readings / sizeof readings[0]; i++) {
        int t = readings[i];
        uint8_t duty = fan_duty(t);

        pin_write(PIN_FAN_RELAY, duty > 0U);
        /* || : alarm if too hot OR the sensor reports something impossible (wire fault). */
        pin_write(PIN_ALARM, t >= 85 || t < -40);

        printf("%6d  %3u%%  %-5s  %s\n", t, (unsigned)duty,
               (GPIOB->ODR & (1U << PIN_FAN_RELAY)) ? "ON" : "off",      /* ?: picks a text */
               (GPIOB->ODR & (1U << PIN_ALARM)) ? "ALARM" : "-");
    }
    return 0;
}
