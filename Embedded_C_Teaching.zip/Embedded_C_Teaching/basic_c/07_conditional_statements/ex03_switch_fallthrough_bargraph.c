/*
 * ============================================================================
 *  Topic   : 07 Conditional Statements
 *  Example : 03 - Intentional switch fall-through: a 4-LED level bar graph
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Without break, a case "falls through" into the next one. Usually that is a bug,
 *            but here it is the point: level 3 should light LED3 AND everything below it.
 *            Always mark deliberate fall-through with a comment  fall through  (gcc's
 *            -Wimplicit-fallthrough accepts it), or use __attribute__((fallthrough)) /
 *            [[fallthrough]] in C23. Often plain arithmetic ( (1U << n) - 1U ) is simpler.
 *  Embedded use : battery gauges, VU meters and signal-strength indicators light N of M LEDs.
 *            ADC value -> level -> LED pattern is a very common three-step pipeline.
 *  Real STM32F4 : GPIOB->ODR = (GPIOB->ODR & ~0x0FU) | bar_pattern(level);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_switch_fallthrough_bargraph.c -o ex03
 *  Output  : eight ADC readings shown as LED bars from empty to full, an out-of-range value,
 *            and a check that the arithmetic version gives the same patterns
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Reorder the cases to 1,2,3,4 (keeping the fall-through comments). What breaks?
 *            2) Build with -DDEMO_BUG (no -Werror): which letter does mode 1 return, and why?
 * ============================================================================
 */
#include "hw_sim.h"

#define LEVELS 4U
#define ADC_PER_LEVEL 820U              /* 4095 / 5 steps, so raw 0..4095 gives level 0..4 */

static uint8_t bar_pattern(unsigned level)
{
    uint8_t leds = 0U;
    switch (level) {
    case 4U:
        leds |= (1U << 3);              /* fall through */
    case 3U:
        leds |= (1U << 2);              /* fall through */
    case 2U:
        leds |= (1U << 1);              /* fall through */
    case 1U:
        leds |= (1U << 0);
        break;                          /* the cascade ends here */
    case 0U:
        break;                          /* nothing lit */
    default:
        leds = 0x0FU;                   /* out of range: light all LEDs as a warning */
        break;
    }
    return leds;
}

#ifdef DEMO_BUG
/* A forgotten break in a normal (non-cascading) switch. mode 1 runs 'A', then falls into
 * 'B', then into 'C' and stops there: the function always answers 'C' for 1, 2 and 3.   */
static char mode_letter(int mode)
{
    char r = '?';
    switch (mode) {
    case 1: r = 'A';                    /* BUG: no break */
    case 2: r = 'B';                    /* BUG: no break */
    case 3: r = 'C'; break;
    default: break;
    }
    return r;
}
#endif

int main(void)
{
    static const uint16_t adc[] = { 0, 500, 1000, 1700, 2500, 3300, 4095, 5000 };

    puts("ADC raw -> level -> LEDs (LED3 on the left)");
    for (size_t i = 0; i < sizeof adc / sizeof adc[0]; i++) {
        sim_delay_ms(250U);                                    /* one sample every 250 ms */
        unsigned level = (unsigned)adc[i] / ADC_PER_LEVEL;     /* integer division = bands */
        uint8_t pattern = bar_pattern(level);
        char label[24];
        snprintf(label, sizeof label, "raw %4u -> L%u", (unsigned)adc[i], level);
        sim_show_leds(label, pattern, LEVELS);
    }
    puts("(raw 5000 is above the 12-bit range, so the default branch lit every LED)");

    int same = 1;
    for (unsigned lv = 0U; lv <= LEVELS; lv++) {
        same = same && (bar_pattern(lv) == ((1U << lv) - 1U));   /* no switch needed */
    }
    printf("(1U << level) - 1U gives the same patterns for levels 0..4: %s\n",
           same ? "yes" : "NO");
#ifdef DEMO_BUG
    printf("mode_letter(1) = '%c' (expected 'A')\n", mode_letter(1));
#endif
    return 0;
}
