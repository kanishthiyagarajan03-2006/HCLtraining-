/*
 * ============================================================================
 *  Topic   : 07 Conditional Statements
 *  Example : 02 - UART command parser with switch (stacked labels, break, default)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : switch compares ONE integer (or char / enum) against constant case labels.
 *            Each case ends with break, otherwise execution "falls through" into the next
 *            case. Two labels in a row ("case 't': case 'T':") share one block.
 *            default: handles everything unexpected - always write it.
 *            Use switch for many equality tests, if/else for ranges and strings.
 *  Embedded use : a one-letter command protocol on a UART is the simplest remote control:
 *            the RX interrupt stores a byte, the main loop runs it through a switch.
 *  Real STM32F4 : switch (USART2->DR) { case 'L': ... }   // reading DR clears RXNE
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_uart_command_switch.c -o ex02
 *  Output  : each received character with the action taken; processing stops at 'Q'
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a command 'b' that blinks the LED three times. Where does it go?
 *            2) Remove the break after case '1'. What does '1' do now, and who warns you?
 * ============================================================================
 */
#include "hw_sim.h"

#define LED_PIN 5U                      /* PA5, the green LED on Nucleo boards */

/* What arrived on the UART (an ISR would normally put these bytes in a buffer). */
static const char rx_stream[] = "1 t T ? s 0 z Q 1";

/* Returns 1 when the session should end, 0 to keep going. */
static int handle_command(char c)
{
    switch (c) {
    case '1':
        GPIOA->ODR |= (1U << LED_PIN);
        puts("  LED on");
        break;
    case '0':
        GPIOA->ODR &= ~(1U << LED_PIN);
        puts("  LED off");
        break;
    case 't':                           /* stacked labels: lower and upper case ...   */
    case 'T':                           /* ... run the same code                       */
        GPIOA->ODR ^= (1U << LED_PIN);
        puts("  LED toggled");
        break;
    case 's':
    case 'S':
        printf("  status: LED is %s (ODR=0x%04X)\n",
               (GPIOA->ODR & (1U << LED_PIN)) ? "ON" : "OFF", (unsigned)GPIOA->ODR);
        break;
    case '?':
        puts("  commands: 1 on, 0 off, t toggle, s status, Q quit");
        break;
    case ' ':
    case '\r':
    case '\n':
        return 0;                       /* whitespace: ignore silently */
    case 'Q':
        puts("  quit requested");
        return 1;
    default:                            /* unknown byte: report it, never crash */
        printf("  unknown command '%c' (0x%02X)\n", c, (unsigned)(uint8_t)c);
        break;
    }
    return 0;
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->MODER |= (1U << (LED_PIN * 2U));            /* PA5 = output */

    size_t i = 0;
    for (; rx_stream[i] != '\0'; i++) {
        char c = rx_stream[i];
        if (c != ' ') {
            printf("rx '%c'\n", c);
        }
        if (handle_command(c)) {
            break;
        }
    }
    printf("processed %zu of %zu bytes; the rest stays unread\n", i + 1U, sizeof rx_stream - 1U);
    return 0;
}
