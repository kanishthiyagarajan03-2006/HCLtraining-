/*
 * ============================================================================
 *  Topic   : 07 Conditional Statements
 *  Example : 08 - Linux: if (fp == NULL) then switch (errno), perror and argc
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Library and system calls report failure through their return value (NULL, -1)
 *            and put the reason in the global errno. Test the return value first, copy
 *            errno at once (the next call may change it), then switch on it to react
 *            differently to each cause. perror() and strerror() turn the number into text.
 *            argc tells you how many command-line arguments you got: check it before argv.
 *  Embedded use : an embedded Linux service that cannot open its config file, /dev/ttyS1 or
 *            a sysfs GPIO must say WHY: "missing" -> use defaults, "permission denied" ->
 *            fix the service user, "is a directory" -> wrong path in the config.
 *  Real Linux   : FILE *fp = fopen("/etc/myapp.conf", "r"); if (fp == NULL) { perror("fopen"); }
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex08_linux_fopen_errno_switch.c -o ex08
 *  Output  : five open attempts in a private temp folder, each classified (ENOENT, EISDIR,
 *            ENOTDIR or OK); perror text goes to stderr. Pass paths: ./ex08 /etc/shadow
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Run  ./ex08 /etc/hostname /etc/shadow /nonexistent  as a normal user (not root).
 *            2) Add a case for EMFILE (too many open files). What would the right reaction be?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* Try to open path; explain the outcome. Returns 0 on success, -1 on failure. */
static int check_path(const char *label, const char *path, const char *mode)
{
    FILE *fp = fopen(path, mode);
    if (fp != NULL) {                           /* guard clause: the good case first */
        printf("  %-24s -> opened OK (mode \"%s\")\n", label, mode);
        fclose(fp);
        return 0;
    }

    int err = errno;                            /* save it NOW, before any other call */
    perror(label);                              /* text to stderr: "label: reason"    */
    printf("  %-24s -> failed: ", label);
    switch (err) {
    case ENOENT:
        puts("no such file -> use built-in defaults");
        break;
    case EACCES:
        puts("permission denied -> check the file mode and the service user");
        break;
    case EISDIR:
        puts("is a directory -> the path in the config is wrong");
        break;
    default:                                    /* anything else: show the system's text */
        printf("errno %d (%s)\n", err, strerror(err));
        break;
    }
    return -1;
}

int main(int argc, char *argv[])
{
    if (argc > 1) {                             /* paths given on the command line: test them */
        int failed = 0;
        for (int i = 1; i < argc; i++) {
            failed += (check_path(argv[i], argv[i], "r") != 0);
        }
        return failed ? 1 : 0;
    }
    puts("no arguments given: running the built-in demo (try ./ex08 /etc/hostname /nonexistent)");

    char dir[] = "/tmp/ex08_XXXXXX";
    if (mkdtemp(dir) == NULL) {
        perror("mkdtemp");
        return 1;
    }
    char file[64];
    char below_file[80];
    char missing[64];
    snprintf(file, sizeof file, "%s/settings.cfg", dir);
    snprintf(below_file, sizeof below_file, "%s/settings.cfg/extra", dir);
    snprintf(missing, sizeof missing, "%s/missing.cfg", dir);

    check_path("read missing.cfg", missing, "r");           /* ENOENT  */
    /* fopen(dir, "r") would succeed on Linux (the error only shows at the first read),
     * so we ask for write access to get EISDIR right away.                       */
    check_path("write to a directory", dir, "w");           /* EISDIR  */
    check_path("create settings.cfg", file, "w");           /* OK      */
    check_path("read settings.cfg", file, "r");             /* OK      */
    check_path("open settings.cfg/extra", below_file, "r"); /* ENOTDIR: a file used as a folder */

    remove(file);                               /* clean up what we created */
    rmdir(dir);
    return 0;
}
