/*
 * ============================================================================
 *  Topic   : 07 Conditional Statements
 *  Example : 05 - Button debounce: accept a change only after N identical samples
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A mechanical contact "bounces": the raw pin flickers 0-1-0-1 for a few
 *            milliseconds. The debouncer keeps the accepted (stable) state and a counter.
 *            if / else if / else decides each millisecond: raw equals stable -> reset the
 *            counter; raw differs -> count it; counted long enough -> accept the change.
 *  Embedded use : without debouncing one button press can register as five, so a menu
 *            skips or a motor toggles on and off. Sample every 1 ms from a timer ISR.
 *  Real STM32F4 : raw = (GPIOC->IDR >> 13) & 1U;   // PC13 = blue user button on Nucleo
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_button_debounce.c -o ex05
 *  Output  : the PRESS and RELEASE events with timestamps, then the raw samples and the
 *            debounced state as two rows of 0/1; a 1 ms glitch is ignored
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Set DEBOUNCE_SAMPLES to 2. Does the 1 ms glitch still get ignored? The bounce?
 *            2) Set it to 12. What is the cost of such a long filter for the user?
 * ============================================================================
 */
#include "hw_sim.h"

#define BTN_PIN          13U
#define DEBOUNCE_SAMPLES 5U             /* 5 identical 1 ms samples = 5 ms filter */

static uint8_t  stable;                 /* accepted state: 0 released, 1 pressed  */
static unsigned counter;                /* how long raw has disagreed with stable */

/* Call once per millisecond. Returns +1 on a PRESS, -1 on a RELEASE, 0 otherwise. */
static int debounce(uint8_t raw)
{
    int event = 0;
    if (raw == stable) {
        counter = 0U;                   /* nothing pending: the pin agrees with us */
    } else if (++counter >= DEBOUNCE_SAMPLES) {
        stable = raw;                   /* it disagreed long enough: accept it */
        counter = 0U;
        event = raw ? +1 : -1;
    } else {
        /* disagreeing, but not for long enough yet: could still be noise */
    }
    return event;
}

int main(void)
{
    /* One character per millisecond of the raw pin. Idle, a 1 ms glitch, a bouncy press,
     * a long hold, a bouncy release.                                                  */
    static const char script[] = "0000" "1" "0000" "10110" "11111111" "1111" "0100" "00000000";

    char raw_row[sizeof script];
    char stable_row[sizeof script];
    size_t n = sizeof script - 1U;

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;            /* PC13 stays an input (MODER = 00) */

    puts("events:");
    for (size_t i = 0; i < n; i++) {
        if (script[i] == '1') {
            sim_press(GPIOC, BTN_PIN);              /* the "contact" closes */
        } else {
            sim_release(GPIOC, BTN_PIN);
        }
        sim_delay_ms(1U);                           /* 1 ms sample tick */

        uint8_t raw = (uint8_t)((GPIOC->IDR >> BTN_PIN) & 1U);
        int ev = debounce(raw);
        if (ev > 0) {
            printf("  t=%2u ms  PRESS accepted\n", (unsigned)sim_millis());
        } else if (ev < 0) {
            printf("  t=%2u ms  RELEASE accepted\n", (unsigned)sim_millis());
        }
        raw_row[i] = (char)('0' + raw);
        stable_row[i] = (char)('0' + stable);
    }
    raw_row[n] = '\0';
    stable_row[n] = '\0';

    printf("raw    : %s\n", raw_row);
    printf("stable : %s\n", stable_row);
    return 0;
}
