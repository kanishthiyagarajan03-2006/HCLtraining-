# Topic 07 - Conditional Statements
**Suggested session:** 75-90 min | **Prerequisite topics:** 03 Variable types, 04 Operators, 05-06 printf basics

Students learn to turn sensor values and events into decisions: `if / else if / else` for ranges,
`switch` for exact values and states, `?:` for a quick either-or, and early-return "guard clauses"
for error handling. The examples go from a temperature ladder, through two flavours of `switch`
(command parser, deliberate fall-through) to state machines, a debouncer and error codes, and end
with the same ideas inside an RTOS event loop and an embedded-Linux `errno` handler.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_fan_speed_if_ladder.c` | MCU | `if / else if / else` ladder, order of tests, `&&` `\|\|` `?:`, boundary values |
| 02 | `ex02_uart_command_switch.c` | MCU | `switch` on a char, `break`, stacked labels, `default`, switch vs if |
| 03 | `ex03_switch_fallthrough_bargraph.c` | MCU | deliberate fall-through (commented), forgotten `break` (`DEMO_BUG`), arithmetic alternative |
| 04 | `ex04_traffic_light_state_machine.c` | MCU | `switch` on an `enum`, pure `next_state()`, `-Wswitch`, nested conditions |
| 05 | `ex05_button_debounce.c` | MCU | `if / else if / else` with a counter, filtering noise, event detection |
| 06 | `ex06_error_codes_guard_clauses.c` | MCU | status codes, `if (st != ST_OK)`, nested pyramid vs guard clauses |
| 07 | `ex07_rtos_event_switch.c` | RTOS | queue-driven event loop with `switch`, timeout as an event, mode logic |
| 08 | `ex08_linux_fopen_errno_switch.c` | LINUX | `fopen` NULL check, `switch (errno)`, `perror`/`strerror`, `argc` |

## Teaching notes
* In a ladder the FIRST true test wins. Ask the class to test the boundaries: 24, 25, 29, 30.
* `switch` needs `break`; forgetting it is the classic bug. Real fall-through must carry a
  `/* fall through */` comment (and gcc's `-Wimplicit-fallthrough` then stays quiet).
* Write `default:` for char/int switches (unknown input). For an `enum` switch, leave it out so
  the compiler warns about missing states (ex04), and add a safe fallback after the switch.
* `=` vs `==` in a condition: `if (x = 5)` assigns. Put the constant first or turn on `-Wall`.
* Guard clauses (ex06) keep the success path flat and make error handling visible.
* `errno` is only meaningful right after a call that failed, and must be saved before printing.

## Live-demo tips
* ex01 and ex03: `gcc -DDEMO_BUG ...` (without `-Werror`) to show the ladder bug and the gcc fall-through warnings.
* ex04: delete a `case` from `lamp_pattern()` and rebuild to show the `-Wswitch` warning.
* ex08: run `./ex08 /etc/hostname /etc/shadow /nonexistent` to see `EACCES` as a normal user.
