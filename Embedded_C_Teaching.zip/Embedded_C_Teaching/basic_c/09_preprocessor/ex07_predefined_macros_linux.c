/*
 * ============================================================================
 *  Topic   : 09 The C Preprocessor
 *  Example : 07 - Predefined macros and feature-test macros on embedded Linux
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : The compiler predefines macros that describe the file (__FILE__,
 *            __LINE__, __func__), the language (__STDC_VERSION__) and the target
 *            (__linux__, __x86_64__, __arm__). Feature-test macros such as
 *            _GNU_SOURCE must be defined BEFORE the first #include to unlock
 *            extra library functions. See them all:  gcc -dM -E - < /dev/null
 *  Embedded use : one source tree builds for the PC and for an ARM Linux board;
 *            #if chooses the right code. __FILE__/__LINE__ make log lines traceable.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex07_predefined_macros_linux.c -o ex07
 *            Cross build example: arm-linux-gnueabihf-gcc ex07_predefined_macros_linux.c
 *  Output  : traced log lines, a target description built from macros, and file
 *            extensions found with memrchr() (declared only when _GNU_SOURCE is set)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Delete the _GNU_SOURCE block: gcc reports an implicit declaration (a warning
 *               before gcc 14, an error from gcc 14). Of which function?
 *            2) Run  gcc -dM -E - < /dev/null | grep SIZEOF_  and find __SIZEOF_POINTER__.
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#ifndef _GNU_SOURCE
#define _GNU_SOURCE            /* unlocks memrchr() and other GNU extensions */
#endif
#include <stdio.h>
#include <string.h>

/* __FILE__ is the path exactly as given to the compiler: show just the file name. */
static const char *base_name(const char *path)
{
    const char *slash = strrchr(path, '/');
    return slash ? slash + 1 : path;
}

/* ##__VA_ARGS__ (GNU extension) swallows the comma when no extra arguments exist. */
#define LOG(fmt, ...)  printf("%s:%d %s(): " fmt "\n", base_name(__FILE__), __LINE__, \
                              __func__, ##__VA_ARGS__)

/* Target description chosen by the preprocessor, not at run time. */
#if defined(__x86_64__)
#  define TARGET_ARCH "x86-64 (PC / cloud VM)"
#elif defined(__aarch64__)
#  define TARGET_ARCH "AArch64 (Raspberry Pi 4 / Jetson class board)"
#elif defined(__arm__)
#  define TARGET_ARCH "32-bit ARM (BeagleBone / i.MX class board)"
#else
#  define TARGET_ARCH "unknown architecture"
#endif

#if defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__)
#  define TARGET_ENDIAN "little-endian"
#else
#  define TARGET_ENDIAN "big-endian or unknown"
#endif

/* Find the file extension: search BACKWARDS for the last '.'. memrchr() is a GNU
 * extension (not ISO C), so glibc hides its prototype unless _GNU_SOURCE is set.  */
static void show_extension(const char *name)
{
    const char *dot = memrchr(name, '.', strlen(name));
    LOG("\"%s\" -> extension \"%s\"", name, dot ? dot + 1 : "(none)");
}

int main(void)
{
    LOG("starting");                                   /* no extra arguments */
    LOG("answer is %d", 42);

    printf("\nTarget described by predefined macros:\n");
    printf("  architecture : %s\n", TARGET_ARCH);
    printf("  byte order   : %s\n", TARGET_ENDIAN);
    printf("  pointer size : %d bytes\n", __SIZEOF_POINTER__);
    printf("  C standard   : __STDC_VERSION__ = %ldL\n", (long)__STDC_VERSION__);
    printf("  hosted       : __STDC_HOSTED__ = %d  (bare-metal builds often use 0)\n",
           __STDC_HOSTED__);
#ifdef __OPTIMIZE__
    printf("  optimisation : on (-O1 or higher)\n");
#else
    printf("  optimisation : off (-O0)\n");
#endif
    /* __DATE__ and __TIME__ also exist, but they change on every build, so
     * firmware that must be reproducible avoids printing them. */

    printf("\nFirmware image names (memrchr needs _GNU_SOURCE):\n");
    show_extension("app_v2.1.bin");
    show_extension("bootloader.hex");
    show_extension("README");
    return 0;
}
