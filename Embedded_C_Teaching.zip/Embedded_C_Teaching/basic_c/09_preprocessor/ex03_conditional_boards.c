/*
 * ============================================================================
 *  Topic   : 09 The C Preprocessor
 *  Example : 03 - Conditional compilation: one source, three boards, debug on/off
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : #if / #ifdef / #elif / #else / #endif keep or drop whole blocks of
 *            source BEFORE compilation. Dropped code is not in the binary at all.
 *            #error stops the build with a message when the configuration is wrong.
 *  Embedded use : the same firmware runs on different boards (pin map, LED polarity)
 *            and a DEBUG build adds logging that the release build must not carry.
 *  Real STM32F4 : Nucleo-F446RE user LED = PA5, F4-Discovery green LED = PD12.
 *            Many cheap boards (e.g. Blue Pill) wire the LED on PC13 active-LOW:
 *            writing 0 turns it ON - that is what BOARD_BLUEPILL models. (The real
 *            Blue Pill is an STM32F103, whose GPIO registers differ from the F4;
 *            only the LED polarity is copied here.)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_conditional_boards.c -o ex03
 *            Try:  -DBOARD_DISCO   or   -DBOARD_BLUEPILL   or   -DDEBUG
 *  Output  : board name, LED port/pin, and the LED blinking with the right polarity
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -DBOARD_DISCO, then with -DBOARD_BLUEPILL: what changes?
 *            2) Build with -DBOARD_DISCO -DBOARD_BLUEPILL: read the #error message.
 * ============================================================================
 */
#include "hw_sim.h"

/* Exactly one board may be chosen. (defined(X) is 1 or 0 inside #if.) */
#if (defined(BOARD_NUCLEO) + defined(BOARD_DISCO) + defined(BOARD_BLUEPILL)) > 1
#  error "Select exactly ONE board: -DBOARD_NUCLEO, -DBOARD_DISCO or -DBOARD_BLUEPILL"
#endif

/* No board given on the command line: fall back to a default. */
#if !defined(BOARD_NUCLEO) && !defined(BOARD_DISCO) && !defined(BOARD_BLUEPILL)
#  define BOARD_NUCLEO
#endif

#if defined(BOARD_NUCLEO)
#  define BOARD_NAME     "Nucleo-F446RE"
#  define LED_PORT       GPIOA
#  define LED_PORT_NAME  "GPIOA"
#  define LED_PIN        5U
#  define LED_CLK_EN     RCC_AHB1ENR_GPIOAEN
#  define LED_ACTIVE_LOW 0
#elif defined(BOARD_DISCO)
#  define BOARD_NAME     "STM32F4-Discovery"
#  define LED_PORT       GPIOD
#  define LED_PORT_NAME  "GPIOD"
#  define LED_PIN        12U
#  define LED_CLK_EN     RCC_AHB1ENR_GPIODEN
#  define LED_ACTIVE_LOW 0
#elif defined(BOARD_BLUEPILL)
#  define BOARD_NAME     "Blue-Pill style board"
#  define LED_PORT       GPIOC
#  define LED_PORT_NAME  "GPIOC"
#  define LED_PIN        13U
#  define LED_CLK_EN     RCC_AHB1ENR_GPIOCEN
#  define LED_ACTIVE_LOW 1
#endif

/* Debug logging: in a release build DBG(...) becomes an empty statement. */
#ifdef DEBUG
#  define DBG(...)  printf("[DBG] " __VA_ARGS__)
#else
#  define DBG(...)  ((void)0)
#endif

static void led_set(int on)
{
#if LED_ACTIVE_LOW
    int level = !on;              /* pin LOW lights the LED */
#else
    int level = on;               /* pin HIGH lights the LED */
#endif
    if (level) LED_PORT->ODR |=  (1U << LED_PIN);
    else       LED_PORT->ODR &= ~(1U << LED_PIN);
    DBG("led_set(%d) -> pin level %d\n", on, level);
}

int main(void)
{
    printf("Board : %s\n", BOARD_NAME);
    printf("LED   : %s pin %u, %s\n", LED_PORT_NAME, LED_PIN,
           LED_ACTIVE_LOW ? "active-LOW" : "active-HIGH");
#ifdef DEBUG
    printf("Build : DEBUG (extra logging compiled in)\n\n");
#else
    printf("Build : RELEASE (DBG() lines removed by the preprocessor)\n\n");
#endif

    RCC->AHB1ENR |= LED_CLK_EN;
    LED_PORT->MODER |= (1U << (LED_PIN * 2U));        /* output mode */
    LED_PORT->ODR |= (LED_ACTIVE_LOW ? (1U << LED_PIN) : 0U);   /* start with LED off */

    for (int i = 0; i < 4; i++) {
        led_set(i % 2 == 0);                          /* ON, OFF, ON, OFF */
        sim_delay_ms(500);
        printf("LED logical %-3s -> ", (i % 2 == 0) ? "ON" : "OFF");
        sim_show_port(LED_PORT_NAME, LED_PORT);
    }
    return 0;
}
