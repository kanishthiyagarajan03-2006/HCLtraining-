/*
 * ============================================================================
 *  Topic   : 09 The C Preprocessor
 *  Example : 06 - FreeRTOSConfig.h style macros configure the whole kernel
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : An RTOS is tuned with #define "config" macros: tick rate, number of
 *            priorities, which features exist. Defaults are supplied with #ifndef,
 *            nonsense settings are rejected with #error / _Static_assert, and
 *            helper macros such as pdMS_TO_TICKS() convert units at compile time.
 *  Embedded use : every FreeRTOS project has a FreeRTOSConfig.h. Turning a feature
 *            off removes its code from flash, which matters on a 32 KB MCU.
 *  Real FreeRTOS : #define configTICK_RATE_HZ ( ( TickType_t ) 1000 )
 *            xTaskCreate(vTask, "ctl", 256, NULL, configMAX_PRIORITIES - 1, NULL);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_rtos_config_macros.c -o ex06
 *  Output  : the configuration summary, then a sensor task (100 ms) feeding a control
 *            task (higher priority) through a queue, plus a slow heartbeat task
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Set configMAX_PRIORITIES to 3 and read the #error / _Static_assert text.
 *            2) Set configUSE_TRACE to 0: the "heartbeat" lines disappear from the build.
 * ============================================================================
 */
#include "mini_rtos.h"

/* ============ the "FreeRTOSConfig.h" part =================================== */
#define configTICK_RATE_HZ        1000U       /* 1 tick = 1 ms                        */
#define configMAX_PRIORITIES      5           /* valid priorities: 0 .. 4             */
#define configMINIMAL_STACK_SIZE  128U        /* in words on a real MCU               */
#define configUSE_TRACE           1           /* our own switch: heartbeat logging    */

/* FreeRTOS.h style defaults: only used when the config file did not set them. */
#ifndef configUSE_PREEMPTION
#  define configUSE_PREEMPTION    1
#endif
#ifndef configUSE_IDLE_HOOK
#  define configUSE_IDLE_HOOK     0
#endif

#if configMAX_PRIORITIES < 4
#  error "This application needs at least 4 priority levels"
#endif

#define STR_(x) #x
#define STR(x)  STR_(x)

#define tskIDLE_PRIORITY          0
#define pdMS_TO_TICKS(ms)         ((uint32_t)(((uint64_t)(ms) * configTICK_RATE_HZ) / 1000U))

/* mini_rtos always counts 1 tick = 1 ms, so the config has to agree with it. */
_Static_assert(configTICK_RATE_HZ == 1000U, "mini_rtos has a fixed 1 ms tick");

/* Priority plan written with names instead of numbers. */
#define PRIO_HEARTBEAT  (tskIDLE_PRIORITY + 1)
#define PRIO_SENSOR     (tskIDLE_PRIORITY + 2)
#define PRIO_CONTROL    (configMAX_PRIORITIES - 1)       /* highest of all */
_Static_assert(PRIO_CONTROL < configMAX_PRIORITIES, "priority out of range");

#define configASSERT(x)                                                   \
    do { if (!(x)) printf("ASSERT FAILED: %s (line %d)\n", #x, __LINE__); } while (0)

/* ============ application ==================================================== */
#define SENSOR_PERIOD_MS   100U
#define QUEUE_LEN          4U

static rtos_queue_t *adc_queue;

static void task_sensor(void *arg)
{
    (void)arg;
    uint16_t adc = 2000;
    for (;;) {
        adc = (uint16_t)(adc + 120);                  /* pretend the temperature rises */
        rtos_queue_send(adc_queue, &adc, RTOS_WAIT_FOREVER);
        rtos_delay(pdMS_TO_TICKS(SENSOR_PERIOD_MS));
    }
}

static void task_control(void *arg)
{
    (void)arg;
    for (;;) {
        uint16_t adc;
        if (rtos_queue_recv(adc_queue, &adc, RTOS_WAIT_FOREVER))
            rtos_log("adc=%u -> fan %s", (unsigned)adc, adc > 2300 ? "HIGH" : "low");
    }
}

#if configUSE_TRACE
static void task_heartbeat(void *arg)
{
    (void)arg;
    for (;;) {
        rtos_log("heartbeat (tick count %u)", (unsigned)rtos_ticks());
        rtos_delay(pdMS_TO_TICKS(250));
    }
}
#endif

int main(void)
{
    printf("tick rate  : %u Hz (macro text: %s)\n", configTICK_RATE_HZ, STR(configTICK_RATE_HZ));
    printf("priorities : 0..%d (idle=%d, control=%d)\n", configMAX_PRIORITIES - 1,
           tskIDLE_PRIORITY, PRIO_CONTROL);
    printf("preemption : %d, idle hook : %d, 500 ms = %u ticks\n\n", configUSE_PREEMPTION,
           configUSE_IDLE_HOOK, (unsigned)pdMS_TO_TICKS(500));

    adc_queue = rtos_queue_create(QUEUE_LEN, sizeof(uint16_t));
    configASSERT(adc_queue != NULL);
    if (adc_queue == NULL) return 1;

    rtos_task_create("sensor",  task_sensor,  NULL, PRIO_SENSOR,  configMINIMAL_STACK_SIZE * 4U);
    rtos_task_create("control", task_control, NULL, PRIO_CONTROL, configMINIMAL_STACK_SIZE * 4U);
#if configUSE_TRACE
    rtos_task_create("heartbt", task_heartbeat, NULL, PRIO_HEARTBEAT,
                     configMINIMAL_STACK_SIZE * 4U);
#endif

    rtos_start(pdMS_TO_TICKS(600));
    rtos_queue_delete(adc_queue);
    rtos_shutdown();
    return 0;
}
