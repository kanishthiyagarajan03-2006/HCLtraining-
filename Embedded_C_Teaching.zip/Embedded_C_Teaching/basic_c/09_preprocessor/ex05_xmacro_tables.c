/*
 * ============================================================================
 *  Topic   : 09 The C Preprocessor
 *  Example : 05 - X-macros: one list generates the enum, the names and the table
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : An X-macro is a list written once as  X(a, b, c) X(d, e, f) ...
 *            Each use re-defines X to produce something different: an enum, a
 *            string table, a configuration array. The pieces can never get out of
 *            step. _Static_assert catches mistakes at compile time (no runtime cost).
 *  Embedded use : error-code tables, pin maps, command lists, interrupt names.
 *            Adding one line to the list updates every table automatically.
 *  Real STM32F4 : a pin map such as  { GPIOA, GPIO_PIN_5 }  for each board signal.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_xmacro_tables.c -o ex05
 *  Output  : the error table printed from the generated strings, then the four
 *            board pins configured and driven from the generated pin table
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add  X(ERR_CRC, 5, "CRC mismatch")  to ERROR_TABLE and rerun.
 *               How many other lines did you have to edit?
 *            2) Lower the limit in  _Static_assert(PIN_COUNT <= 16, ...)  to 3 and
 *               read the compiler message.
 * ============================================================================
 */
#include "hw_sim.h"

/* ---- 1. error codes: ONE list ---------------------------------------------- */
#define ERROR_TABLE(X)                                 \
    X(ERR_OK,      0, "no error")                      \
    X(ERR_TIMEOUT, 1, "peripheral did not respond")    \
    X(ERR_BUSY,    2, "bus busy")                      \
    X(ERR_PARAM,   3, "bad parameter")                 \
    X(ERR_OVERRUN, 4, "UART receive overrun")

/* Expansion A: the enum   ERR_OK = 0, ERR_TIMEOUT = 1, ... */
#define X_ENUM(name, code, text)  name = code,
typedef enum { ERROR_TABLE(X_ENUM) ERR_COUNT } err_t;

/* Expansion B: text table. [name] = ... is a designated initialiser (index = code). */
#define X_TEXT(name, code, text)  [name] = text,
static const char *const err_text[ERR_COUNT] = { ERROR_TABLE(X_TEXT) };

/* Expansion C: names of the enumerators, using '#' */
#define X_NAME(name, code, text)  [name] = #name,
static const char *const err_name[ERR_COUNT] = { ERROR_TABLE(X_NAME) };

/* ---- 2. board pin map: another list, another table ------------------------- */
#define PIN_TABLE(X)          \
    X(PIN_LED_GREEN, A, 5)    \
    X(PIN_LED_RED,   A, 6)    \
    X(PIN_BUZZER,    B, 0)    \
    X(PIN_RELAY,     B, 3)

enum { PORT_A, PORT_B };                          /* index for sim_gpio() */

#define X_PIN_ENUM(id, port, pin)  id,
enum { PIN_TABLE(X_PIN_ENUM) PIN_COUNT };

typedef struct { const char *name; uint8_t port; uint8_t pin; } pin_cfg_t;
#define X_PIN_CFG(id, port, pin)  [id] = { #id, PORT_##port, (pin) },
static const pin_cfg_t pin_cfg[PIN_COUNT] = { PIN_TABLE(X_PIN_CFG) };

/* Compile-time checks: the build FAILS with this text if the assumption breaks. */
/* Count the list entries (each X(...) adds "+ 1"): a gap in the codes would leave a NULL text. */
#define X_COUNT(name, code, text)  + 1
_Static_assert(0 ERROR_TABLE(X_COUNT) == ERR_COUNT, "error codes must run 0..N-1, no gaps");
_Static_assert(PIN_COUNT <= 16, "pin list must fit one 16-bit bitmap");
_Static_assert(sizeof(pin_cfg_t) <= 16, "pin_cfg_t should stay small (it lives in flash)");

int main(void)
{
    printf("%-4s %-12s %s\n", "code", "name", "meaning");
    for (int e = 0; e < (int)ERR_COUNT; e++)
        printf("%-4d %-12s %s\n", e, err_name[e], err_text[e]);

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN;
    printf("\nConfiguring %d pins from the table:\n", (int)PIN_COUNT);
    uint32_t used[2] = { 0, 0 };
    for (int i = 0; i < (int)PIN_COUNT; i++) {
        GPIO_TypeDef *p = sim_gpio(pin_cfg[i].port);
        p->MODER |= (1U << (pin_cfg[i].pin * 2U));          /* output */
        p->ODR   |= (1U << pin_cfg[i].pin);                 /* drive high */
        used[pin_cfg[i].port] |= (1U << pin_cfg[i].pin);
        printf("  %-14s -> port %c, pin %u\n", pin_cfg[i].name, 'A' + pin_cfg[i].port,
               (unsigned)pin_cfg[i].pin);
    }
    printf("\n");
    sim_show_port("GPIOA", GPIOA);
    sim_show_port("GPIOB", GPIOB);
    printf("pins used: A=0x%04X B=0x%04X\n", (unsigned)used[0], (unsigned)used[1]);
    return 0;
}
