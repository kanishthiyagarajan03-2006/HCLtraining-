/*
 * ============================================================================
 *  Topic   : 09 The C Preprocessor
 *  Example : 02 - Function-like macros: bit helpers, ARRAY_SIZE, MIN/MAX
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A function-like macro takes arguments but is still text pasting.
 *            Rule 1: parenthesise every argument AND the whole expansion.
 *            Rule 2: an argument may be pasted several times, so never pass
 *            something with a side effect (i++, read_uart(), ...).
 *            Multi-statement macros are wrapped in do { ... } while (0).
 *  Embedded use : vendor headers (CMSIS, HAL) are full of SET_BIT, CLEAR_BIT,
 *            READ_BIT, MODIFY_REG and ARRAY_SIZE style macros.
 *  Real STM32F4 : SET_BIT(GPIOA->ODR, GPIO_ODR_OD5);   // from stm32f4xx.h
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex02_function_like_macros.c -o ex02
 *  Output  : register value after each macro, an LED-pin loop sized by ARRAY_SIZE,
 *            and MIN/MAX results
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Compile with -DDEMO_BUG: the MAX() macro increments a variable twice.
 *            2) Remove the parentheses around (x) in SQUARE() and predict SQUARE(2 + 1).
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define BIT(n)                (1U << (n))
#define SET_BIT(reg, mask)    ((reg) |= (mask))
#define CLEAR_BIT(reg, mask)  ((reg) &= ~(mask))
#define READ_BIT(reg, mask)   ((reg) & (mask))
#define ARRAY_SIZE(a)         (sizeof(a) / sizeof((a)[0]))
#define MIN(a, b)             (((a) < (b)) ? (a) : (b))
#define MAX(a, b)             (((a) > (b)) ? (a) : (b))
#define SQUARE(x)             ((x) * (x))   /* without inner (x): 2 + 1 * 2 + 1 = 5 */

/* Two statements in one macro: the do/while(0) wrapper makes it behave like ONE
 * statement, so it is safe inside "if (...) MACRO(...); else ...".              */
#define LOG_REG(name, reg)                                          \
    do {                                                            \
        printf("%-4s = ", (name));                                  \
        printf("0x%04X\n", (unsigned)(reg));                        \
    } while (0)

static volatile uint32_t FAKE_ODR;                   /* stands in for GPIOA->ODR */
static const uint8_t led_pins[] = { 5, 6, 7, 9 };    /* lives in flash (.rodata) */

int main(void)
{
    /* --- bit helpers: same operators as topic 04, now with readable names --- */
    SET_BIT(FAKE_ODR, BIT(5) | BIT(7));
    LOG_REG("ODR", FAKE_ODR);                        /* 0x00A0 */
    CLEAR_BIT(FAKE_ODR, BIT(7));
    LOG_REG("ODR", FAKE_ODR);                        /* 0x0020 */
    printf("PA5 is %s\n", READ_BIT(FAKE_ODR, BIT(5)) ? "high" : "low");

    /* --- ARRAY_SIZE: the count follows the initialiser, no magic number ----- */
    printf("\n%zu LED pins:", ARRAY_SIZE(led_pins));
    for (size_t i = 0; i < ARRAY_SIZE(led_pins); i++) {
        SET_BIT(FAKE_ODR, BIT(led_pins[i]));
        printf(" PA%u", (unsigned)led_pins[i]);
    }
    printf("\n");
    LOG_REG("ODR", FAKE_ODR);                        /* 0x02E0 */

    /* Thanks to do/while(0) the macro followed by ';' and 'else' still parses. */
    if (READ_BIT(FAKE_ODR, BIT(9)))
        LOG_REG("PA9", READ_BIT(FAKE_ODR, BIT(9)));
    else
        printf("PA9 is off\n");

    /* --- MIN / MAX on plain values ----------------------------------------- */
    int adc_a = 812, adc_b = 790;
    printf("\nMAX(%d, %d) = %d   MIN(%d, %d) = %d\n", adc_a, adc_b, MAX(adc_a, adc_b),
           adc_a, adc_b, MIN(adc_a, adc_b));
    printf("SQUARE(2 + 1) = %d  (parentheses make it 9, not 5)\n", SQUARE(2 + 1));

    /* --- side-effect trap ---------------------------------------------------- */
    int a = 5;
    int b = 3;
#ifdef DEMO_BUG
    /* MAX(a++, b) expands to  (((a++) > (b)) ? (a++) : (b))  -> a++ runs TWICE. */
    int m = MAX(a++, b);
    printf("MAX(a++, b) = %d, a = %d   <-- a should be 6\n", m, a);   /* prints 6 and 7 */
#else
    /* Safe habit: evaluate the side effect once, then pass a plain variable. */
    int next = a++;
    int m = MAX(next, b);
    printf("evaluate first, then MAX: m = %d, a = %d (a incremented once)\n", m, a);
#endif
    return 0;
}
