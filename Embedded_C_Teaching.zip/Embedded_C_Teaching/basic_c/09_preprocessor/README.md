# Topic 09 - The C Preprocessor
**Suggested session:** 75 min | **Prerequisite topics:** 01 Introduction, 02 Compilation Process, 04 Expressions and Operators

Students leave knowing that the preprocessor is a text-rewriting step that runs before the compiler, and they can use it safely: parenthesised macros, board and debug configuration with `#if`, name generation with `#` and `##`, X-macro tables, and compile-time checks. The examples go from a single constant, through function-like macros and build configurations, to code generation, then to the real-world pattern of an RTOS config header, and finally to target detection on Linux.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_object_like_macros.c` | MCU | `#define` constants, parentheses, `U`/`UL` suffixes, seeing the expansion with `#`, timer prescaler maths |
| 02 | `ex02_function_like_macros.c` | MCU | `BIT/SET_BIT/CLEAR_BIT/READ_BIT`, `ARRAY_SIZE`, `MIN/MAX`, `do { } while (0)`, side-effect trap (`DEMO_BUG`) |
| 03 | `ex03_conditional_boards.c` | MCU | `#if/#elif/#else/#error`, one source for three boards, active-low LED, `DEBUG` logging that disappears in release |
| 04 | `ex04_stringify_token_paste.c` | MCU | `#` and `##`, two-level `STR()`, generating `led_on()/led_off()` and `RCC_AHB1ENR_GPIOxEN` names |
| 05 | `ex05_xmacro_tables.c` | MCU | X-macros: one list makes the enum, the text table and the pin map; `_Static_assert` |
| 06 | `ex06_rtos_config_macros.c` | RTOS | `FreeRTOSConfig.h` style `config...` macros, `#ifndef` defaults, `pdMS_TO_TICKS`, priorities by name |
| 07 | `ex07_predefined_macros_linux.c` | LINUX | `__FILE__/__LINE__/__func__` logging, `__linux__`/`__x86_64__` detection, `_GNU_SOURCE` feature macro |

## Teaching notes
* A macro is TEXT. Ask: "what does `SQUARE(2 + 1)` become if the parameter is not parenthesised?" Then show ex01/ex02 with `-DDEMO_BUG`.
* `MIN(a++, b)`: arguments can be pasted twice. Contrast with `static inline` functions in topic 10 ex03.
* Dropped `#if` code is NOT in the binary at all, so it cannot be compiled or tested. Mention the risk of rarely built configurations.
* `#` does not expand its argument; that is why `STR(x)` needs two levels (ex04 prints both results side by side).
* X-macros look strange at first; walk through ex05 with `gcc -E` so students see the three generated tables.
* Prefer `const`, `enum` and `static inline` when they can do the job; keep macros for conditional compilation, token pasting and stringification.

## Live-demo tips
* Always show the preprocessor output: `gcc -E -P -I../../common ex04_stringify_token_paste.c | tail -40` (`-P` hides the line markers; `-I` is needed for `hw_sim.h`).
* Flip the switches on the command line: `gcc -DBOARD_DISCO -DDEBUG ex03_conditional_boards.c -I../../common`.
* List everything the compiler predefines: `gcc -dM -E - < /dev/null | sort | less` (ex07 uses a few of them).
