/*
 * ============================================================================
 *  Topic   : 09 The C Preprocessor
 *  Example : 01 - Object-like macros: timer settings computed at compile time
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : "#define NAME text" is pure TEXT replacement done BEFORE the compiler
 *            runs. A macro has no type, no memory and ignores C block scope (it
 *            lasts until #undef or end of file). So wrap every expression in
 *            parentheses and give integer constants a suffix (U/UL).
 *  Embedded use : clock speeds, pin numbers, buffer sizes and timeouts live in
 *            macros so a board change is a one-line edit. The compiler folds the
 *            arithmetic into one constant: zero flash, zero CPU cycles.
 *  Real STM32F4 : TIM2->PSC = (SYSCLK_HZ / TICK_HZ) - 1U;   TIM2->ARR = 19999U;
 *            See the expanded text yourself:  gcc -E ex01_object_like_macros.c
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_object_like_macros.c -o ex01
 *  Output  : the timer register values, the text each macro expands to, and the
 *            result of a macro that was written WITH and WITHOUT parentheses
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change SYSCLK_HZ to 84000000UL. Predict PSC before you run.
 *            2) Compile with -DDEMO_BUG and see what the unparenthesised macro does.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

/* Two-level stringify: STR(x) first expands x, then turns the result into text. */
#define STR_(x) #x
#define STR(x)  STR_(x)

/* ---- configuration constants (the "UL" keeps the maths in 32/64 bit) ------- */
#define SYSCLK_HZ   16000000UL                        /* HSI oscillator            */
#define TICK_HZ     1000000UL                         /* we want a 1 MHz timer tick */
#define PERIOD_MS   20UL                              /* servo PWM frame           */

#define PRESCALER   ((SYSCLK_HZ / TICK_HZ) - 1UL)     /* parentheses: safe anywhere */
#define AUTO_RELOAD ((PERIOD_MS * 1000UL) - 1UL)      /* 20 ms at 1 us per tick     */

/* GOOD: whole expression parenthesised.  BAD: the same idea, but no parentheses. */
#define TICKS_PER_MS      (TICK_HZ / 1000UL)
#define BAD_TICKS_PER_MS  TICK_HZ / 1000UL

/* Fake timer registers (a real chip has TIM2->PSC and TIM2->ARR at fixed addresses). */
static volatile uint32_t TIM2_PSC;
static volatile uint32_t TIM2_ARR;

int main(void)
{
    TIM2_PSC = (uint32_t)PRESCALER;
    TIM2_ARR = (uint32_t)AUTO_RELOAD;

    printf("TIM2_PSC = %lu   TIM2_ARR = %lu\n", (unsigned long)TIM2_PSC, (unsigned long)TIM2_ARR);

    /* Check the maths the way the hardware does: tick = SYSCLK / (PSC + 1). */
    uint64_t frame_us = ((uint64_t)(TIM2_PSC + 1U) * (TIM2_ARR + 1U) * 1000000ULL) / SYSCLK_HZ;
    printf("PWM frame = %llu us (wanted %lu ms)\n", (unsigned long long)frame_us, PERIOD_MS);

    /* The preprocessor only pastes text. STR() shows exactly what it pasted. */
    printf("\nWhat the compiler really sees:\n");
    printf("  PRESCALER        -> %s\n", STR(PRESCALER));
    printf("  AUTO_RELOAD      -> %s\n", STR(AUTO_RELOAD));
    printf("  TICKS_PER_MS     -> %s\n", STR(TICKS_PER_MS));
    printf("  BAD_TICKS_PER_MS -> %s   <-- no parentheses!\n", STR(BAD_TICKS_PER_MS));

    /* Convert 20000 elapsed ticks to milliseconds: the answer must be 20. */
    unsigned long elapsed_ticks = 20000UL;
    printf("\nelapsed_ticks / TICKS_PER_MS     = %lu ms (correct)\n", elapsed_ticks / TICKS_PER_MS);

#ifdef DEMO_BUG
    /* Expands to  20000UL / 1000000UL / 1000UL  -> two integer divisions -> 0 ms. */
    printf("elapsed_ticks / BAD_TICKS_PER_MS = %lu ms (WRONG)\n", elapsed_ticks / BAD_TICKS_PER_MS);
#else
    /* Same text written by hand: left-to-right evaluation divides TWICE. */
    unsigned long wrong = 20000UL / 1000000UL / 1000UL;
    printf("20000UL / 1000000UL / 1000UL     = %lu ms (what BAD_TICKS_PER_MS would give)\n", wrong);
#endif

    /* Macros are not objects: they have no address and no type of their own.
     * The literal's type is unsigned long: 8 bytes on 64-bit Linux, 4 on a Cortex-M. */
    printf("\nsizeof(SYSCLK_HZ) = %zu bytes (it is just the literal 16000000UL)\n",
           sizeof(SYSCLK_HZ));
    return 0;
}
