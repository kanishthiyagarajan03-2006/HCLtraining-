/*
 * ============================================================================
 *  Topic   : 09 The C Preprocessor
 *  Example : 04 - Stringify (#) and token pasting (##) to generate code
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : #arg   turns a macro argument into a string literal: #GPIOA->ODR
 *            a##b   glues two tokens into one identifier:  GPIO ## A  ->  GPIOA
 *            Combined, one macro line can write many near-identical functions.
 *  Embedded use : register dump helpers that print their own name, and macros that
 *            build names like RCC_AHB1ENR_GPIOAEN or led_on()/led_off() per pin.
 *  Real STM32F4 : RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;  (the macro below builds that
 *            name from the single letter A)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_stringify_token_paste.c -o ex04
 *  Output  : register dumps labelled with their source text, then LED/buzzer pins
 *            driven by functions that the preprocessor generated
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add DEFINE_PIN(heater, C, 2) and call heater_on() from main.
 *            2) Run  gcc -E -P -I../../common ex04_stringify_token_paste.c | tail -30  to
 *               read the generated code.
 * ============================================================================
 */
#include "hw_sim.h"

#define STR_(x) #x
#define STR(x)  STR_(x)        /* extra level so that macro arguments are expanded first */

/* ---- '#': the register name is printed exactly as it was typed ------------ */
#define SHOW_REG(reg)  printf("%-14s = 0x%04X\n", #reg, (unsigned)((reg) & 0xFFFFu))

/* ---- '##': build identifiers out of pieces ---------------------------------- */
#define CLOCK_ENABLE(x)  (RCC->AHB1ENR |= RCC_AHB1ENR_GPIO##x##EN)   /* GPIO A EN */
#define PIN_OUTPUT(port, pin) \
    (GPIO##port->MODER = (GPIO##port->MODER & ~(3U << ((pin) * 2U))) | (1U << ((pin) * 2U)))

/* One line generates three functions and a label for a pin. The 'unused' attribute
 * means no warning if a generated function is never called (clang is stricter than gcc). */
#define UNUSED_OK __attribute__((unused))
#define DEFINE_PIN(name, port, pin)                                                           \
    static inline UNUSED_OK void name##_on(void)  { GPIO##port->ODR |=  (1U << (pin)); }      \
    static inline UNUSED_OK void name##_off(void) { GPIO##port->ODR &= ~(1U << (pin)); }      \
    static inline UNUSED_OK void name##_toggle(void) { GPIO##port->ODR ^= (1U << (pin)); }    \
    static const char name##_label[] = #name " on P" #port #pin

DEFINE_PIN(led_green, A, 5);        /* -> led_green_on(), led_green_off(), ... */
DEFINE_PIN(buzzer,    B, 0);
DEFINE_PIN(relay,     B, 3);

#define SAMPLE_PIN 7                /* a macro used to show why STR() has two levels */

int main(void)
{
    CLOCK_ENABLE(A);                /* RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN */
    CLOCK_ENABLE(B);
    PIN_OUTPUT(A, 5);
    PIN_OUTPUT(B, 0);
    PIN_OUTPUT(B, 3);

    printf("--- '#' stringify: the dump prints the code that produced it ---\n");
    SHOW_REG(RCC->AHB1ENR);
    SHOW_REG(GPIOA->MODER);
    SHOW_REG(GPIOB->MODER);

    printf("\n--- why two levels? ---\n");
    printf("STR_(SAMPLE_PIN) = \"%s\"   (argument NOT expanded)\n", STR_(SAMPLE_PIN));
    printf("STR(SAMPLE_PIN)  = \"%s\"            (expanded first, then stringified)\n",
           STR(SAMPLE_PIN));

    printf("\n--- '##' generated functions ---\n");
    printf("labels: \"%s\", \"%s\", \"%s\"\n", led_green_label, buzzer_label, relay_label);

    led_green_on();
    buzzer_on();
    relay_on();
    sim_show_port("GPIOA", GPIOA);
    sim_show_port("GPIOB", GPIOB);

    led_green_toggle();
    buzzer_off();
    sim_show_port("GPIOA", GPIOA);
    sim_show_port("GPIOB", GPIOB);
    return 0;
}
