/*
 * ============================================================================
 *  Topic   : 04 C Expressions and Operators
 *  Example : 10 - Linux file permission bits: st_mode tested, set, cleared and toggled
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : st_mode is a bit-field. Each permission is ONE bit with a named mask:
 *            S_IRUSR (0400) S_IWUSR (0200) S_IXUSR (0100); the group bits are the owner bits
 *            shifted right by 3 and the "other" bits by 6. Test with &, set with |, clear with
 *            & ~, toggle with ^, and take one rwx triplet apart with (mode >> 6) & 7.
 *  Embedded use : embedded Linux boards guard /dev nodes, /sys/class/gpio files and config
 *            files with exactly these bits (a udev rule or chmod makes a GPIO writable by a
 *            non-root service). The same flag-word pattern as a GPIO register.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex10_file_permission_bits.c -o ex10
 *  Output  : a temp file starts at rw-r----- (0640); each step prints st_mode in octal and as
 *            rwx letters after chmod  u+x, g+w, u-w, o+r, o-r toggled twice, a-w
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a step that removes ALL group and other bits with one mask and one &.
 *            2) After "ls -l"-style output, run  stat -c '%a %A' <file>  in a shell and compare.
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define HAS(mode, flag)  (((mode) & (flag)) != 0)       /* 0/1 answer for one or more bits */
#define PERM_BITS        07777                          /* low 12 bits: rwx x3 + suid/sgid/sticky */

/* Build an "ls -l" style string such as -rw-r----- by testing nine masks. */
static void mode_string(mode_t m, char *out, size_t n)
{
    static const struct { mode_t mask; char ch; } bits[9] = {
        { S_IRUSR, 'r' }, { S_IWUSR, 'w' }, { S_IXUSR, 'x' },
        { S_IRGRP, 'r' }, { S_IWGRP, 'w' }, { S_IXGRP, 'x' },
        { S_IROTH, 'r' }, { S_IWOTH, 'w' }, { S_IXOTH, 'x' } };
    if (n < 11U) return;
    out[0] = S_ISREG(m) ? '-' : (S_ISDIR(m) ? 'd' : '?');
    for (unsigned i = 0U; i < 9U; i++)
        out[1U + i] = HAS(m, bits[i].mask) ? bits[i].ch : '-';
    out[10] = '\0';
}

static mode_t current_mode(const char *path)            /* 0 means "stat failed" */
{
    struct stat st;
    if (stat(path, &st) != 0) { perror("stat"); return 0; }
    return st.st_mode;
}

/* chmod to new_mode, read it back from the kernel, print it. Returns the mode now in force. */
static mode_t apply(const char *path, const char *label, mode_t new_mode)
{
    char text[16];
    if (chmod(path, new_mode & PERM_BITS) != 0) { perror("chmod"); return 0; }
    mode_t m = current_mode(path);
    mode_string(m, text, sizeof text);
    printf("%-27s st_mode = 0%o  perms = %04o  %s\n", label, (unsigned)m,
           (unsigned)(m & PERM_BITS), text);
    return m;
}

int main(void)
{
    char dir[] = "/tmp/ex10_XXXXXX";
    if (mkdtemp(dir) == NULL) { perror("mkdtemp"); return 1; }
    char path[64];
    snprintf(path, sizeof path, "%s/config.cfg", dir);

    int fd = open(path, O_CREAT | O_WRONLY | O_TRUNC, 0600);
    if (fd < 0) { perror("open"); rmdir(dir); return 1; }
    const char text[] = "baud=115200\n";
    ssize_t written = write(fd, text, sizeof text - 1U);
    close(fd);

    int failures = (written == (ssize_t)(sizeof text - 1U)) ? 0 : 1;
    mode_t m = apply(path, "start: chmod 0640", 0640);
    if (m == 0) failures++;

    puts("\n--- Taking st_mode apart with masks and shifts ---");
    printf("file type bits   : st_mode & S_IFMT = 0%o  (S_IFREG = 0%o, S_ISREG = %d)\n",
           (unsigned)(m & S_IFMT), (unsigned)S_IFREG, S_ISREG(m) ? 1 : 0);
    printf("owner triplet    : (mode >> 6) & 7 = %u  (4=r 2=w 1=x)\n", (unsigned)((m >> 6) & 7U));
    printf("group triplet    : (mode >> 3) & 7 = %u\n", (unsigned)((m >> 3) & 7U));
    printf("other triplet    :  mode       & 7 = %u\n", (unsigned)(m & 7U));
    printf("S_IRUSR >> 3 == S_IRGRP : %s,  S_IRGRP >> 3 == S_IROTH : %s\n",
           ((S_IRUSR >> 3) == S_IRGRP) ? "yes" : "no", ((S_IRGRP >> 3) == S_IROTH) ? "yes" : "no");
    printf("owner can read/write/execute: %d/%d/%d   others can read: %d\n",
           HAS(m, S_IRUSR), HAS(m, S_IWUSR), HAS(m, S_IXUSR), HAS(m, S_IROTH));
    printf("whole-class test : (mode & S_IRWXG) == S_IRGRP  -> group has ONLY read: %s\n\n",
           ((m & S_IRWXG) == S_IRGRP) ? "yes" : "no");

    puts("--- Set, clear and toggle (the GPIO idioms again) ---");
    m = apply(path, "SET    u+x   | S_IXUSR", m | S_IXUSR);
    m = apply(path, "SET    g+w   | S_IWGRP", m | S_IWGRP);
    m = apply(path, "CLEAR  u-w   & ~S_IWUSR", m & ~(mode_t)S_IWUSR);
    m = apply(path, "SET    o+r   | S_IROTH", m | S_IROTH);
    m = apply(path, "TOGGLE o-r   ^ S_IROTH", m ^ S_IROTH);
    m = apply(path, "TOGGLE o-r   ^ S_IROTH", m ^ S_IROTH);
    m = apply(path, "CLEAR  a-w   & ~(3 masks)", m & ~(mode_t)(S_IWUSR | S_IWGRP | S_IWOTH));
    if (m == 0 || HAS(m, S_IWUSR | S_IWGRP | S_IWOTH) || !HAS(m, S_IXUSR)) failures++;

    puts("\numask is just a CLEAR mask: new file mode = requested & ~umask");
    printf("  0666 & ~022 = 0%o   (the familiar 0644)\n", (unsigned)(0666 & ~022));

    unlink(path);                                       /* always clean up what we create */
    rmdir(dir);
    return failures;
}
