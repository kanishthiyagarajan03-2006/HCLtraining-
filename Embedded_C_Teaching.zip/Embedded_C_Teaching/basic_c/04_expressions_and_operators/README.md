# Topic 04 - C Expressions and Operators
**Suggested session:** 120 min (two 60-min parts: ex01-ex06 bit operators, ex07-ex10 the rest) | **Prerequisite topics:** 01, 03

The headline skill is controlling digital I/O with the shift operators: build a mask with `1U << n`, then
set with `|`, clear with `& ~`, toggle with `^`, test with `& mask` or `>> n & 1`, write fields with
clear-then-OR, and use `BSRR` for atomic updates. After the pin examples (ex01-ex05), ex06 packs and unpacks
data with the same shifts, ex07 shows the precedence traps that break all of this, ex08 covers arithmetic,
relational, logical, ternary, `++/--` and compound operators in a thermostat, and ex09/ex10 apply the bit idioms
to RTOS event flags and Linux file permissions. All the register examples use the simulated STM32F4 port from
`common/hw_sim.h`; the real register line is always in the header comment.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_set_clear_toggle_pin.c` | MCU | `\|=`, `&= ~`, `^=` with `(1U << n)` on ONE pin (PA5 LED) |
| 02 | `ex02_multi_pin_masks_macros.c` | MCU | Masks for several pins, `BIT/SET_BIT/CLEAR_BIT/TOGGLE_BIT` macros, `\|` vs `+`, untouched bystander pin |
| 03 | `ex03_read_pin_and_flags.c` | MCU | `(IDR >> n) & 1U`, `!!`, why `(IDR & mask) == 1` fails, any/all tests, press edge via `now ^ prev` |
| 04 | `ex04_write_bit_fields.c` | MCU | Multi-bit fields: `MODER` 2-bit, `AFR` 4-bit (`pin >> 3`, `pin & 7`), `MODIFY_REG`, generic `FIELD_MASK/SET_FIELD` |
| 05 | `ex05_bsrr_atomic_set_reset.c` | MCU | Traced lost-update race with `\|=` vs one `BSRR` store; `1U << (n + 16)`; writing a 4-bit value in one store |
| 06 | `ex06_pack_unpack_fields.c` | MCU | 12-bit ADC in a 16-bit frame, RGB565, signed 24-bit big-endian, byte swap; cast before `<< 24` |
| 07 | `ex07_precedence_and_pitfalls.c` | MCU | `a & b == c`, `&` vs `&&`, `1 << n - 1`, `~` and promotion, shift rules; DEMO_BUG shows the gcc warnings |
| 08 | `ex08_sensor_scaling_operators.c` | MCU | Integer maths order, rounding, hysteresis with `< > && \|\|`, `?:`, `++/--`, compound assignment, `>> 2` as divide by 4 |
| 09 | `ex09_rtos_event_flags.c` | RTOS | Event-group bitmasks: set, clear, wait-ANY vs wait-ALL (`xEventGroupWaitBits`), timeout reporting |
| 10 | `ex10_file_permission_bits.c` | LINUX | `st_mode` as a bit-field: `S_IRUSR`..., `>> 3` between classes, `chmod` set/clear/toggle, umask as a clear mask |

## Bit-twiddling cheat sheet (put it on the board)
| Goal | Idiom | Real STM32F4 line |
|------|-------|-------------------|
| Mask for pin n | `(1U << n)` | `(1U << 5)` |
| Set pin | `reg \|= (1U << n)` | `GPIOA->ODR \|= (1U << 5);` |
| Clear pin | `reg &= ~(1U << n)` | `GPIOA->ODR &= ~(1U << 5);` |
| Toggle pin | `reg ^= (1U << n)` | `GPIOA->ODR ^= (1U << 5);` |
| Test pin (0 or mask) | `reg & (1U << n)` | `if (GPIOC->IDR & (1U << 13))` |
| Read pin as 0/1 | `(reg >> n) & 1U` | `(GPIOC->IDR >> 13) & 1U` |
| Write a field | `reg = (reg & ~(M << s)) \| (v << s)` | `MODIFY_REG(GPIOA->MODER, 3U << 10, 1U << 10)` |
| Atomic set / reset | `BSRR = (1U << n)` / `(1U << (n + 16))` | `GPIOA->BSRR = (1U << (5 + 16));` |
| Extract a field | `(reg >> s) & M` | `(frame >> 12) & 0xF` |

## Teaching notes
* Always write `1U`, never `1`: shifting a signed `1` into bit 31 is undefined behaviour (ex07).
* Say it aloud: "OR sets, AND-NOT clears, XOR toggles". Ask why clear needs `~` and what `~` does to a `uint8_t` (ex07).
* `|=` is read-modify-write. It is fine in `main` only; if an ISR touches the same port, switch to `BSRR` (ex05).
* A pin number is not a mask: `SET_BIT(reg, 5)` is wrong, `SET_BIT(reg, BIT(5))` is right (ex02).
* Precedence: `&`, `^`, `|` rank below `==`. Write the brackets, every time (ex03 and ex07).
* Ask the class: why can `b[0] << 24` (a `uint8_t`) be undefined while `(uint32_t)b[0] << 24` is fine? (ex06).

## Live-demo tips
* Compile ex05 and step through section 1 in the VS Code debugger to watch `tmp` get overwritten.
* `gcc -DDEMO_BUG ex07_precedence_and_pitfalls.c` (without `-Werror`) lists the gcc warnings that catch the traps.
* `gcc -DDEMO_BUG -fsanitize=undefined ex06_pack_unpack_fields.c` shows the UBSan shift report on a real bug.
* In ex10 open a second terminal and run `stat -c '%a %A' <file>` while the program is paused in a debugger.
