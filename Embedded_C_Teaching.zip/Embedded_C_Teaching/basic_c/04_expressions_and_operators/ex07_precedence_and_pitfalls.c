/*
 * ============================================================================
 *  Topic   : 04 C Expressions and Operators
 *  Example : 07 - Precedence traps and shift pitfalls, shown safely
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Precedence, high to low:  ~ !   * / %   + -   << >>   < <= > >=   == !=   &   ^   |
 *            &&   ||   ?:   = op=
 *            The bit operators & ^ | rank BELOW == and !=, and + - rank ABOVE << >>. So
 *            "flags & MASK == MASK" is "flags & (MASK == MASK)". When in doubt, parenthesise.
 *            Shifts: a count >= the type width, a left shift of a negative value, or a 1 shifted
 *            into the sign bit of a signed int are undefined; use unsigned and guard the count.
 *  Embedded use : these slips compile silently and give "random" flag tests on real hardware.
 *            MISRA-C and code-review checklists demand brackets around bitwise sub-expressions.
 *  Real STM32F4 : if ((USART2->SR & USART_SR_TXE) == USART_SR_TXE) { ... }   // brackets matter!
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_precedence_and_pitfalls.c -o ex07
 *  Output  : each trap printed twice: how C really groups it vs what you meant (with values)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -DDEMO_BUG (no -Werror) and count the gcc warnings it gives.
 *            2) Predict  0x0F & 0x30 == 0  before running it with explicit brackets added.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

/* Print the source text of an expression next to its value (# stringifies the argument). */
#define SHOW(expr)   printf("    %-34s -> %u (0x%X)\n", #expr, (unsigned)(expr), (unsigned)(expr))
#define SHOW_S(expr) printf("    %-34s -> %d\n", #expr, (int)(expr))

/* Compares exactly what C promoted the operands to (a helper keeps gcc quiet, see DEMO_BUG). */
static int equal_int(int a, int b) { return a == b; }

/* A shift count >= 32 is undefined for a 32-bit type: guard variable counts. */
static uint32_t safe_shl(uint32_t x, unsigned n) { return (n < 32U) ? (x << n) : 0U; }

int main(void)
{
    uint32_t mask = 0x06U, want = 0x06U;

    puts("1) & ^ | rank BELOW == !=   (all bits of mask must be set; mask = want = 0x06)");
    const uint32_t cases[] = { 0x06U, 0x01U };
    for (unsigned i = 0; i < 2U; i++) {
        uint32_t flags = cases[i];
        printf("  flags = 0x%02X\n", (unsigned)flags);
        SHOW(flags & (mask == want));            /* what 'flags & mask == want' really is  */
        SHOW((flags & mask) == want);            /* what you meant                         */
    }
    puts("    -> the buggy form says 'not all set' for 0x06 and 'all set' for 0x01: backwards!\n");

    puts("2) & and | are bit operators, && and || are logical (they answer only 0 or 1)");
    uint32_t status = 0x02U, ready = 0x04U;      /* READY bit is NOT set in status */
    SHOW(status & ready);
    SHOW(status && ready);                       /* both non-zero -> 1: always 'true' here */
    SHOW(status | 0x80U);
    SHOW(status || 0x80U);
    puts("");

    puts("3) + - bind tighter than << >>, and << >> bind tighter than &");
    unsigned n = 4U;
    SHOW(1U << (n - 1U));                        /* how '1U << n - 1U' is parsed           */
    SHOW((1U << n) - 1U);                        /* the width-4 field mask you meant       */
    uint32_t byte = 0xABU, hi_nibble = 0xF0U;
    SHOW(byte & (hi_nibble >> 4));               /* how 'byte & hi_nibble >> 4' is parsed  */
    SHOW((byte & hi_nibble) >> 4);               /* the upper nibble, as intended          */
    puts("");

    puts("4) ~ works on the promoted value: a uint8_t becomes a 32-bit int first");
    uint8_t m = 0x0FU;
    SHOW(~m);                                    /* 0xFFFFFFF0, not 0xF0                   */
    SHOW(equal_int(~m, 0xF0));                   /* false! (writing ~m == 0xF0 even makes  */
    SHOW(equal_int((uint8_t)~m, 0xF0));          /* gcc warn). Cast back to 8 bits first.  */
    puts("");

    puts("5) Shift rules");
    SHOW(1U << 31);                              /* fine: unsigned */
    puts("    1 << 31 (signed int) is undefined in ISO C: write 1U << 31");
    for (unsigned c = 0; c < 4U; c++) {
        static const unsigned counts[] = { 0U, 5U, 31U, 32U };
        printf("    safe_shl(1, %2u) = 0x%08X%s\n", counts[c], (unsigned)safe_shl(1U, counts[c]),
               counts[c] >= 32U ? "   (1U << 32 itself would be undefined)" : "");
    }
    int32_t neg = -64;
    SHOW_S(neg >> 2);                            /* implementation-defined; gcc/ARM: arithmetic */
    SHOW(0x80000000U >> 4);                      /* unsigned >> always shifts in zeros          */
    puts("    (-64 << 1 would be undefined; do bit work on unsigned types only)");

#ifdef DEMO_BUG
    /* The same mistakes written the way people actually type them. They COMPILE, so only the
     * warnings (-Wall -Wextra) save you: "suggest parentheses around comparison in operand
     * of '&'", "suggest parentheses around '-' inside '<<'", "assignment used as truth value",
     * and for ~m == 0xF0 "comparison of promoted bitwise complement ... [-Wsign-compare]". */
    uint32_t state = 0U;
    if (cases[1] & mask == want) puts("DEMO_BUG: 0x01 'contains' 0x06");
    printf("DEMO_BUG: mask = 0x%X, field = 0x%X\n", (unsigned)(1U << n - 1U),
           (unsigned)(byte & hi_nibble >> 4));
    if (state = 3U) puts("DEMO_BUG: assignment inside if - always true");
    if (~m == 0xF0U) puts("DEMO_BUG: never printed, ~m is 0xFFFFFFF0");
#endif
    return 0;
}
