/*
 * ============================================================================
 *  Topic   : 04 C Expressions and Operators
 *  Example : 03 - Reading a pin or flag: (IDR >> n) & 1, !!, any/all tests, press edges
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : To TEST a bit, AND the register with a mask. The result is 0 or "the mask",
 *            NOT 0 or 1. Shift the bit down first ((reg >> n) & 1U) or normalise with
 *            (reg & mask) != 0 / !!(reg & mask) when you need a clean 0/1.
 *            XOR of two snapshots (now ^ prev) shows WHICH bits changed.
 *  Embedded use : reading buttons, limit switches and status flags (RXNE, TXE, BUSY).
 *            A button press is an EVENT: react to the edge, not to the level.
 *  Real STM32F4 : if (GPIOC->IDR & (1U << 13)) { ... }   // B1 on PC13: reads 1 when pressed on
 *            Nucleo-144 boards (on Nucleo-64 boards B1 is active-low: pressed reads 0)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_read_pin_and_flags.c -o ex03
 *  Output  : one button read four ways, an any/all switch test, then LD1 toggling once per press
 * ----------------------------------------------------------------------------
 *  Try it  : 1) In part 1 change the test to (idr & BTN_USER) == 1 - why does it never fire?
 *            2) Add a long press (more 1s in press_script). Does LD1 still toggle only once?
 * ============================================================================
 */
#include "hw_sim.h"

#define BIT(n)            (1U << (n))
#define READ_BIT(reg, m)  ((reg) & (m))             /* 0, or the mask itself (CMSIS style) */

#define BTN_USER   BIT(13)      /* PC13: B1 (Nucleo-144), reads 1 while pressed         */
#define LD1_PIN    0U           /* PB0 : green LED                                      */
#define SW_DOOR    BIT(2)       /* three limit switches wired to PD2..PD4               */
#define SW_LID     BIT(3)
#define SW_GUARD   BIT(4)
#define SW_ALL     (SW_DOOR | SW_LID | SW_GUARD)

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN | RCC_AHB1ENR_GPIOCEN | RCC_AHB1ENR_GPIODEN;
    GPIOB->MODER |= (1U << (LD1_PIN * 2U));          /* PB0 = output; PC13/PD2..4 stay inputs */

    puts("--- Part 1: four ways to read ONE bit (button on PC13) ---");
    for (int pressed = 0; pressed <= 1; pressed++) {
        if (pressed) sim_press(GPIOC, 13u); else sim_release(GPIOC, 13u);
        uint32_t idr = GPIOC->IDR;
        printf("button %-8s  IDR & mask = %5u   (IDR >> 13) & 1U = %u   (IDR & mask) != 0 = %d"
               "   !!(IDR & mask) = %d\n",
               pressed ? "pressed" : "released", (unsigned)READ_BIT(idr, BTN_USER),
               (unsigned)((idr >> 13) & 1U), (idr & BTN_USER) != 0U, !!(idr & BTN_USER));
    }
    puts("Note: 'IDR & mask' is 8192 (= 1 << 13), so  (IDR & mask) == 1  can NEVER be true.\n");

    puts("--- Part 2: testing several bits: ANY vs ALL ---");
    const uint32_t samples[] = { 0u, SW_LID, SW_DOOR | SW_GUARD, SW_ALL };
    for (unsigned i = 0; i < sizeof samples / sizeof samples[0]; i++) {
        GPIOD->IDR = samples[i];
        uint32_t in = GPIOD->IDR & SW_ALL;           /* mask off pins we do not care about */
        printf("PD4..PD2 = ");
        sim_print_bits(in >> 2, 3u);                 /* shift down so the 3 switches read 0..7 */
        printf("   any closed: %-3s   all closed: %-3s\n",
               (in != 0U) ? "yes" : "no", (in == SW_ALL) ? "yes" : "no");
    }

    puts("\n--- Part 3: react to the press EDGE with XOR, not the level ---");
    const uint8_t press_script[] = { 0, 0, 1, 1, 1, 0, 0, 1, 0 };   /* one sample per 10 ms */
    uint32_t prev = 0U;
    unsigned presses = 0U;
    for (unsigned i = 0; i < sizeof press_script; i++) {
        if (press_script[i]) sim_press(GPIOC, 13u); else sim_release(GPIOC, 13u);
        uint32_t now     = GPIOC->IDR;
        uint32_t changed = now ^ prev;               /* 1 = this bit differs from last sample */
        uint32_t rising  = changed & now;            /* changed AND now high = just pressed   */
        if (rising & BTN_USER) {
            GPIOB->ODR ^= BIT(LD1_PIN);              /* toggle LD1 once per press */
            presses++;
        }
        sim_delay_ms(10);
        printf("[%3u ms] button=%u changed=%u rising=%u  LD1=%s\n", (unsigned)sim_millis(),
               (unsigned)((now >> 13) & 1U), (unsigned)((changed >> 13) & 1U),
               (unsigned)((rising >> 13) & 1U), (GPIOB->ODR & BIT(LD1_PIN)) ? "ON " : "off");
        prev = now;
    }
    printf("presses counted: %u (expected 2)\n", presses);
    return (presses == 2U) ? 0 : 1;
}
