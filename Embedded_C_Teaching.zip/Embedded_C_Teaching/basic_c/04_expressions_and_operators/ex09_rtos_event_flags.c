/*
 * ============================================================================
 *  Topic   : 04 C Expressions and Operators
 *  Example : 09 - RTOS event-flag group: wait-ANY vs wait-ALL with bitmasks
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : One 32-bit word holds many independent flags, one bit each, built with (1U << n).
 *            SET   = group |= bits         CLEAR = group &= ~bits
 *            ANY   = (group & want) != 0   ALL   = (group & want) == want
 *            The same four operators as GPIO pins, now used for task synchronisation.
 *  Embedded use : FreeRTOS xEventGroupSetBits() / xEventGroupWaitBits(group, want, clearOnExit,
 *            waitForAllBits, ticks): a boot task waits until ADC, sensor AND WiFi are ready; a UI
 *            task wakes on ANY input event. (Real kernels block the waiting task; this teaching
 *            version polls every 10 ms. FreeRTOS keeps only 24 usable bits per group.)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex09_rtos_event_flags.c -o ex09
 *  Output  : timestamped log: "ui" wakes on BTN / UART_RX / both together; "boot" first times out
 *            (WIFI_UP missing) and then sees all three ready bits at 400 ms
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Make "boot" use clear_on_exit = 1. Is EV_READY still set afterwards?
 *            2) Make "ui" wait for ALL of EV_BTN | EV_UART_RX. When does it wake now?
 * ============================================================================
 */
#include "mini_rtos.h"

typedef uint32_t EventBits_t;

#define EV_ADC_DONE  (1U << 0)
#define EV_TEMP_OK   (1U << 1)
#define EV_WIFI_UP   (1U << 2)
#define EV_BTN       (1U << 3)
#define EV_UART_RX   (1U << 4)
#define EV_READY     (EV_ADC_DONE | EV_TEMP_OK | EV_WIFI_UP)    /* boot needs all three */
#define EV_INPUT     (EV_BTN | EV_UART_RX)                      /* ui needs any of these */

static volatile EventBits_t group;          /* the event group: shared by all tasks */

static const char *bits_str(EventBits_t b, char *buf, size_t n)
{
    static const struct { EventBits_t bit; const char *name; } names[] = {
        { EV_ADC_DONE, "ADC_DONE" }, { EV_TEMP_OK, "TEMP_OK" }, { EV_WIFI_UP, "WIFI_UP" },
        { EV_BTN, "BTN" }, { EV_UART_RX, "UART_RX" } };
    size_t used = 0U;
    snprintf(buf, n, "(none)");
    for (size_t i = 0U; i < sizeof names / sizeof names[0]; i++) {
        if ((b & names[i].bit) && used + 2U < n) {
            int w = snprintf(buf + used, n - used, "%s%s", used ? "|" : "", names[i].name);
            if (w > 0) used += (size_t)w;
        }
    }
    return buf;
}

static void event_set(EventBits_t bits)     /* xEventGroupSetBits */
{
    char buf[48];
    group |= bits;                          /* SET: OR the mask into the group */
    rtos_log("event_set(%s) -> group = 0x%02X", bits_str(bits, buf, sizeof buf), (unsigned)group);
}

/* xEventGroupWaitBits: returns the group value when the wait ended (test it to see why). */
static EventBits_t event_wait(EventBits_t want, int clear_on_exit, int wait_all,
                              uint32_t timeout_ms)
{
    for (uint32_t waited = 0U;; waited += 10U) {
        EventBits_t now = group;
        int satisfied = wait_all ? ((now & want) == want) : ((now & want) != 0U);
        if (satisfied && clear_on_exit) group &= ~want;
        if (satisfied || waited >= timeout_ms) return now;
        rtos_delay(10);                     /* a real RTOS parks the task here for free */
    }
}

/* ---- producers: in a real system these are ISRs and driver tasks ------------------- */
static void sensor_task(void *arg)
{
    (void)arg;
    rtos_delay(100); rtos_log("ADC conversion finished");  event_set(EV_ADC_DONE);
    rtos_delay(100); rtos_log("temperature in range");     event_set(EV_TEMP_OK);
}
static void network_task(void *arg)
{
    (void)arg;
    rtos_delay(400); rtos_log("WiFi associated");          event_set(EV_WIFI_UP);
}
static void input_task(void *arg)
{
    (void)arg;
    rtos_delay(150); rtos_log("button pressed");           event_set(EV_BTN);
    rtos_delay(170); rtos_log("byte arrived on UART");     event_set(EV_UART_RX);
    rtos_delay(130); rtos_log("button AND UART together"); event_set(EV_INPUT);
}

/* ---- consumers --------------------------------------------------------------------- */
static void ui_task(void *arg)              /* wait ANY, clear the bits we consumed */
{
    (void)arg;
    char buf[48];
    for (int i = 0; i < 3; i++) {
        EventBits_t got = event_wait(EV_INPUT, 1, 0, 500);
        rtos_log("woke on: %s", bits_str(got & EV_INPUT, buf, sizeof buf));
    }
}
static void boot_task(void *arg)            /* wait ALL, keep the bits set */
{
    (void)arg;
    char got_s[48], miss_s[48];
    EventBits_t got = event_wait(EV_READY, 0, 1, 300);
    if ((got & EV_READY) != EV_READY)       /* ALL test failed: timeout. Which bits are missing? */
        rtos_log("TIMEOUT: have %s, missing %s", bits_str(got & EV_READY, got_s, sizeof got_s),
                 bits_str(~got & EV_READY, miss_s, sizeof miss_s));
    got = event_wait(EV_READY, 0, 1, 500);
    if ((got & EV_READY) == EV_READY) rtos_log("OK: %s -> starting application",
                                               bits_str(got & EV_READY, got_s, sizeof got_s));
}

int main(void)
{
    /* Producers get a higher priority so consumers see their events in the same tick. */
    rtos_task_create("sensor",  sensor_task,  NULL, 3, 2048);
    rtos_task_create("network", network_task, NULL, 3, 2048);
    rtos_task_create("input",   input_task,   NULL, 3, 2048);
    rtos_task_create("ui",      ui_task,      NULL, 1, 2048);
    rtos_task_create("boot",    boot_task,    NULL, 1, 2048);
    puts("event bits: ADC_DONE=1<<0  TEMP_OK=1<<1  WIFI_UP=1<<2  BTN=1<<3  UART_RX=1<<4");
    rtos_start(700);
    int ok = ((group & EV_READY) == EV_READY);
    rtos_shutdown();
    return ok ? 0 : 1;
}
