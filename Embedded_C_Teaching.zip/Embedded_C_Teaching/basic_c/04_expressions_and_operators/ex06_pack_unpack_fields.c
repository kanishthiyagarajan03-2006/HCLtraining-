/*
 * ============================================================================
 *  Topic   : 04 C Expressions and Operators
 *  Example : 06 - Packing and unpacking fields with << >> & | (ADC frame, RGB565, big-endian)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : PACK  : (field & MASK) << SHIFT, then OR the fields together.
 *            UNPACK: (word >> SHIFT) & MASK.   Left shift moves a field up, right shift moves
 *            it down to bit 0, the AND throws away everything that is not the field.
 *            A byte must be cast to uint32_t BEFORE it is shifted left by 24 (int promotion!).
 *  Embedded use : SPI/I2C sensor replies, TFT pixels (RGB565), CAN/UART protocol headers and
 *            24-bit load-cell ADCs all arrive as bytes or bit-fields inside a bigger word.
 *  Real STM32F4 : uint16_t adc = (uint16_t)(spi_rx & 0x0FFF);   // 12-bit result in a 16-bit frame
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_pack_unpack_fields.c -o ex06
 *  Output  : an ADC frame round trip, RGB565 colours with their bit groups, a signed 24-bit
 *            load-cell value and a big-endian 32-bit id (plus byte swap)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Pack channel 9 and value 0x1ABC: which bits of 0x1ABC are lost, and why?
 *            2) Build with -DDEMO_BUG -fsanitize=undefined and read the UBSan report.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

/* ---- Part 1: 16-bit SPI ADC frame  [15:12] channel | [11:0] 12-bit sample ------------ */
#define ADC_VALUE_MASK  0x0FFFU
#define ADC_CH_SHIFT    12U
#define ADC_CH_MASK     0x0FU

static uint16_t adc_pack(unsigned ch, unsigned value)
{
    return (uint16_t)(((ch & ADC_CH_MASK) << ADC_CH_SHIFT) | (value & ADC_VALUE_MASK));
}
static unsigned adc_channel(uint16_t f) { return (f >> ADC_CH_SHIFT) & ADC_CH_MASK; }
static unsigned adc_value(uint16_t f)   { return f & ADC_VALUE_MASK; }

/* ---- Part 2: RGB565  RRRRR GGGGGG BBBBB  (5-6-5 bits) --------------------------------- */
static uint16_t rgb565(uint8_t r, uint8_t g, uint8_t b)
{
    return (uint16_t)(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3));   /* drop low bits */
}
/* Expand back to 8 bits; copying the top bits into the gap makes 31 -> 255, not 248. */
static uint8_t red8(uint16_t c)
{
    unsigned v = (c >> 11) & 0x1FU;
    return (uint8_t)((v << 3) | (v >> 2));
}
static uint8_t green8(uint16_t c)
{
    unsigned v = (c >> 5) & 0x3FU;
    return (uint8_t)((v << 2) | (v >> 4));
}
static uint8_t blue8(uint16_t c)
{
    unsigned v = c & 0x1FU;
    return (uint8_t)((v << 3) | (v >> 2));
}

static void print565(uint16_t c)
{
    for (unsigned i = 16U; i > 0U; i--) {
        putchar(((c >> (i - 1U)) & 1U) ? '1' : '0');
        if (i == 12U || i == 6U) putchar(' ');             /* group as 5 | 6 | 5 */
    }
}

int main(void)
{
    puts("--- 1. SPI ADC frame: channel in [15:12], 12-bit value in [11:0] ---");
    const unsigned samples[][2] = { {0, 0x000}, {3, 0x7FF}, {9, 0xABC}, {15, 0xFFF} };
    for (unsigned i = 0; i < sizeof samples / sizeof samples[0]; i++) {
        uint16_t frame = adc_pack(samples[i][0], samples[i][1]);
        printf("ch %2u, value 0x%03X -> frame 0x%04X -> ch %2u, value 0x%03X %s\n",
               samples[i][0], samples[i][1], (unsigned)frame, adc_channel(frame), adc_value(frame),
               (adc_channel(frame) == samples[i][0] && adc_value(frame) == samples[i][1])
                   ? "(round trip OK)" : "(MISMATCH)");
    }

    puts("\n--- 2. RGB565: 24-bit colour squeezed into 16 bits ---");
    puts("colour    R   G   B   RRRRR GGGGGG BBBBB  rgb565   back to 8 bits");
    const struct { const char *name; uint8_t r, g, b; } colours[] = {
        { "red",    255,   0,   0 }, { "green",   0, 255,   0 }, { "blue",    0,   0, 255 },
        { "orange", 255, 165,   0 }, { "teal",    0, 128, 128 }, { "white",  255, 255, 255 },
    };
    for (unsigned i = 0; i < sizeof colours / sizeof colours[0]; i++) {
        uint16_t c = rgb565(colours[i].r, colours[i].g, colours[i].b);
        printf("%-7s %3u %3u %3u   ", colours[i].name, colours[i].r, colours[i].g, colours[i].b);
        print565(c);
        printf("  0x%04X   %3u %3u %3u\n", (unsigned)c, red8(c), green8(c), blue8(c));
    }

    puts("\n--- 3. Signed 24-bit big-endian load-cell reading (HX711 style) ---");
    const uint8_t cells[][3] = { {0x00, 0x00, 0x64}, {0xFF, 0xFF, 0xFE}, {0x7F, 0xFF, 0xFF},
                                 {0x80, 0x00, 0x00} };
    for (unsigned i = 0; i < sizeof cells / sizeof cells[0]; i++) {
        uint32_t raw = ((uint32_t)cells[i][0] << 16) | ((uint32_t)cells[i][1] << 8) | cells[i][2];
        /* Sign-extend 24 -> 32 bit without UB: the top bit is worth -2^23, the rest is positive. */
        int32_t value = (int32_t)(raw & 0x7FFFFFU) - (int32_t)(raw & 0x800000U);
        printf("bytes %02X %02X %02X -> raw 0x%06X -> signed %8d  | back: %02X %02X %02X\n",
               cells[i][0], cells[i][1], cells[i][2], (unsigned)raw, (int)value,
               (unsigned)((raw >> 16) & 0xFFU), (unsigned)((raw >> 8) & 0xFFU),
               (unsigned)(raw & 0xFFU));
    }

    puts("\n--- 4. Big-endian 32-bit id: the cast BEFORE the shift matters ---");
    const uint8_t id_bytes[4] = { 0xDE, 0xAD, 0xBE, 0xEF };   /* first byte on the wire = MSB */
    uint32_t id = ((uint32_t)id_bytes[0] << 24) | ((uint32_t)id_bytes[1] << 16) |
                  ((uint32_t)id_bytes[2] << 8)  |  (uint32_t)id_bytes[3];
    uint32_t swapped = (id >> 24) | ((id >> 8) & 0x0000FF00U) |
                       ((id << 8) & 0x00FF0000U) | (id << 24);
    printf("id = 0x%08X, byte-swapped = 0x%08X\n", (unsigned)id, (unsigned)swapped);
#ifdef DEMO_BUG
    /* BUG: id_bytes[0] is promoted to (signed) int, and 0xDE << 24 does not fit in an int.
     * That is undefined behaviour: UBSan prints "left shift of 222 by 24 places cannot be
     * represented in type 'int'". In practice the value turns NEGATIVE and then sign-extends
     * when widened, so the 64-bit result below is 0xFFFFFFFFDE000000. Write (uint32_t)b << 24. */
    uint64_t bad = id_bytes[0] << 24;
    printf("buggy 64-bit result = 0x%016llX\n", (unsigned long long)bad);
#endif
    return (id == 0xDEADBEEFU && swapped == 0xEFBEADDEU) ? 0 : 1;
}
