/*
 * ============================================================================
 *  Topic   : 04 C Expressions and Operators
 *  Example : 02 - Several pins at once: masks and BIT / SET_BIT / CLEAR_BIT / TOGGLE_BIT
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : OR-ing shifted bits builds a MASK for many pins: (1U << 0) | (1U << 7).
 *            One |=, &= ~ or ^= with that mask changes ALL those pins in a single
 *            read-modify-write and leaves every other pin alone.
 *            Wrapping the idiom in macros makes the code read like English.
 *  Embedded use : a 3-LED bar, a 7-segment digit or a motor driver's enable lines are
 *            groups of bits inside ONE port register. Vendor headers (CMSIS) ship the
 *            very same SET_BIT / CLEAR_BIT macros.
 *  Real STM32F4 : GPIOB->ODR |= (1U << 0) | (1U << 7) | (1U << 14);  // LD1 LD2 LD3 on Nucleo-144
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_multi_pin_masks_macros.c -o ex02
 *  Output  : the 3 LEDs on PB0/PB7/PB14 are set, cleared, toggled in groups; PB3 never changes
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a 4th LED on PB9 to ALL_LEDS - which line of output changes?
 *            2) Replace '|' by '+' when you build LD1_GREEN | LD1_GREEN. Why is '|' safer?
 * ============================================================================
 */
#include "hw_sim.h"

/* The four idioms from ex01, wrapped up. "mask" = bits ALREADY shifted into place. */
#define BIT(n)                (1U << (n))          /* mask with only bit n set      */
#define SET_BIT(reg, mask)    ((reg) |=  (mask))   /* force the masked bits to 1    */
#define CLEAR_BIT(reg, mask)  ((reg) &= ~(mask))   /* force the masked bits to 0    */
#define TOGGLE_BIT(reg, mask) ((reg) ^=  (mask))   /* flip the masked bits          */

/* Nucleo-144 user LEDs, all on GPIOB. Each name is a MASK, not a pin number. */
#define LD1_GREEN  BIT(0)
#define LD2_BLUE   BIT(7)
#define LD3_RED    BIT(14)
#define ALL_LEDS   (LD1_GREEN | LD2_BLUE | LD3_RED)
#define BYSTANDER  BIT(3)                          /* an unrelated pin: must never move */

static void show(const char *what)
{
    printf("[%4u ms] %-26s 0x%04X  ", (unsigned)sim_millis(), what, (unsigned)GPIOB->ODR);
    sim_print_bits(GPIOB->ODR, 16u);
    putchar('\n');
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    /* Mode details come in ex04; for now: 2 bits per pin, 01 = output. */
    GPIOB->MODER |= (1U << (0 * 2)) | (1U << (7 * 2)) | (1U << (14 * 2));

    puts("--- Masks are built by shifting a 1 to the pin number ---");
    for (unsigned n = 0; n < 8u; n++) {
        printf("BIT(%u) = 0x%02X  ", n, BIT(n));
        sim_print_bits(BIT(n), 8u);
        putchar('\n');
    }
    printf("ALL_LEDS      = 0x%04X  ", (unsigned)ALL_LEDS);
    sim_print_bits(ALL_LEDS, 16u);
    printf("   (bits 14, 7, 0)\n");
    printf("~ALL_LEDS     = 0x%04X  ", (unsigned)(~ALL_LEDS & 0xFFFFU));
    sim_print_bits(~ALL_LEDS, 16u);
    printf("   (AND with this clears the LEDs)\n");
    printf("BIT(1)|BIT(1) = 0x%02X but BIT(1)+BIT(1) = 0x%02X : OR is idempotent, + is not\n\n",
           BIT(1) | BIT(1), BIT(1) + BIT(1));

    printf("%-45s%s\n", "pin number (hex digit) ->", "FEDC BA98 7654 3210");
    SET_BIT(GPIOB->ODR, BYSTANDER);         /* the pin that must survive everything */
    show("start (bystander PB3 high)");

    SET_BIT(GPIOB->ODR, LD1_GREEN | LD3_RED);        /* two LEDs, one statement */
    show("SET   LD1 + LD3");

    CLEAR_BIT(GPIOB->ODR, LD1_GREEN | LD2_BLUE);     /* LD2 was already off: harmless */
    show("CLEAR LD1 + LD2");

    SET_BIT(GPIOB->ODR, ALL_LEDS);
    show("SET   all three");

    for (int i = 0; i < 3; i++) {                    /* blink the whole bar */
        TOGGLE_BIT(GPIOB->ODR, ALL_LEDS);
        sim_delay_ms(250);
        show("TOGGLE all three");
    }

    CLEAR_BIT(GPIOB->ODR, ALL_LEDS);
    show("CLEAR all three");

    int ok = (GPIOB->ODR == BYSTANDER);
    printf("Only the bystander PB3 is still high: %s\n", ok ? "yes" : "NO!");
    return ok ? 0 : 1;
}
