/*
 * ============================================================================
 *  Topic   : 04 C Expressions and Operators
 *  Example : 08 - Arithmetic, relational, logical, ternary, ++/-- and compound operators
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A thermostat pipeline uses nearly every operator family:
 *            + - * / % (integer maths: multiply BEFORE divide), += and >> for averaging,
 *            < > && || for thresholds with hysteresis, ?: for min/max/labels, ++ for indexes,
 *            and & (N-1) as a cheap modulo for power-of-two ring buffers.
 *  Embedded use : no FPU, no floats: ADC counts become millivolts and tenths of a degree with
 *            32-bit integer maths. Hysteresis stops a relay chattering around one threshold.
 *  Real STM32F4 : mv = (adc_raw * 3300U + 2047U) / 4095U;   // 12-bit ADC, 3.3 V reference
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex08_sensor_scaling_operators.c -o ex08
 *  Output  : integer-maths traps, then a 10-reading table (raw -> mV -> degC -> heater state),
 *            and a short tour of ++, -- and compound assignment
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Move HEAT_OFF_ABOVE down to 205. What happens to the heater column?
 *            2) Replace 'sum >> 2' by 'sum / 4': is the output identical? Why is a power of two
 *               convenient? (compare  gcc -O1 -S  for  / 4  and  / 3)
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define ADC_MAX         4095U       /* 12-bit converter: (1U << 12) - 1           */
#define VREF_MV         3300U
#define N_SAMPLES       4U          /* power of two: divide by shifting right by 2 */
#define HEAT_ON_BELOW   200         /* 20.0 degC in tenths of a degree             */
#define HEAT_OFF_ABOVE  220         /* 22.0 degC: 2 degC of hysteresis band        */
#define HISTORY_LEN     4U          /* ring buffer length, must be a power of two  */

static uint32_t adc_to_mv(uint32_t raw)
{
    return (raw * VREF_MV + ADC_MAX / 2U) / ADC_MAX;   /* multiply, add half to round, divide */
}

/* TMP36-style sensor: 500 mV offset, 10 mV per degC  ->  1 mV = 0.1 degC. */
static int32_t mv_to_tenths_c(uint32_t mv) { return (int32_t)mv - 500; }

static const char *fmt_temp(char *buf, size_t n, int32_t t10)
{
    uint32_t mag = (t10 < 0) ? (uint32_t)(-t10) : (uint32_t)t10;   /* % and / dislike negatives */
    snprintf(buf, n, "%s%u.%u", (t10 < 0) ? "-" : "", (unsigned)(mag / 10U), (unsigned)(mag % 10U));
    return buf;
}

#define STEP(stmt) do { stmt; printf("    %-12s -> v = %u\n", #stmt, (unsigned)v); } while (0)

int main(void)
{
    puts("--- Integer maths traps (raw = 3000 counts) ---");
    uint32_t raw = 3000U;
    printf("  raw * 3300 / 4095           = %u mV  (multiply first: 2417.6 truncates to 2417)\n",
           (unsigned)(raw * VREF_MV / ADC_MAX));
    printf("  raw / 4095 * 3300           = %u mV  (divide first: 3000/4095 is 0!)\n",
           (unsigned)(raw / ADC_MAX * VREF_MV));
    printf("  rounded adc_to_mv(raw)      = %u mV  (adds half a count before dividing)\n",
           (unsigned)adc_to_mv(raw));
    printf("  (uint16_t)(raw * 3300)      = %u      (9900000 does not fit in 16 bits)\n",
           (unsigned)(uint16_t)(raw * VREF_MV));
    printf("  -7 / 2 = %d, -7 %% 2 = %d, 7 / 2 = %d, 7 %% 2 = %d  (division truncates to 0)\n\n",
           -7 / 2, -7 % 2, 7 / 2, 7 % 2);

    puts("--- Thermostat: 4 ADC samples -> average -> mV -> degC -> heater with hysteresis ---");
    const uint16_t bursts[][N_SAMPLES] = {
        {850, 852, 849, 851}, {863, 860, 862, 863}, {874, 876, 877, 873}, {887, 887, 888, 886},
        {902, 899, 900, 899}, {885, 888, 888, 887}, {876, 875, 874, 877}, {862, 861, 863, 861},
        {851, 851, 848, 850}, {4095, 4095, 4095, 4095} };            /* last one: shorted sensor */
    puts("  #  samples (raw)          avg   mV   degC  heater  status");

    int32_t history[HISTORY_LEN] = {0};
    unsigned idx = 0U;
    int heater = 0;
    int32_t t_min = 1000, t_max = -1000;
    char tbuf[16];

    for (unsigned i = 0U; i < sizeof bursts / sizeof bursts[0]; i++) {
        uint32_t sum = 0U;
        for (unsigned j = 0U; j < N_SAMPLES; j++)
            sum += bursts[i][j];                       /* compound assignment            */
        uint32_t avg = sum >> 2;                       /* same as sum / 4, but one shift */
        uint32_t mv  = adc_to_mv(avg);
        int32_t  t10 = mv_to_tenths_c(mv);

        int sensor_ok = (avg > 0U) && (avg < ADC_MAX); /* a reading stuck at a rail = fault */
        if (!sensor_ok)               heater = 0;      /* fail safe: never heat blind       */
        else if (t10 < HEAT_ON_BELOW) heater = 1;      /* too cold: on                      */
        else if (t10 > HEAT_OFF_ABOVE) heater = 0;     /* too warm: off. In between: KEEP   */

        if (sensor_ok) {                               /* keep statistics of GOOD readings  */
            t_min = (t10 < t_min) ? t10 : t_min;       /* ternary as min / max              */
            t_max = (t10 > t_max) ? t10 : t_max;
            history[idx] = t10;
            idx = (idx + 1U) & (HISTORY_LEN - 1U);     /* wrap 0,1,2,3,0,1,... no division  */
        }

        printf("  %u  %4u %4u %4u %4u  %5u %4u  %5s   %-3s   %s\n", i,
               (unsigned)bursts[i][0], (unsigned)bursts[i][1], (unsigned)bursts[i][2],
               (unsigned)bursts[i][3], (unsigned)avg, (unsigned)mv,
               fmt_temp(tbuf, sizeof tbuf, t10),
               heater ? "ON" : "off", !sensor_ok ? "SENSOR FAULT" : (t10 > 400 ? "ALARM" : "ok"));
    }
    char lo[16], hi[16];
    printf("  good readings: min %s degC, max %s degC, ring index after 9 of them = %u (9 & 3)\n\n",
           fmt_temp(lo, sizeof lo, t_min), fmt_temp(hi, sizeof hi, t_max), idx);

    puts("--- ++ and -- : prefix changes first, postfix returns the old value ---");
    unsigned k = 5U;
    unsigned a = k++;                                  /* a = 5, then k = 6 */
    unsigned b = ++k;                                  /* k = 7, then b = 7 */
    printf("    k = 5; a = k++; b = ++k;   ->  a = %u, b = %u, k = %u\n", a, b, k);
    printf("    never write  x = x++ + ++x  (undefined: x changed twice, no sequence point)\n\n");

    puts("--- Compound assignment: each one is  v = v OP expr ---");
    uint32_t v = 3U;
    STEP(v <<= 2);          /* 3 * 4  */
    STEP(v += 1U);
    STEP(v |= 0x10U);       /* set bit 4 */
    STEP(v &= ~1U);         /* clear bit 0 */
    STEP(v ^= 0xFFU);       /* flip low byte */
    STEP(v %= 100U);
    STEP(v >>= 1);

    int ok = (history[(idx - 1U) & (HISTORY_LEN - 1U)] == 185 && idx == 1U &&
              t_min == 185 && t_max == 225);
    return ok ? 0 : 1;
}
