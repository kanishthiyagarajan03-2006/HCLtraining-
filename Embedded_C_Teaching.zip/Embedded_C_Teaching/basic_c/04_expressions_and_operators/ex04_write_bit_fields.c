/*
 * ============================================================================
 *  Topic   : 04 C Expressions and Operators
 *  Example : 04 - Writing a multi-bit field: clear it with a mask, then OR in the value
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Many registers pack several bits into one field (MODER: 2 bits per pin,
 *            AFR: 4 bits per pin). To change ONE field:  reg = (reg & ~mask) | (value << shift).
 *            Skipping the clear step (OR only) corrupts the field; writing the whole register
 *            with '=' wipes out the neighbours. A generic mask is ((1U << width) - 1U) << shift.
 *  Embedded use : choosing pin mode (input/output/alternate/analog), selecting the UART
 *            alternate function, setting timer prescalers and clock dividers.
 *  Real STM32F4 : MODIFY_REG(GPIOA->MODER, 3U << (5*2), 1U << (5*2));   // PA5 -> output
 *                 GPIOA->AFR[1] = (GPIOA->AFR[1] & ~(0xFU << 4)) | (7U << 4);  // PA9 -> AF7
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_write_bit_fields.c -o ex04
 *  Output  : PA5 mode written three ways (right, OR-only bug, '=' bug), then AFR and a 3-bit field
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Start PA5 in input mode (00) instead of analog (11). Does OR-only still fail?
 *            2) Use set_field() to put value 5 into a 3-bit field at bits [6:4] of a register.
 * ============================================================================
 */
#include "hw_sim.h"

#define MODE_INPUT   0U
#define MODE_OUTPUT  1U
#define MODE_AF      2U
#define MODE_ANALOG  3U

/* CMSIS-style helper: clear the bits in CLEARMASK, then set the bits in SETMASK. */
#define MODIFY_REG(reg, clearmask, setmask) \
    ((reg) = (((reg) & ~(clearmask)) | (setmask)))

/* Generic field mask: 'width' ones, moved up by 'shift'. Valid for width < 32. */
#define FIELD_MASK(width, shift)  (((1U << (width)) - 1U) << (shift))

/* Write 'value' into a field of any width/position, truncating value to fit. */
#define SET_FIELD(reg, width, shift, value) \
    MODIFY_REG(reg, FIELD_MASK(width, shift), \
               ((uint32_t)(value) << (shift)) & FIELD_MASK(width, shift))

static void show(const char *what, uint32_t v, unsigned nbits)
{
    printf("%-30s 0x%08X  ", what, (unsigned)v);
    sim_print_bits(v, nbits);
    putchar('\n');
}

/* MODER-style view: one PAIR of bits per pin, pin 7 on the left. */
static void show_pairs(const char *what, uint32_t v)
{
    printf("%-30s 0x%04X  ", what, (unsigned)(v & 0xFFFFu));
    for (unsigned pin = 8u; pin > 0u; pin--)
        printf("%u%u%s", (unsigned)((v >> ((pin - 1u) * 2u + 1u)) & 1u),
               (unsigned)((v >> ((pin - 1u) * 2u)) & 1u), pin > 1u ? " " : "\n");
}

/* Right way: pin n owns bits [2n+1 : 2n] of MODER. */
static void gpio_set_mode(GPIO_TypeDef *port, unsigned pin, uint32_t mode)
{
    unsigned shift = pin * 2U;
    MODIFY_REG(port->MODER, 3U << shift, (mode & 3U) << shift);
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    const unsigned pin = 5U;

    puts("--- MODER: 2 bits per pin (00 in, 01 out, 10 alt-fn, 11 analog) ---");
    printf("%-30s %-6s  P7 P6 P5 P4 P3 P2 P1 P0\n", "", "");
    uint32_t start = (MODE_OUTPUT << (0 * 2)) | (MODE_ANALOG << (pin * 2)) | (MODE_AF << (6 * 2));

    GPIOA->MODER = start;                                  /* PA0 out, PA5 analog, PA6 alt-fn */
    show_pairs("start: PA0=01 PA5=11 PA6=10", GPIOA->MODER);

    GPIOA->MODER |= (MODE_OUTPUT << (pin * 2U));           /* BUG: OR only, 11 | 01 = 11 */
    show_pairs("BUG 1: OR only (PA5 still 11)", GPIOA->MODER);

    GPIOA->MODER = start;
    GPIOA->MODER = (MODE_OUTPUT << (pin * 2U));            /* BUG: '=' wipes PA0 and PA6 */
    show_pairs("BUG 2: '=' (PA0, PA6 lost)", GPIOA->MODER);

    GPIOA->MODER = start;
    gpio_set_mode(GPIOA, pin, MODE_OUTPUT);                /* clear field, then OR value */
    show_pairs("RIGHT: clear, then OR", GPIOA->MODER);
    int mode_ok = (((GPIOA->MODER >> (pin * 2U)) & 3U) == MODE_OUTPUT);   /* read the field back */
    int others_ok = ((GPIOA->MODER & ~(3U << (pin * 2U))) == (start & ~(3U << (pin * 2U))));
    printf("PA5 field reads back %u (1 = output); all other pins unchanged: %s\n\n",
           (unsigned)((GPIOA->MODER >> (pin * 2U)) & 3U), others_ok ? "yes" : "NO");

    puts("--- AFR: 4 bits per pin, two registers (AFR[0] = pins 0-7, AFR[1] = pins 8-15) ---");
    unsigned af_pin = 9U;                       /* PA9 = USART1_TX, alternate function 7   */
    unsigned reg_idx = af_pin >> 3;             /* pin / 8  -> which AFR register          */
    unsigned shift   = (af_pin & 7U) * 4U;      /* pin % 8  -> which nibble inside it      */
    GPIOA->AFR[1] = (0xFU << 4) | 0x1U;        /* pretend: PA9 was AF15, PA8 = AF1         */
    show("AFR[1] before", GPIOA->AFR[reg_idx], 32u);
    MODIFY_REG(GPIOA->AFR[reg_idx], 0xFU << shift, 7U << shift);
    show("AFR[1] after PA9 -> AF7", GPIOA->AFR[reg_idx], 32u);
    printf("register index = %u >> 3 = %u,  nibble shift = (%u & 7) * 4 = %u\n\n",
           af_pin, reg_idx, af_pin, shift);

    puts("--- One macro for any field: SET_FIELD(reg, width, shift, value) ---");
    uint32_t cr = 0xFFFFu;                      /* pretend 16-bit control register, all ones */
    show("CR before", cr, 16u);
    SET_FIELD(cr, 3, 4, 5U);                    /* 3-bit field at bits [6:4] = 101           */
    show("CR after field[6:4] = 5", cr, 16u);
    cr = 0u;
    SET_FIELD(cr, 3, 4, 13U);                   /* 13 = 1101 needs 4 bits: top bit is masked */
    show("CR=0, field[6:4] = 13", cr, 16u);     /* away instead of corrupting bit 7          */

    return (mode_ok && others_ok) ? 0 : 1;
}
