/*
 * ============================================================================
 *  Topic   : 04 C Expressions and Operators
 *  Example : 01 - Set, clear and toggle ONE GPIO pin with shift operators
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : (1U << n) builds a mask with only bit n set.
 *              OR  (|)  with the mask   -> SET    that bit
 *              AND (&)  with ~mask      -> CLEAR  that bit
 *              XOR (^)  with the mask   -> TOGGLE that bit
 *            Every other bit in the register is left untouched.
 *  Embedded use : every LED, relay, chip-select and enable line is just one
 *            bit inside a GPIO output register.
 *  Real STM32F4 : GPIOA->ODR |= (1U << 5);   // PA5 = user LED on Nucleo boards
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_set_clear_toggle_pin.c -o ex01
 *  Output  : PA5 goes ON, OFF, then toggles four times; PA0 and PA7 never change
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change LED_PIN to 7 - what do you expect to happen?
 *            2) Set PA1 and PA3 together using a single statement.
 * ============================================================================
 */
#include "hw_sim.h"

#define LED_PIN 5U

int main(void)
{
    /* Step 1: enable the GPIOA peripheral clock (nothing works without it). */
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;

    /* Step 2: make PA5 an output. MODER uses 2 bits per pin, so pin n lives
     * in bits [2n+1 : 2n]. Clear both bits first, then write 01 = output.   */
    GPIOA->MODER &= ~(3U << (LED_PIN * 2U));
    GPIOA->MODER |=  (1U << (LED_PIN * 2U));

    /* Put two *other* pins high so we can prove they are never disturbed.   */
    GPIOA->ODR = (1U << 0) | (1U << 7);
    sim_show_port("GPIOA", GPIOA);

    /* SET: OR with the mask forces the bit to 1, leaves the rest alone. */
    GPIOA->ODR |= (1U << LED_PIN);
    printf("SET    PA5 -> ");
    sim_show_port("GPIOA", GPIOA);

    /* CLEAR: AND with the inverted mask forces the bit to 0. */
    GPIOA->ODR &= ~(1U << LED_PIN);
    printf("CLEAR  PA5 -> ");
    sim_show_port("GPIOA", GPIOA);

    /* TOGGLE: XOR flips the bit every time - the classic LED blink. */
    for (int i = 0; i < 4; i++) {
        GPIOA->ODR ^= (1U << LED_PIN);
        sim_delay_ms(500);
        printf("TOGGLE PA5 -> ");
        sim_show_port("GPIOA", GPIOA);
    }

    /* The other pins must be exactly as we left them. */
    int others_ok = (GPIOA->ODR & ~(1U << LED_PIN)) == ((1U << 0) | (1U << 7));
    printf("PA0 and PA7 untouched: %s\n", others_ok ? "yes" : "NO!");
    return others_ok ? 0 : 1;
}
