/*
 * ============================================================================
 *  Topic   : 04 C Expressions and Operators
 *  Example : 05 - BSRR: atomic set/reset with shifts vs read-modify-write (and the ISR race)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : "ODR |= mask" is THREE steps (load, or, store). If an interrupt changes ODR
 *            between the load and the store, its change is silently overwritten.
 *            BSRR avoids this: ONE write sets pins with its low half (1U << n) and clears
 *            pins with its high half (1U << (n + 16)). Zero bits in a BSRR write are ignored.
 *  Embedded use : any output pin shared between main code and an ISR (or two RTOS tasks) -
 *            LEDs, chip-selects, motor enables. Intermittent "lost update" bugs like this are
 *            nearly impossible to find with a debugger.
 *  Real STM32F4 : GPIOA->BSRR = (1U << 5);          // set   PA5
 *                 GPIOA->BSRR = (1U << (5 + 16));   // reset PA5
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_bsrr_atomic_set_reset.c -o ex05
 *  Output  : a traced lost-update with |=, the same interleaving harmless with BSRR, and a
 *            4-bit LED counter written in one atomic store per step
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Write BSRR = BIT(2) | (BIT(2) << 16): set AND reset the same pin in one store.
 *               Predict the result first, then run it and check RM0090 (the simulator follows
 *               the real chip: the set bit "BSx" has priority over the reset bit "BRx").
 *            2) Change the counter field to PA4..PA7 (shift the value left by 4).
 * ============================================================================
 */
#include "hw_sim.h"

#define BIT(n) (1U << (n))

/* On real silicon a BSRR write takes effect INSTANTLY. The PC simulator only "applies"
 * BSRR when sim_gpio_apply() runs, so we call it right after every write to imitate that. */
#define BSRR_WRITE(port, value) do { (port)->BSRR = (value); sim_gpio_apply(port); } while (0)

#define PIN_MAIN  0U     /* PA0: owned by the main loop */
#define PIN_ISR   1U     /* PA1: owned by a timer interrupt */

static void show(const char *what)
{
    printf("  %-34s ODR = 0x%04X  ", what, (unsigned)GPIOA->ODR);
    sim_print_bits(GPIOA->ODR, 8u);
    putchar('\n');
}

/* Real hardware would call these asynchronously (TIM2_IRQHandler). Two flavours: */
static void isr_rmw(void)   { GPIOA->ODR |= BIT(PIN_ISR); }             /* load/or/store */
static void isr_bsrr(void)  { BSRR_WRITE(GPIOA, BIT(PIN_ISR)); }        /* one store     */

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->MODER |= 0x5555U;                 /* PA0..PA7 = outputs (01 in each 2-bit field) */
    int failures = 0;

    puts("--- 1. Read-modify-write, interrupted between LOAD and STORE ---");
    GPIOA->ODR = 0U;
    uint32_t tmp = GPIOA->ODR;               /* LOAD    (LDR r3,[r2,#0x14])  tmp = 0x00      */
    show("main: LOAD done, ODR still");
    isr_rmw();                               /*  <-- the interrupt hits right here           */
    show("ISR : sets PA1, ODR now");
    tmp |= BIT(PIN_MAIN);                    /* MODIFY  (ORR r3,r3,#1)     tmp = 0x01        */
    GPIOA->ODR = tmp;                        /* STORE   (STR r3,[r2,#0x14]) overwrites PA1!  */
    show("main: STORE done, ODR now");
    int lost = ((GPIOA->ODR & BIT(PIN_ISR)) == 0U);
    printf("  PA1 set by the ISR was %s\n\n", lost ? "LOST (the race bug)" : "kept");
    if (!lost) failures++;

    puts("--- 2. Same interleaving, but main uses ONE BSRR store ---");
    GPIOA->ODR = 0U;
    show("start");
    BSRR_WRITE(GPIOA, BIT(PIN_MAIN));        /* a single store: nothing to interleave with   */
    isr_bsrr();                              /* the ISR may hit before OR after, both are OK */
    show("main set PA0, ISR set PA1");
    int kept = (GPIOA->ODR == (BIT(PIN_MAIN) | BIT(PIN_ISR)));
    printf("  both bits present: %s\n\n", kept ? "yes" : "NO");
    if (!kept) failures++;

    puts("--- 3. Reset uses the HIGH half: 1U << (n + 16) ---");
    BSRR_WRITE(GPIOA, BIT(PIN_MAIN + 16U));
    show("BSRR = 1U << (0 + 16): PA0 off");
    BSRR_WRITE(GPIOA, BIT(PIN_ISR + 16U) | BIT(4U));
    show("one write: PA1 off, PA4 on");
    BSRR_WRITE(GPIOA, 0U);
    printf("  writing 0 changes nothing, and BSRR reads back 0x%X\n\n", (unsigned)GPIOA->BSRR);

    puts("--- 4. Write a 4-bit value into PA0..PA3 in ONE store ---");
    puts("  BSRR = (value & 0xF) | ((~value & 0xF) << 16)   -> 1s set, 0s reset, others untouched");
    GPIOA->ODR = 0U;
    BSRR_WRITE(GPIOA, BIT(7U));              /* bystander PA7 high */
    for (uint32_t value = 0U; value <= 12U; value += 3U) {
        uint32_t set   = value & 0xFU;
        uint32_t clear = ~value & 0xFU;
        char label[32];
        BSRR_WRITE(GPIOA, set | (clear << 16));
        snprintf(label, sizeof label, "value %2u (PA7 untouched)", (unsigned)value);
        show(label);
        if ((GPIOA->ODR & 0xFU) != value || !(GPIOA->ODR & BIT(7U))) failures++;
    }
    printf("failures: %d\n", failures);
    return failures;
}
