/*
 * ============================================================================
 *  Topic   : 14 Recursion
 *  Example : 07 - Why firmware avoids recursion: stack budget, depth guard, loop
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Every recursive call costs one stack frame (return address, saved
 *            registers, locals). Depth = problem size, so worst-case stack use
 *            depends on DATA you do not control. A loop does the same work in a
 *            single frame. Rule of thumb: if recursion is unavoidable, bound the
 *            depth by design and check it (a guard) before you recurse.
 *  Embedded use : MISRA C:2012 Rule 17.2 forbids recursion; automotive/medical
 *            code needs a provable worst-case stack. Cortex-M stacks are often
 *            512 B - 4 KB and an overflow silently corrupts other variables.
 *  Real STM32F4 : arm-none-eabi-gcc -fstack-usage -c file.c   (writes file.su with
 *                 the bytes ONE call of each function uses; for a recursive function
 *                 it cannot tell you the total, which is frame size x depth)
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex07_depth_guard_and_iteration.c -o ex07
 *  Output  : sum of n ADC samples done recursively (with a simulated 256-byte
 *            stack budget) and with a loop: the recursive one is refused for n >= 10
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Raise STACK_BUDGET to 512: from which n does the guard trigger now?
 *            2) Compile with -fstack-usage -c and read the .su file for sum_rec.
 * ============================================================================
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#define STACK_BUDGET  256U   /* bytes we can afford for this feature          */
#define FRAME_BYTES    24U   /* assumed cost per call: ret addr + regs + locals */
#define N_SAMPLES      32U

static unsigned stack_now;   /* simulated stack currently in use */
static unsigned stack_peak;  /* highest value stack_now reached  */

static void frame_enter(void)
{
    stack_now += FRAME_BYTES;
    if (stack_now > stack_peak) {
        stack_peak = stack_now;
    }
}

/* Recursive sum of a[0..n-1]. Returns false (and recurses no further) when the
 * next frame would not fit into the stack budget: a bounded-depth guard.      */
static bool sum_rec(const uint16_t *a, size_t n, uint32_t *out)
{
    if (stack_now + FRAME_BYTES > STACK_BUDGET) {
        return false;                       /* refuse instead of overflowing  */
    }
    frame_enter();

    bool ok = true;
    if (n == 0U) {                          /* base case */
        *out = 0U;
    } else {
        uint32_t rest;
        ok = sum_rec(a + 1, n - 1U, &rest); /* one more frame per element      */
        if (ok) {
            *out = a[0] + rest;
        }
    }
    stack_now -= FRAME_BYTES;               /* frame is popped on return       */
    return ok;
}

/* Same result, one frame, no matter how many samples. */
static uint32_t sum_loop(const uint16_t *a, size_t n)
{
    frame_enter();
    uint32_t sum = 0U;
    for (size_t i = 0; i < n; i++) {
        sum += a[i];
    }
    stack_now -= FRAME_BYTES;
    return sum;
}

int main(void)
{
    uint16_t adc[N_SAMPLES];
    uint32_t seed = 12345U;                 /* tiny LCG: repeatable "ADC data" */
    for (size_t i = 0; i < N_SAMPLES; i++) {
        seed = seed * 1103515245U + 12345U;
        adc[i] = (uint16_t)((seed >> 16) & 0x0FFFU);
    }

    printf("stack budget %u bytes, %u bytes per frame -> room for %u frames\n\n",
           STACK_BUDGET, FRAME_BYTES, STACK_BUDGET / FRAME_BYTES);
    printf("%3s | %-34s | %s\n", "n", "recursive", "loop");

    static const size_t sizes[] = { 4U, 9U, 10U, 32U };
    for (size_t k = 0; k < sizeof sizes / sizeof sizes[0]; k++) {
        size_t n = sizes[k];
        uint32_t r = 0U;

        stack_now = 0U;
        stack_peak = 0U;
        bool ok = sum_rec(adc, n, &r);
        unsigned peak_rec = stack_peak;

        stack_now = 0U;
        stack_peak = 0U;
        uint32_t l = sum_loop(adc, n);

        if (ok) {
            printf("%3u | sum=%6u peak stack=%3u bytes    | sum=%6u peak stack=%u bytes\n",
                   (unsigned)n, (unsigned)r, peak_rec, (unsigned)l, stack_peak);
        } else {
            printf("%3u | REFUSED: would exceed %3u bytes    | sum=%6u peak stack=%u bytes\n",
                   (unsigned)n, STACK_BUDGET, (unsigned)l, stack_peak);
        }
    }
    return 0;
}
