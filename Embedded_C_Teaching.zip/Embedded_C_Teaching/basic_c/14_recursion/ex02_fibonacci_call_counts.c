/*
 * ============================================================================
 *  Topic   : 14 Recursion
 *  Example : 02 - Fibonacci: how many calls? Naive vs memoised vs loop
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A function that calls itself TWICE (fib(n-1) + fib(n-2)) repeats the
 *            same work again and again, so its call count grows exponentially.
 *            A 'static' lookup table (memoisation) or a simple loop fixes it.
 *  Embedded use : a 16 MHz MCU has no time to waste: the same answer that takes
 *            millions of calls recursively needs 30 loop steps. Always count the
 *            cost of recursion before putting it in an interrupt or control loop.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex02_fibonacci_call_counts.c -o ex02
 *  Output  : a table with fib(n), call counts for the three methods and the
 *            estimated run time of the naive version on a 16 MHz Cortex-M
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add n = 35 to the table. How long would the naive version take
 *               on the MCU? (Run it and read the estimate.)
 *            2) Call fib_memo(30) a second time WITHOUT clearing memo[]: how many
 *               calls does it need now, and why?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define MCU_HZ           16000000ULL   /* assumed clock of the target                */
#define CYCLES_PER_CALL  20ULL         /* rough cost of one call+return on Cortex-M */
#define FIB_MAX_N        47U           /* fib(47) is the last one that fits uint32_t */

static uint32_t calls_naive;
static uint32_t calls_memo;
static uint32_t memo[FIB_MAX_N + 1U];      /* cache, 0 = "not computed yet" (fib(n)>0 for n>=1) */

static uint32_t fib_naive(uint32_t n)
{
    calls_naive++;
    if (n < 2U) {
        return n;                          /* base cases: fib(0)=0, fib(1)=1 */
    }
    return fib_naive(n - 1U) + fib_naive(n - 2U);
}

static uint32_t fib_memo(uint32_t n)
{
    calls_memo++;
    if (n < 2U) {
        return n;
    }
    if (memo[n] == 0U) {
        memo[n] = fib_memo(n - 1U) + fib_memo(n - 2U);   /* computed only once */
    }
    return memo[n];
}

static uint32_t fib_loop(uint32_t n, uint32_t *steps)
{
    uint32_t a = 0U, b = 1U;
    *steps = 0U;
    for (uint32_t i = 0U; i < n; i++) {
        uint32_t next = a + b;
        a = b;
        b = next;
        (*steps)++;
    }
    return a;
}

int main(void)
{
    static const uint32_t test_n[] = { 5U, 10U, 20U, 25U, 30U };

    printf("%3s %9s | %10s %10s %6s | %s\n",
           "n", "fib(n)", "naive", "memo", "loop", "naive time @16MHz");
    for (size_t i = 0; i < sizeof test_n / sizeof test_n[0]; i++) {
        uint32_t n = test_n[i];

        calls_naive = 0U;
        calls_memo  = 0U;
        memset(memo, 0, sizeof memo);      /* start every row with an empty cache */
        uint32_t f1 = fib_naive(n);
        uint32_t f2 = fib_memo(n);
        uint32_t steps;
        uint32_t f3 = fib_loop(n, &steps);

        if (f1 != f2 || f2 != f3) {
            puts("MISMATCH between methods!");
            return 1;
        }
        uint64_t ms = (uint64_t)calls_naive * CYCLES_PER_CALL * 1000ULL / MCU_HZ;
        printf("%3u %9u | %10u %10u %6u | %llu ms\n", (unsigned)n, (unsigned)f1,
               (unsigned)calls_naive, (unsigned)calls_memo, (unsigned)steps,
               (unsigned long long)ms);
    }
    return 0;
}
