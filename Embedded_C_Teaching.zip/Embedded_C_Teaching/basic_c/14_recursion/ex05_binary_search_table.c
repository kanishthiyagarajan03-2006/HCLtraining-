/*
 * ============================================================================
 *  Topic   : 14 Recursion
 *  Example : 05 - Recursive binary search in a sorted calibration table
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Binary search looks at the middle element and recurses into ONE half,
 *            so a table of n entries needs only about log2(n) calls. The base
 *            cases are "range is empty" and "found". Recursion depth = number
 *            of halvings, which is tiny, so stack use stays small.
 *  Embedded use : thermistor (NTC) and other non-linear sensors are converted with
 *            a const lookup table in flash: find the two neighbouring entries,
 *            then interpolate between them using integer maths.
 *  Real STM32F4 : adc = ADC1->DR;   // 12-bit counts, then look up temperature
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex05_binary_search_table.c -o ex05
 *  Output  : for each ADC reading, the probes the search makes, the table
 *            interval found and the interpolated temperature in 0.1 C units
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add the reading 1470 (exactly one table entry) - what temperature?
 *            2) Why does the search only work if the table is sorted?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define N_POINTS 17U

/* NTC divider calibration: ascending ADC counts <-> temperature -10..70 C, step 5. */
static const uint16_t adc_pts[N_POINTS] = {
     350,  450,  570,  710,  870, 1050, 1250, 1470, 1700,
    1940, 2180, 2420, 2650, 2860, 3050, 3220, 3370
};
#define TEMP_START_C  (-10)
#define TEMP_STEP_C   5

/* Find i in [lo, hi] such that adc_pts[i] <= key < adc_pts[i+1].
 * Returns -1 if key is below the table, and the LAST index if key is at or above the last
 * entry (no interval above it; main() rejects both).  `depth` is only for the printout. */
static int find_interval(uint16_t key, int lo, int hi, unsigned depth)
{
    if (lo > hi) {                                    /* base case: empty range */
        return -1;
    }
    int mid = lo + (hi - lo) / 2;                     /* avoids lo+hi overflow  */
    printf("    probe %u: index %2d (adc %4u)\n", depth, mid, (unsigned)adc_pts[mid]);

    if (key < adc_pts[mid]) {
        return find_interval(key, lo, mid - 1, depth + 1U);        /* left half  */
    }
    if (mid + 1 < (int)N_POINTS && key >= adc_pts[mid + 1]) {
        return find_interval(key, mid + 1, hi, depth + 1U);        /* right half */
    }
    return mid;                                       /* base case: found it    */
}

int main(void)
{
    static const uint16_t readings[] = { 2048U, 400U, 3300U, 200U, 3500U };

    for (size_t k = 0; k < sizeof readings / sizeof readings[0]; k++) {
        uint16_t adc = readings[k];
        printf("ADC = %u\n", (unsigned)adc);

        int i = find_interval(adc, 0, (int)N_POINTS - 1, 1U);
        if (i < 0 || i >= (int)N_POINTS - 1) {
            puts("    out of calibration range -> sensor fault\n");
            continue;
        }
        /* linear interpolation inside the interval, result in 0.1 C */
        int32_t span  = (int32_t)adc_pts[i + 1] - (int32_t)adc_pts[i];
        int32_t frac  = ((int32_t)adc - (int32_t)adc_pts[i]) * (TEMP_STEP_C * 10) / span;
        int32_t tenth = (TEMP_START_C + TEMP_STEP_C * i) * 10 + frac;
        int32_t mag = (tenth < 0) ? -tenth : tenth;       /* print sign by hand: -7.5 C */
        printf("    interval [%u .. %u] -> %s%d.%d C\n\n", (unsigned)adc_pts[i],
               (unsigned)adc_pts[i + 1], (tenth < 0) ? "-" : "", (int)(mag / 10),
               (int)(mag % 10));
    }
    return 0;
}
