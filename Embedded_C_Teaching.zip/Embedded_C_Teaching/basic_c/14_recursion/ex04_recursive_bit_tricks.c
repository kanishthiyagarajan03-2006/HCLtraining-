/*
 * ============================================================================
 *  Topic   : 14 Recursion
 *  Example : 04 - Recursion on bits: popcount, parity and print-binary
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Many bit problems are naturally recursive: handle the lowest bit,
 *            then recurse on (value >> 1) until the value is 0 (base case).
 *            Recursion also reverses order for free: printing AFTER the recursive
 *            call outputs the most significant bit first.
 *  Embedded use : count how many LEDs / relays / interrupt sources are active in a
 *            register, compute parity for a UART frame, show a register in binary.
 *            (A table or a loop is cheaper on a real MCU - this is for learning.)
 *  Real STM32F4 : Cortex-M4 has no popcount instruction; GCC's
 *                 __builtin_popcount(GPIOA->ODR) calls a small library routine.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_recursive_bit_tricks.c -o ex04
 *  Output  : for five port values read from GPIOA->ODR: the binary form (MSB
 *            first), the number of set bits and the even-parity bit
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add the value 0xFFFF - predict popcount and parity first.
 *            2) Move the putchar in print_bin BEFORE the recursive call - what changes?
 * ============================================================================
 */
#include "hw_sim.h"

/* Number of 1-bits: lowest bit + popcount of the rest. */
static unsigned popcount(uint32_t v)
{
    if (v == 0U) {                         /* base case: no bits left */
        return 0U;
    }
    return (v & 1U) + popcount(v >> 1);
}

/* Parity bit for "even parity" framing: 1 if the number of set bits is odd. */
static unsigned parity(uint32_t v)
{
    if (v == 0U) {
        return 0U;
    }
    return (v & 1U) ^ parity(v >> 1);
}

/* Print the lowest `bits` bits of v, MSB first.
 * The recursive call comes FIRST, so the highest bit is printed first. */
static void print_bin(uint32_t v, unsigned bits)
{
    if (bits == 0U) {                      /* base case */
        return;
    }
    print_bin(v >> 1, bits - 1U);          /* higher bits first ... */
    putchar((v & 1U) ? '1' : '0');         /* ... then this bit     */
}

int main(void)
{
    static const uint16_t samples[] = { 0x0020U, 0x00FFU, 0x2C5AU, 0x8001U, 0x0000U };

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->MODER = 0x55555555U;            /* PA0..PA15 outputs */

    printf("%-8s %-17s %-5s %s\n", "ODR", "binary", "ones", "parity bit");
    for (size_t i = 0; i < sizeof samples / sizeof samples[0]; i++) {
        GPIOA->ODR = samples[i];
        uint32_t v = GPIOA->ODR & 0xFFFFU;

        printf("0x%04X   ", (unsigned)v);
        print_bin(v, 16U);
        printf("  %-5u %u\n", popcount(v), parity(v));
    }
    return 0;
}
