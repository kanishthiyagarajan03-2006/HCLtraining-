/*
 * ============================================================================
 *  Topic   : 14 Recursion
 *  Example : 06 - Tower of Hanoi: a plan that is easy to write but costly to run
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : "Move n discs" = move n-1 discs out of the way, move the biggest disc,
 *            move the n-1 discs back on top. Recursion states that plan in three
 *            lines. The NUMBER OF MOVES doubles with every disc (2^n - 1) while
 *            the recursion DEPTH (stack use) only grows by one frame per disc.
 *  Embedded use : generating a move sequence for a stepper-driven pick-and-place
 *            arm or a sorting machine. Two different costs to watch: run time
 *            (exponential here) and stack depth (linear here).
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex06_tower_of_hanoi.c -o ex06
 *  Output  : the 7 moves for 3 discs, then a table of move count, recursion depth
 *            and the time a slow arm (2 s per move) would need
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Run 4 discs verbosely and count the moves before you read them.
 *            2) Estimate 30 discs at 2 s per move (hint: each disc doubles the time).
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define SECONDS_PER_MOVE  2U

static uint32_t moves;
static unsigned max_depth;

/* Move n discs from peg `from` to peg `to`, using peg `via` as parking space. */
static void hanoi(unsigned n, char from, char to, char via, unsigned depth, int verbose)
{
    if (depth > max_depth) {
        max_depth = depth;                 /* deepest stack we ever needed */
    }
    if (n == 0U) {                         /* base case: nothing to move */
        return;
    }
    hanoi(n - 1U, from, via, to, depth + 1U, verbose);   /* 1. clear the top    */
    moves++;                                             /* 2. move the biggest */
    if (verbose) {
        printf("  move %u: disc %u  %c -> %c\n", (unsigned)moves, n, from, to);
    }
    hanoi(n - 1U, via, to, from, depth + 1U, verbose);   /* 3. put them back on */
}

int main(void)
{
    puts("--- 3 discs, every move printed (A -> C, B is the parking peg) ---");
    moves = 0U;
    max_depth = 0U;
    hanoi(3U, 'A', 'C', 'B', 0U, 1);
    printf("total: %u moves, recursion depth %u\n\n", (unsigned)moves, max_depth);

    puts("--- cost table (moves are counted, not printed) ---");
    printf("%5s %10s %6s   %s\n", "discs", "moves", "depth", "time at 2 s/move");
    for (unsigned n = 1U; n <= 20U; n += (n < 5U) ? 1U : 5U) {
        moves = 0U;
        max_depth = 0U;
        hanoi(n, 'A', 'C', 'B', 0U, 0);

        uint32_t secs = moves * SECONDS_PER_MOVE;
        printf("%5u %10u %6u   %u s = %u min = %u h\n", n, (unsigned)moves, max_depth,
               (unsigned)secs, (unsigned)(secs / 60U), (unsigned)(secs / 3600U));
    }
    return 0;
}
