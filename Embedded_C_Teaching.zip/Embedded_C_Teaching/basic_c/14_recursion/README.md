# Topic 14 - Recursion
**Suggested session:** 75 min | **Prerequisite topics:** 07 Conditional Statements, 10 Functions, 13 Storage Classes (stack frames, `static`)

Students should be able to write a recursive function with a clear base case and recursive case, trace the stack frames by hand, and judge the cost (time AND stack) before using recursion on a microcontroller. The examples go from the classic traces (factorial, Fibonacci) through useful integer recursion (gcd, power, bit tricks, binary search), then the embedded reality check: stack budgets, MISRA, RTOS stack high-water marks, and a recursive walk over a Linux directory tree.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_factorial_call_trace.c` | MCU | Base case vs recursive case, indented call/return trace, `uint32_t` overflow check (13! does not fit) |
| 02 | `ex02_fibonacci_call_counts.c` | MCU | Double recursion explodes (2.7 million calls for fib(30)); cache and loop versions; estimated time on a 16 MHz MCU |
| 03 | `ex03_gcd_and_power.c` | MCU | Euclid's gcd (tail recursion) for sample-rate ratio 48000:44100; power by squaring in log2(n) calls |
| 04 | `ex04_recursive_bit_tricks.c` | MCU | Recursive popcount, parity and print-binary of a GPIO register; recursion reverses output order |
| 05 | `ex05_binary_search_table.c` | MCU | Recursive binary search in a const NTC calibration table plus integer interpolation |
| 06 | `ex06_tower_of_hanoi.c` | MCU | Moves grow as 2^n - 1 but recursion depth grows only as n: time cost vs stack cost |
| 07 | `ex07_depth_guard_and_iteration.c` | MCU | Simulated stack budget, refusing to recurse too deep, converting recursion to a loop, MISRA 17.2 |
| 08 | `ex08_rtos_recursion_stack_hwm.c` | RTOS | Task stack high-water mark measured while a worker recurses deeper; monitor task logs stack use |
| 09 | `ex09_linux_recursive_dir_walk.c` | LINUX | Recursive `scandir`/`lstat` walk and recursive delete on a temp tree; depth limit and symlink safety |

## Teaching notes
* Always ask for the **base case first**, then the recursive step. A missing or unreachable base case is the number-one bug (see `-DDEMO_BUG` in ex01).
* Two different costs: **time** (ex02 and ex06 explode) and **stack** (ex07 and ex08 grow with depth). A function can be fine on one and terrible on the other.
* Tail recursion (ex03 `gcd`) can be compiled into a loop with `-O2`, but you must not rely on it for correctness in firmware; MISRA C:2012 Rule 17.2 bans recursion outright.
* Overflow hides inside recursion too: ask what happens to `fact(13)` on a 32-bit `int` (ex01) and to the intermediate square in ex03.
* Every iterative loop can be turned into recursion and (with an explicit stack if needed) vice versa. Ask the class which they would ship on a 2 KB-RAM part and why.

## Live-demo tips
* Build the broken ex01 with `gcc -DDEMO_BUG ex01_factorial_call_trace.c -o bug && ./bug`: GCC warns about infinite recursion at compile time, and the run ends in a segmentation fault (stack overflow) after the first 12 traced calls.
* Compile ex03 and ex02 with `gcc -O2 -S`: ex03's assembly contains no `call gcd` (the tail call became a loop), but ex02 still contains real `call fib_naive` instructions.
* In ex08 compare per-level stack cost at `-O0` and `-O2`: `gcc -O2 ...`. The numbers differ, the conclusion (budget your stack) does not.
