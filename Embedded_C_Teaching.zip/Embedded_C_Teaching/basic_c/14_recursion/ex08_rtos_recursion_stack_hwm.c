/*
 * ============================================================================
 *  Topic   : 14 Recursion
 *  Example : 08 - Recursion inside an RTOS task: watching the stack high-water mark
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Each RTOS task has a FIXED-size stack chosen at creation. Recursion
 *            eats that stack one frame per level, so the recursion depth must be
 *            small enough for the stack you gave the task. The kernel fills the
 *            stack with a pattern and can tell you how much was never touched
 *            (the "high-water mark").
 *  Embedded use : a worker task that recurses over data of unknown size can
 *            overflow into the next task's memory and crash the whole system.
 *            Production firmware checks uxTaskGetStackHighWaterMark() in testing.
 *  Real FreeRTOS : UBaseType_t left = uxTaskGetStackHighWaterMark(handle);  // free, in WORDS
 *                  configCHECK_FOR_STACK_OVERFLOW = 2 catches the overflow itself.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex08_rtos_recursion_stack_hwm.c -o ex08
 *  Output  : the worker recurses deeper each 100 ms; the monitor task logs the
 *            stack used so far; main prints the measured bytes per recursion level
 * ----------------------------------------------------------------------------
 *  Try it  : 1) From the measured bytes per level, predict the deepest recursion that fits
 *               in STACK_BYTES (do not run past it: an overflow corrupts memory).
 *            2) On a 1 KB MCU stack, how many levels could this function afford?
 * ============================================================================
 */
#include "mini_rtos.h"

#define STACK_BYTES  (256U * 1024U)   /* PC stacks are huge; a Cortex-M task has ~0.5-2 KB */

static const uint32_t depths[] = { 1U, 8U, 32U, 128U, 512U };
#define N_DEPTHS  (sizeof depths / sizeof depths[0])

static rtos_task_t *worker_tcb;
static size_t       used_after[N_DEPTHS];

/* One frame = return address + saved registers + 48 bytes of locals. The
 * volatile array stops the compiler from optimising the recursion away.     */
static uint32_t descend(uint32_t n)
{
    volatile uint8_t scratch[48];
    scratch[0] = (uint8_t)n;
    if (n == 0U) {                               /* base case */
        return scratch[0];
    }
    return descend(n - 1U) + scratch[0];
}

static size_t stack_used(const rtos_task_t *t)
{
    return t->stack_size - rtos_stack_high_water(t);
}

static void worker(void *arg)
{
    (void)arg;
    for (size_t i = 0; i < N_DEPTHS; i++) {
        uint32_t r = descend(depths[i]);
        used_after[i] = stack_used(worker_tcb);
        rtos_log("recursed %3u levels deep (checksum %u)", (unsigned)depths[i], (unsigned)r);
        rtos_delay(100);
    }
}

static void monitor(void *arg)
{
    (void)arg;
    rtos_delay(50);                              /* look in between worker steps */
    for (int i = 0; i < 5; i++) {
        size_t used = stack_used(worker_tcb);
        rtos_log("worker stack: %6zu of %zu bytes used (%zu%%)", used,
                 worker_tcb->stack_size, used * 100U / worker_tcb->stack_size);
        rtos_delay(100);
    }
}

int main(void)
{
    worker_tcb = rtos_task_create("worker", worker, NULL, 1, STACK_BYTES);
    rtos_task_create("monitor", monitor, NULL, 2, 0);
    rtos_start(600);

    size_t n_diff = depths[N_DEPTHS - 1U] - depths[N_DEPTHS - 2U];
    size_t per_level = (used_after[N_DEPTHS - 1U] - used_after[N_DEPTHS - 2U]) / n_diff;
    printf("\nmeasured cost of one recursion level: about %zu bytes\n", per_level);
    printf("a 1024-byte task stack would allow only about %zu levels of this function\n"
           "(a Cortex-M frame is smaller than a PC frame, but the idea is the same)\n",
           1024U / per_level);

    rtos_shutdown();
    return 0;
}
