/*
 * ============================================================================
 *  Topic   : 14 Recursion
 *  Example : 03 - GCD (Euclid) and fast power: recursion that shrinks quickly
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Good recursion cuts the problem down fast. Euclid's gcd(a, b) =
 *            gcd(b, a % b) ends in a handful of steps; power by squaring halves
 *            the exponent each call, so x^n needs only about log2(n) calls.
 *            gcd is TAIL recursive (the call is the last action): an optimising
 *            compiler can turn it into a plain loop with no stack growth.
 *  Embedded use : reduce a clock ratio to its simplest fraction (48 kHz -> 44.1 kHz
 *            sample-rate conversion), and compute 10^n scale factors for
 *            fixed-point printing without floating point or pow().
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex03_gcd_and_power.c -o ex03
 *  Output  : the gcd steps for 48000 and 44100, the reduced ratio 147/160, and
 *            10^n values with the number of recursive calls needed
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the rates to 48000 and 32000: predict the gcd and the ratio first.
 *            2) What is power_u32(2, 31) and how many calls does it need?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

static unsigned gcd_calls;
static unsigned pow_calls;

/* Tail recursion: nothing is left to do after the recursive call returns. */
static uint32_t gcd(uint32_t a, uint32_t b)
{
    gcd_calls++;
    printf("  gcd(%u, %u)\n", (unsigned)a, (unsigned)b);
    if (b == 0U) {                         /* base case */
        return a;
    }
    return gcd(b, a % b);
}

/* x^n by repeated squaring: x^n = (x^(n/2))^2, times x if n is odd. */
static uint32_t power_u32(uint32_t x, uint32_t n)
{
    pow_calls++;
    if (n == 0U) {                         /* base case: x^0 = 1 */
        return 1U;
    }
    uint32_t half = power_u32(x, n / 2U);  /* one call on HALF the exponent */
    uint32_t sq   = half * half;           /* (caller must keep result < 2^32) */
    return (n % 2U == 0U) ? sq : sq * x;
}

int main(void)
{
    uint32_t in_hz = 48000U, out_hz = 44100U;

    puts("Euclid's algorithm for 48000 and 44100:");
    uint32_t g = gcd(in_hz, out_hz);
    printf("gcd = %u after %u calls\n", (unsigned)g, gcd_calls);
    printf("sample-rate converter: upsample by %u, downsample by %u\n\n",
           (unsigned)(out_hz / g), (unsigned)(in_hz / g));

    puts("Powers of ten for fixed-point scaling (no float, no pow()):");
    for (uint32_t n = 0U; n <= 9U; n += 3U) {
        pow_calls = 0U;
        uint32_t v = power_u32(10U, n);
        printf("  10^%u = %10u   (%u calls)\n", (unsigned)n, (unsigned)v, pow_calls);
    }

    /* The exponent goes 20, 10, 5, 2, 1, 0 -> only 6 calls, not 20 multiplications. */
    pow_calls = 0U;
    uint32_t p = power_u32(3U, 20U);
    printf("  3^20 = %10u   (%u calls instead of 20 multiplications)\n",
           (unsigned)p, pow_calls);
    return 0;
}
