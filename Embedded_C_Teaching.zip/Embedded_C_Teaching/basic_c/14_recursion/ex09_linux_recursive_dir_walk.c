/*
 * ============================================================================
 *  Topic   : 14 Recursion
 *  Example : 09 - Recursive directory walk (and recursive delete) on embedded Linux
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A directory tree is a naturally recursive structure: a directory
 *            contains files (base case) and smaller directories (recursive case).
 *            The same shape of function lists the tree, totals the sizes, and
 *            deletes it bottom-up. A depth limit keeps the recursion bounded.
 *  Embedded use : an embedded Linux gateway scans /var/log or /sys/class to find
 *            files, sums log size before the flash fills up, or cleans old data.
 *            Use lstat() (not stat()) so symbolic links cannot create endless loops.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex09_linux_recursive_dir_walk.c -o ex09
 *  Output  : an indented listing of a small log/config tree that the program builds
 *            in /tmp, file/dir counts and total size, then confirmation of cleanup
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Print the full path of each file instead of just its name.
 *            2) Lower MAX_DEPTH to 2 - which entries disappear and why?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <dirent.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define MAX_DEPTH  8U

typedef struct {
    unsigned files;
    unsigned dirs;
    unsigned long bytes;
    unsigned deepest;
} stats_t;

static bool join_path(char *out, size_t size, const char *dir, const char *name)
{
    int n = snprintf(out, size, "%s/%s", dir, name);
    return n > 0 && (size_t)n < size;               /* false if it was truncated */
}

static int skip_dots(const struct dirent *e)
{
    return strcmp(e->d_name, ".") != 0 && strcmp(e->d_name, "..") != 0;
}

/* ---- tree builder (test data) -------------------------------------------- */
static void put_file(const char *root, const char *rel, const char *text)
{
    char path[512];
    if (!join_path(path, sizeof path, root, rel)) return;
    FILE *f = fopen(path, "w");
    if (f != NULL) {
        fputs(text, f);
        fclose(f);
    }
}

static void put_dir(const char *root, const char *rel)
{
    char path[512];
    if (join_path(path, sizeof path, root, rel) && mkdir(path, 0700) != 0) {
        perror("mkdir");
    }
}

/* ---- recursion 1: list and measure --------------------------------------- */
static void walk(const char *dir, unsigned depth, stats_t *st)
{
    if (depth > MAX_DEPTH) {                         /* guard: bounded recursion */
        printf("%*s(depth limit reached)\n", (int)(depth * 2U), "");
        return;
    }
    if (depth > st->deepest) st->deepest = depth;

    struct dirent **list = NULL;
    int n = scandir(dir, &list, skip_dots, alphasort);   /* sorted: stable output */
    for (int i = 0; i < n; i++) {
        char path[512];
        struct stat sb;
        if (join_path(path, sizeof path, dir, list[i]->d_name) && lstat(path, &sb) == 0) {
            if (S_ISDIR(sb.st_mode)) {
                st->dirs++;
                printf("%*s%s/\n", (int)((depth + 1U) * 2U), "", list[i]->d_name);
                walk(path, depth + 1U, st);          /* RECURSIVE CASE: a subdirectory */
            } else {                                 /* BASE CASE: a plain file        */
                st->files++;
                st->bytes += (unsigned long)sb.st_size;
                printf("%*s%s  (%ld bytes)\n", (int)((depth + 1U) * 2U), "",
                       list[i]->d_name, (long)sb.st_size);
            }
        }
        free(list[i]);
    }
    free(list);                                      /* scandir allocated both levels */
}

/* ---- recursion 2: delete bottom-up, return how many entries were removed -- */
static unsigned remove_tree(const char *path)
{
    unsigned removed = 0U;
    struct stat sb;
    if (lstat(path, &sb) != 0) return 0U;

    if (S_ISDIR(sb.st_mode)) {
        struct dirent **list = NULL;
        int n = scandir(path, &list, skip_dots, alphasort);
        for (int i = 0; i < n; i++) {
            char child[512];
            if (join_path(child, sizeof child, path, list[i]->d_name)) {
                removed += remove_tree(child);       /* children first ... */
            }
            free(list[i]);
        }
        free(list);
        if (rmdir(path) == 0) removed++;             /* ... then the empty directory */
    } else if (unlink(path) == 0) {
        removed++;
    }
    return removed;
}

int main(void)
{
    char root[] = "/tmp/rec_tree_XXXXXX";
    if (mkdtemp(root) == NULL) {
        perror("mkdtemp");
        return 1;
    }

    put_dir(root, "sensors");
    put_dir(root, "logs");
    put_dir(root, "logs/old");
    put_dir(root, "logs/old/2023");
    put_file(root, "readme.txt", "gateway data directory\n");
    put_file(root, "sensors/adc.cfg", "channel=3\nrate_hz=100\n");
    put_file(root, "sensors/temp.cfg", "unit=C\n");
    put_file(root, "logs/boot.log", "boot ok\nlink up\nntp synced\n");
    put_file(root, "logs/old/a.log", "old entry\n");
    put_file(root, "logs/old/2023/jan.log", "2023-01-01 power cycle\n");

    stats_t st = { 0U, 0U, 0UL, 0U };
    printf("tree/\n");                                   /* real name is random: hide it */
    walk(root, 0U, &st);
    printf("\nfiles: %u, directories: %u, total %lu bytes, deepest level %u\n",
           st.files, st.dirs, st.bytes, st.deepest);

    unsigned gone = remove_tree(root);
    struct stat sb;
    bool still_there = (stat(root, &sb) == 0);
    printf("removed %u entries, temp tree still exists: %s\n", gone,
           still_there ? "YES (cleanup failed)" : "no");
    return still_there ? 1 : 0;
}
