/*
 * ============================================================================
 *  Topic   : 14 Recursion
 *  Example : 01 - Factorial with a call trace (base case, recursive case, frames)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A recursive function calls itself on a SMALLER problem until it hits
 *            the base case. Every call gets its own stack frame (own copy of the
 *            parameters), and the results are multiplied on the way BACK up.
 *            Forget the base case and the stack overflows.
 *  Embedded use : the result must fit the integer type: 13! overflows uint32_t,
 *            so a checked version is needed. Each pending call also costs RAM
 *            on a chip with only a few hundred bytes of stack.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex01_factorial_call_trace.c -o ex01
 *  Output  : an indented trace of fact(4) going down and coming back, then a
 *            table of n! for n = 10..14 where 13 and 14 are reported as overflow
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Predict the trace of fact(1) before you run it.
 *            2) Delete the base case (build with -DDEMO_BUG) - what happens?
 *               (stack overflow; do not leave it on!)
 * ============================================================================
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#define TRACE_DEPTH  12U       /* print only the first frames (keeps DEMO_BUG readable) */

/* Number of ways n tasks could be ordered = n!. The trace shows each frame. */
static uint32_t fact_trace(uint32_t n, unsigned depth)
{
    if (depth < TRACE_DEPTH) {
        printf("%*scall   fact(%u)\n", (int)(depth * 3U), "", (unsigned)n);
    }

    uint32_t result;
#ifndef DEMO_BUG
    if (n <= 1U) {                        /* BASE CASE: stops the recursion       */
        result = 1U;
    } else {                              /* RECURSIVE CASE: smaller problem n-1  */
        result = n * fact_trace(n - 1U, depth + 1U);
    }
#else
    /* Without a base case n wraps below 0 to 4294967295 and the calls never end:
     * every call needs a new stack frame until the stack is full -> crash.
     * (GCC even warns: -Winfinite-recursion. Expect 'Segmentation fault'.)       */
    result = n * fact_trace(n - 1U, depth + 1U);
#endif

    if (depth < TRACE_DEPTH) {
        printf("%*sreturn %u\n", (int)(depth * 3U), "", (unsigned)result);
    }
    return result;
}

/* Production version: no printing, reports overflow instead of wrapping around. */
static bool fact_checked(uint32_t n, uint32_t *out)
{
    if (n <= 1U) {
        *out = 1U;
        return true;
    }
    uint32_t smaller;
    if (!fact_checked(n - 1U, &smaller)) {
        return false;
    }
    if (smaller > UINT32_MAX / n) {       /* would smaller * n exceed 32 bits?    */
        return false;
    }
    *out = smaller * n;
    return true;
}

int main(void)
{
    puts("--- trace of fact(4): frames pile up, then unwind ---");
    uint32_t r = fact_trace(4U, 0U);
    printf("fact(4) = %u\n\n", (unsigned)r);

    puts("--- uint32_t limit ---");
    for (uint32_t n = 10U; n <= 14U; n++) {
        uint32_t v;
        if (fact_checked(n, &v)) {
            printf("%2u! = %u\n", (unsigned)n, (unsigned)v);
        } else {
            printf("%2u! = overflow (does not fit in 32 bits)\n", (unsigned)n);
        }
    }
    return 0;
}
