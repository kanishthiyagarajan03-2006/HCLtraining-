/*
 * ============================================================================
 *  Topic   : 08 Control Loops
 *  Example : 06 - Bit-banging one SPI byte, MSB first (loop from 7 down to 0)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A loop can walk through the bits of a byte: for (i = 7; i >= 0; i--) tests bit i
 *            with (byte >> i) & 1U. MSB first means bit 7 goes out first, so received bits
 *            are shifted in from the right:  rx = (rx << 1) | bit.
 *            Counting DOWN to zero needs a SIGNED counter (or the idiom  i-- > 0 ):
 *            an unsigned i >= 0 is always true and the loop never ends.
 *  Embedded use : when a chip has no SPI peripheral free (or the pins are wrong), you can
 *            "bit-bang" the protocol by toggling GPIO pins in software.
 *  Real STM32F4 : the hardware does this loop for you:  SPI1->DR = b; while (!(SPI1->SR & 1U)) {}
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_bitbang_spi_msb_first.c -o ex06
 *  Output  : one line per clock pulse (bit number, MOSI, MISO, the rx register filling up)
 *            for the byte 0xA5 sent while the slave answers 0x3C
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Run the loop from 0 up to 7 and send 0x01 instead of 0xA5: on which clock pulse
 *               does the 1 appear, and what byte does the slave see? (0xA5 and 0x3C read the same
 *               backwards, so they would hide the difference.)
 *            2) Build with -DDEMO_BUG (no -Werror) to see the unsigned countdown trap.
 * ============================================================================
 */
#include "hw_sim.h"

#define PIN_CS   4U                     /* PA4 chip select, active low */
#define PIN_SCK  5U                     /* PA5 clock                   */
#define PIN_MISO 6U                     /* PA6 data from the slave     */
#define PIN_MOSI 7U                     /* PA7 data to the slave       */

static const uint8_t slave_reply = 0x3CU;

/* BSRR writes take effect at once on real silicon; the simulator needs sim_sync(). */
static void pin_set(unsigned pin)
{
    GPIOA->BSRR = (1U << pin);
    sim_sync();
}

static void pin_clear(unsigned pin)
{
    GPIOA->BSRR = (1U << (pin + 16U));
    sim_sync();
}

/* The SLAVE chip would do this by itself; it presents the next reply bit on MISO. */
static void slave_drive_bit(int i)
{
    if ((slave_reply >> i) & 1U) {
        sim_press(GPIOA, PIN_MISO);
    } else {
        sim_release(GPIOA, PIN_MISO);
    }
}

static uint8_t spi_transfer(uint8_t tx)
{
    uint8_t rx = 0U;

    for (int i = 7; i >= 0; i--) {                      /* MSB first: bit 7, 6, ... 0 */
        slave_drive_bit(i);
        if ((tx >> i) & 1U) {                           /* set up MOSI while SCK is low */
            pin_set(PIN_MOSI);
        } else {
            pin_clear(PIN_MOSI);
        }
        pin_set(PIN_SCK);                               /* rising edge: the data is sampled */
        unsigned miso = (unsigned)((GPIOA->IDR >> PIN_MISO) & 1U);
        rx = (uint8_t)((rx << 1) | miso);               /* shift in from the right */

        printf("  bit %d: MOSI=%u  MISO=%u  rx register: ", i,
               (unsigned)((GPIOA->ODR >> PIN_MOSI) & 1U), miso);
        sim_print_bits(rx, 8U);                         /* watch the bits shift in */
        putchar('\n');
        pin_clear(PIN_SCK);                             /* falling edge */
    }
    return rx;
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->MODER |= (1U << (PIN_CS * 2U)) | (1U << (PIN_SCK * 2U)) | (1U << (PIN_MOSI * 2U));
    pin_set(PIN_CS);                                    /* idle: not selected */

    pin_clear(PIN_CS);                                  /* select the slave */
    uint8_t rx = spi_transfer(0xA5U);
    pin_set(PIN_CS);                                    /* release */

    printf("sent 0x%02X, received 0x%02X (slave answered 0x%02X)\n", 0xA5U, (unsigned)rx,
           (unsigned)slave_reply);

#ifdef DEMO_BUG
    /* uint8_t is never negative, so "i >= 0" is ALWAYS true: after 0 the counter wraps to
     * 255 and the loop would run forever (gcc -Wextra: comparison is always true). The guard
     * variable only stops this demo after a few extra turns.                              */
    for (uint8_t i = 2U, guard = 0U; i >= 0 && guard < 6U; i--, guard++) {
        printf("i = %u\n", (unsigned)i);                /* 2 1 0 255 254 253 */
    }
#endif
    return 0;
}
