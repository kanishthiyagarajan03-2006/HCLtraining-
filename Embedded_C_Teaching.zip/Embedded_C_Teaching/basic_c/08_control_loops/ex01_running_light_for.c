/*
 * ============================================================================
 *  Topic   : 08 Control Loops
 *  Example : 01 - Running light with for loops and (1U << i)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : for (init; condition; step) is the loop to use when you know HOW MANY times to
 *            repeat. The loop variable doubles as a bit number: (1U << i) is a mask with
 *            only bit i set. "ODR = mask" lights ONE LED; "ODR |= mask" ADDS an LED.
 *            Counting down uses the same pattern with i-- (careful with unsigned counters).
 *  Embedded use : LED chasers, bar graphs, configuring a block of pins, scanning channels.
 *            One loop replaces eight copy-pasted lines.
 *  Real STM32F4 : for (int i = 0; i < 8; i++) { GPIOB->ODR = (1U << i); HAL_Delay(100); }
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_running_light_for.c -o ex01
 *  Output  : one LED sweeping from LED0 (right box) to LED7 (left box), back again, then a
 *            bar that fills up. sim_show_leds draws the highest bit on the left
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Make the sweep faster by changing one number. Which one?
 *            2) Change the backward loop to start at NUM_LEDS - 1. What is displayed twice?
 * ============================================================================
 */
#include "hw_sim.h"

#define NUM_LEDS 8U
#define STEP_MS  100U                   /* time each LED pattern stays visible */

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;

    /* Loop #1: configure PB0..PB7 as outputs. MODER has 2 bits per pin, so the field for
     * pin n starts at bit 2n. Clear the field, then write 01 (= output).               */
    for (unsigned pin = 0U; pin < NUM_LEDS; pin++) {
        GPIOB->MODER &= ~(3U << (pin * 2U));
        GPIOB->MODER |=  (1U << (pin * 2U));
    }

    /* Loop #2: forward sweep, exactly one LED on. */
    puts("forward:");
    for (unsigned i = 0U; i < NUM_LEDS; i++) {
        GPIOB->ODR = (1U << i);                 /* "=": all other LEDs go off */
        sim_delay_ms(STEP_MS);
        sim_show_leds("PORTB", GPIOB->ODR, NUM_LEDS);
    }

    /* Loop #3: backward sweep. The ends were already shown, so skip bit 7 and bit 0.
     * A signed counter is simplest when counting DOWN to zero.                      */
    puts("backward:");
    for (int i = (int)NUM_LEDS - 2; i > 0; i--) {
        GPIOB->ODR = (1U << i);
        sim_delay_ms(STEP_MS);
        sim_show_leds("PORTB", GPIOB->ODR, NUM_LEDS);
    }

    /* Loop #4: bar graph - "|=" keeps the LEDs that are already on. */
    puts("fill:");
    GPIOB->ODR = 0U;
    for (unsigned i = 0U; i < NUM_LEDS; i++) {
        GPIOB->ODR |= (1U << i);
        sim_delay_ms(STEP_MS);
        sim_show_leds("PORTB", GPIOB->ODR, NUM_LEDS);
    }
    return 0;
}
