/*
 * ============================================================================
 *  Topic   : 08 Control Loops
 *  Example : 07 - The RTOS task loop: for (;;) with a blocking delay, and a bounded init loop
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : An RTOS task is an endless loop, for (;;), that BLOCKS every round (delay, queue,
 *            semaphore). Blocking is what lets other tasks run - a task that loops without
 *            ever blocking starves everything below it. A loop that is allowed to end
 *            (init, self-test) must be BOUNDED with a retry limit.
 *            rtos_delay_until() keeps a fixed period; rtos_delay() lets the period drift.
 *  Embedded use : every FreeRTOS application is a handful of such loops: blink, sample sensor,
 *            handle UART. Choosing the delay call decides if your 1 s task really runs at 1 s.
 *  Real FreeRTOS: for (;;) { ...; vTaskDelayUntil(&last_wake, pdMS_TO_TICKS(1000)); }
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_rtos_task_loop_delay.c -o ex07
 *  Output  : a time-stamped log from three tasks: a bounded init that succeeds on its 3rd try,
 *            an LED task toggling every 500 ms, and a heartbeat exactly every 1000 ms
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Replace rtos_delay_until in heartbeat_task with rtos_delay(1000). How do the
 *               time stamps change?
 *            2) Give init_task priority 1 instead of 3. What is logged first now, and why?
 * ============================================================================
 */
#include "mini_rtos.h"

/* Bounded loop: this task ends by returning (mini_rtos allows it; in FreeRTOS call
 * vTaskDelete(NULL) instead - a FreeRTOS task function must never simply return). */
static void init_task(void *arg)
{
    (void)arg;
    unsigned attempt = 0U;
    int ready = 0;

    while (!ready && attempt < 5U) {            /* retry limit: never wait forever */
        attempt++;
        ready = (attempt == 3U);                /* pretend the sensor wakes up on try 3 */
        rtos_log("init attempt %u: %s", attempt, ready ? "sensor ready" : "not ready");
        if (!ready) {
            rtos_delay(100);                    /* blocks: the other tasks get the CPU */
        }
    }
    rtos_log("init %s, task ends", ready ? "done" : "FAILED");
}

static void blink_task(void *arg)
{
    (void)arg;
    int led_on = 0;
    for (;;) {                                  /* a task never returns */
        led_on = !led_on;
        rtos_log("LED %s", led_on ? "ON " : "off");
        rtos_delay(500);                        /* the only thing that lets others run */
    }
}

static void heartbeat_task(void *arg)
{
    (void)arg;
    uint32_t last_wake = rtos_ticks();          /* reference point for a drift-free period */
    for (unsigned beat = 1U; ; beat++) {
        rtos_busy(20);                          /* 20 ms of real work each round */
        rtos_log("heartbeat #%u", beat);
        rtos_delay_until(&last_wake, 1000);     /* next wake-up at last_wake + 1000 */
    }
}

int main(void)
{
    rtos_task_create("init", init_task, NULL, 3, RTOS_MIN_STACK);
    rtos_task_create("blink", blink_task, NULL, 1, RTOS_MIN_STACK);
    rtos_task_create("heart", heartbeat_task, NULL, 2, RTOS_MIN_STACK);

    rtos_start(2100);

    rtos_shutdown();
    return 0;
}
