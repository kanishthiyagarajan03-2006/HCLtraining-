/*
 * ============================================================================
 *  Topic   : 08 Control Loops
 *  Example : 08 - Reading a log file line by line (while + continue + break)
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : while ((p = fgets(buf, size, fp)) != NULL) is the standard read-until-EOF loop:
 *            the test both reads and detects the end. Inside, `continue` skips lines we do
 *            not care about (blank, comments) and `break` stops early at an END marker.
 *            A fixed buffer silently splits long lines - detect a missing '\n' - or use
 *            getline(), which grows its buffer for you (and must be free()d).
 *  Embedded use : embedded Linux boxes keep sensor logs, config files and /proc entries as text.
 *            Reading them line by line, skipping junk, and never trusting the format is the
 *            everyday pattern.
 *  Real Linux   : while (fgets(line, sizeof line, fp) != NULL) { ... }   // fp = fopen(path, "r")
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex08_linux_read_file_lines.c -o ex08
 *  Output  : a temp log file is written, then read twice: a parse loop that skips comments,
 *            blanks and one bad line, stops at END and prints the average; a getline loop
 *            that reports the longest line
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Move the END line to the top of log_text. How many samples are used now?
 *            2) Reduce LINE_BUF to 16. Why does the long comment line still not break the parser?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define LINE_BUF 64U

static const char log_text[] =
    "# sensor log written by the data logger service, one sample per line, newest last ----\n"
    "t=100 temp=24\n"
    "\n"
    "t=200 temp=25\n"
    "t=300 temp=ERR\n"
    "t=400 temp=27\n"
    "END\n"
    "t=500 temp=99\n";

int main(void)
{
    char dir[] = "/tmp/ex08_XXXXXX";
    if (mkdtemp(dir) == NULL) {
        perror("mkdtemp");
        return 1;
    }
    char path[64];
    snprintf(path, sizeof path, "%s/sensor.log", dir);

    FILE *fp = fopen(path, "w");
    if (fp == NULL) {
        perror("fopen (write)");
        rmdir(dir);
        return 1;
    }
    fputs(log_text, fp);
    fclose(fp);

    fp = fopen(path, "r");
    if (fp == NULL) {
        perror("fopen (read)");
        remove(path);
        rmdir(dir);
        return 1;
    }

    puts("-- pass 1: fgets loop with continue and break --");
    char line[LINE_BUF];
    unsigned lineno = 0U, used = 0U, bad = 0U;
    long sum = 0;

    while (fgets(line, sizeof line, fp) != NULL) {          /* NULL = end of file (or error) */
        lineno++;
        if (strchr(line, '\n') == NULL && !feof(fp)) {      /* buffer filled before the newline */
            int ch;
            while ((ch = fgetc(fp)) != '\n' && ch != EOF) { /* throw the rest of the line away */
            }
        }
        line[strcspn(line, "\r\n")] = '\0';

        if (line[0] == '\0' || line[0] == '#') {
            printf("  line %u: skipped (%s)\n", lineno, line[0] == '#' ? "comment" : "blank");
            continue;                                       /* next line, skip the parsing below */
        }
        if (strcmp(line, "END") == 0) {
            printf("  line %u: END marker, stop reading\n", lineno);
            break;                                          /* leave the loop early */
        }
        unsigned t;
        int temp;
        if (sscanf(line, "t=%u temp=%d", &t, &temp) != 2) {
            printf("  line %u: cannot parse \"%s\"\n", lineno, line);
            bad++;
            continue;
        }
        printf("  line %u: t=%u ms, temp=%d C\n", lineno, t, temp);
        sum += temp;
        used++;
    }
    printf("used %u samples, %u bad, average %.2f C\n", used, bad,
           used ? (double)sum / used : 0.0);

    puts("-- pass 2: getline (grows its own buffer) --");
    rewind(fp);                                             /* back to the start of the file */
    char *buf = NULL;
    size_t cap = 0U;
    ssize_t len;
    size_t longest = 0U;
    unsigned lines = 0U;
    while ((len = getline(&buf, &cap, fp)) != -1) {
        lines++;
        if ((size_t)len > longest) {
            longest = (size_t)len;
        }
    }
    free(buf);                                              /* getline allocated it */
    printf("%u lines in the file, longest has %zu bytes (fgets buffer was %u)\n", lines, longest,
           LINE_BUF);

    fclose(fp);
    remove(path);                                           /* clean up the temp file and dir */
    rmdir(dir);
    return 0;
}
