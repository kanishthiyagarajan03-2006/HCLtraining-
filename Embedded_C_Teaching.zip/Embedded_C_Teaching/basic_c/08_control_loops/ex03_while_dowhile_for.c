/*
 * ============================================================================
 *  Topic   : 08 Control Loops
 *  Example : 03 - for vs while vs do-while: blink an LED N times
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Three loops, one job.
 *              for      : counter loop, init / test / step in one line
 *              while    : test FIRST, body may run zero times
 *              do-while : body first, test AFTER, runs at least once
 *            They only differ when the count is 0: the do-while still blinks once!
 *            Pick the loop that states your intent.
 *  Embedded use : "blink the error code N times" (N might be 0 = no error), "retry at least
 *            once", "read a sensor, then decide whether to read again".
 *  Real STM32F4 : GPIOA->ODR ^= (1U << 5); HAL_Delay(200);   // inside the loop body
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_while_dowhile_for.c -o ex03
 *  Output  : a timeline of three blinks, then a table of blinks per loop for N = 3, 1 and 0
 *            (only the do-while blinks when N = 0)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add N = 2 to the requests[] array and predict the new table row first.
 *            2) Which loop would you use to "show the error code, N may be zero"? Why?
 * ============================================================================
 */
#include "hw_sim.h"

#define LED_PIN 5U

static unsigned blinks_done;            /* how many ON-OFF pairs the LED performed */

/* One blink: LED on 100 ms, off 100 ms. */
static void blink_once(int verbose)
{
    GPIOA->ODR |= (1U << LED_PIN);
    sim_delay_ms(100U);
    if (verbose) {
        printf("  [%4u ms] LED ON \n", (unsigned)sim_millis());
    }
    GPIOA->ODR &= ~(1U << LED_PIN);
    sim_delay_ms(100U);
    if (verbose) {
        printf("  [%4u ms] LED OFF\n", (unsigned)sim_millis());
    }
    blinks_done++;
}

static unsigned blink_for(unsigned n, int verbose)
{
    blinks_done = 0U;
    for (unsigned i = 0U; i < n; i++) {         /* counter loop: the natural fit */
        blink_once(verbose);
    }
    return blinks_done;
}

static unsigned blink_while(unsigned n, int verbose)
{
    blinks_done = 0U;
    unsigned i = 0U;
    while (i < n) {                             /* tested first: n == 0 skips the body */
        blink_once(verbose);
        i++;
    }
    return blinks_done;
}

static unsigned blink_do_while(unsigned n, int verbose)
{
    blinks_done = 0U;
    unsigned i = 0U;
    do {                                        /* body first: runs once even if n == 0 */
        blink_once(verbose);
        i++;
    } while (i < n);                            /* note the ';' after a do-while */
    return blinks_done;
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->MODER |= (1U << (LED_PIN * 2U));

    puts("timeline of blink_for(3):");
    blink_for(3U, 1);

    puts("\nblinks performed by each loop:");
    puts("requested  for  while  do-while");
    static const unsigned requests[] = { 3U, 1U, 0U };
    for (size_t i = 0; i < sizeof requests / sizeof requests[0]; i++) {
        unsigned n = requests[i];
        unsigned f = blink_for(n, 0);           /* separate statements: no argument-order issues */
        unsigned w = blink_while(n, 0);
        unsigned d = blink_do_while(n, 0);
        printf("%9u  %3u  %5u  %8u%s\n", n, f, w, d,
               (d != f) ? "   <- only the do-while blinked" : "");
    }
    return 0;
}
