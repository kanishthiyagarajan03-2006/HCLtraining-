# Topic 08 - Control Loops
**Suggested session:** 75-90 min | **Prerequisite topics:** 04 Operators, 07 Conditional statements

Students learn `for`, `while` and `do-while`, plus `break` and `continue`, by driving things that
repeat in firmware: LEDs, status flags, retries, keypad rows, the bits of a byte, RTOS tasks and
log files. The examples begin with the counter loop (`for` with `1U << i`), compare the three loop
types, then add real hardware patterns (polling with a timeout, retry with back-off, nested keypad
scan, bit-banged SPI) and close with an RTOS task loop and a Linux read-until-EOF loop.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_running_light_for.c` | MCU | `for` loops, `(1U << i)` masks, `=` vs `\|=`, counting down |
| 02 | `ex02_poll_flag_with_timeout.c` | MCU | `while (!(SR & FLAG) && timeout--)`, the wrapped-counter trap, off-by-one |
| 03 | `ex03_while_dowhile_for.c` | MCU | `for` vs `while` vs `do-while`: the "runs at least once" difference |
| 04 | `ex04_retry_until_ack_do_while.c` | MCU | `do-while` retry with a limit and exponential back-off, two loop exits |
| 05 | `ex05_keypad_matrix_scan.c` | MCU | nested `for`, `continue`, `break` (innermost only) with a "done" flag |
| 06 | `ex06_bitbang_spi_msb_first.c` | MCU | looping over bits MSB first, shift-in, unsigned countdown trap (`DEMO_BUG`) |
| 07 | `ex07_rtos_task_loop_delay.c` | RTOS | `for (;;)` task loop that blocks, `delay` vs `delay_until`, bounded init loop |
| 08 | `ex08_linux_read_file_lines.c` | LINUX | `fgets`/`getline` until EOF, `continue` on junk, `break` on END, long lines |

## Teaching notes
* Pick the loop by intent: `for` = known count, `while` = may run zero times, `do-while` = at least once.
* Every hardware wait needs an exit: a timeout or retry limit. "Wait forever" is a firmware hang.
* After a timeout loop, test the thing you waited for (the flag), not the counter (ex02).
* `break` leaves only the innermost loop; for nested loops use a flag (ex05), or move the loops into a function and `return`.
* An unsigned counter is never `< 0`: `for (uint8_t i = 7; i >= 0; i--)` never ends (ex06). Use an `int`, or `i-- > 0`.
* An RTOS task loop that does not block starves lower-priority tasks. Ask: which call in ex07 gives the CPU away?

## Live-demo tips
* ex02 and ex06: build with `-DDEMO_BUG` (without `-Werror`) to show the timeout bug and the unsigned wrap-around.
* ex01: change `STEP_MS` and watch the timestamps; ex03: add `2U` to `requests[]`.
* ex07: swap `rtos_delay_until` for `rtos_delay(1000)` and compare the heartbeat time stamps (drift).
