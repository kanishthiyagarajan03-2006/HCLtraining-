/*
 * ============================================================================
 *  Topic   : 08 Control Loops
 *  Example : 04 - Retry until ACK with do-while, a retry limit and back-off
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : do { try } while (failed && attempts < MAX);  The try must happen at least once,
 *            so the test belongs AFTER the body. The loop has two exits: success, or the
 *            retry limit - never write an endless retry loop around hardware.
 *            After the loop, find out WHICH exit was taken (check the result, not the counter).
 *  Embedded use : an EEPROM that is busy with its internal write cycle NACKs its address for
 *            up to 5 ms; the master must poll ("ACK polling") and give up eventually.
 *            Doubling the wait each time (exponential back-off) avoids hammering the bus.
 *  Real STM32F4 : st = HAL_I2C_IsDeviceReady(&hi2c1, 0xA0, 5, 10);   // 5 trials, bounded
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_retry_until_ack_do_while.c -o ex04
 *  Output  : an EEPROM write that succeeds on attempt 4 after three NACKs, then a dead device
 *            that makes the driver give up after 5 attempts; each line shows the time
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change MAX_ATTEMPTS to 3. Which device now fails, and at what time?
 *            2) Remove the cap on backoff_ms. How long is the wait before attempt 5?
 * ============================================================================
 */
#include "hw_sim.h"

#define MAX_ATTEMPTS 5U
#define BACKOFF_START_MS 1U
#define BACKOFF_CAP_MS   4U

static unsigned nacks_before_ack;       /* fake device: busy for this many attempts */

/* One bus transaction: returns 1 for ACK, 0 for NACK. */
static int eeprom_write_byte(uint8_t value)
{
    (void)value;
    sim_delay_ms(1U);                   /* the transaction itself takes 1 ms */
    if (nacks_before_ack == 0U) {
        return 1;
    }
    nacks_before_ack--;
    return 0;
}

/* Returns 1 if the byte was acknowledged, 0 if we gave up. */
static int write_with_retry(uint8_t value)
{
    unsigned attempt = 0U;
    unsigned backoff_ms = BACKOFF_START_MS;
    int ack;

    do {
        attempt++;
        ack = eeprom_write_byte(value);
        printf("  [%2u ms] attempt %u: %s\n", (unsigned)sim_millis(), attempt,
               ack ? "ACK" : "NACK (device busy)");
        if (!ack && attempt < MAX_ATTEMPTS) {
            sim_delay_ms(backoff_ms);                   /* wait a little, then try again */
            backoff_ms *= 2U;
            if (backoff_ms > BACKOFF_CAP_MS) {
                backoff_ms = BACKOFF_CAP_MS;            /* never wait longer than this */
            }
        }
    } while (!ack && attempt < MAX_ATTEMPTS);           /* two ways out of the loop */

    return ack;                                         /* success flag, not the counter */
}

int main(void)
{
    puts("device busy for 3 attempts:");
    nacks_before_ack = 3U;
    int ok = write_with_retry(0x5A);
    printf("  -> %s\n\n", ok ? "written" : "GAVE UP");

    puts("dead device (never answers):");
    nacks_before_ack = 1000U;
    ok = write_with_retry(0x5A);
    printf("  -> %s\n", ok ? "written" : "GAVE UP - report an error to the application");
    return 0;
}
