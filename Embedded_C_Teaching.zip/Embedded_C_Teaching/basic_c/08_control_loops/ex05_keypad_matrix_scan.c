/*
 * ============================================================================
 *  Topic   : 08 Control Loops
 *  Example : 05 - Scanning a 4x4 keypad matrix with nested for loops
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Nested loops: the outer loop drives each ROW in turn, the inner loop checks each
 *            COLUMN. 16 keys need only 4 + 4 = 8 pins. `continue` skips to the next
 *            iteration (empty columns), `break` leaves only the INNERMOST loop, so we
 *            keep a flag when the whole scan should stop early.
 *  Embedded use : phone pads, door locks, microwaves, calculators. The same scan idea works for
 *            multiplexed 7-segment displays and LED matrices.
 *  Real STM32F4 : GPIOB->BSRR = (1U << row); cols = (GPIOB->IDR >> 4) & 0xFU;
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_keypad_matrix_scan.c -o ex05
 *  Output  : four scans: no key, key '5', keys '1' and '#' together, and the first-key-only
 *            variant that stops early with break; each prints the row/column found
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Press key 'D' (row 3, column 3) by editing the second scan. What changes?
 *            2) Why can three pressed keys in an L-shape show a fourth "ghost" key?
 * ============================================================================
 */
#include "hw_sim.h"

#define ROWS 4U
#define COLS 4U
#define ROW_SHIFT 0U                    /* rows   = PB0..PB3 (outputs) */
#define COL_SHIFT 4U                    /* columns = PB4..PB7 (inputs, pulled by the keys) */

static const char keymap[ROWS][COLS] = {
    { '1', '2', '3', 'A' },
    { '4', '5', '6', 'B' },
    { '7', '8', '9', 'C' },
    { '*', '0', '#', 'D' },
};

static uint8_t pressed[ROWS];           /* test input: bit c of pressed[r] = key (r,c) is down */

/* This function stands for the WIRES of the keypad. A closed key connects its row line to
 * its column line, so a column reads 1 when a pressed key sits on the row being driven.
 * On real hardware nothing calls this - physics does it.                              */
static void keypad_wires(void)
{
    uint32_t cols = 0U;
    for (unsigned r = 0U; r < ROWS; r++) {
        if (GPIOB->ODR & (1U << (r + ROW_SHIFT))) {         /* is this row driven high? */
            cols |= pressed[r];
        }
    }
    GPIOB->IDR = (GPIOB->IDR & ~(0xFU << COL_SHIFT)) | (cols << COL_SHIFT);
}

/* Scan the whole matrix; list every key found. If first_only, stop at the first one. */
static unsigned scan(int first_only)
{
    unsigned found = 0U;
    int done = 0;

    for (unsigned r = 0U; r < ROWS && !done; r++) {         /* outer: one row at a time */
        GPIOB->ODR = (GPIOB->ODR & ~0xFU) | (1U << (r + ROW_SHIFT));   /* drive row r only */
        keypad_wires();
        unsigned cols = (unsigned)(GPIOB->IDR >> COL_SHIFT) & 0xFU;

        for (unsigned c = 0U; c < COLS; c++) {              /* inner: every column */
            if ((cols & (1U << c)) == 0U) {
                continue;                                   /* not pressed: next column */
            }
            printf("  key '%c' at row %u, column %u\n", keymap[r][c], r, c);
            found++;
            if (first_only) {
                done = 1;                                   /* tell the OUTER loop to stop */
                break;                                      /* ... and leave the inner one */
            }
        }
    }
    GPIOB->ODR &= ~0xFU;                                    /* idle: no row driven */
    return found;
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    GPIOB->MODER |= (1U << 0) | (1U << 2) | (1U << 4) | (1U << 6);   /* PB0..PB3 outputs */

    puts("scan 1: nothing pressed");
    printf("  -> %u key(s)\n", scan(0));

    puts("scan 2: key '5' pressed");
    pressed[1] = (1U << 1);                                 /* row 1, column 1 */
    printf("  -> %u key(s)\n", scan(0));

    puts("scan 3: keys '1' and '#' pressed together");
    pressed[1] = 0U;
    pressed[0] = (1U << 0);                                 /* '1' */
    pressed[3] = (1U << 2);                                 /* '#' */
    printf("  -> %u key(s)\n", scan(0));

    puts("scan 4: same keys, but stop after the first one (break)");
    printf("  -> %u key(s)\n", scan(1));
    return 0;
}
