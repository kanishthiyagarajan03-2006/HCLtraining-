/*
 * ============================================================================
 *  Topic   : 08 Control Loops
 *  Example : 02 - Polling a status flag with a timeout (while loop)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : while (condition) repeats as long as the condition is true and may run ZERO
 *            times. A hardware wait is  while (!(SR & READY) && timeout--) { }  - two exits:
 *            the flag came up, or we ran out of patience. Short-circuit && means timeout--
 *            is only evaluated while the flag is still clear.
 *            Trap: after a timed-out loop, timeout has wrapped to 0xFFFFFFFF, so never decide
 *            success or failure by testing the counter - test the flag again.
 *  Embedded use : waiting for ADC end-of-conversion, PLL lock, flash busy, I2C bus free. A
 *            peripheral that never answers must not freeze the whole firmware.
 *  Real STM32F4 : while (!(ADC1->SR & ADC_SR_EOC) && timeout--) { }
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_poll_flag_with_timeout.c -o ex02
 *  Output  : three ADC conversions: fast (ok), slow but within the limit (ok), too slow
 *            (timeout), each with the number of polls used
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -DDEMO_BUG: the code decides by the counter. Which case is wrong?
 *            2) What is the longest conversion (in polls) that still succeeds for timeout=100?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define ADC_SR_EOC (1U << 1)            /* bit 1 = End Of Conversion */

static volatile uint32_t ADC_SR;        /* fake status register       */
static volatile uint32_t ADC_DR;        /* fake data register         */
static unsigned polls_left;             /* how many polls until the "hardware" is done */
static unsigned poll_count;             /* how many times software looked */

/* Reading SR in the simulation advances time; real hardware needs no help. */
static uint32_t sr_read(void)
{
    poll_count++;
    if (polls_left > 0U && --polls_left == 0U) {
        ADC_SR |= ADC_SR_EOC;
        ADC_DR = 2048U;
    }
    return ADC_SR;
}

static void adc_start(unsigned conversion_polls)
{
    ADC_SR &= ~ADC_SR_EOC;
    polls_left = conversion_polls;
    poll_count = 0U;
}

/* Returns 1 on success, 0 on timeout. */
static int adc_wait(uint32_t timeout)
{
    while (!(sr_read() & ADC_SR_EOC) && timeout--) {
        /* empty body: real silicon sets EOC by itself while we spin */
    }
#ifndef DEMO_BUG
    return (ADC_SR & ADC_SR_EOC) != 0U;     /* GOOD: decide by the thing we waited for */
#else
    return timeout != 0U;                   /* BUG: after a timeout this is 0xFFFFFFFF, i.e. true */
#endif
}

static void run_case(const char *label, unsigned conversion_polls, uint32_t timeout)
{
    adc_start(conversion_polls);
    int ok = adc_wait(timeout);
    printf("%-22s needs %3u polls, limit %3u -> %s after %u polls", label, conversion_polls,
           (unsigned)timeout, ok ? "OK     " : "TIMEOUT", poll_count);
    if (ok) {
        printf(", value %u", (unsigned)ADC_DR);
    }
    putchar('\n');
}

int main(void)
{
    run_case("fast conversion", 5U, 100U);
    run_case("slow, still in time", 90U, 100U);
    run_case("too slow (dead ADC?)", 500U, 100U);
    return 0;
}
