/*
 * ============================================================================
 *  Topic   : 02 The C Compilation Process
 *  Example : 05 - Where variables land: .text, .rodata, .data, .bss, stack and heap
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : The LINKER sorts everything the compiler produced into sections:
 *              .text   code                       .data  globals WITH a non-zero initial value
 *              .rodata const data, string literals .bss   globals that start at zero
 *            and it publishes the section boundaries as symbols (etext, edata, end ...). The
 *            program below compares the address of each variable with those boundaries.
 *            Locals live on the stack and malloc() memory on the heap: not in the image at all.
 *  Embedded use : on a Cortex-M, .text and .rodata sit in flash; .data needs RAM AND a flash
 *            copy of its initial values (startup code copies it); .bss needs RAM only (startup
 *            code zeroes it). Adding 'const' to a table can move it from RAM to flash.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex05_memory_sections.c -o ex05    (then:  size ex05)
 *  Output  : a list of variables with the section each one lives in, a check that the sections
 *            are in the order text < rodata < data < bss, and a summary table
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Remove 'const' from table_const - which section does it move to?
 *            2) Make counter_zero = 5 and re-run: does it stay in .bss?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

/* Boundary symbols made by the GNU linker. Only their ADDRESS means anything: &etext is
 * "the address where .text ends". (On an MCU your linker script defines _sdata, _edata,
 * _sbss, _ebss in the same way and the startup code uses them.) */
extern char __executable_start;     /* where the program image begins (start of .text)   */
extern char etext;                  /* end of .text                                      */
extern char __data_start;           /* start of .data                                    */
extern char edata;                  /* end of .data                                      */
extern char end;                    /* end of .bss                                       */

int counter_init = 42;                          /* global, non-zero   -> .data   */
int counter_zero;                               /* global, no value   -> .bss    */
static int static_init = 7;                     /* file-private       -> .data   */
static int static_zero;                         /* file-private       -> .bss    */
const int table_const[4] = { 1, 2, 3, 4 };      /* const global       -> .rodata */
static const char banner[] = "firmware v1";     /* const array        -> .rodata */

static void a_function(void) { }                /* code               -> .text   */

static const char *section_of(uintptr_t a)
{
    if (a < (uintptr_t)&__executable_start) return "outside the image (heap or stack)";
    if (a < (uintptr_t)&etext)              return ".text   (code, flash)";
    if (a < (uintptr_t)&__data_start)       return ".rodata (const data, flash)";
    if (a < (uintptr_t)&edata)              return ".data   (initialised, RAM + flash copy)";
    if (a < (uintptr_t)&end)                return ".bss    (zero-initialised, RAM)";
    return "outside the image (heap or stack)";
}

static void show(const char *what, uintptr_t addr)
{
    printf("  %-34s -> %s\n", what, section_of(addr));
}

int main(void)
{
    static int call_count;                      /* static local, no value -> .bss  */
    static int limit = 100;                     /* static local, non-zero -> .data */
    int local = 1;                              /* automatic local        -> stack */
    int *heap = (int *)malloc(sizeof *heap);    /* the block malloc gave  -> heap  */
    if (heap == NULL) return 1;
    *heap = 2;
    call_count++;

    puts("--- Which section does each object live in? ---");
    show("a_function() (any function)",     (uintptr_t)a_function);
    show("string literal \"abc\"",           (uintptr_t)"abc");
    show("const int table_const[4]",        (uintptr_t)table_const);
    show("static const char banner[]",      (uintptr_t)banner);
    show("int counter_init = 42",           (uintptr_t)&counter_init);
    show("static int static_init = 7",      (uintptr_t)&static_init);
    show("static int limit = 100 (in main)", (uintptr_t)&limit);
    show("int counter_zero",                (uintptr_t)&counter_zero);
    show("static int static_zero",          (uintptr_t)&static_zero);
    show("static int call_count (in main)", (uintptr_t)&call_count);
    show("int local (in main)",             (uintptr_t)&local);
    show("*heap (from malloc)",             (uintptr_t)heap);

    int ordered = ((uintptr_t)&__executable_start < (uintptr_t)&etext) &&
                  ((uintptr_t)&etext <= (uintptr_t)&__data_start) &&
                  ((uintptr_t)&__data_start < (uintptr_t)&edata) &&
                  ((uintptr_t)&edata <= (uintptr_t)&end);
    printf("\nsection order text < rodata < data < bss holds: %s\n", ordered ? "yes" : "NO");

    puts("\n  section   lives in      costs");
    puts("  .text     flash         code size");
    puts("  .rodata   flash         const data, string literals");
    puts("  .data     RAM + flash   RAM, plus a flash copy of the initial values");
    puts("  .bss      RAM           RAM only (zeroed at start-up, nothing stored in flash)");
    puts("  stack     RAM           grows and shrinks with function calls");
    puts("  heap      RAM           malloc/free (usually avoided on small MCUs)");

    free(heap);
    return ordered ? 0 : 1;
}
