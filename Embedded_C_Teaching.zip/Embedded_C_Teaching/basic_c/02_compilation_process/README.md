# Topic 02 - The C Compilation Process
**Suggested session:** 75 min | **Prerequisite topics:** 01 Introduction to C

Students see the four stages (preprocess, compile, assemble, link) plus loading, on real files. Five
examples are small multi-file projects with a `build_steps.sh` helper that runs `gcc -E`, `-S`, `-c`, the
link, `nm` and `size`; two are single files (one drives gcc from C, one shows where variables land).
Each folder is built by `tools/check.sh` from `main.c` and every other `.c` in it (the `.sh` is only a helper).

| # | File / folder | Flavour | What it teaches |
|---|---------------|---------|-----------------|
| 01 | `ex01_preprocessor_effects/` | MCU | Macros, `#ifdef`, `#if`/`#error`, `__LINE__`, stringify; `-DDEBUG_LOG`; `gcc -E` output |
| 02 | `ex02_three_file_led_project/` | MCU | `main.c` + `led.c` + `led.h`: separate compilation, `nm` letters (T U B D R), `size`, link, run |
| 03 | `ex03_link_error_demo/` | MCU | Three error classes and the stage that reports each: implicit declaration, undefined reference, multiple definition |
| 04 | `ex04_drive_gcc_stages.c` | LINUX | A C program runs `gcc -E/-S/-c/link` through `system()` and prints each intermediate file's size |
| 05 | `ex05_memory_sections.c` | LINUX | `.text`, `.rodata`, `.data`, `.bss`, stack, heap classified with linker symbols (`etext`, `edata`, `end`) |
| 06 | `ex06_freertos_config_macros/` | RTOS | `FreeRTOSConfig.h`-style macros select scheduler code and array sizes at build time; compare 3 builds |
| 07 | `ex07_same_source_other_target/` | MCU | Same source, different target: `sizeof`, `char` signedness, endianness, predefined macros, `-m32`, ARM cross-compile |

## Teaching notes
* Stage vs tool: preprocessor and compiler work on ONE `.c` file at a time; only the linker sees all `.o` files.
  Ex03 makes this concrete: three broken builds; the compiler catches the typo, only the linker can catch a
  missing or duplicated definition.
* `nm`: `U` = undefined (somebody else must provide it), `T` = code, `D` = initialised data, `B` = zeroed data,
  `R` = read-only data; lower case = `static` (file-private). Connect `size` columns (text/data/bss) to flash and RAM use.
* A header is a contract, not code: no function bodies and no variable definitions in `.h` files (topic 11).
* Ex06: a config macro is not a run-time switch. The cooperative build does not contain the preemptive code.
* Ex07 is the classic porting trap: `long` is 8 bytes on 64-bit Linux, 4 on Cortex-M, 4 on 64-bit Windows.
* Warn students: a forgotten `.c` file on the command line gives "undefined reference" (a linker error, every
  `.c` compiled fine), while a missing `-I` folder gives "No such file or directory" (a preprocessor error).

## Live-demo tips
* Open **Compiler Explorer (https://godbolt.org)**, choose "C" and an "ARM GCC (none)" compiler with
  `-mcpu=cortex-m4 -mthumb -O1`. Godbolt cannot see `hw_sim.h`, so paste this stand-in for `led_toggle()`:
  `#include <stdint.h>` then `#define ODR (*(volatile uint32_t *)0x40020014)` then
  `void led_toggle(void) { ODR ^= (1U << 5); }` - students see `ldr / eor / str` live.
* Run `./build_steps.sh` inside a project folder; it writes only into `build_out/`. Open the `.i` and `.s` files in VS Code.
* For ex03 pass the flag by hand: `gcc -DDEMO_BUG=1 main.c sensor.c` and ask "which program printed this, `cc1` or `ld`?".
* Install `gcc-arm-none-eabi` (optional): the scripts then also build for a Cortex-M and print its `size`.
