/*
 * ============================================================================
 *  Topic   : 02 The C Compilation Process
 *  Example : 02 - A three-file project: main.c + led.c + led.h, built in separate stages
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Each .c file is compiled on its own into an object file (.o) - a "translation
 *            unit". main.o only KNOWS that led_on() exists (from led.h); the LINKER later
 *            connects the call in main.o to the code in led.o. The header is the contract
 *            between the files; the .o files hold the real machine code and data.
 *  Embedded use : every firmware project is many .c files compiled separately and linked
 *            into one .elf; only changed files are recompiled (that is what make does).
 *  Real STM32F4 : arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -c led.c -o led.o
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../../common main.c led.c -o ex02
 *            or run  ./build_steps.sh  to see every stage (preprocess, compile, assemble, link)
 *  Output  : the LED on PA5 is switched on, off and toggled; the port register is printed
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Run ./build_steps.sh and find led_on in the output of nm main.o and nm led.o.
 *            2) Delete  led.o  from the link command: which error message do you get?
 * ============================================================================
 */
#include <stdio.h>
#include "led.h"                /* declarations only: no hardware details leak into main.c */

int main(void)
{
    printf("LED driver '%s', brightness %d%%\n", led_name, led_brightness_pct);

    led_init();
    led_report("after init");

    led_on();
    led_report("led_on()");
    led_off();
    led_report("led_off()");

    for (int i = 0; i < 3; i++) {
        led_toggle();
        led_wait_ms(500);
        led_report("led_toggle()");
    }

    printf("led_toggle() was called %u times, LED is now %s\n", led_toggle_count,
           led_is_on() ? "ON" : "off");
    return 0;
}
