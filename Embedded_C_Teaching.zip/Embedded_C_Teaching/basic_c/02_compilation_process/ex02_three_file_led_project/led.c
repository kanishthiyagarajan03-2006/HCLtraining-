/* led.c - the LED driver. The only file that knows which pin the LED is on.
 *
 * Why only this file includes hw_sim.h: its simulated registers are 'static inline' helpers,
 * so every .c file that includes it gets a PRIVATE copy of the "hardware". On a real chip the
 * registers exist once at a fixed address and every file sees the same ones.             */
#include "hw_sim.h"
#include "led.h"

#define LED_PIN 5U                      /* PA5, the user LED on a Nucleo board */

/* Where each kind of variable goes (see  nm led.o  in build_steps.sh):                 */
unsigned led_toggle_count;              /* global, zero-initialised  -> .bss    ('B')  */
int led_brightness_pct = 50;            /* global, initial value     -> .data   ('D')  */
const char led_name[] = "LD2 (PA5)";    /* global, constant          -> .rodata ('R')  */
static unsigned calls_to_led_on;        /* 'static': private to led.c -> lower case 'b' */

void led_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->MODER &= ~(3U << (LED_PIN * 2U));
    GPIOA->MODER |=  (1U << (LED_PIN * 2U));
}

void led_on(void)     { GPIOA->ODR |=  (1U << LED_PIN); calls_to_led_on++; }
void led_off(void)    { GPIOA->ODR &= ~(1U << LED_PIN); }
void led_toggle(void) { GPIOA->ODR ^=  (1U << LED_PIN); led_toggle_count++; }
int  led_is_on(void)  { return (GPIOA->ODR & (1U << LED_PIN)) != 0U; }

void led_wait_ms(uint32_t ms) { sim_delay_ms(ms); }

void led_report(const char *label)
{
    printf("%-14s ", label);
    sim_show_port("GPIOA", GPIOA);
}
