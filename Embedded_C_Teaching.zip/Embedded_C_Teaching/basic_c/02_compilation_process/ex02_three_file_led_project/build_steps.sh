#!/usr/bin/env bash
# ============================================================================
#  build_steps.sh - run the four compiler stages by hand on the 3-file LED project
#  Run from anywhere:   ./build_steps.sh      (everything is written to build_out/)
# ============================================================================
set -e
cd "$(dirname "$0")"
OUT=build_out
COMMON=../../../common
CFLAGS="-std=gnu11 -Wall -Wextra -I$COMMON"
rm -rf "$OUT"
mkdir "$OUT"

echo "== Stage 1  PREPROCESS   gcc -E led.c -> led.i  (headers pasted in, macros replaced) =="
gcc $CFLAGS -E led.c -o "$OUT/led.i"
echo "led.c: $(wc -l < led.c) lines   led.i: $(wc -l < "$OUT/led.i") lines"
echo

echo "== Stage 2  COMPILE      gcc -S led.c -> led.s  (C becomes assembly text) =="
gcc $CFLAGS -O0 -fno-asynchronous-unwind-tables -S led.c -o "$OUT/led.s"
echo "--- led_toggle() as x86-64 assembly (open $OUT/led.s to see everything) ---"
sed -n '/^led_toggle:/,/\.size.*led_toggle/p' "$OUT/led.s"
echo "(for a Cortex-M the same C gives  ldr / eor / str  instructions on the register address)"
echo

echo "== Stage 3  ASSEMBLE     gcc -c  -> led.o and main.o  (machine code, not yet runnable) =="
gcc $CFLAGS -c led.c  -o "$OUT/led.o"
gcc $CFLAGS -c main.c -o "$OUT/main.o"
ls -l "$OUT"/*.o | awk '{print $5 " bytes  " $9}'
echo

echo "== Symbols: nm main.o  (U = Undefined here: the linker must find them elsewhere) =="
nm "$OUT/main.o" | grep -E ' [TU] (led_|main|printf|puts)' || true
echo
echo "== Symbols: nm led.o   (T code, B .bss, D .data, R .rodata; lower case = file-private) =="
nm "$OUT/led.o" | grep -E ' [TBDRbd] (led_|calls_)' || true
echo

echo "== Stage 4  LINK         gcc main.o led.o -> led_app  (calls get connected) =="
gcc "$OUT/main.o" "$OUT/led.o" -o "$OUT/led_app"
echo "after linking, main's calls are resolved:"
nm "$OUT/led_app" | grep -E ' [TBDR] (led_|main)' || true
echo

echo "== size: the classic firmware report =="
echo "   (text = code + const, data = initialised RAM, bss = zeroed RAM)"
size "$OUT/main.o" "$OUT/led.o" "$OUT/led_app"
echo

echo "== LOAD + RUN: the loader maps led_app into memory and jumps to main =="
"$OUT/led_app" | head -n 6
echo "..."
echo

if command -v arm-none-eabi-gcc >/dev/null 2>&1; then
    echo "== Bonus: the same led.c for a Cortex-M4 =="
    arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -Os -I"$COMMON" -c led.c -o "$OUT/led_arm.o"
    arm-none-eabi-size "$OUT/led_arm.o"
else
    echo "(arm-none-eabi-gcc not installed: skipping the Cortex-M build. Try godbolt.org with an"
    echo " 'ARM gcc' compiler to see the same function as Thumb-2 instructions.)"
fi
