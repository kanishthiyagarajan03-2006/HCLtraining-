/* led.h - the PUBLIC face of the LED driver: declarations only, no code, no storage. */
#ifndef LED_H
#define LED_H

#include <stdint.h>

void led_init(void);                    /* declarations (prototypes): "this function exists"  */
void led_on(void);
void led_off(void);
void led_toggle(void);
int  led_is_on(void);
void led_wait_ms(uint32_t ms);          /* board delay, like HAL_Delay()                      */
void led_report(const char *label);     /* print the port, like a debugger watch window       */

extern unsigned led_toggle_count;       /* 'extern' = declared here, DEFINED in led.c         */
extern int led_brightness_pct;
extern const char led_name[];

#endif /* LED_H */
