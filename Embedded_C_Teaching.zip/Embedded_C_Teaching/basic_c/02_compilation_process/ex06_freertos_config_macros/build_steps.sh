#!/usr/bin/env bash
# ============================================================================
#  build_steps.sh - one source, three configurations: see how config macros change the program
#  Run from anywhere:   ./build_steps.sh      (binaries go to build_out/)
# ============================================================================
set -e
cd "$(dirname "$0")"
OUT=build_out
rm -rf "$OUT"
mkdir "$OUT"
CFLAGS="-std=gnu11 -Wall -Wextra"

echo "== The configuration the preprocessor sees (gcc -E -dM, only the config* macros) =="
gcc $CFLAGS -E -dM main.c | grep -E '^#define config' | sort
echo

build() {   # build <name> [-D flags]
    local name="$1"; shift
    gcc $CFLAGS "$@" main.c -o "$OUT/$name"
}
build preemptive
build cooperative -DconfigUSE_PREEMPTION=0
build traced      -DconfigUSE_TRACE_FACILITY=1

echo "== preemptive (default): the high-priority task takes the CPU as soon as it is ready =="
"$OUT/preemptive" | tail -n 9
echo
echo "== cooperative (-DconfigUSE_PREEMPTION=0): the running task is never interrupted =="
"$OUT/cooperative" | tail -n 9
echo
echo "== traced (-DconfigUSE_TRACE_FACILITY=1): extra code and an extra array are compiled in =="
"$OUT/traced" | tail -n 3
echo
echo "== size of each build: every config option has a price in flash and RAM =="
size "$OUT/preemptive" "$OUT/cooperative" "$OUT/traced"
