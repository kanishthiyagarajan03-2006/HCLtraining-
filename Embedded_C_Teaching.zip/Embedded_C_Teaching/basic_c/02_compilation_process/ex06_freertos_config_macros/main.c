/*
 * ============================================================================
 *  Topic   : 02 The C Compilation Process
 *  Example : 06 - FreeRTOSConfig.h style macros select code at compile time
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : An RTOS is configured by the PREPROCESSOR: #if configUSE_PREEMPTION keeps one
 *            scheduler policy and throws the other away before the compiler even sees it, and
 *            configMAX_PRIORITIES becomes the size of an array. Change a macro, rebuild, and
 *            you get a different program - not a run-time option, a different binary.
 *            This model has two tasks: LOGGER (low priority, long job) and ALARM (high priority,
 *            made ready by an "interrupt" at 30 ms). Who runs, and when, depends on one macro.
 *  Embedded use : FreeRTOSConfig.h is the first file you edit in any FreeRTOS project: tick
 *            rate, priorities, heap size, which kernel features to compile in (and pay for).
 *  Build   : gcc -std=gnu11 -Wall -Wextra main.c -o ex06
 *            then:  -DconfigUSE_PREEMPTION=0   or   -DconfigUSE_TRACE_FACILITY=1
 *            or run  ./build_steps.sh  to build all three and compare output and size
 *  Output  : a tick-by-tick schedule and the ALARM response time: 0 ms when preemptive,
 *            30 ms when cooperative (it must wait for LOGGER to finish)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -DconfigUSE_PREEMPTION=0: which line of the schedule changes?
 *            2) Set configTICK_RATE_HZ to 1000: what does one line of output now represent?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>
#include "FreeRTOSConfig.h"

#define MS_PER_TICK        (1000U / configTICK_RATE_HZ)
#define pdMS_TO_TICKS(ms)  ((uint32_t)(ms) * configTICK_RATE_HZ / 1000U)   /* same as FreeRTOS */

typedef struct {
    const char *name;
    unsigned    prio;           /* 0 = idle level ... configMAX_PRIORITIES - 1 = most urgent */
    uint32_t    ready_at;       /* tick at which an interrupt makes the task ready          */
    uint32_t    work_left;      /* ticks of CPU time still needed                            */
    int32_t     first_run;      /* tick when the task first got the CPU, -1 = not yet        */
} Task;

static Task tasks[] = {
    { "LOGGER", 1U, 0U,                    pdMS_TO_TICKS(60), -1 },
    { "ALARM",  3U, pdMS_TO_TICKS(30),     pdMS_TO_TICKS(20), -1 },
};
#define NTASKS (sizeof tasks / sizeof tasks[0])

static unsigned ready_count[configMAX_PRIORITIES];   /* one slot per priority level */
static unsigned assert_failures;

void vAssertCalled(const char *expr, int line)
{
    assert_failures++;
    printf("ASSERT FAILED: %s (main.c line %d)\n", expr, line);
}

static int is_ready(const Task *t, uint32_t now) { return t->work_left > 0U && t->ready_at <= now; }

static Task *pick_highest_ready(uint32_t now)
{
    Task *best = NULL;
    for (size_t i = 0; i < NTASKS; i++) {
        configASSERT(tasks[i].prio < configMAX_PRIORITIES);
        if (is_ready(&tasks[i], now) && (best == NULL || tasks[i].prio > best->prio))
            best = &tasks[i];
    }
    return best;
}

int main(void)
{
    printf("configUSE_PREEMPTION   = %d  (%s)\n", configUSE_PREEMPTION,
           configUSE_PREEMPTION ? "preemptive scheduler" : "cooperative scheduler");
    printf("configTICK_RATE_HZ     = %d  -> one tick = %u ms\n", configTICK_RATE_HZ, MS_PER_TICK);
    printf("configMAX_PRIORITIES   = %d  -> ready-list array has %zu slots\n", configMAX_PRIORITIES,
           sizeof ready_count / sizeof ready_count[0]);
    printf("configUSE_TRACE_FACILITY = %d\n\n", configUSE_TRACE_FACILITY);

#if configUSE_TRACE_FACILITY
    const char *trace[32];                 /* this array exists ONLY in a trace build */
    unsigned trace_n = 0U;
#endif

    Task *running = NULL;
    for (uint32_t tick = 0U; tick < 64U; tick++) {
        for (unsigned p = 0U; p < configMAX_PRIORITIES; p++) ready_count[p] = 0U;
        for (size_t i = 0; i < NTASKS; i++)
            if (is_ready(&tasks[i], tick)) ready_count[tasks[i].prio]++;

        const char *event = "";
        if (tick == tasks[1].ready_at) event = "  <- interrupt: ALARM is now ready";

        Task *before = running;
#if configUSE_PREEMPTION
        running = pick_highest_ready(tick);              /* re-decide on EVERY tick          */
#else
        if (running == NULL || running->work_left == 0U) /* only when the task gives up      */
            running = pick_highest_ready(tick);
#endif
        if (running == NULL) break;                      /* nothing left to do               */
        if (running->first_run < 0) running->first_run = (int32_t)tick;
        running->work_left--;

        int switched = (running != before && before != NULL);
        printf("%3u ms  ready by priority [3:%u 2:%u 1:%u 0:%u]  running %-6s%s%s\n",
               (unsigned)(tick * MS_PER_TICK), ready_count[3], ready_count[2], ready_count[1],
               ready_count[0], running->name, switched ? " (switch)" : "", event);
#if configUSE_TRACE_FACILITY
        if (running != before && trace_n < 32U) trace[trace_n++] = running->name;
#endif
    }

    unsigned response = (unsigned)((uint32_t)tasks[1].first_run - tasks[1].ready_at) * MS_PER_TICK;
    printf("\nALARM response time: %u ms after it became ready\n", response);
#if configUSE_TRACE_FACILITY
    printf("trace of context switches:");
    for (unsigned i = 0U; i < trace_n; i++) printf(" %s", trace[i]);
    putchar('\n');
#endif
    return (int)assert_failures;
}
