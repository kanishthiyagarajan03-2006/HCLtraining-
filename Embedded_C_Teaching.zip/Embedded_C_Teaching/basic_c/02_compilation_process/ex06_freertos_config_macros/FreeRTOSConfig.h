/* FreeRTOSConfig.h - the build-time switchboard of an RTOS (same names as real FreeRTOS).
 * The kernel source is compiled AGAINST this file, so a setting here changes which code and
 * which data structures exist at all. Each default can be overridden on the command line:
 *       gcc -DconfigUSE_PREEMPTION=0 ...                                                   */
#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

#ifndef configUSE_PREEMPTION
#  define configUSE_PREEMPTION        1        /* 1 = preemptive, 0 = cooperative scheduler */
#endif
#ifndef configTICK_RATE_HZ
#  define configTICK_RATE_HZ          100      /* tick interrupt frequency: 100 Hz = 10 ms  */
#endif
#ifndef configUSE_TRACE_FACILITY
#  define configUSE_TRACE_FACILITY    0        /* 1 = record every context switch           */
#endif

#define configMAX_PRIORITIES          4        /* sizes the ready-list array in the kernel  */
#define configMINIMAL_STACK_SIZE      128      /* idle task stack, in WORDS (512 bytes)     */
#define configCPU_CLOCK_HZ            16000000UL

#if (configTICK_RATE_HZ < 1) || (configTICK_RATE_HZ > 1000)
#  error "configTICK_RATE_HZ must be 1..1000 for this demo"
#endif

/* configASSERT: a failed assert must be impossible to ignore. Real firmware disables interrupts
 * and spins so a debugger can stop there; the demo only counts and reports. */
void vAssertCalled(const char *expr, int line);
#define configASSERT(x)  ((x) ? (void)0 : vAssertCalled(#x, __LINE__))

#endif /* FREERTOS_CONFIG_H */
