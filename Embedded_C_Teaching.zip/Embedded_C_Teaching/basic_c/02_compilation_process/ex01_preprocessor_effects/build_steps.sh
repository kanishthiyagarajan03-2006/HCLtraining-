#!/usr/bin/env bash
# ============================================================================
#  build_steps.sh - look at what the PREPROCESSOR does to main.c (stage 1 of 4)
#  Run from anywhere:   ./build_steps.sh        (needs gcc; nothing outside build_out/ is touched)
# ============================================================================
set -e
cd "$(dirname "$0")"
OUT=build_out
rm -rf "$OUT"
mkdir "$OUT"

echo "== Step 1: gcc -E main.c -o $OUT/main.i   (preprocess only, no compiling) =="
gcc -std=gnu11 -E main.c -o "$OUT/main.i"
echo "main.c has $(wc -l < main.c) lines, main.i has $(wc -l < "$OUT/main.i") lines"
echo "(open $OUT/main.i in VS Code: stdio.h and string.h were pasted in at the top)"
echo

echo "== Step 2: main() after preprocessing - macros replaced, comments gone =="
sed -n '/^int main/,$p' "$OUT/main.i" | grep -v '^$' | head -n 24
echo "..."
echo "(__func__ stays: it is not a macro. __FILE__ and __LINE__ became \"main.c\" and a number.)"
echo

echo "== Step 3: the same file with -DDEBUG_LOG: only a few lines of main() change =="
gcc -std=gnu11 -E -DDEBUG_LOG main.c -o "$OUT/main_debug.i"
diff <(sed -n '/^int main/,$p' "$OUT/main.i") <(sed -n '/^int main/,$p' "$OUT/main_debug.i") || true
echo

echo "== Step 4: macros the compiler defines for you  (gcc -E -dM) =="
echo "number of predefined macros: $(gcc -E -dM -x c /dev/null | wc -l)"
SHOW=' (__GNUC__|__linux__|__x86_64__|__SIZEOF_INT__|__BYTE_ORDER__) '
gcc -E -dM -x c /dev/null | grep -E "$SHOW" || true
echo "(arm-none-eabi-gcc defines __arm__, __ARM_ARCH_7EM__ ... instead: this is how"
echo " code detects its target)"
echo

echo "== Step 5: build and run both variants =="
gcc -std=gnu11 -Wall -Wextra main.c -o "$OUT/release"
gcc -std=gnu11 -Wall -Wextra -DDEBUG_LOG main.c -o "$OUT/debug"
echo "size of the two builds (the debug build carries the extra printf and its strings):"
size "$OUT/release" "$OUT/debug"
echo "--- release run (last 2 lines) ---"
"$OUT/release" | tail -n 2
echo "--- debug run (last 3 lines) ---"
"$OUT/debug" | tail -n 3
