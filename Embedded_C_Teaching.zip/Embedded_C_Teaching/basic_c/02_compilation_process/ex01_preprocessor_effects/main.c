/*
 * ============================================================================
 *  Topic   : 02 The C Compilation Process
 *  Example : 01 - What the preprocessor does: macros, __LINE__, #ifdef, -DDEBUG_LOG
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Stage 1 of compiling is the PREPROCESSOR. It knows nothing about C types: it
 *            pastes #include files in, replaces macros with text, keeps or drops #ifdef blocks
 *            and removes comments. The compiler proper only ever sees the result (gcc -E).
 *            Macro arguments are TEXT, so write SQUARE(x) as ((x) * (x)).
 *  Embedded use : debug logging that vanishes from the release build, board selection and
 *            pin maps are all done with macros - zero run-time cost, zero flash cost.
 *  Real STM32F4 : arm-none-eabi-gcc -DSTM32F446xx -DUSE_HAL_DRIVER -c main.c
 *  Build   : gcc -std=gnu11 -Wall -Wextra main.c -o ex01        (add -DDEBUG_LOG to see LOG())
 *            or run  ./build_steps.sh  to look at the preprocessed text (main.i)
 *  Output  : each macro printed as text and as value, __FILE__/__LINE__/__func__, and a RELEASE
 *            or DEBUG build note depending on -DDEBUG_LOG
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Compile with -DDEBUG_LOG and run: which line appears, and what is its LINE number?
 *            2) Set BLINK_MS to 505 in config.h. At which stage does the build stop?
 * ============================================================================
 */
#include <stdio.h>
#include "config.h"             /* quotes: look next to this file first, then the -I folders */

#define STR(x)   #x             /* stringify: the argument's TEXT becomes a string literal   */
#define XSTR(x)  STR(x)         /* two levels: macros inside x are expanded BEFORE stringify */
#define SQUARE(x) ((x) * (x))

int main(void)
{
    puts("--- What the preprocessor produced ---");
    printf("__FILE__, __LINE__ : %s, line %d\n", source_file(__FILE__), __LINE__);
    printf("__func__           : %s()   (not a macro: the compiler supplies it)\n", __func__);
    printf("__STDC_VERSION__   : %ld   (201112 = C11, 201710 = C17)\n", (long)__STDC_VERSION__);
    printf("LED_PIN            : %u\n", LED_PIN);
    printf("XSTR(LED_MASK)     : %s\n", XSTR(LED_MASK));
    printf("STR(LED_MASK)      : %s   (one level only: NOT expanded)\n", STR(LED_MASK));
    printf("LED_MASK (value)   : 0x%02X\n", LED_MASK);
    printf("XSTR(BLINK_TICKS)  : %s = %u\n", XSTR(BLINK_TICKS), BLINK_TICKS);
    printf("SQUARE(3 + 1)      : %d   (brackets in the macro give 16, not 7)\n", SQUARE(3 + 1));
    printf("firmware           : %s v%s\n", FW_NAME, FW_VERSION);

    LOG("this line exists only in a -DDEBUG_LOG build");

#ifdef DEBUG_LOG
    puts("build type         : DEBUG   (LOG() calls printf)");
#else
    puts("build type         : RELEASE (LOG() was replaced by ((void)0))");
#endif
    /* __DATE__ and __TIME__ also exist, but they change on every build, so they are not
     * printed here. Embedded products store them in flash as a build stamp. */
    return 0;
}
