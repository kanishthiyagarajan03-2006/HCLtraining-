/* config.h - build-time configuration: plain TEXT that the preprocessor substitutes. */
#ifndef CONFIG_H                /* include guard: a second #include of this file becomes empty */
#define CONFIG_H

#include <stdio.h>
#include <string.h>

#define LED_PIN      5U
#define LED_MASK     (1U << LED_PIN)         /* uses LED_PIN: macros may build on macros */
#define TICK_MS      10U
#define BLINK_MS     500U
#define BLINK_TICKS  (BLINK_MS / TICK_MS)

#define FW_NAME      "blinky"
#define FW_VERSION   "1.2"

/* Compile-time check: stops the build (preprocessing stage!) if the numbers do not fit. */
#if (BLINK_MS % TICK_MS) != 0U
#  error "BLINK_MS must be a multiple of TICK_MS"
#endif

/* __FILE__ is whatever path the compiler was given; keep only the file name for printing. */
static inline const char *source_file(const char *path)
{
    const char *slash = strrchr(path, '/');
    return (slash != NULL) ? slash + 1 : path;
}

/* Debug logging is switched on by the compiler command line:  gcc -DDEBUG_LOG ...
 * Without it LOG(msg) is replaced by ((void)0): no code, no strings, no flash space used. */
#ifdef DEBUG_LOG
#  define LOG(msg) printf("  [debug] %s:%d in %s(): %s\n", source_file(__FILE__), __LINE__, \
                          __func__, (msg))
#else
#  define LOG(msg) ((void)0)
#endif

#endif /* CONFIG_H */
