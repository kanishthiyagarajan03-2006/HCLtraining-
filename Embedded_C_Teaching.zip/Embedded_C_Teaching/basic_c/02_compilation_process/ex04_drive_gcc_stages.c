/*
 * ============================================================================
 *  Topic   : 02 The C Compilation Process
 *  Example : 04 - Drive the real gcc stages from C and measure every intermediate file
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : gcc is a driver that runs four programs in turn:
 *              gcc -E  : preprocess   tiny.c -> tiny.i   (text)
 *              gcc -S  : compile      tiny.i -> tiny.s   (assembly text)
 *              gcc -c  : assemble     tiny.s -> tiny.o   (machine code, not runnable)
 *              gcc     : link         tiny.o -> tiny     (executable: symbols resolved, layout set)
 *            This program writes a 6-line C file, runs each stage with system() and prints how
 *            big every result is, what the macro became, and the final exit status.
 *  Embedded use : the same four stages run inside arm-none-eabi-gcc; its last stage also needs
 *            a linker script and produces an .elf that is converted to a .bin/.hex for flashing.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex04_drive_gcc_stages.c -o ex04
 *  Output  : a table  stage / command / output file / size in bytes  (numbers depend on your
 *            gcc version), the line of tiny.i where LED_MASK was replaced, and exit status 16
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add -O2 to the compile stage. How does tiny.s shrink?
 *            2) Add  #include <stdio.h>  to TINY_SOURCE: how much bigger does tiny.i become?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

/* The C program we compile. It has no #include, so tiny.i stays tiny and readable. */
static const char TINY_SOURCE[] =
    "#define LED_PIN  5\n"
    "#define LED_MASK (1U << LED_PIN)\n"
    "unsigned odr = 0;\n"
    "int main(void)\n"
    "{\n"
    "    odr |= LED_MASK;                  /* set PA5 */\n"
    "    return (int)(odr >> 1);           /* 32 >> 1 = 16: the exit status */\n"
    "}\n";

static long file_size(const char *path)
{
    struct stat st;
    return (stat(path, &st) == 0) ? (long)st.st_size : -1L;
}

/* Run "cd dir && cmd" quietly; return the command's exit status (-1 if it could not run). */
static int run_in(const char *dir, const char *cmd)
{
    char line[256];
    snprintf(line, sizeof line, "cd %s && %s > /dev/null 2>&1", dir, cmd);
    int st = system(line);
    return (st != -1 && WIFEXITED(st)) ? WEXITSTATUS(st) : -1;
}

static void stage(const char *dir, const char *name, const char *cmd, const char *outfile)
{
    char path[128];
    snprintf(path, sizeof path, "%s/%s", dir, outfile);
    int rc = run_in(dir, cmd);
    printf("%-11s %-26s %-8s ", name, cmd, outfile);
    if (rc == 0) printf("%6ld bytes\n", file_size(path));
    else         printf("FAILED (status %d)\n", rc);
}

static void remove_in(const char *dir, const char *name)
{
    char path[128];
    snprintf(path, sizeof path, "%s/%s", dir, name);
    remove(path);                                       /* ignore "does not exist" */
}

int main(void)
{
    if (system("gcc --version > /dev/null 2>&1") != 0) {
        puts("gcc was not found on this machine, so the stages cannot be run here.");
        puts("On a machine with gcc this program would run:  gcc -E, gcc -S, gcc -c, gcc (link)");
        return 0;                                       /* graceful: not an error */
    }

    char dir[] = "/tmp/ex04_XXXXXX";
    if (mkdtemp(dir) == NULL) { perror("mkdtemp"); return 1; }

    char src[128];
    snprintf(src, sizeof src, "%s/tiny.c", dir);
    FILE *f = fopen(src, "w");
    if (f == NULL) { perror("fopen"); rmdir(dir); return 1; }
    fputs(TINY_SOURCE, f);
    fclose(f);

    printf("%-11s %-26s %-8s %s\n", "stage", "command", "output", "size");
    printf("%-11s %-26s %-8s %6ld bytes\n", "source", "(you wrote it)", "tiny.c", file_size(src));
    stage(dir, "preprocess", "gcc -E tiny.c -o tiny.i", "tiny.i");
    stage(dir, "compile",    "gcc -S tiny.i -o tiny.s", "tiny.s");
    stage(dir, "assemble",   "gcc -c tiny.s -o tiny.o", "tiny.o");
    stage(dir, "link",       "gcc tiny.o -o tiny",      "tiny");

    char path[128];
    snprintf(path, sizeof path, "%s/tiny.i", dir);
    f = fopen(path, "r");
    if (f != NULL) {
        char line[160];
        while (fgets(line, sizeof line, f) != NULL)
            if (strstr(line, "odr |=") != NULL)
                printf("\nin tiny.i, 'odr |= LED_MASK;' became:  %s", line);
        fclose(f);
    }

    int status = run_in(dir, "./tiny");                 /* the LOAD stage: the OS runs it */
    printf("run tiny    : exit status %d (expected 16)\n", status);

    remove_in(dir, "tiny.c"); remove_in(dir, "tiny.i"); remove_in(dir, "tiny.s");
    remove_in(dir, "tiny.o"); remove_in(dir, "tiny");
    rmdir(dir);
    return (status == 16) ? 0 : 1;
}
