#!/usr/bin/env bash
# ============================================================================
#  build_steps.sh - compile ONE source for several targets and compare
#  Run from anywhere:   ./build_steps.sh      (needs gcc; -m32 and ARM are optional extras)
#  Tip: godbolt.org (Compiler Explorer) does the same in the browser: pick "ARM gcc" and
#       watch the assembly change when you switch compiler or add -Os.
# ============================================================================
cd "$(dirname "$0")" || exit 1
OUT=build_out
rm -rf "$OUT"
mkdir "$OUT"
CFLAGS="-std=gnu11 -Wall -Wextra"

echo "== Target 1: this machine ($(gcc -dumpmachine)) =="
gcc $CFLAGS main.c -o "$OUT/native" || exit 1
"$OUT/native" | sed -n '1p;/^  long /p;/^  void \*/p;/CHAR_MIN/p'
echo

echo "== Target 2: 32-bit x86 (gcc -m32) - same CPU family, different ABI =="
if gcc $CFLAGS -m32 main.c -o "$OUT/native32" 2> "$OUT/m32.err"; then
    "$OUT/native32" | sed -n '1p;/^  long /p;/^  void \*/p'
else
    echo "(skipped: this gcc has no 32-bit support: 'sudo apt install gcc-multilib' adds it)"
fi
echo

echo "== Target 3: Cortex-M4 firmware (arm-none-eabi-gcc -c: compile only, nothing to run it on) =="
if command -v arm-none-eabi-gcc >/dev/null 2>&1; then
    arm-none-eabi-gcc $CFLAGS -mcpu=cortex-m4 -mthumb -Os -c main.c -o "$OUT/main_m4.o"
    arm-none-eabi-size "$OUT/main_m4.o"
    SHOW='__ARM_ARCH_7EM__|__SIZEOF_LONG__|__SIZEOF_POINTER__'
    arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -dM -E -x c /dev/null | grep -E "$SHOW"
else
    echo "(skipped: arm-none-eabi-gcc is not installed. Install the 'gcc-arm-none-eabi' package, or"
    echo " use godbolt.org with the compiler 'ARM GCC (none)' and flags  -mcpu=cortex-m4 -mthumb)"
fi
echo

echo "== Native, but with unsigned plain char (what ARM does by default) =="
gcc $CFLAGS -funsigned-char main.c -o "$OUT/unsigned_char"
"$OUT/unsigned_char" | sed -n '/CHAR_MIN/,/stored/p'
