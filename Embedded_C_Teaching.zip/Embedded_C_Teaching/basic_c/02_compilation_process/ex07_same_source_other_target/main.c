/*
 * ============================================================================
 *  Topic   : 02 The C Compilation Process
 *  Example : 07 - Same source, different target: type sizes, char signedness, endianness
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : The compiler translates C for ONE target (CPU + ABI) at a time. The language does
 *            not fix the size of int/long/pointers, whether plain char is signed, or the byte
 *            order; the target does. So the same main.c prints different answers when it is
 *            compiled for a PC, a 32-bit board or a Cortex-M. Predefined macros (__x86_64__,
 *            __arm__ ...) tell the code which target it is being built for.
 *  Embedded use : code ported from a PC to an MCU breaks on exactly these differences: long is
 *            8 bytes on 64-bit Linux but 4 on Cortex-M; char is signed on x86 but unsigned on
 *            ARM; pointers shrink from 8 to 4 bytes. Fixed-width types (stdint.h) avoid it.
 *  Real STM32F4 : arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -c main.c
 *  Build   : gcc -std=gnu11 -Wall -Wextra main.c -o ex07
 *            or run  ./build_steps.sh  to build for native 64-bit, 32-bit and ARM if installed
 *  Output  : the target name, a table of type sizes, plain-char signedness and byte order of
 *            THIS machine, and what a Cortex-M would print instead
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Compile with -funsigned-char. Which line of the output changes?
 *            2) Compile with -m32 (if your gcc has 32-bit support). Which sizes shrink?
 * ============================================================================
 */
#include <inttypes.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>

/* Which target are we being compiled for? Decided by the compiler, not by the program. */
static const char *target_name(void)
{
#if defined(__x86_64__)
    return "x86-64 (64-bit PC)";
#elif defined(__i386__)
    return "x86 (32-bit)";
#elif defined(__aarch64__)
    return "AArch64 (64-bit ARM, e.g. Raspberry Pi 4/5)";
#elif defined(__ARM_ARCH_7EM__)
    return "ARM Cortex-M4/M7 (ARMv7E-M)";
#elif defined(__ARM_ARCH_6M__)
    return "ARM Cortex-M0/M0+ (ARMv6-M)";
#elif defined(__arm__)
    return "ARM 32-bit";
#else
    return "unknown target";
#endif
}

/* One table row: the type's name (via #), its size HERE, and what a Cortex-M4 gives. */
#define TYPE_ROW(T, cortex_m4) printf("  %-12s %-9zu %s\n", #T, sizeof(T), cortex_m4)

int main(void)
{
    printf("compiled for : %s\n", target_name());
    printf("compiler     : gcc %d.%d\n\n", __GNUC__, __GNUC_MINOR__);

    puts("--- sizeof on THIS target (what changes on a Cortex-M is in the second column) ---");
    printf("  %-12s %-9s %s\n", "type", "here", "Cortex-M4 (arm-none-eabi)");
    TYPE_ROW(char,      "1");
    TYPE_ROW(short,     "2");
    TYPE_ROW(int,       "4");
    TYPE_ROW(long,      "4   <- differs from 64-bit Linux!");
    TYPE_ROW(long long, "8");
    TYPE_ROW(void *,    "4   <- differs from a 64-bit PC");
    TYPE_ROW(size_t,    "4");
    TYPE_ROW(float,     "4   (hardware FPU on a Cortex-M4F)");
    TYPE_ROW(double,    "8   (software on a Cortex-M4F: slow!)");
    TYPE_ROW(int32_t,   "4   same everywhere: use these");
    TYPE_ROW(uint8_t,   "1   same everywhere");
    puts("\n--- plain char: signed or unsigned? (the language leaves it to the target) ---");
    printf("  CHAR_MIN = %d  -> plain char is %s here (ARM gcc: unsigned)\n", CHAR_MIN,
           (CHAR_MIN < 0) ? "SIGNED" : "unsigned");
    char c = (char)200;                                 /* 200 does not fit in a signed char */
    printf("  (char)200 stored, read back as int: %d   (x86 gives -56, ARM gives 200)\n", (int)c);

    puts("\n--- byte order ---");
    uint32_t word = 0x11223344U;
    const uint8_t *bytes = (const uint8_t *)&word;      /* look at the same memory byte by byte */
    printf("  0x11223344 is stored as: %02X %02X %02X %02X  -> %s-endian (Cortex-M: little)\n",
           bytes[0], bytes[1], bytes[2], bytes[3], (bytes[0] == 0x44U) ? "little" : "big");
#ifdef __BYTE_ORDER__
    printf("  the compiler's own macro agrees: __BYTE_ORDER__ %s __ORDER_LITTLE_ENDIAN__\n",
           (__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__) ? "==" : "!=");
#endif

    printf("\nlongest value in a 'long' here: %ld\n", LONG_MAX);
    printf("UINT32_MAX (fixed width, same on every target): %" PRIu32 "\n", (uint32_t)UINT32_MAX);
    return 0;
}
