/* sensor.c - a fake 12-bit sensor driver. Note: sensor_calibrate() is NOT defined here. */
#include "sensor.h"

uint16_t sensor_read_raw(void)
{
    static const uint16_t script[] = { 2048, 2051, 2047, 2050 };
    static unsigned next;
    return script[next++ % (sizeof script / sizeof script[0])];
}
