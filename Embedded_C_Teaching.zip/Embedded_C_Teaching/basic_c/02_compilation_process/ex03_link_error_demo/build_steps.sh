#!/usr/bin/env bash
# ============================================================================
#  build_steps.sh - run the normal build and the three broken builds, stage by stage
#  Run from anywhere:   ./build_steps.sh      (objects go to build_out/)
#  Every failure below is EXPECTED: read which stage reports it.
# ============================================================================
cd "$(dirname "$0")" || exit 1
OUT=build_out
# Make a missing declaration an error on every gcc version (new gcc does this by default).
CFLAGS="-std=gnu11 -Wall -Wextra -Werror=implicit-function-declaration"
rm -rf "$OUT"
mkdir "$OUT"

# try_build <label> [extra compiler flags]  - compile each .c, then link, reporting each stage
try_build() {
    local label="$1"; shift
    local ok=1
    echo "=================== $label ==================="
    for f in main.c sensor.c; do
        if gcc $CFLAGS "$@" -c "$f" -o "$OUT/${f%.c}.o" 2> "$OUT/err.txt"; then
            echo "  COMPILE $f ... ok"
        else
            echo "  COMPILE $f ... FAILED   <- stage 2 (compiler), message:"
            sed 's/^/      /' "$OUT/err.txt" | head -n 4
            ok=0
        fi
    done
    if [ $ok -eq 0 ]; then
        echo "  LINK ... not reached"
    elif gcc "$OUT/main.o" "$OUT/sensor.o" -o "$OUT/prog" 2> "$OUT/err.txt"; then
        echo "  LINK ... ok"
        echo "  RUN: $("$OUT/prog" | tail -n 1)"
    else
        echo "  LINK ... FAILED   <- stage 4 (linker), message:"
        sed 's/^/      /' "$OUT/err.txt" | head -n 4
    fi
    echo
}

try_build "normal build"
try_build "DEMO_BUG=1  declared but never defined" -DDEMO_BUG=1
try_build "DEMO_BUG=2  typo in a function name"    -DDEMO_BUG=2
try_build "DEMO_BUG=3  defined twice"              -DDEMO_BUG=3

echo "Summary: the compiler checks ONE file at a time against declarations;"
echo "only the linker sees all object files together."
