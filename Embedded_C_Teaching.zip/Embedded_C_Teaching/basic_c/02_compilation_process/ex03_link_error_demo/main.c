/*
 * ============================================================================
 *  Topic   : 02 The C Compilation Process
 *  Example : 03 - Three error classes, three stages: preprocessor/compiler vs linker
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : An error message tells you WHICH STAGE failed. 'implicit declaration' comes from
 *            the compiler: it saw a name that was never declared. 'undefined reference' comes
 *            from the LINKER: the name was declared (so every .c compiled) but no object file
 *            contains the code. 'multiple definition' is also a linker error: two .o files both
 *            define the same name. A declaration (prototype) is not a definition.
 *  Embedded use : "undefined reference to ..." is the most common build error when you add a
 *            driver file to the source tree but forget to add it to the Makefile / IDE project.
 *  Real STM32F4 : arm-none-eabi-gcc main.o -o fw.elf  ->  undefined reference to `HAL_GPIO_Init'
 *            (the usual symptom of forgetting stm32f4xx_hal_gpio.c in the project)
 *  Build   : gcc -std=gnu11 -Wall -Wextra main.c sensor.c -o ex03
 *            then try  -DDEMO_BUG=1  (linker),  -DDEMO_BUG=2  (compiler),  -DDEMO_BUG=3  (linker)
 *            or run  ./build_steps.sh  to see all four builds and where each one stops
 *  Output  : the default build converts four raw ADC readings to millivolts
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -DDEMO_BUG=1 and find the word "undefined" in the message. Which
 *               program printed it: cc1 (compiler) or ld (linker)?
 *            2) Make DEMO_BUG=1 build by writing sensor_calibrate() in sensor.c.
 * ============================================================================
 */
#include <stdio.h>
#include "sensor.h"

#if defined(DEMO_BUG) && DEMO_BUG == 3
/* BUG 3: a second definition of sensor_read_raw. Both main.c and sensor.c compile happily on
 * their own; the linker then finds the same name in two object files:
 *   multiple definition of `sensor_read_raw'                                              */
uint16_t sensor_read_raw(void) { return 0U; }
#endif

int main(void)
{
    puts("raw  -> millivolts (12-bit ADC, 3.3 V reference)");
    for (int i = 0; i < 4; i++) {
        uint16_t raw = sensor_read_raw();
        printf("%4u -> %4u mV\n", (unsigned)raw, (unsigned)(((uint32_t)raw * 3300U) / 4095U));
    }

#if defined(DEMO_BUG) && DEMO_BUG == 1
    /* BUG 1: declared in sensor.h, so the COMPILER is satisfied, but no .c file defines it.
     * Stage that fails: LINK.   Message: undefined reference to `sensor_calibrate'          */
    sensor_calibrate();
#endif
#if defined(DEMO_BUG) && DEMO_BUG == 2
    /* BUG 2: a typo. The name was never declared anywhere. Stage that fails: COMPILE.
     * Message: implicit declaration of function 'sensor_read_rwa'
     * (gcc 14 and newer make this an error by default; older gcc only WARNS and the linker
     * then complains. Add -Werror=implicit-function-declaration to get the same everywhere.) */
    sensor_read_rwa();
#endif

    puts("all stages succeeded: preprocess, compile, assemble, link");
    return 0;
}
