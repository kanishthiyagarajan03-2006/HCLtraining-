/* sensor.h - the contract for the sensor module. */
#ifndef SENSOR_H
#define SENSOR_H

#include <stdint.h>

uint16_t sensor_read_raw(void);         /* defined in sensor.c                              */
int sensor_calibrate(void);             /* PROMISED here, but sensor.c never implements it  */

#endif /* SENSOR_H */
