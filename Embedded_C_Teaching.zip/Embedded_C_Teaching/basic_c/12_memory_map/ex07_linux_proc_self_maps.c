/*
 * ============================================================================
 *  Topic   : 12 Memory Map
 *  Example : 07 - A Linux process memory map: linker symbols and /proc/self/maps
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A Linux process has the same sections as firmware (.text, .rodata, .data,
 *            .bss, heap, stack) but at VIRTUAL addresses, each region with permissions:
 *            r-x code, r-- constants, rw- data/heap/stack. The linker exports symbols
 *            etext, edata and end marking where those sections stop. The kernel lists
 *            every region of a process in the text file /proc/self/maps.
 *  Embedded use : on an embedded Linux board, /proc/<pid>/maps shows where a daemon's memory
 *            goes (shared libraries, heap, stack); a SIGSEGV address can be matched to
 *            a region exactly as ex02 did for a HardFault on a Cortex-M.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex07_linux_proc_self_maps.c -o ex07
 *            Look at the full list yourself:  cat /proc/self/maps | head
 *  Output  : the linker symbols, then for six objects the permissions and name of the
 *            mapping that contains them (addresses change on every run: ASLR). A plain
 *            build shows [heap] and [stack]; with AddressSanitizer both look anonymous.
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Run it twice: which numbers change (addresses) and which stay (perms)?
 *            2) Add a 1 MB malloc: is it in [heap] or in an anonymous mmap region?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Symbols created by the GNU linker: we only take their ADDRESS, never their value. */
extern char etext;     /* end of .text   */
extern char edata;     /* end of .data   */
extern char end;       /* end of .bss    */

static const char g_rodata[] = "read-only text";   /* .rodata */
static int g_data = 17;                            /* .data   */
static int g_bss;                                  /* .bss    */

/* Find the line of /proc/self/maps that contains 'addr' and describe it. */
static void describe(const char *what, const void *addr)
{
    FILE *f = fopen("/proc/self/maps", "r");
    if (f == NULL) {
        printf("  %-22s (cannot open /proc/self/maps here)\n", what);
        return;
    }
    char line[512];
    int found = 0;
    while (fgets(line, sizeof line, f) != NULL) {
        unsigned long lo, hi;
        char perms[8];
        int name_at = 0;
        if (sscanf(line, "%lx-%lx %7s %*s %*s %*s %n", &lo, &hi, perms, &name_at) < 3)
            continue;
        if ((uintptr_t)addr < lo || (uintptr_t)addr >= hi) continue;

        const char *name = line + name_at;
        line[strcspn(line, "\n")] = '\0';
        const char *slash = strrchr(name, '/');            /* show the file name only */
        if (slash != NULL) name = slash + 1;
        printf("  %-22s %p  %s  %s\n", what, addr, perms, (*name != '\0') ? name : "(anonymous)");
        found = 1;
        break;
    }
    if (!found) printf("  %-22s %p  (no mapping found)\n", what, addr);
    fclose(f);
}

int main(void)
{
    printf("Linker symbols (section boundaries):\n");
    printf("  etext = %p   end of .text (code)\n", (void *)&etext);
    printf("  edata = %p   end of .data\n", (void *)&edata);
    printf("  end   = %p   end of .bss, the heap would start after it\n", (void *)&end);
    printf("  etext <= edata <= end ? %s\n",
           ((uintptr_t)&etext <= (uintptr_t)&edata && (uintptr_t)&edata <= (uintptr_t)&end)
               ? "yes" : "no (this linker orders sections differently)");

    int local = 1;
    char *block = (char *)malloc(64);
    if (block == NULL) return 1;
    snprintf(block, 64, "heap");

    printf("\nWhich mapping holds each object?   (object, address, permissions, mapping)\n");
    describe("main() code",   (const void *)(uintptr_t)main);
    describe("g_rodata[]",    (const void *)g_rodata);
    describe("g_data (.data)", (const void *)&g_data);
    describe("g_bss  (.bss)", (const void *)&g_bss);
    describe("malloc(64) block", (const void *)block);
    describe("local variable", (const void *)&local);

    printf("\nPermissions: r-x code can run but not be written; r-- constants are protected;\n");
    printf("rw- data/heap/stack can be written but never executed. On a Cortex-M the MPU\n");
    printf("(memory protection unit) can enforce the same rules if you configure it.\n");
    free(block);
    return 0;
}
