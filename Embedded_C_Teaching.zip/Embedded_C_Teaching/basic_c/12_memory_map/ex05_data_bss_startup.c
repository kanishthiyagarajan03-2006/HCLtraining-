/*
 * ============================================================================
 *  Topic   : 12 Memory Map
 *  Example : 05 - Start-up code: copy .data from Flash, zero .bss, THEN run main()
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : When power comes on, SRAM holds random garbage. C promises that
 *                int a = 5;   starts as 5      (initialised global -> .data)
 *                int b;       starts as 0      (uninitialised global -> .bss)
 *            The compiler cannot keep that promise alone, so the Reset_Handler does it
 *            BEFORE main(): copy the initial values from their Flash image into RAM, and
 *            fill the .bss range with zeros. The linker script gives the ranges as symbols
 *            (_sidata, _sdata, _edata, _sbss, _ebss). Here a struct stands in for SRAM.
 *  Embedded use : explains why .data costs Flash AND RAM, why uninitialised globals are 0,
 *            and why a bug in start-up code breaks every global variable at once.
 *  Real STM32F4 : startup_stm32f446xx.s: LDR R0,=_sdata ... copy loop ... then bss loop.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex05_data_bss_startup.c -o ex05
 *  Output  : a hex dump of the fake SRAM before start-up (garbage 0xDE), after the .data
 *            copy, and after the .bss clear, plus the variables read as C code sees them
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Comment out the .bss clearing loop: which variables are now wrong?
 *            2) Add a field to data_t with a non-zero initial value; what changes in the dump?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

/* The two kinds of globals, as structs so we control the layout of our fake SRAM. */
typedef struct {            /* .data: initialised variables                */
    uint32_t baud;
    uint32_t timeout_ms;
    uint8_t  mode;
} data_t;

typedef struct {            /* .bss: variables without an initialiser      */
    uint32_t rx_count;
    uint8_t  rx_buf[8];
    uint16_t errors;
} bss_t;

typedef struct {            /* the whole fake SRAM: .data first, then .bss */
    data_t data;
    bss_t  bss;
} sram_t;

/* The Flash image of .data: this is what the compiler stored for "int baud = 115200;".
 * In the dump, 115200 = 0x0001C200 shows up as bytes 00 C2 01 00 (little-endian).     */
static const data_t flash_data_image = { 115200U, 250U, 3U };

static sram_t sram;                              /* stands for SRAM at 0x20000000 */

static void dump(const char *title)
{
    const uint8_t *p = (const uint8_t *)&sram;
    printf("%s\n", title);
    for (size_t off = 0; off < sizeof sram; off += 4) {      /* one 32-bit word per row */
        printf("  +%02zu:", off);
        for (size_t i = off; i < off + 4 && i < sizeof sram; i++)
            printf(" %02X", (unsigned)p[i]);
        if (off == 0)                    printf("   <- .data starts");
        if (off == sizeof(data_t))       printf("   <- .bss starts");
        printf("\n");
    }
}

static void show_variables(void)
{
    printf("  baud=0x%08X timeout=0x%08X mode=0x%02X | rx_count=0x%08X errors=0x%04X\n",
           (unsigned)sram.data.baud, (unsigned)sram.data.timeout_ms, (unsigned)sram.data.mode,
           (unsigned)sram.bss.rx_count, (unsigned)sram.bss.errors);
}

/* What the assembly start-up code does with the linker-script symbols. */
static void startup(void)
{
    const uint8_t *src = (const uint8_t *)&flash_data_image;   /* _sidata: image in Flash */
    uint8_t *dst       = (uint8_t *)&sram.data;                /* _sdata  */
    uint8_t *edata     = dst + sizeof sram.data;               /* _edata  */
    while (dst < edata) *dst++ = *src++;                       /* copy .data Flash -> RAM */
    printf("  .data copied: %zu bytes Flash -> RAM\n", sizeof sram.data);
    dump("SRAM after the .data copy (bss area still garbage)");
    show_variables();

    uint8_t *sbss = (uint8_t *)&sram.bss;                      /* _sbss */
    uint8_t *ebss = sbss + sizeof sram.bss;                    /* _ebss */
    for (uint8_t *p = sbss; p < ebss; p++) *p = 0;             /* clear .bss */
    printf("  .bss cleared: %zu bytes set to 0\n", sizeof sram.bss);
}

int main(void)
{
    memset(&sram, 0xDE, sizeof sram);            /* power-on SRAM: unpredictable contents */

    dump("SRAM at power-on (garbage)");
    show_variables();
    printf("\nReset_Handler runs start-up code:\n");
    startup();

    printf("\n");
    dump("SRAM when main() starts");
    show_variables();

    printf("\nResult: baud == %u as initialised, rx_count == %u as guaranteed by C.\n",
           (unsigned)sram.data.baud, (unsigned)sram.bss.rx_count);
    printf("Cost: .data = %zu bytes of Flash AND RAM, .bss = %zu bytes of RAM only.\n",
           sizeof(data_t), sizeof(bss_t));
    return 0;
}
