/*
 * ============================================================================
 *  Topic   : 12 Memory Map
 *  Example : 03 - Flash and RAM budget: text / data / bss like arm-none-eabi-size
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : What you declare decides which memory you spend:
 *              const table            -> Flash only          (.rodata)
 *              initialised variable   -> Flash AND RAM       (.data: image + working copy)
 *              zero-initialised array -> RAM only            (.bss)
 *              + heap and stack reserve in RAM
 *            sizeof() of the real objects gives the numbers, and _Static_assert makes the
 *            compiler refuse a design that does not fit in the chip.
 *  Embedded use : a 128 KB RAM part fills up quickly with buffers. The linker reports
 *            "region 'RAM' overflowed by N bytes"; here you see the same arithmetic.
 *  Real STM32F4 : arm-none-eabi-size firmware.elf  ->  text  data  bss  dec  hex
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex03_flash_ram_budget.c -o ex03
 *  Output  : an "arm-none-eabi-size" style line and a usage table for Flash and RAM
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Make adc_history 20000 samples: how much RAM is left? Then try 30000.
 *            2) Compile with -DDEMO_BUG: a 200 KB buffer makes _Static_assert fail the build.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

/* ---- the chip: STM32F446RE-like ---------------------------------------------- */
#define FLASH_BYTES     (512U * 1024U)
#define SRAM_BYTES      (128U * 1024U)

/* ---- what we reserve for the run-time -------------------------------------------- */
#define HEAP_BYTES      (8U * 1024U)       /* e.g. for an RTOS or malloc()          */
#define STACK_BYTES     (4U * 1024U)       /* main stack, sized from measurements   */

/* ---- our data, each in a different section ------------------------------------ */
#define CODE_BYTES      21500U             /* .text size: read it from the map file */

static const uint8_t  font_5x7[96][5] = { { 0x7E, 0x11, 0x11, 0x11, 0x7E } };   /* .rodata */
static const uint16_t sine_lut[256]   = { 2048, 2098, 2148 };                   /* .rodata */

static uint32_t cal_gain          = 1000;                                       /* .data */
static uint16_t cal_offsets[64]   = { 3, 1, 4, 1, 5 };                          /* .data */

static uint8_t  uart_rx_buf[512];                                               /* .bss  */
static uint32_t adc_history[2048];                                              /* .bss  */

#ifdef DEMO_BUG
static uint8_t huge_buffer[200U * 1024U];  /* bigger than all of SRAM */
#  define EXTRA_BSS  sizeof(huge_buffer)
#else
#  define EXTRA_BSS  0U
#endif

#define RODATA_BYTES  (sizeof font_5x7 + sizeof sine_lut)
#define DATA_BYTES    (sizeof cal_gain + sizeof cal_offsets)
#define BSS_BYTES     (sizeof uart_rx_buf + sizeof adc_history + EXTRA_BSS)

#define TEXT_TOTAL    (CODE_BYTES + RODATA_BYTES)             /* what "size" calls text */
#define FLASH_USED    (TEXT_TOTAL + DATA_BYTES)               /* data image is stored in Flash */
#define RAM_STATIC    (DATA_BYTES + BSS_BYTES)
#define RAM_USED      (RAM_STATIC + HEAP_BYTES + STACK_BYTES)

/* The build fails with these messages if the design does not fit. */
_Static_assert(FLASH_USED <= FLASH_BYTES, "program does not fit in Flash");
_Static_assert(RAM_USED   <= SRAM_BYTES,  "data + heap + stack do not fit in SRAM");

static void usage_line(const char *name, unsigned used, unsigned total)
{
    unsigned permille = (unsigned)(((unsigned long long)used * 1000ULL) / total);
    printf("  %-6s %7u of %7u bytes used (%u.%u %%), %7u free\n", name, used, total,
           permille / 10U, permille % 10U, total - used);
}

int main(void)
{
    /* Touch the tables so the compiler keeps them (and to show they are real objects). */
    unsigned check = font_5x7[0][0] + sine_lut[1] + cal_gain + cal_offsets[2] + uart_rx_buf[0] +
                     adc_history[0];
    (void)check;

    printf("   text    data     bss     dec     hex  (like: arm-none-eabi-size firmware.elf)\n");
    printf("%7u %7u %7u %7u %7x\n\n", (unsigned)TEXT_TOTAL, (unsigned)DATA_BYTES,
           (unsigned)BSS_BYTES, (unsigned)(TEXT_TOTAL + DATA_BYTES + BSS_BYTES),
           (unsigned)(TEXT_TOTAL + DATA_BYTES + BSS_BYTES));

    printf("Where each part lands:\n");
    printf("  .text   %6u bytes   code                       -> Flash\n", (unsigned)CODE_BYTES);
    printf("  .rodata %6u bytes   const tables (font, sine)  -> Flash\n", (unsigned)RODATA_BYTES);
    printf("  .data   %6u bytes   initialised globals        -> Flash (image) + RAM (copy)\n",
           (unsigned)DATA_BYTES);
    printf("  .bss    %6u bytes   zero-initialised buffers   -> RAM only\n", (unsigned)BSS_BYTES);
    printf("  heap    %6u bytes   reserved for malloc/RTOS   -> RAM\n", (unsigned)HEAP_BYTES);
    printf("  stack   %6u bytes   reserved for main stack    -> RAM\n\n", (unsigned)STACK_BYTES);

    printf("Budget:\n");
    usage_line("Flash", (unsigned)FLASH_USED, FLASH_BYTES);
    usage_line("RAM", (unsigned)RAM_USED, SRAM_BYTES);
    return 0;
}
