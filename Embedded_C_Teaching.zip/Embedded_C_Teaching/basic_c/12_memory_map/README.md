# Topic 12 - Memory Map
**Suggested session:** 90 min | **Prerequisite topics:** 02 Compilation Process, 03 Constants and Variable Types, 10 Functions

Students connect C declarations to physical memory: which section a variable lands in, what it costs in Flash and RAM, how a Cortex-M memory map is organised, how the vector table and start-up code prepare memory before `main()`, how an RTOS gives every task its own stack, and how the same ideas appear in a Linux process.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_where_variables_live.c` | MCU | `.text/.rodata/.data/.bss/heap/stack`, printing addresses with `%p`, stack direction (do not rely on it) |
| 02 | `ex02_cortex_m_memory_map.c` | MCU | memory map as a table, address classifier, `GPIOA->ODR` = base + offset (`offsetof`), `_Static_assert` on register layout |
| 03 | `ex03_flash_ram_budget.c` | MCU | Flash vs RAM cost of const / initialised / zero-initialised data, `size`-style report, compile-time budget check |
| 04 | `ex04_vector_table_reset_handler.c` | MCU | vector table as a const array of function pointers (union with the stack word), `Reset_Handler`, interrupt dispatch, `Default_Handler` |
| 05 | `ex05_data_bss_startup.c` | MCU | start-up code: copy `.data` from Flash, zero `.bss`, hex dump before / after, little-endian bytes |
| 06 | `ex06_rtos_stack_high_water.c` | RTOS | one stack per task, high-water mark, canary guard zone, stack sizing advice, simulated overflow |
| 07 | `ex07_linux_proc_self_maps.c` | LINUX | `etext/edata/end` linker symbols, `/proc/self/maps`, r-x / r-- / rw- permissions per region |

## Teaching notes
* Ask first: "Where does `int x = 5;` live? And `int y;`? And `const int z = 5;`?" Then run ex01 and let the table answer.
* `.data` is stored twice (Flash image + RAM copy); `.bss` only costs RAM. This explains why a big zero-initialised buffer does not enlarge the firmware file but does eat RAM (ex03, ex05).
* Peripheral registers are ordinary addresses inside the 0x40000000 region; `volatile` tells the compiler every access is real (ex02 shows the addresses, topic 04 shows the bit work).
* The first Flash word is a stack pointer value, not code. Students often expect the first instruction there (ex04).
* Stack direction, heap address and exact stack usage depend on compiler, options and tools: use them for understanding, never in program logic. Results of ex01 and ex06 change with `-O2` or AddressSanitizer on purpose.
* Stack overflow is silent corruption of the neighbouring memory; canaries and high-water marks turn it into a diagnosable event (ex06).

## Live-demo tips
* On a real build tree show the sections of ex01 with `size ex01` and `nm -n ex01 | grep -E ' [bBdDrRtT] '` to match each symbol to its section.
* Compare plain and sanitizer builds of ex01 and ex07: `gcc ... ` vs `gcc -fsanitize=address ...` and talk about why the stack and heap addresses look different.
* Open godbolt.org with `-mcpu=cortex-m4 -mthumb` (compiler: ARM GCC) to show `.data` / `.bss` directives for a few global variables.
