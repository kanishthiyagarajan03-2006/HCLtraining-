/*
 * ============================================================================
 *  Topic   : 12 Memory Map
 *  Example : 02 - A Cortex-M memory map as data: classify any address
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A microcontroller has ONE flat 32-bit address space. Flash, SRAM and every
 *            peripheral register sit at fixed addresses chosen by the chip maker. A
 *            "register" is just a memory location: GPIOA->ODR is the 32-bit word at
 *            0x40020000 + 0x14. Describe the map as a table of {name, base, size} and
 *            a small function can tell where any address lands.
 *  Embedded use : reading a HardFault address ("which region was that?"), writing a linker
 *            script (MEMORY { FLASH ... RAM ... }) and checking buffers fit.
 *  Real STM32F4 : #define GPIOA_BASE (AHB1PERIPH_BASE + 0x0000UL)
 *            #define GPIOA ((GPIO_TypeDef *)GPIOA_BASE)   -> a fixed-address struct pointer
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_cortex_m_memory_map.c -o ex02
 *  Output  : a classification of 10 addresses and the computed address of GPIOA/GPIOB
 *            registers (nothing is dereferenced, so it is safe on a PC)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add the test address 0x00000004. Which region answers and why does it exist?
 *            2) Compute the address of GPIOB->BSRR (GPIOB base is 0x40020400).
 * ============================================================================
 */
#include <stddef.h>
#include "hw_sim.h"

typedef struct {
    const char *name;
    uint32_t    base;
    uint32_t    size;             /* bytes */
} region_t;

/* STM32F446-style map, sorted by address (sizes rounded from the reference manual). */
static const region_t memory_map[] = {
    { "Boot alias (flash/SRAM/ROM)",    0x00000000u, 0x00080000u },
    { "Flash (512 KB)",                 0x08000000u, 0x00080000u },
    { "System memory (ST bootloader)",  0x1FFF0000u, 0x00007800u },
    { "SRAM1 + SRAM2 (128 KB)",         0x20000000u, 0x00020000u },
    { "APB1 peripherals (timers, UART)", 0x40000000u, 0x00008000u },
    { "APB2 peripherals",               0x40010000u, 0x00006C00u },
    { "AHB1 peripherals (GPIO, RCC)",   0x40020000u, 0x00060000u },
    { "Cortex-M4 core (NVIC, SysTick)", 0xE0000000u, 0x00100000u },
};
#define NREGIONS (sizeof memory_map / sizeof memory_map[0])

static const region_t *classify(uint32_t addr)
{
    for (size_t i = 0; i < NREGIONS; i++) {
        /* (addr - base) < size is overflow-safe, unlike base + size > addr */
        if (addr >= memory_map[i].base && (addr - memory_map[i].base) < memory_map[i].size)
            return &memory_map[i];
    }
    return NULL;                  /* reserved: an access here raises a BusFault/HardFault */
}

#define AHB1PERIPH_BASE  0x40020000u
#define GPIOA_BASE       (AHB1PERIPH_BASE + 0x0000u)
#define GPIOB_BASE       (AHB1PERIPH_BASE + 0x0400u)

/* hw_sim.h's GPIO_TypeDef has the SAME member order as the real chip, so offsetof()
 * gives the real register offsets. If someone reorders the struct, the build fails. */
_Static_assert(offsetof(GPIO_TypeDef, IDR)  == 0x10u, "IDR offset must be 0x10");
_Static_assert(offsetof(GPIO_TypeDef, ODR)  == 0x14u, "ODR offset must be 0x14");
_Static_assert(offsetof(GPIO_TypeDef, BSRR) == 0x18u, "BSRR offset must be 0x18");

int main(void)
{
    static const struct { uint32_t addr; const char *meaning; } tests[] = {
        { 0x08000000u, "first word of flash: initial stack pointer" },
        { 0x08000004u, "second word: address of Reset_Handler" },
        { 0x20000040u, "a global variable in SRAM" },
        { 0x20020000u, "one byte PAST the end of SRAM (stack top value)" },
        { 0x40020014u, "GPIOA->ODR" },
        { 0x40023800u, "RCC base" },
        { 0xE000E100u, "NVIC->ISER[0] (interrupt enable)" },
        { 0xE000E010u, "SysTick->CTRL" },
        { 0x30000000u, "nothing is mapped here" },
        { 0xFFFFFFFFu, "top of the address space" },
    };

    printf("%-12s %-34s %s\n", "address", "region", "what it is");
    for (size_t i = 0; i < sizeof tests / sizeof tests[0]; i++) {
        const region_t *r = classify(tests[i].addr);
        printf("0x%08X   %-34s %s\n", (unsigned)tests[i].addr, r ? r->name : "RESERVED / unmapped",
               tests[i].meaning);
    }

    printf("\nRegister address = peripheral base + offset of the member:\n");
    printf("  GPIOA->ODR  at 0x%08X\n", (unsigned)(GPIOA_BASE + offsetof(GPIO_TypeDef, ODR)));
    printf("  GPIOA->BSRR at 0x%08X\n", (unsigned)(GPIOA_BASE + offsetof(GPIO_TypeDef, BSRR)));
    printf("  GPIOB->IDR  at 0x%08X\n", (unsigned)(GPIOB_BASE + offsetof(GPIO_TypeDef, IDR)));
    printf("On the real chip: GPIOA is ((GPIO_TypeDef *)0x40020000). Here GPIOA points to a\n");
    printf("simulated struct at %p, so we only PRINT the real address, never use it.\n",
           (void *)GPIOA);
    return 0;
}
