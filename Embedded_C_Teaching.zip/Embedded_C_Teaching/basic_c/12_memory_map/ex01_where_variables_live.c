/*
 * ============================================================================
 *  Topic   : 12 Memory Map
 *  Example : 01 - Where do variables live? .text .rodata .data .bss heap stack
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : The linker places every object in a SECTION decided by how you declared it:
 *              code                       -> .text     (read-only, executable)
 *              const data, string literal -> .rodata   (read-only)
 *              global/static, initialised -> .data     (read-write, initial value stored)
 *              global/static, zero/none   -> .bss      (read-write, zeroed at start-up)
 *              malloc()                   -> heap      (grows at run time)
 *              locals, parameters         -> stack     (one frame per call)
 *            %p prints the address, so we can SEE which region each object is in.
 *  Embedded use : on a Cortex-M the first two live in Flash (0x08000000...), the rest in SRAM
 *            (0x20000000...). Knowing the section tells you the Flash and RAM cost of a line.
 *  Real STM32F4 : the same code on a Nucleo prints 0x0800xxxx for code/const and 0x2000xxxx
 *            for everything else (see ex02 for the full map).
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex01_where_variables_live.c -o ex01
 *  Output  : a table: object, section, where a Cortex-M puts it, and its PC address.
 *            Addresses differ from run to run (ASLR); the sections do not.
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add  const int g_big_table[1000];  Does it use RAM, Flash or both on a Cortex-M?
 *            2) Make g_init 'const' (this program only reads it). Which section does it
 *               move to, and does it still need a copy in RAM?
 * ============================================================================
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

int g_init = 42;                                 /* .data  : non-zero initialiser    */
int g_zero;                                      /* .bss   : no initialiser = 0      */
int g_zero_explicit = 0;                         /* .bss   : zero initialiser = bss  */
const int g_const = 7;                           /* .rodata: const -> flash on MCU   */
static const char s_banner[] = "memory map";     /* .rodata                          */

static void row(const char *what, const char *section, const char *mcu, const void *addr)
{
    printf("  %-24s %-8s %-11s %p\n", what, section, mcu, addr);
}

/* Stores the address of a local of the DEEPEST call in *out. noinline keeps real frames. */
__attribute__((noinline)) static void frame_address(int depth, uintptr_t *out)
{
    volatile int marker = depth;                 /* lives in this call's stack frame */
    if (depth == 0) *out = (uintptr_t)&marker;
    else            frame_address(depth - 1, out);
}

/* A static LOCAL has function scope but static storage: it lives in .data, not on the stack. */
static const int *calls_counter(void)
{
    static int s_calls = 5;
    s_calls++;
    return &s_calls;
}

int main(void)
{
    int local = 1;                               /* stack */
    int *heap = (int *)malloc(sizeof *heap);
    if (heap == NULL) return 1;
    *heap = 99;
    const int *calls = calls_counter();
    const char *literal = "hello";               /* pointer: stack, the text itself: .rodata */

    printf("  %-24s %-8s %-11s %s\n", "object", "section", "Cortex-M", "address");
    row("main() code",              ".text",   "Flash",  (const void *)(uintptr_t)main);
    row("g_const",                  ".rodata", "Flash",  (const void *)&g_const);
    row("s_banner[]",               ".rodata", "Flash",  (const void *)s_banner);
    row("\"hello\" literal",        ".rodata", "Flash",  (const void *)literal);
    row("g_init = 42",              ".data",   "Flash+RAM", (const void *)&g_init);
    row("static local s_calls",     ".data",   "Flash+RAM", (const void *)calls);
    row("g_zero",                   ".bss",    "RAM",    (const void *)&g_zero);
    row("g_zero_explicit = 0",      ".bss",    "RAM",    (const void *)&g_zero_explicit);
    row("malloc(4) block",          "heap",    "RAM",    (const void *)heap);
    row("int local in main()",      "stack",   "RAM",    (const void *)&local);
    free(heap);

    /* Stack direction: compare a deeper call's local with a shallower one's. */
    uintptr_t shallow = 0, deep = 0;
    frame_address(1, &shallow);
    frame_address(5, &deep);
    printf("\nA deeper call's local is at a %s address than a shallow one's.\n",
           deep < shallow ? "LOWER" : "HIGHER");
    printf("Cortex-M hardware always pushes the stack DOWN. On a PC the answer depends on the\n");
    printf("compiler and tools (AddressSanitizer uses a heap-like 'fake stack'), so never\n");
    printf("write code that relies on the direction.\n");
    return 0;
}
