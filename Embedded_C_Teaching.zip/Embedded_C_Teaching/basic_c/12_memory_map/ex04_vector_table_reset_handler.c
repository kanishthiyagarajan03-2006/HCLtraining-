/*
 * ============================================================================
 *  Topic   : 12 Memory Map
 *  Example : 04 - The vector table: a const array of function pointers in Flash
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : At address 0x08000000 a Cortex-M finds a TABLE, not code:
 *              word 0  initial stack pointer          (loaded into SP on reset)
 *              word 1  address of Reset_Handler       (the first code that runs)
 *              word 2.. NMI, HardFault, ... SysTick (exception 15), then IRQ 0, 1, 2...
 *            Entry n is the function the hardware calls for exception/interrupt n.
 *            In C this is a const array of function pointers (so it stays in Flash),
 *            with one non-pointer word first, modelled here with a union.
 *  Embedded use : an ISR is "just a function" whose address sits at index 16 + IRQn.
 *            A wrong name means the chip jumps to Default_Handler: a classic bug.
 *  Real STM32F4 : startup_stm32f446xx.s places  g_pfnVectors  in section .isr_vector;
 *            SCB->VTOR holds the table address and can be moved to RAM.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex04_vector_table_reset_handler.c -o ex04
 *  Output  : the simulated reset sequence, then interrupts dispatched through the table,
 *            including one that has no handler (it lands in Default_Handler)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Register a TIM2_IRQHandler (IRQ 28) in the table and fire it.
 *            2) Remove the NULL check in dispatch(): what would a NULL entry do on a chip?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

typedef void (*isr_t)(void);

/* A table slot is either a function address or a plain 32-bit word (the stack pointer). */
typedef union {
    isr_t    isr;
    uint32_t word;
} vector_t;

#define STACK_TOP   0x20020000u        /* end of 128 KB SRAM: the stack grows DOWN from here */
#define IRQ_EXTI0   6                  /* STM32F4 IRQ numbers (see the reference manual) */
#define IRQ_USART2  38
#define FIRST_IRQ   16                 /* entries 0..15 are the core exceptions */

static void Reset_Handler(void);
static void NMI_Handler(void);
static void HardFault_Handler(void);
static void SysTick_Handler(void);
static void EXTI0_IRQHandler(void);
static void USART2_IRQHandler(void);
static void Default_Handler(void);

/* const: lives in Flash. [index] = ... places each entry at its exact slot; slots we do
 * not mention stay zero (NULL). Real startup code fills them all with Default_Handler. */
static const vector_t vector_table[] = {
    [0]                    = { .word = STACK_TOP },
    [1]                    = { .isr  = Reset_Handler },
    [2]                    = { .isr  = NMI_Handler },
    [3]                    = { .isr  = HardFault_Handler },
    [15]                   = { .isr  = SysTick_Handler },
    [FIRST_IRQ + IRQ_EXTI0]  = { .isr = EXTI0_IRQHandler },
    [FIRST_IRQ + IRQ_USART2] = { .isr = USART2_IRQHandler },
};
#define VECTOR_COUNT  (sizeof vector_table / sizeof vector_table[0])

static unsigned s_systick_count;

static void NMI_Handler(void)        { printf("  NMI_Handler\n"); }
static void HardFault_Handler(void)  { printf("  HardFault_Handler\n"); }
static void EXTI0_IRQHandler(void)   { printf("  EXTI0_IRQHandler: button on PA0\n"); }
static void USART2_IRQHandler(void)  { printf("  USART2_IRQHandler: byte received\n"); }

static void SysTick_Handler(void)
{
    s_systick_count++;                         /* real code: ++uwTick, the HAL time base */
    printf("  SysTick_Handler #%u\n", s_systick_count);
}

static void Default_Handler(void)
{
    printf("  Default_Handler: unexpected interrupt (real chips loop here forever)\n");
}

/* What the NVIC hardware does when interrupt number 'exc' fires. */
static void dispatch(unsigned exc)
{
    if (exc >= FIRST_IRQ) printf("exception %u fires (= 16 + IRQ %u)\n", exc, exc - FIRST_IRQ);
    else                  printf("exception %u fires (core exception)\n", exc);
    if (exc >= VECTOR_COUNT || vector_table[exc].isr == NULL)
        Default_Handler();
    else
        vector_table[exc].isr();
}

static void app_main(void)
{
    printf("application running; interrupts start arriving\n\n");
    dispatch(15);                              /* SysTick */
    dispatch(FIRST_IRQ + IRQ_EXTI0);
    dispatch(FIRST_IRQ + IRQ_USART2);
    dispatch(FIRST_IRQ + 28);                  /* TIM2: nobody wrote a handler */
    dispatch(15);
}

static void Reset_Handler(void)
{
    /* Real Reset_Handler (assembly + C): SystemInit(); copy .data; zero .bss;
     * __libc_init_array(); main();   -> see example 05 for the copy and zero steps. */
    printf("Reset_Handler: SystemInit, copy .data, zero .bss, then call main()\n");
    printf("(here the application entry is called app_main)\n\n");
    app_main();
}

int main(void)
{
    printf("vector table: %zu entries here (%zu bytes on a Cortex-M: 4 bytes each)\n\n",
           (size_t)VECTOR_COUNT, (size_t)VECTOR_COUNT * 4U);

    /* "Power on": the core reads word 0 and word 1 of the table by itself. */
    printf("CPU reset: SP <- table[0] = 0x%08X\n", (unsigned)vector_table[0].word);
    printf("           PC <- table[1] = Reset_Handler\n");
    vector_table[1].isr();
    return 0;
}
