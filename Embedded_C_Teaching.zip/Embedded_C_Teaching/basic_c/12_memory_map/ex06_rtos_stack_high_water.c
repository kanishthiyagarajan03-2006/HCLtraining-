/*
 * ============================================================================
 *  Topic   : 12 Memory Map
 *  Example : 06 - Every task has its own stack: high-water mark and a guard zone
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : An RTOS carves SRAM into one stack per task (plus the heap and the kernel's
 *            own data). The stack is filled with a known pattern (0xA5) at creation, so
 *            later the overwritten part of the pattern = the PEAK use. FreeRTOS's "high-water
 *            mark" is the opposite number: the least stack that was ever still FREE. The
 *            lowest few bytes act as a CANARY: if they change, the stack has overflowed
 *            into its neighbour.
 *  Embedded use : stacks are the #1 source of mysterious RTOS crashes. Measure with
 *            uxTaskGetStackHighWaterMark() (minimum free stack, counted in WORDS), then
 *            size each stack with a safety margin.
 *  Real FreeRTOS : uxTaskGetStackHighWaterMark(handle);  configCHECK_FOR_STACK_OVERFLOW = 2
 *            vApplicationStackOverflowHook(handle, name);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_rtos_stack_high_water.c -o ex06
 *  Output  : three tasks run, then a table of stack size / peak use per task and a canary
 *            check; one overflow is SIMULATED by corrupting the guard bytes on purpose
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change heavy_task's buffer from 4096 to 8192 bytes: how does its peak change?
 *            2) Why can the numbers differ between -O0 and -O2 builds?
 * ============================================================================
 */
#include "mini_rtos.h"

#define CANARY_BYTES   32U                 /* guard zone at the LOW end of every stack */

/* Recursion burns one frame per level: a simple way to make a stack deeper. */
static int depth_sum(int n)
{
    volatile int pad[8];                   /* keep each frame a realistic size */
    pad[0] = n;
    if (n <= 0) return 0;
    return pad[0] + depth_sum(n - 1);
}

static void light_task(void *arg)
{
    (void)arg;
    rtos_log("light: small locals only");
    rtos_delay(50);
}

static void medium_task(void *arg)
{
    (void)arg;
    rtos_log("medium: recursion depth 20 -> sum = %d", depth_sum(20));
    rtos_delay(50);
}

static void heavy_task(void *arg)
{
    (void)arg;
    volatile uint8_t frame[4096];          /* a big local array: 4 KB of stack in one go */
    for (size_t i = 0; i < sizeof frame; i++) frame[i] = (uint8_t)i;
    rtos_log("heavy: filled a %zu byte local buffer", sizeof frame);
    rtos_delay(50);
}

/* Stack grows toward lower addresses: the canary is the FIRST bytes of the allocation. */
static int canary_intact(const rtos_task_t *t)
{
    for (size_t i = 0; i < CANARY_BYTES; i++)
        if (t->stack[i] != RTOS_STACK_FILL) return 0;
    return 1;
}

static void report(const char *name, const rtos_task_t *t)
{
    size_t untouched = rtos_stack_high_water(t);              /* bytes never used */
    size_t peak = t->stack_size - untouched;
    size_t advice = ((peak + peak / 2U) + 63U) & ~(size_t)63U; /* peak + 50 %, 64-byte steps */
    printf("%-7s %6zu %6zu %6zu %5zu%%  %6zu   %s\n", name, t->stack_size, peak, untouched,
           (peak * 100U) / t->stack_size, advice, canary_intact(t) ? "ok" : "OVERFLOW!");
}

int main(void)
{
    rtos_task_t *light  = rtos_task_create("light",  light_task,  NULL, 2, 512);
    rtos_task_t *medium = rtos_task_create("medium", medium_task, NULL, 2, 512);
    rtos_task_t *heavy  = rtos_task_create("heavy",  heavy_task,  NULL, 2, 512);
    if (light == NULL || medium == NULL || heavy == NULL) return 1;

    rtos_start(500);

    printf("\nStack report (bytes). mini_rtos uses %u-byte stacks on a PC; a real MCU task\n",
           (unsigned)RTOS_MIN_STACK);
    printf("would get the 'advice' size (bytes; xTaskCreate wants WORDS, so divide by 4).\n");
    printf("Peak values depend on compiler and options.\n");
    printf("%-7s %6s %6s %6s %6s  %6s   %s\n", "task", "size", "peak", "free", "used", "advice",
           "canary");
    report("light", light);
    report("medium", medium);
    report("heavy", heavy);
    printf("Even 'light' has a large peak: printf (inside rtos_log) is stack-hungry. On a\n");
    printf("small MCU, use a lean printf or keep it out of tasks with tiny stacks.\n");

    /* Simulate a stack overflow: scribble over the guard zone (still our own memory). */
    printf("\nSimulating an overflow of 'medium': writing 0x00 into its guard bytes...\n");
    medium->stack[3] = 0x00;
    printf("canary check: light=%s medium=%s heavy=%s\n",
           canary_intact(light) ? "ok" : "OVERFLOW!", canary_intact(medium) ? "ok" : "OVERFLOW!",
           canary_intact(heavy) ? "ok" : "OVERFLOW!");
    printf("A real kernel would call vApplicationStackOverflowHook() right here.\n");

    rtos_shutdown();
    return 0;
}
