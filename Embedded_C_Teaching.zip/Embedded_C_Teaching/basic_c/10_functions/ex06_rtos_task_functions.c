/*
 * ============================================================================
 *  Topic   : 10 Functions
 *  Example : 06 - The RTOS task function: void task(void *arg), one body, many tasks
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Every RTOS task is an ordinary C function with the fixed signature
 *                void task(void *arg)
 *            The kernel calls it once. A void * parameter carries anything, so ONE
 *            function can run as several tasks, each with its own configuration struct.
 *            The data behind arg must outlive the task: use static/global storage,
 *            never a local variable of the function that created the task.
 *  Embedded use : three LED tasks that differ only in label and period share one body;
 *            helper functions (static, with return values) keep the task loop short.
 *  Real FreeRTOS : xTaskCreate(led_task, "red", 256, &cfg_red, 2, NULL);
 *            A FreeRTOS task must NEVER just return: it ends itself with vTaskDelete(NULL).
 *            mini_rtos is more forgiving and deletes a task whose function returns.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_rtos_task_functions.c -o ex06
 *  Output  : interleaved log lines of three LED tasks and an uptime reporter; the LED
 *            tasks finish after their blink count and the reporter keeps going
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a fourth LED task "blue" using the same led_task function.
 *            2) Move one cfg struct into main() as a plain local: what could go wrong
 *               if main() returned while that task was still running?
 * ============================================================================
 */
#include "mini_rtos.h"

typedef struct {
    const char *label;
    uint32_t    period_ms;      /* time per ON or OFF phase */
    unsigned    blinks;         /* how many full blinks before the task ends */
} led_cfg_t;

/* static storage: still valid when the tasks run (and long after main() created them) */
static const led_cfg_t cfg_green = { "green", 200, 3 };
static const led_cfg_t cfg_amber = { "amber", 300, 2 };
static const led_cfg_t cfg_red   = { "red",   500, 1 };

/* Helper functions used by the task bodies. */
static const char *phase_name(unsigned phase) { return (phase % 2U == 0U) ? "ON " : "off"; }
static unsigned uptime_seconds(void)          { return rtos_ticks() / 1000U; }

/* One function, three tasks. 'arg' is converted back to the type that was passed in. */
static void led_task(void *arg)
{
    const led_cfg_t *cfg = (const led_cfg_t *)arg;

    for (unsigned phase = 0; phase < cfg->blinks * 2U; phase++) {
        rtos_log("%-5s LED %s", cfg->label, phase_name(phase));
        rtos_delay(cfg->period_ms);
    }
    rtos_log("%-5s LED done, function returns (mini_rtos deletes the task)", cfg->label);
}

/* A task that does not need an argument says so explicitly. */
static void report_task(void *arg)
{
    (void)arg;                                   /* silence "unused parameter" */
    for (;;) {
        rtos_log("uptime check: %u s, %u ms", uptime_seconds(), (unsigned)rtos_ticks());
        rtos_delay(500);
    }
}

int main(void)
{
    /* The same function address is given to three tasks, with three different args.
     * The cast removes const because the generic parameter type is plain void *;
     * led_task() immediately restores const.                                         */
    rtos_task_create("t_green", led_task, (void *)&cfg_green, 3, 1024);
    rtos_task_create("t_amber", led_task, (void *)&cfg_amber, 3, 1024);
    rtos_task_create("t_red",   led_task, (void *)&cfg_red,   3, 1024);
    rtos_task_create("report",  report_task, NULL, 1, 1024);

    rtos_start(1500);
    rtos_shutdown();
    return 0;
}
