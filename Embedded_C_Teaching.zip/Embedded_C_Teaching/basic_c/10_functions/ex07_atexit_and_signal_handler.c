/*
 * ============================================================================
 *  Topic   : 10 Functions
 *  Example : 07 - Functions the system calls for you: atexit() and a signal handler
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Passing a function's name to atexit() or sigaction() registers a callback:
 *            the C library / kernel calls it later. atexit handlers run in REVERSE
 *            order of registration when the program ends. A signal handler runs
 *            asynchronously, so it must be tiny: set a volatile sig_atomic_t flag
 *            and use only async-signal-safe calls such as write() (not printf).
 *  Embedded use : a Linux daemon must turn its LED/relay OFF and flush logs when it gets
 *            SIGTERM (systemd stop) or Ctrl+C. Cleanup lives in atexit handlers.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex07_atexit_and_signal_handler.c -o ex07
 *  Output  : a signal is raised, the handler reports it, main acts on the flag, and at
 *            exit the cleanup handlers run in the opposite order to their registration
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Register a third atexit handler and predict where its message appears.
 *            2) Run  kill -USR1 <pid>  from another shell after adding a long sleep().
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static volatile sig_atomic_t g_signal_seen;      /* written by the handler, read by main */

/* ---- atexit handlers: plain void(void) functions ------------------------------- */
static void flush_log(void)   { printf("  [atexit] 2nd registered, runs 1st: flush log file\n"); }
static void leds_off(void)    { printf("  [atexit] 1st registered, runs 2nd: all LEDs off\n"); }

/* ---- signal handler: runs "on top of" whatever main() was doing ----------------- */
static void on_sigusr1(int signo)
{
    static const char msg[] = "  [handler] SIGUSR1 arrived, setting the flag\n";
    ssize_t r = write(STDOUT_FILENO, msg, sizeof msg - 1);   /* write() is async-signal-safe */
    (void)r;
    g_signal_seen = signo;                                   /* just record it */
}

int main(void)
{
    /* Register cleanup callbacks. Think of them as a stack: last in, first out. */
    if (atexit(leds_off) != 0 || atexit(flush_log) != 0) {
        fprintf(stderr, "atexit registration failed\n");
        return 1;
    }

    /* sigaction() is the portable, well-defined way to install a handler. */
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);                   /* no flags, nothing blocked */
    sa.sa_handler = on_sigusr1;                  /* the callback */
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGUSR1, &sa, NULL) != 0) {
        perror("sigaction");
        return 1;
    }

    printf("main: handler installed, now raising SIGUSR1 against myself\n");
    fflush(stdout);                              /* keep stdout and write() in order */

    raise(SIGUSR1);                              /* kernel calls on_sigusr1() right away */

    if (g_signal_seen != 0)
        printf("main: flag says signal %d (%s) was delivered\n", (int)g_signal_seen,
               strsignal((int)g_signal_seen));
    else
        printf("main: no signal seen\n");

    printf("main: returning from main() now; the exit handlers will run\n");
    return 0;                                    /* same as exit(0): atexit handlers run */
}
