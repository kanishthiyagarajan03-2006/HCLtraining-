/*
 * ============================================================================
 *  Topic   : 10 Functions
 *  Example : 04 - Callbacks: function pointers, typedef and an ISR as a plain function
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A function pointer stores the ADDRESS of a function so that library code
 *            can call YOUR function later. typedef makes the ugly syntax readable:
 *                typedef void (*button_cb_t)(void);
 *            A void *ctx parameter lets one callback serve many objects without globals.
 *            Always check a callback for NULL before calling it.
 *  Embedded use : drivers cannot know what the application wants to do on a button press
 *            or timer expiry, so the application registers a callback. An interrupt
 *            service routine is just a function that the hardware calls.
 *  Real STM32F4 : void EXTI0_IRQHandler(void) { HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_0); }
 *            then HAL calls your  HAL_GPIO_EXTI_Callback(uint16_t pin).
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_callbacks_function_pointers.c -o ex04
 *  Output  : a 1-second timeline: two soft timers blink two LEDs and the button callback
 *            fires when the (simulated) button interrupt runs
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Register a second button callback. Why does this driver keep only one?
 *            2) Call EXTI0_IRQHandler() before button_register(): why is the NULL check needed?
 * ============================================================================
 */
#include "hw_sim.h"

/* ===== button driver (would live in button.c) ================================= */
typedef void (*button_cb_t)(void);

static button_cb_t s_button_cb;                      /* NULL until someone registers */

static void button_register(button_cb_t cb) { s_button_cb = cb; }

/* On real hardware the NVIC calls this when PA0 sees an edge. Here WE call it. */
static void EXTI0_IRQHandler(void)
{
    if (s_button_cb != NULL)                         /* never call a NULL pointer */
        s_button_cb();
}

/* ===== soft-timer driver: callbacks WITH a context pointer ==================== */
typedef void (*timer_cb_t)(void *ctx);

typedef struct {
    uint32_t    period_ms;
    uint32_t    next_ms;
    timer_cb_t  cb;
    void       *ctx;
} soft_timer_t;

#define MAX_TIMERS 4
static soft_timer_t s_timers[MAX_TIMERS];
static unsigned     s_ntimers;

static int timer_start(uint32_t period_ms, timer_cb_t cb, void *ctx)
{
    if (s_ntimers >= MAX_TIMERS || cb == NULL) return -1;
    s_timers[s_ntimers++] = (soft_timer_t){ period_ms, period_ms, cb, ctx };
    return 0;
}

/* Called once per millisecond by the SysTick interrupt on a real board. */
static void timer_tick(uint32_t now_ms)
{
    for (unsigned i = 0; i < s_ntimers; i++) {
        if (now_ms >= s_timers[i].next_ms) {
            s_timers[i].next_ms += s_timers[i].period_ms;
            s_timers[i].cb(s_timers[i].ctx);          /* call the user's function */
        }
    }
}

/* ===== application (would live in main.c) ===================================== */
typedef struct { GPIO_TypeDef *port; uint8_t pin; const char *name; } led_t;

static void led_toggle_cb(void *ctx)
{
    const led_t *led = (const led_t *)ctx;           /* one callback, many LEDs */
    led->port->ODR ^= (1U << led->pin);
    printf("[%4u ms] %-6s toggled -> %s\n", (unsigned)sim_millis(), led->name,
           (led->port->ODR >> led->pin) & 1U ? "ON" : "off");
}

static unsigned s_presses;

static void on_button_press(void)
{
    s_presses++;
    printf("[%4u ms] BUTTON callback, press #%u\n", (unsigned)sim_millis(), s_presses);
}

int main(void)
{
    led_t green_led = { GPIOA, 5, "green" };          /* lives as long as main() does */
    led_t red_led   = { GPIOA, 6, "red" };

    button_register(on_button_press);                 /* pass the function NAME (its address) */
    timer_start(300, led_toggle_cb, &green_led);      /* same function, different context */
    timer_start(500, led_toggle_cb, &red_led);

    for (uint32_t ms = 1; ms <= 1000; ms++) {
        sim_delay_ms(1);
        timer_tick(sim_millis());
        if (ms == 420 || ms == 800) {                 /* the user presses the button */
            sim_press(GPIOB, 0);
            EXTI0_IRQHandler();                       /* hardware would do this call */
            sim_release(GPIOB, 0);
        }
    }
    printf("done: %u button presses handled\n", s_presses);
    return 0;
}
