/*
 * ============================================================================
 *  Topic   : 10 Functions
 *  Example : 05 - Variadic functions: a log_printf() with levels, going out of a UART
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A function with "..." takes any number of extra arguments. Inside, <stdarg.h>
 *            (va_list, va_start, va_arg, va_end) walks them; vsnprintf() forwards them to
 *            the printf engine. The compiler cannot check the types of "..." arguments,
 *            so GCC's format attribute asks it to check them like printf.
 *  Embedded use : every firmware has a log function that formats into a small buffer
 *            (snprintf-style, so it can never overflow) and pushes bytes to the UART.
 *  Real STM32F4 : HAL_UART_Transmit(&huart2, (uint8_t *)line, len, 100);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_variadic_log_printf.c -o ex05
 *  Output  : an average computed from a variable argument list, then time-stamped log
 *            lines; a DEBUG line is filtered out until the level is raised
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Move log_set_level(LOG_DEBUG) before the first log line.
 *            2) Compile with -DDEMO_BUG: GCC warns about the wrong format only because
 *               of the format attribute (with -Werror the build stops).
 * ============================================================================
 */
#include <stdarg.h>
#include <string.h>
#include "hw_sim.h"

/* ---- variadic basics: the first argument tells HOW MANY follow ----------------- */
static int average_mv(int count, ...)
{
    va_list ap;
    int sum = 0;
    va_start(ap, count);                    /* start after the last named parameter */
    for (int i = 0; i < count; i++)
        sum += va_arg(ap, int);             /* caller MUST pass ints, nothing checks that */
    va_end(ap);                             /* always pair with va_start */
    return count > 0 ? sum / count : 0;
}

/* ---- the UART "driver" (bytes go to stdout here) ------------------------------ */
static void uart_putc(char c) { putchar(c); }           /* real: wait TXE, write USART2->DR */

static void uart_puts(const char *s)
{
    while (*s != '\0') uart_putc(*s++);
}

/* ---- the logger ------------------------------------------------------------------ */
typedef enum { LOG_ERROR = 0, LOG_WARN, LOG_INFO, LOG_DEBUG } log_level_t;

static log_level_t s_level = LOG_INFO;                  /* anything above is dropped */
static void log_set_level(log_level_t lvl) { s_level = lvl; }

/* Tell GCC "argument 2 is a printf format, arguments from 3 on are its values". */
#if defined(__GNUC__)
__attribute__((format(printf, 2, 3)))
#endif
static void log_printf(log_level_t lvl, const char *fmt, ...);

static void log_printf(log_level_t lvl, const char *fmt, ...)
{
    static const char *const tag[] = { "ERR ", "WARN", "INFO", "DBG " };
    if (lvl > s_level) return;                          /* filtered: costs almost nothing */

    char msg[40];                                       /* small on purpose: MCU RAM is tight */
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(msg, sizeof msg, fmt, ap);        /* never writes past msg[39] */
    va_end(ap);

    char line[80];
    snprintf(line, sizeof line, "[%5u ms] %s %s%s\n", (unsigned)sim_millis(), tag[lvl], msg,
             (n >= (int)sizeof msg) ? "..." : "");      /* n = length it WANTED to write */
    uart_puts(line);
}

int main(void)
{
    printf("average_mv(3, 1650, 1700, 1750) = %d\n\n", average_mv(3, 1650, 1700, 1750));

    log_printf(LOG_INFO, "boot, SYSCLK=%lu Hz", 16000000UL);
    sim_delay_ms(120);
    log_printf(LOG_DEBUG, "this line is filtered out (level is INFO)");
    log_printf(LOG_WARN, "battery at %d.%02d V", 3, 41);
    sim_delay_ms(380);
    log_printf(LOG_ERROR, "sensor %s timeout after %d ms", "TMP117", 250);
    log_printf(LOG_INFO, "this message is far longer than the 40 byte buffer allows");

    log_set_level(LOG_DEBUG);                           /* a service technician enables debug */
    log_printf(LOG_DEBUG, "now debug lines appear, ADC=%u", 2048U);

#ifdef DEMO_BUG
    /* %d expects an int but a double is passed: wrong output at best, a crash at
     * worst. The format attribute lets GCC warn at compile time.                  */
    log_printf(LOG_INFO, "temperature %d", 36.6);
#endif
    return 0;
}
