/*
 * ============================================================================
 *  Topic   : 10 Functions
 *  Example : 03 - static and static inline: file-private, type-safe helpers
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : "static" on a function = internal linkage: only this .c file can call it,
 *            so the name cannot clash with another file.
 *            "inline" = a hint to paste the body at the call site (no call overhead).
 *            Unlike a macro, a static inline function has TYPED parameters, evaluates
 *            each argument exactly once and can be stepped through in a debugger.
 *  Embedded use : tiny hot-path helpers (MODIFY_REG, clamp, unit conversion) in an
 *            ISR or control loop. Modern C code prefers them to function-like macros.
 *  Real STM32F4 : the HAL's MODIFY_REG(REG, CLEARMASK, SETMASK) is a macro; the same
 *            idea as reg_modify() below, but with type checking.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_static_inline_helpers.c -o ex03
 *            Compare:  gcc -O2 -S ex03_static_inline_helpers.c   (no call to adc_to_mv)
 *  Output  : helper results, the MODER field edit, and the call count of an argument
 *            that has a side effect (it is evaluated once)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Compile with -O2 -S and search the .s file for "call": which helpers vanish?
 *            2) Compile with -DDEMO_BUG: the MAX macro evaluates read_sensor() twice.
 * ============================================================================
 */
#include "hw_sim.h"

/* ---- typed helpers ------------------------------------------------------------ */
static inline int32_t max_i32(int32_t a, int32_t b) { return (a > b) ? a : b; }

static inline uint16_t clamp_u16(int32_t v, uint16_t lo, uint16_t hi)
{
    if (v < (int32_t)lo) return lo;
    if (v > (int32_t)hi) return hi;
    return (uint16_t)v;
}

/* 12-bit ADC (0..4095) with a 3.3 V reference -> millivolts, integer maths only. */
static inline uint32_t adc_to_mv(uint16_t raw) { return ((uint32_t)raw * 3300U) / 4095U; }

/* Read-modify-write of a register field: clear the bits in 'clear', then OR in 'set'. */
static inline void reg_modify(volatile uint32_t *reg, uint32_t clear, uint32_t set)
{
    *reg = (*reg & ~clear) | set;
}

/* A function with a side effect: every call returns the next ADC sample. */
static int calls_to_sensor;
static int32_t read_sensor(void)
{
    static const int32_t samples[] = { 2450, 3100, 900, 1800 };
    return samples[calls_to_sensor++ % 4];
}

#ifdef DEMO_BUG
#  define MAX_MACRO(a, b) (((a) > (b)) ? (a) : (b))     /* 'a' may be pasted twice */
#endif

int main(void)
{
    printf("max_i32(-5, 7)           = %d\n", (int)max_i32(-5, 7));
    printf("clamp_u16(5000, 0, 4095) = %u\n", (unsigned)clamp_u16(5000, 0, 4095));
    printf("clamp_u16(-20, 0, 4095)  = %u\n", (unsigned)clamp_u16(-20, 0, 4095));
    printf("adc_to_mv(2048)          = %u mV\n", (unsigned)adc_to_mv(2048));
    printf("adc_to_mv(4095)          = %u mV\n", (unsigned)adc_to_mv(4095));

    /* Same job as topic 04 ex04: put the value 01 (output) into PA5's MODER field. */
    reg_modify(&GPIOA->MODER, 3U << (5U * 2U), 1U << (5U * 2U));
    printf("\nGPIOA->MODER after reg_modify = 0x%08X\n", (unsigned)GPIOA->MODER);

    /* The argument is evaluated ONCE even though the function uses 'a' twice inside. */
    calls_to_sensor = 0;
    int32_t best = max_i32(read_sensor(), 2000);
    printf("\nmax_i32(read_sensor(), 2000) = %d, read_sensor() was called %d time(s)\n",
           (int)best, calls_to_sensor);

#ifdef DEMO_BUG
    calls_to_sensor = 0;
    best = MAX_MACRO(read_sensor(), 2000);
    /* Expands to ((read_sensor() > 2000) ? read_sensor() : 2000): TWO calls, and the
     * value returned is a DIFFERENT sample from the one that was compared.          */
    printf("MAX_MACRO(read_sensor(), 2000) = %d, called %d time(s)  <-- BUG\n",
           (int)best, calls_to_sensor);
#endif
    return 0;
}
