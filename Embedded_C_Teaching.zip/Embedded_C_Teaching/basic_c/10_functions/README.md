# Topic 10 - Functions
**Suggested session:** 75 min | **Prerequisite topics:** 01 Introduction, 03 Constants and Variable Types, 07 Conditional Statements, 09 Preprocessor

Students learn to split firmware into small functions with clear prototypes, return values and status codes, then to treat functions as data: file-private and inline helpers, callbacks through function pointers, variadic logging, RTOS task functions, and the callbacks the Linux C library and kernel invoke for you.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_declare_define_call.c` | MCU | prototype vs definition, `void`, `(void)`, return values, call by value, `static` helpers |
| 02 | `ex02_hal_style_api_status.c` | MCU | HAL-style API: status enum, guard clauses, enum parameters, checking return codes |
| 03 | `ex03_static_inline_helpers.c` | MCU | `static` / `static inline`, typed helpers vs macros, arguments evaluated once (`DEMO_BUG` shows the macro trap) |
| 04 | `ex04_callbacks_function_pointers.c` | MCU | `typedef` for function pointers, button callback from an ISR-style function, timer callbacks with `void *ctx` |
| 05 | `ex05_variadic_log_printf.c` | MCU | `...`, `va_list`, `vsnprintf`, log levels, format attribute checking, UART output |
| 06 | `ex06_rtos_task_functions.c` | RTOS | `void task(void *arg)`, one function for many tasks, argument lifetime, a task that returns |
| 07 | `ex07_atexit_and_signal_handler.c` | LINUX | `atexit` order, `sigaction` handler, `volatile sig_atomic_t`, async-signal-safe `write` |

## Teaching notes
* Declaration vs definition: the prototype is a promise to the compiler; the linker later checks the promise was kept (see topic 11).
* Parameters are copies. Preview of topic 21: to change the caller's variable you must pass its address.
* Every driver function that can fail should return a status, and callers must check it (ex02). Ask: "what happens in the field if nobody checks?"
* A function name without parentheses is its address. `button_register(on_press)` stores it; `s_cb()` calls it (ex04). Always test for NULL before calling.
* A `void *arg` or `void *ctx` removes the need for global variables, but the pointed-to data must outlive the call (ex04, ex06).
* Signal handlers and ISRs share one rule: do almost nothing, set a flag, return (ex07, ex04).

## Live-demo tips
* ex03: `gcc -O2 -S ex03_static_inline_helpers.c -I../../common` and search the `.s` file for `call` to show that the inline helpers vanished.
* ex05: build with `-DDEMO_BUG` to show GCC catching a wrong `%d` through the format attribute.
* ex01: delete one prototype and compile to show the "implicit declaration / conflicting types" message.
