/*
 * ============================================================================
 *  Topic   : 10 Functions
 *  Example : 02 - A HAL-style API: parameters, status codes and guard clauses
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Driver functions return a STATUS (an enum) so the caller can tell success
 *            from failure, and use the return value for nothing else. Each function
 *            starts with guard clauses: reject bad parameters first, then do the
 *            work. Enums replace "magic numbers" in parameters (pin_state_t).
 *  Embedded use : every vendor HAL (STM32 HAL, nRF SDK) works this way: HAL_OK / HAL_ERROR
 *            / HAL_BUSY / HAL_TIMEOUT. Ignoring a status is a classic field bug.
 *  Real STM32F4 : HAL_StatusTypeDef st = HAL_UART_Transmit(&huart2, buf, len, 100);
 *            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
 *            (The real GPIO calls return void; this example gives GPIO the status style
 *            that most other HAL calls use. HAL_INVALID_PARAM is our own addition.)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_hal_style_api_status.c -o ex02
 *  Output  : good calls returning HAL_OK, then three bad calls that are rejected with
 *            HAL_INVALID_PARAM / HAL_ERROR and a readable message
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a call that writes pin 16 of GPIOB. Which status do you expect?
 *            2) Make hal_status_str() handle a new status HAL_NOT_READY.
 * ============================================================================
 */
#include "hw_sim.h"

typedef enum { HAL_OK = 0, HAL_ERROR, HAL_BUSY, HAL_TIMEOUT, HAL_INVALID_PARAM } hal_status_t;
typedef enum { PIN_LOW = 0, PIN_HIGH = 1 } pin_state_t;
typedef enum { MODE_INPUT = 0, MODE_OUTPUT = 1, MODE_AF = 2, MODE_ANALOG = 3 } pin_mode_t;

/* ---- the driver API (what a gpio.h would declare) ---------------------------- */
static hal_status_t gpio_init(GPIO_TypeDef *port, uint8_t pin, pin_mode_t mode);
static hal_status_t gpio_write(GPIO_TypeDef *port, uint8_t pin, pin_state_t state);
static pin_state_t  gpio_read(GPIO_TypeDef *port, uint8_t pin);
static const char  *hal_status_str(hal_status_t s);

/* Calls a driver function, prints the result and returns it unchanged. */
static hal_status_t report(const char *what, hal_status_t s)
{
    printf("  %-34s -> %s\n", what, hal_status_str(s));
    return s;
}

int main(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN;   /* GPIOC left OFF */

    printf("Good calls:\n");
    report("gpio_init(GPIOA, 5, OUTPUT)", gpio_init(GPIOA, 5, MODE_OUTPUT));
    report("gpio_write(GPIOA, 5, HIGH)", gpio_write(GPIOA, 5, PIN_HIGH));
    report("gpio_init(GPIOB, 0, INPUT)", gpio_init(GPIOB, 0, MODE_INPUT));
    sim_press(GPIOB, 0);                                          /* user presses a button */
    printf("  gpio_read(GPIOB, 0)                -> %d\n", (int)gpio_read(GPIOB, 0));

    printf("\nBad calls (each one is caught by a guard clause):\n");
    report("gpio_write(NULL, 5, HIGH)", gpio_write(NULL, 5, PIN_HIGH));
    report("gpio_init(GPIOA, 16, OUTPUT)", gpio_init(GPIOA, 16, MODE_OUTPUT));
    report("gpio_init(GPIOC, 3, OUTPUT)", gpio_init(GPIOC, 3, MODE_OUTPUT));

    /* The pattern a real caller uses: check, then react. */
    if (gpio_write(GPIOA, 5, PIN_LOW) != HAL_OK)
        printf("LED write failed!\n");
    else
        printf("\nLED off, ODR = 0x%04X\n", (unsigned)(GPIOA->ODR & 0xFFFFu));
    return 0;
}

/* ---- driver implementation --------------------------------------------------- */
static int port_clock_is_on(const GPIO_TypeDef *port)
{
    for (unsigned i = 0; i < SIM_NUM_PORTS; i++)
        if (sim_gpio(i) == port) return (RCC->AHB1ENR >> i) & 1U;   /* bit i = port i */
    return 0;
}

static hal_status_t gpio_init(GPIO_TypeDef *port, uint8_t pin, pin_mode_t mode)
{
    if (port == NULL || pin > 15U) return HAL_INVALID_PARAM;       /* guard clauses */
    if (!port_clock_is_on(port))   return HAL_ERROR;               /* peripheral off */

    port->MODER &= ~(3U << (pin * 2U));
    port->MODER |=  ((uint32_t)mode << (pin * 2U));
    return HAL_OK;
}

static hal_status_t gpio_write(GPIO_TypeDef *port, uint8_t pin, pin_state_t state)
{
    if (port == NULL || pin > 15U) return HAL_INVALID_PARAM;
    if (state == PIN_HIGH) port->BSRR = 1U << pin;                 /* set   */
    else                   port->BSRR = 1U << (pin + 16U);         /* reset */
    sim_gpio_apply(port);                         /* the PC needs this; real HW is instant */
    return HAL_OK;
}

static pin_state_t gpio_read(GPIO_TypeDef *port, uint8_t pin)
{
    if (port == NULL || pin > 15U) return PIN_LOW;                 /* safe default */
    return ((port->IDR >> pin) & 1U) ? PIN_HIGH : PIN_LOW;
}

static const char *hal_status_str(hal_status_t s)
{
    switch (s) {
    case HAL_OK:            return "HAL_OK";
    case HAL_ERROR:         return "HAL_ERROR (peripheral clock off?)";
    case HAL_BUSY:          return "HAL_BUSY";
    case HAL_TIMEOUT:       return "HAL_TIMEOUT";
    case HAL_INVALID_PARAM: return "HAL_INVALID_PARAM";
    }
    return "unknown status";
}
