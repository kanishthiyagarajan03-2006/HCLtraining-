/*
 * ============================================================================
 *  Topic   : 10 Functions
 *  Example : 01 - Declare, define and call: small LED helper functions
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A PROTOTYPE (declaration) tells the compiler a function's name, parameter
 *            types and return type. The DEFINITION holds the body. Declare first, so
 *            main() reads like an outline and the definitions follow below it.
 *            Arguments are COPIED into the parameters (call by value).
 *            "void f(void)" = takes nothing; "void f()" leaves the parameters unchecked.
 *  Embedded use : firmware is built from tiny single-purpose functions (led_on,
 *            read_adc, delay) so each one can be tested and reused on its own.
 *  Real STM32F4 : HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_declare_define_call.c -o ex01
 *  Output  : LED on/off steps, a 3-blink sequence, and a proof that the callee
 *            cannot change the caller's variable
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Delete the prototype of blink() and compile: read the warning/error.
 *            2) Change try_to_change() to print its parameter before and after the
 *               assignment. Is the caller's variable affected?
 * ============================================================================
 */
#include "hw_sim.h"

/* ---- prototypes: the "table of contents" of this file ----------------------- */
static void     led_init(uint8_t pin);              /* returns nothing            */
static void     led_set(uint8_t pin, int on);       /* two parameters             */
static uint8_t  led_is_on(uint8_t pin);             /* returns a value            */
static uint32_t pin_mask(uint8_t pin);              /* pure function: no side effects */
static void     blink(uint8_t pin, unsigned times, uint32_t period_ms);
static void     print_banner(void);                 /* (void) = no parameters     */
static void     try_to_change(uint8_t pin);

int main(void)
{
    const uint8_t LED = 5;

    print_banner();
    led_init(LED);

    led_set(LED, 1);
    sim_show_port("GPIOA", GPIOA);
    printf("led_is_on(%u) returned %u\n", (unsigned)LED, (unsigned)led_is_on(LED));

    led_set(LED, 0);
    sim_show_port("GPIOA", GPIOA);
    printf("led_is_on(%u) returned %u\n", (unsigned)LED, (unsigned)led_is_on(LED));

    blink(LED, 3, 250);

    /* Call by value: the function gets a COPY of LED. */
    uint8_t pin = 7;
    try_to_change(pin);
    printf("after try_to_change(), pin in main is still %u\n", (unsigned)pin);
    return 0;
}

/* ---- definitions ---------------------------------------------------------------- */
static void print_banner(void)
{
    printf("=== LED helper functions ===\n");
}

static uint32_t pin_mask(uint8_t pin)
{
    return 1U << pin;                    /* the value is handed back to the caller */
}

static void led_init(uint8_t pin)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;                   /* clock first          */
    GPIOA->MODER &= ~(3U << (pin * 2U));                   /* clear the 2-bit field */
    GPIOA->MODER |=  (1U << (pin * 2U));                   /* 01 = output          */
}

static void led_set(uint8_t pin, int on)
{
    if (on) GPIOA->ODR |=  pin_mask(pin);                  /* one function reuses another */
    else    GPIOA->ODR &= ~pin_mask(pin);
}

static uint8_t led_is_on(uint8_t pin)
{
    return (GPIOA->ODR & pin_mask(pin)) != 0U;
}

static void blink(uint8_t pin, unsigned times, uint32_t period_ms)
{
    for (unsigned i = 0; i < times; i++) {
        led_set(pin, 1);
        sim_show_leds("PA5 LED", led_is_on(pin), 1);
        sim_delay_ms(period_ms);
        led_set(pin, 0);
        sim_show_leds("PA5 LED", led_is_on(pin), 1);
        sim_delay_ms(period_ms);
    }
    printf("blink() finished %u blinks, now t = %u ms\n", times, (unsigned)sim_millis());
}

static void try_to_change(uint8_t pin)
{
    pin = 99;                            /* changes only this function's own copy */
    printf("inside try_to_change(), pin = %u\n", (unsigned)pin);
}
