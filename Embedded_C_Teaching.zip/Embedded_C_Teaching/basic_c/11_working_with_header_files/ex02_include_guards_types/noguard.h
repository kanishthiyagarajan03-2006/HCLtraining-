/*
 * noguard.h - a header WITHOUT an include guard. Only main.c uses it, and only when
 * built with -DDEMO_BUG, to show what the compiler says when it is pasted twice.
 */
typedef struct { int dummy; } noguard_t;
