/*
 * sensor.c - needs board.h for the reference voltage and sensor.h for its own prototype.
 * types.h reaches this file twice (via sensor.h and via board.h): the guard makes it safe.
 */
#include <stddef.h>      /* NULL: include what YOU use, do not rely on other headers */
#include "sensor.h"
#include "board.h"

status_t sensor_read_mv(uint16_t raw, uint16_t *mv_out)
{
    if (mv_out == NULL) return STATUS_ERROR;
    if (raw > 4095U)    return STATUS_RANGE;
    *mv_out = (uint16_t)(((uint32_t)raw * BOARD_ADC_VREF_MV) / 4095U);
    return STATUS_OK;
}
