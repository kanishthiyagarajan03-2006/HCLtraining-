/*
 * ============================================================================
 *  Topic   : 11 Working with Header Files
 *  Example : 02 - Include guards: many headers, one definition of each type
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : #include copies a file's text in place. When headers include other headers,
 *            the same one (types.h here) can arrive several times in ONE .c file. An
 *            include guard  #ifndef X / #define X / #endif  (or #pragma once) makes
 *            every visit after the first empty. Rules: one guard per header, a unique
 *            name, and each header includes what it uses so it compiles on its own.
 *  Embedded use : vendor headers (stm32f4xx.h, core_cm4.h) include each other in a web;
 *            without guards nothing would compile.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../../common main.c sensor.c -o ex02
 *            See the include tree:  gcc -H -fsyntax-only main.c 2>&1 | grep -v /usr/include
 *            (each header is listed once; a repeat visit is skipped by its guard)
 *  Output  : the pin map from board.h and ADC conversions using sensor.c
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -DDEMO_BUG: noguard.h is included twice and the build breaks.
 *            2) Delete the guard lines from types.h and rebuild: read the error.
 * ============================================================================
 */
#include <stdio.h>
#include "types.h"        /* 1st arrival of types.h in this file                      */
#include "board.h"        /* includes types.h again  -> skipped by the guard          */
#include "sensor.h"       /* includes types.h a third time -> skipped again           */
#include "util.h"         /* #pragma once style header, also includes types.h         */

#ifdef DEMO_BUG
#include "noguard.h"
#include "noguard.h"      /* error: conflicting types for 'noguard_t' (defined twice) */
#endif

static void print_pin(const char *label, pin_t p)
{
    printf("  %-7s = port %c, pin %u\n", label, 'A' + p.port, (unsigned)p.pin);
}

int main(void)
{
    printf("Board: %s\n", BOARD_NAME);
    print_pin("LED", BOARD_LED);
    print_pin("BUTTON", BOARD_BUTTON);
    printf("sizeof(pin_t) = %zu bytes\n\n", sizeof(pin_t));

    const uint16_t codes[] = { 0, 2048, 4095, 5000 };
    for (size_t i = 0; i < sizeof codes / sizeof codes[0]; i++) {
        uint16_t mv = 0;
        status_t st = sensor_read_mv(codes[i], &mv);
        printf("raw %4u -> %4u mV   %s\n", (unsigned)codes[i], (unsigned)mv, status_name(st));
    }
    return 0;
}
