/*
 * sensor.h - declaration of the ADC-to-millivolt conversion (defined in sensor.c).
 */
#ifndef SENSOR_H
#define SENSOR_H

#include <stdint.h>
#include "types.h"            /* status_t; already included by board.h in main.c - harmless */

/* Convert a 12-bit ADC code to millivolts. STATUS_RANGE if raw > 4095. */
status_t sensor_read_mv(uint16_t raw, uint16_t *mv_out);

#endif /* SENSOR_H */
