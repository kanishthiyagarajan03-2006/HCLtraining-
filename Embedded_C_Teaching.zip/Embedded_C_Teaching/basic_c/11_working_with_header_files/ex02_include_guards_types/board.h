/*
 * board.h - the pin map: which MCU pin is wired to what on THIS board.
 * Moving to a new PCB means editing only this file.
 */
#ifndef BOARD_H
#define BOARD_H

#include "types.h"            /* we use pin_t below, so we include it ourselves: a header
                               * must never depend on the includer having done it first */

#define BOARD_NAME          "demo-board rev B"
#define BOARD_LED           ((pin_t){ 0, 5 })      /* PA5 */
#define BOARD_BUTTON        ((pin_t){ 2, 13 })     /* PC13 */
#define BOARD_ADC_VREF_MV   3300U                  /* ADC reference voltage in mV */

#endif /* BOARD_H */
