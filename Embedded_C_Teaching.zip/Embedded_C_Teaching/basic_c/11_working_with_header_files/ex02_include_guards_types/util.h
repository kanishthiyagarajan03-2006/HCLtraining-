/*
 * util.h - guarded with "#pragma once" instead of #ifndef/#define/#endif.
 * Shorter and supported by GCC, Clang, ARM compiler and IAR, but not part of ISO C.
 * Many coding standards still prefer the classic guard for maximum portability.
 */
#pragma once

#include "types.h"

/* "static inline" in a header: every .c file that includes it gets its own copy,
 * so there is no "multiple definition" error at link time.                       */
static inline const char *status_name(status_t s)
{
    switch (s) {
    case STATUS_OK:    return "STATUS_OK";
    case STATUS_ERROR: return "STATUS_ERROR";
    case STATUS_RANGE: return "STATUS_RANGE";
    }
    return "?";
}
