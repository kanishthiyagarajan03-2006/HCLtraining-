/*
 * types.h - small shared types. Every other header that needs pin_t or status_t
 * includes THIS file, so the types are defined in exactly one place.
 */
#ifndef TYPES_H               /* 1st time: TYPES_H is not defined, so keep reading...   */
#define TYPES_H               /* ...and define it. Next time the whole file is skipped. */

#include <stdint.h>

/* An anonymous struct typedef: if the preprocessor pasted this twice into one .c
 * file, the compiler would see TWO different struct types named pin_t -> error.   */
typedef struct {
    uint8_t port;             /* 0 = GPIOA, 1 = GPIOB, ... */
    uint8_t pin;              /* 0..15                      */
} pin_t;

typedef enum { STATUS_OK = 0, STATUS_ERROR, STATUS_RANGE } status_t;

#endif /* TYPES_H */
