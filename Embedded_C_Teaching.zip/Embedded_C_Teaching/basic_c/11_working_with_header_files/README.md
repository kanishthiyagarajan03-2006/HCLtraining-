# Topic 11 - Working with Header Files
**Suggested session:** 90 min | **Prerequisite topics:** 02 Compilation Process, 09 Preprocessor, 10 Functions

Every example here is a small multi-file project (a folder containing `main.c` plus other `.c` and `.h` files). Students learn what belongs in a header and what does not, why include guards exist, how `extern` and `static` decide who shares a variable, where the compiler searches for headers, how headers define software layers, and how system headers are used on embedded Linux.

Build a project from inside its folder, for example: `gcc -std=gnu11 -Wall -Wextra -I../../../common main.c led.c -o ex01`. The Build line at the top of each `main.c` lists the exact files.

| # | Folder | Flavour | What it teaches |
|---|--------|---------|-----------------|
| 01 | `ex01_led_module/` | MCU | header = declarations, `.c` = definitions, a `static` private variable, separate compilation and linking |
| 02 | `ex02_include_guards_types/` | MCU | `#ifndef` guards vs `#pragma once`, shared `types.h`, "include what you use", `DEMO_BUG` shows the missing-guard error |
| 03 | `ex03_extern_vs_static_globals/` | MCU | `extern` declaration vs one definition, `SystemCoreClock` pattern, `static` in a header, "multiple definition" (`DEMO_BUG`) |
| 04 | `ex04_include_paths/` | MCU | `<>` vs `""`, search order, `-I`, an `inc/` folder, headers that include sibling headers |
| 05 | `ex05_hal_layering/` | MCU | application -> driver -> HAL layering, `board.h` pin map, only the lowest layer touches registers |
| 06 | `ex06_rtos_config_and_tasks/` | RTOS | `rtos_config.h`, task table in a header, OS-port header, why a header-only kernel must be included by one file |
| 07 | `ex07_linux_system_headers/` | LINUX | what `<unistd.h>`, `<fcntl.h>`, `<sys/stat.h>`, `<errno.h>` provide; keeping system headers out of project headers |

## Teaching notes
* Rule of thumb: a header may contain types, prototypes, `extern` declarations, macros and `static inline` functions. It must NOT contain variable definitions or normal function bodies.
* Include guards protect against duplicates inside ONE `.c` file; every `.c` file still compiles its own copy of the headers.
* Self-contained headers: each header includes what it needs. Test with `gcc -fsyntax-only -x c header.h`.
* "Undefined reference" is a LINKER error (a declaration without a definition); "multiple definition" is the opposite. Show both (remove a `.c` file; build ex03 with `-DDEMO_BUG`).
* `static` has two meanings: a private name at file scope, and a lasting variable inside a function. (Topic 13 goes deeper.)
* `hw_sim.h` and `mini_rtos.h` keep their state inside `static inline` functions, so each `.c` file that includes them gets its own state. That is why only one `.c` file in each project uses them (ex06 explains it).

## Live-demo tips
* See the include tree: `gcc -H -fsyntax-only main.c 2>&1 | grep -v /usr/include` (ex02). Each header is listed once: a guarded header that arrives again is skipped without being re-read.
* Compile in steps: `gcc -c -I../../../common led.c`, `gcc -c main.c`, `nm led.o main.o`, then `gcc main.o led.o -o ex01`, to show `U` (undefined) and `T` (defined) symbols (ex01; only `led.c` needs the `-I` for `hw_sim.h`).
* Print the real search list: `gcc -v -E -x c /dev/null 2>&1 | sed -n '/search starts here/,/End of search/p'` (ex04).
