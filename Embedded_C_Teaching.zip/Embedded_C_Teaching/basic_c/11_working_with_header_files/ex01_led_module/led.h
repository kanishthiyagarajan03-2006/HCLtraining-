/*
 * led.h - PUBLIC interface of the LED module.
 *
 * A header holds DECLARATIONS only: "this function exists, here is its shape".
 * The DEFINITIONS (the bodies) are in led.c. Anybody who wants to use the LEDs
 * writes  #include "led.h"  and never needs to know which pin or register is used.
 */
#ifndef LED_H                 /* include guard: see example 02 for why this is needed */
#define LED_H

#include <stdint.h>           /* uint8_t is used in a prototype below, so include it here */

typedef enum { LED_GREEN = 0, LED_RED, LED_COUNT } led_id_t;

void     led_init(void);
void     led_on(led_id_t id);
void     led_off(led_id_t id);
void     led_toggle(led_id_t id);
uint8_t  led_is_on(led_id_t id);
unsigned led_toggle_count(void);     /* how often led_toggle() ran: hidden state, read-only view */
void     led_dump(void);             /* print the port, so main.c needs no register access */

#endif /* LED_H */
