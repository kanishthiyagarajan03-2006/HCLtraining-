/*
 * led.c - IMPLEMENTATION of the LED module.
 *
 * It includes its own header so the compiler can check that every definition here
 * matches the declaration that other files rely on (wrong type -> compile error).
 */
#include "led.h"
#include "hw_sim.h"             /* only this file knows about GPIO registers */

/* 'static' = private to this file. main.c cannot see or change these names. */
static const uint8_t led_pin[LED_COUNT] = { 5, 6 };        /* PA5 green, PA6 red */
static unsigned      s_toggles;

void led_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    for (int i = 0; i < (int)LED_COUNT; i++) {
        GPIOA->MODER &= ~(3U << (led_pin[i] * 2U));
        GPIOA->MODER |=  (1U << (led_pin[i] * 2U));        /* output */
    }
}

void led_on(led_id_t id)     { GPIOA->ODR |=  (1U << led_pin[id]); }
void led_off(led_id_t id)    { GPIOA->ODR &= ~(1U << led_pin[id]); }

void led_toggle(led_id_t id)
{
    GPIOA->ODR ^= (1U << led_pin[id]);
    s_toggles++;
}

uint8_t led_is_on(led_id_t id)     { return (uint8_t)((GPIOA->ODR >> led_pin[id]) & 1U); }
unsigned led_toggle_count(void)    { return s_toggles; }

void led_dump(void)
{
    sim_show_port("GPIOA", GPIOA);
}
