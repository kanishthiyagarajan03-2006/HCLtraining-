/*
 * ============================================================================
 *  Topic   : 11 Working with Header Files
 *  Example : 01 - A first module: led.h declares, led.c defines, main.c uses
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Split code into a module = header (the contract) + source file (the work).
 *            The header holds declarations (prototypes, types, extern); the .c file holds
 *            definitions (bodies, variables). Each .c file is compiled separately into an
 *            object file, then the linker joins them and resolves the function names.
 *            "static" in led.c keeps helpers and data private to that file.
 *  Embedded use : a firmware project is dozens of such modules (led, uart, adc, timer).
 *            The team agrees on the headers first and everybody codes behind them.
 *  Real STM32F4 : the same split as stm32f4xx_hal_gpio.h / stm32f4xx_hal_gpio.c.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../../common main.c led.c -o ex01
 *            Step by step:  gcc -c led.c  then  gcc -c main.c  then  gcc main.o led.o
 *            (only the led.c compile needs -I../../../common, for hw_sim.h)
 *  Output  : LED states printed through the module, with no register access in main.c
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Remove led.c from the gcc command: read the "undefined reference" error.
 *            2) Try to use s_toggles in main.c: why does the compiler refuse?
 * ============================================================================
 */
#include <stdio.h>
#include "led.h"                       /* the ONLY thing main.c needs to know about LEDs */

int main(void)
{
    led_init();
    printf("after led_init()\n");
    led_dump();

    led_on(LED_GREEN);
    printf("\nled_on(LED_GREEN)  -> green is %s\n", led_is_on(LED_GREEN) ? "ON" : "off");
    led_dump();

    led_on(LED_RED);
    led_off(LED_GREEN);
    printf("\nred on, green off  -> red is %s, green is %s\n",
           led_is_on(LED_RED) ? "ON" : "off", led_is_on(LED_GREEN) ? "ON" : "off");
    led_dump();

    for (int i = 0; i < 3; i++)
        led_toggle(LED_RED);
    printf("\nafter 3 toggles of red: %s (led_toggle() ran %u times)\n",
           led_is_on(LED_RED) ? "ON" : "off", led_toggle_count());
    led_dump();
    return 0;
}
