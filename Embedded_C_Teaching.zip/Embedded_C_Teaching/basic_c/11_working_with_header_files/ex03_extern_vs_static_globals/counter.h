/*
 * counter.h - public view of the counter module: functions only, no variables.
 */
#ifndef COUNTER_H
#define COUNTER_H

#include <stdint.h>

uint32_t    counter_next(void);                  /* returns 1, 2, 3, ...               */
uint32_t    counter_ticks_per_ms(void);          /* uses SystemCoreClock (extern)      */
const void *counter_clock_address(void);         /* where counter.c sees SystemCoreClock */
const void *counter_header_copy_address(void);   /* where counter.c keeps g_tick_copy    */
uint32_t    counter_header_copy_value(void);     /* the value of counter.c's copy        */

#endif /* COUNTER_H */
