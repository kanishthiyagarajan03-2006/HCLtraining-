/*
 * clock_cfg.h - declares the system clock variable shared by the whole firmware.
 *
 * DECLARATION  = "this object exists somewhere"      (extern, no storage here)
 * DEFINITION   = "reserve memory for it, here"       (exactly ONE .c file)
 */
#ifndef CLOCK_CFG_H
#define CLOCK_CFG_H

#include <stdint.h>

/* CMSIS uses exactly this pattern:  extern uint32_t SystemCoreClock;  */
extern uint32_t SystemCoreClock;            /* declaration only - defined in clock_cfg.c */
extern const char fw_version[];             /* extern arrays may omit the size           */

/* WRONG: a variable DEFINED in a header. Every .c file that includes this header would
 * create its own definition and the linker stops with "multiple definition of ...".  */
#ifdef DEMO_BUG
uint32_t g_duplicate = 7;
#endif

/* LEGAL BUT USUALLY A MISTAKE: 'static' in a header gives every .c file its OWN private
 * copy. Both main.c and counter.c use it below, yet they never share one value.
 * GCC warns "defined but not used" in each file that ignores it (clock_cfg.c does), a
 * hint that this is a bad pattern; the attribute only silences that warning for the demo. */
static uint32_t g_tick_copy __attribute__((unused));

#endif /* CLOCK_CFG_H */
