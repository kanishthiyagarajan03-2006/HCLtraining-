/*
 * ============================================================================
 *  Topic   : 11 Working with Header Files
 *  Example : 03 - extern globals vs static variables across files
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : A global has ONE definition (in a .c file) and any number of extern
 *            declarations (in a header). "static" at file scope means private: each file
 *            has its own object. Never define a variable in a header: every .c that
 *            includes it would define it again -> "multiple definition" at link time.
 *            Design rule: expose functions, hide variables.
 *  Embedded use : SystemCoreClock is the textbook shared global (CMSIS). Private state such
 *            as a debounce counter is static so no other file can corrupt it.
 *  Real STM32F4 : extern uint32_t SystemCoreClock;   // in system_stm32f4xx.h
 *            uint32_t SystemCoreClock = 16000000;    // in system_stm32f4xx.c
 *  Build   : gcc -std=gnu11 -Wall -Wextra main.c clock_cfg.c counter.c -o ex03
 *            Linker error demo:  add -DDEMO_BUG to the command line
 *  Output  : the shared clock seen by two files, a proof that the static copies differ,
 *            and the private counter reachable only through its function
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -DDEMO_BUG and read the "multiple definition" message.
 *            2) Remove the extern keyword from SystemCoreClock in clock_cfg.h: what changes?
 *               (gcc 10+ gives "multiple definition"; older gcc silently merged such
 *               "common" symbols, so the bug could hide for years.)
 * ============================================================================
 */
#include <stdio.h>
#include "clock_cfg.h"
#include "counter.h"

int main(void)
{
    printf("firmware %s, SystemCoreClock = %lu Hz\n", fw_version, (unsigned long)SystemCoreClock);
    printf("counter.c computes %lu ticks per ms\n", (unsigned long)counter_ticks_per_ms());

    SystemCoreClock = 84000000U;              /* "PLL configured": main.c writes the variable */
    printf("\nmain.c sets SystemCoreClock = 84000000\n");
    printf("counter.c now computes %lu ticks per ms (it saw the change)\n",
           (unsigned long)counter_ticks_per_ms());
    printf("same object in both files? %s\n",
           (const void *)&SystemCoreClock == counter_clock_address() ? "YES (extern)" : "no");

    /* g_tick_copy is declared 'static' in the header, so each .c file owns one. */
    g_tick_copy = 100;                        /* only main.c's copy changes */
    counter_next();
    counter_next();
    counter_next();                           /* counter.c bumps ITS copy three times */
    const char *same = ((const void *)&g_tick_copy == counter_header_copy_address())
                           ? "yes" : "NO (static in header)";
    printf("\ng_tick_copy: main.c sees %lu, counter.c sees %lu\n", (unsigned long)g_tick_copy,
           (unsigned long)counter_header_copy_value());
    printf("same object in both files? %s\n", same);

    /* s_count is 'static' in counter.c: main.c cannot even name it. */
    printf("\ncounter_next() -> %lu (s_count is private to counter.c)\n",
           (unsigned long)counter_next());
    return 0;
}
