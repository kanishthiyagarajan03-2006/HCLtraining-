/*
 * clock_cfg.c - the ONE place where SystemCoreClock and fw_version are defined.
 * Including our own header lets the compiler verify the types agree.
 */
#include "clock_cfg.h"

uint32_t SystemCoreClock = 16000000U;       /* HSI after reset; PLL code may raise it */
const char fw_version[] = "1.4.2";
