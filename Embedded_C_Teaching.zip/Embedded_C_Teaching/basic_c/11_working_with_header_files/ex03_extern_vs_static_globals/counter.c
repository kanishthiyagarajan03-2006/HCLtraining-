/*
 * counter.c - owns a file-private counter and reads the shared clock variable.
 */
#include "counter.h"
#include "clock_cfg.h"

static uint32_t s_count;              /* 'static' global: invisible outside this file */

uint32_t counter_next(void)
{
    g_tick_copy++;                    /* touches counter.c's OWN copy of g_tick_copy */
    return ++s_count;
}

uint32_t counter_ticks_per_ms(void)
{
    return SystemCoreClock / 1000U;   /* the SAME object that main.c writes to */
}

const void *counter_clock_address(void)       { return &SystemCoreClock; }
const void *counter_header_copy_address(void) { return &g_tick_copy; }
uint32_t    counter_header_copy_value(void)   { return g_tick_copy; }
