/*
 * inc/uart.h - public interface of the UART driver.
 *
 * Look at the two include styles below:
 *   <stdint.h>      angle brackets: search the compiler's system folders (and -I folders)
 *   "board_cfg.h"   quotes: search the folder of THIS file (inc/) first, then the rest
 * main.c lives one folder up, yet "board_cfg.h" is still found: the search for a quoted
 * include starts in the directory of the file that contains the #include.
 */
#ifndef UART_H
#define UART_H

#include <stdint.h>
#include "board_cfg.h"

void     uart_init(void);
void     uart_send(const char *text);
uint32_t uart_baud_register(void);       /* value programmed into USART2->BRR */

#endif /* UART_H */
