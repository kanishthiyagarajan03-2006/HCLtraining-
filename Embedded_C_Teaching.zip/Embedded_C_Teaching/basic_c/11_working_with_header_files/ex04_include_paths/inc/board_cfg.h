/*
 * inc/board_cfg.h - board constants. Lives in the inc/ folder next to uart.h.
 */
#ifndef BOARD_CFG_H
#define BOARD_CFG_H

#define UART_BAUD        115200U
#define UART_CLOCK_HZ    16000000U      /* USART2 kernel clock (APB1) */

#endif /* BOARD_CFG_H */
