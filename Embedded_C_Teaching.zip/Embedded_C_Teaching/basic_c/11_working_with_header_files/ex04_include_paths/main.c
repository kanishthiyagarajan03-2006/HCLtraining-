/*
 * ============================================================================
 *  Topic   : 11 Working with Header Files
 *  Example : 04 - #include "..." vs <...> and where the compiler looks (-I)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : #include <name.h>  searches the system folders and every -I folder.
 *            #include "name.h"  searches the folder of the FILE CONTAINING the include
 *            first, then falls back to the same list as <...>.
 *            "-Idir" adds a folder to the search list, so headers can be kept in
 *            inc/ and shared (like common/hw_sim.h here, found through -I).
 *  Embedded use : real projects keep headers in inc/, drivers in src/, vendor code in
 *            Drivers/CMSIS/Include. The IDE passes each folder with -I to the compiler.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../../common main.c uart.c -o ex04
 *            Variant: add -Iinc and write  #include "uart.h"  instead of "inc/uart.h"
 *  Output  : UART baud-rate register computed from board_cfg.h, then a message "sent"
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -Iinc and change main.c to #include "uart.h". Does uart.c still
 *               compile? (It says "inc/uart.h": think about where that is searched.)
 *            2) See the system search list:
 *               gcc -v -E -x c /dev/null 2>&1 | sed -n '/search starts here/,/End of search/p'
 * ============================================================================
 */
#include <stdio.h>             /* <> : system header folder                               */
#include "hw_sim.h"            /* "" : not next to main.c, so found via -I../../../common */
#include "inc/uart.h"          /* "" : relative to the folder of main.c (inc/uart.h)      */

int main(void)
{
    printf("UART configuration (from inc/board_cfg.h via inc/uart.h)\n");
    printf("  baud rate      : %u\n", UART_BAUD);
    printf("  kernel clock   : %u Hz\n", UART_CLOCK_HZ);

    uart_init();
    uint32_t brr = uart_baud_register();
    printf("  USART2->BRR    : %u (0x%03X)\n", (unsigned)brr, (unsigned)brr);

    /* Real baud rate achieved with an integer divider, and the error it causes. */
    uint32_t real = UART_CLOCK_HZ / brr;
    int err = (int)(((int64_t)real - (int64_t)UART_BAUD) * 10000 / (int64_t)UART_BAUD);
    printf("  actual baud    : %u (error %c%d.%02d %%)\n", (unsigned)real, err < 0 ? '-' : '+',
           (err < 0 ? -err : err) / 100, (err < 0 ? -err : err) % 100);

    sim_delay_ms(10);                              /* hw_sim.h is used in this file only */
    printf("\n[%u ms] sending over the fake UART: ", (unsigned)sim_millis());
    uart_send("hello from the driver\n");
    return 0;
}
