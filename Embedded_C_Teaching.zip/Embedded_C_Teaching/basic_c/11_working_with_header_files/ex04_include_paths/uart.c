/*
 * uart.c - UART driver with file-local fake registers (no hw_sim.h needed here).
 */
#include <stdio.h>
#include "inc/uart.h"                     /* path is relative to THIS file's folder */

static volatile uint32_t USART2_BRR;      /* real chip: USART2->BRR at 0x40004408 */
static volatile uint32_t USART2_DR;       /* real chip: USART2->DR  at 0x40004404 */

void uart_init(void)
{
    /* Oversampling by 16: BRR = fck / baud, rounded to the nearest integer. */
    USART2_BRR = (UART_CLOCK_HZ + (UART_BAUD / 2U)) / UART_BAUD;
}

uint32_t uart_baud_register(void)
{
    return USART2_BRR;
}

void uart_send(const char *text)
{
    while (*text != '\0') {
        USART2_DR = (uint8_t)*text++;                 /* real code first waits for TXE */
        putchar((int)(USART2_DR & 0xFFU));            /* the "wire": stdout here */
    }
}
