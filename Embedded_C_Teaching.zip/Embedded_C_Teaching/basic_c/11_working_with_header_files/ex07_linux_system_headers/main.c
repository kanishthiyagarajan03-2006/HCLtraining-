/*
 * ============================================================================
 *  Topic   : 11 Working with Header Files
 *  Example : 07 - Linux system headers: what <unistd.h>, <sys/stat.h> ... provide
 *  Flavour : LINUX
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : System headers use angle brackets and live in /usr/include. ISO C headers
 *            (<stdio.h>, <string.h>) work everywhere; POSIX headers (<unistd.h>, <fcntl.h>,
 *            <sys/stat.h>) exist on Linux but not on bare-metal or plain Windows.
 *            Include what you use: .c files include the system headers they need, and a
 *            project header (fsutil.h) exposes only what its prototypes require.
 *  Embedded use : embedded Linux code talks to the kernel through these headers: open/read/
 *            write for /dev and /sys files, stat for file info, chmod for permissions.
 *  Build   : gcc -std=gnu11 -Wall -Wextra main.c fsutil.c -o ex07
 *            See every header the compiler really opened:  gcc -H -fsyntax-only main.c 2>&1 | head
 *  Output  : a table "header -> what it gives you", then fsutil functions run on a file
 *            in a temporary folder (created and removed by the program)
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Remove #include <errno.h> from this file: which line fails to compile?
 *            2) Run  gcc -E main.c | grep -c '^# 1 "/usr'  to count the system headers pulled in.
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <errno.h>          /* errno, ENOENT                           */
#include <stdio.h>          /* printf, snprintf, perror (ISO C)        */
#include <stdlib.h>         /* mkdtemp (POSIX), EXIT_FAILURE           */
#include <string.h>         /* strerror                                */
#include <unistd.h>         /* unlink, rmdir                           */
#include "fsutil.h"         /* our own header: quotes, our own folder  */

static void print_header_table(void)
{
    static const struct { const char *header; const char *provides; } t[] = {
        { "<stdio.h>",     "printf, snprintf, FILE, perror            (ISO C)" },
        { "<stdlib.h>",    "malloc, free, exit, mkdtemp               (C + POSIX)" },
        { "<string.h>",    "strlen, memcpy, strerror                  (ISO C)" },
        { "<errno.h>",     "errno, ENOENT, EINTR                      (C + POSIX)" },
        { "<unistd.h>",    "read, write, close, unlink, rmdir, sleep  (POSIX)" },
        { "<fcntl.h>",     "open, O_RDONLY, O_CREAT, O_TRUNC          (POSIX)" },
        { "<sys/stat.h>",  "stat, chmod, S_ISDIR, S_IRUSR             (POSIX)" },
        { "<sys/types.h>", "mode_t, off_t, pid_t, ssize_t             (POSIX)" },
    };
    printf("%-14s %s\n", "header", "what it provides");
    for (size_t i = 0; i < sizeof t / sizeof t[0]; i++)
        printf("%-14s %s\n", t[i].header, t[i].provides);
}

int main(void)
{
    print_header_table();

    char dir[] = "/tmp/hdr_demo_XXXXXX";              /* XXXXXX is replaced by mkdtemp */
    if (mkdtemp(dir) == NULL) {
        perror("mkdtemp");
        return EXIT_FAILURE;
    }
    char path[64];
    snprintf(path, sizeof path, "%s/settings.cfg", dir);

    printf("\nworking in a private temp folder (removed at the end)\n");
    int rc = fsutil_write_text(path, "baud=115200\nmode=8N1\n");
    printf("fsutil_write_text()   -> %d\n", rc);
    printf("fsutil_file_size()    -> %ld bytes\n", fsutil_file_size(path));

    fsutil_set_mode(path, 0640);                      /* rw-r----- */
    printf("fsutil_get_mode()     -> %04o  (owner rw, group r, others none)\n",
           (unsigned)fsutil_get_mode(path));
    printf("fsutil_is_dir(folder) -> %d,  fsutil_is_dir(file) -> %d\n",
           fsutil_is_dir(dir), fsutil_is_dir(path));

    long missing = fsutil_file_size("/nonexistent/file.cfg");
    printf("missing file          -> %ld, errno %d = \"%s\"\n", missing, errno,
           strerror(errno));

    unlink(path);                                     /* clean up everything we created */
    rmdir(dir);
    return rc == 0 ? 0 : EXIT_FAILURE;
}
