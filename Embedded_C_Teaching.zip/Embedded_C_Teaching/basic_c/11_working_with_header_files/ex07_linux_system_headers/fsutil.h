/*
 * fsutil.h - tiny file helper module for embedded Linux.
 *
 * Notice what is NOT included here: <unistd.h>, <fcntl.h>, <sys/stat.h>. The prototypes
 * need only size_t, so only <stddef.h> is included. A header should pull in as little as
 * possible; the heavy system headers stay inside fsutil.c, where they are used.
 */
#ifndef FSUTIL_H
#define FSUTIL_H

#include <stddef.h>

int  fsutil_write_text(const char *path, const char *text);   /* 0 = ok, -1 = error (errno) */
long fsutil_file_size(const char *path);                      /* bytes, or -1 on error       */
int  fsutil_is_dir(const char *path);                         /* 1 = directory, 0 = no/error */
int  fsutil_set_mode(const char *path, unsigned mode);        /* chmod: 0 = ok, -1 = error   */
int  fsutil_get_mode(const char *path);                       /* permission bits, -1 = error */

#endif /* FSUTIL_H */
