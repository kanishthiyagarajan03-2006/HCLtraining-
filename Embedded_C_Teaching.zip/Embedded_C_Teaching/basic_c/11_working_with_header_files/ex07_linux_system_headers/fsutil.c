/*
 * fsutil.c - implementation. This is where the POSIX system headers belong.
 */
#include <errno.h>          /* errno                                         */
#include <fcntl.h>          /* open(), O_WRONLY, O_CREAT, O_TRUNC            */
#include <string.h>         /* strlen()                                      */
#include <sys/stat.h>       /* stat(), chmod(), S_ISDIR(), permission bits   */
#include <unistd.h>         /* write(), close()                              */
#include "fsutil.h"

int fsutil_write_text(const char *path, const char *text)
{
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fd < 0) return -1;

    size_t left = strlen(text);
    while (left > 0) {                               /* write() may write only part */
        ssize_t n = write(fd, text, left);
        if (n < 0) {
            if (errno == EINTR) continue;            /* interrupted by a signal: retry */
            close(fd);
            return -1;
        }
        text += n;
        left -= (size_t)n;
    }
    return close(fd);
}

long fsutil_file_size(const char *path)
{
    struct stat st;
    if (stat(path, &st) != 0) return -1;
    return (long)st.st_size;
}

int fsutil_is_dir(const char *path)
{
    struct stat st;
    return stat(path, &st) == 0 && S_ISDIR(st.st_mode);
}

int fsutil_set_mode(const char *path, unsigned mode)
{
    return chmod(path, (mode_t)mode);
}

int fsutil_get_mode(const char *path)
{
    struct stat st;
    if (stat(path, &st) != 0) return -1;
    return (int)(st.st_mode & 07777);                /* strip the file-type bits */
}
