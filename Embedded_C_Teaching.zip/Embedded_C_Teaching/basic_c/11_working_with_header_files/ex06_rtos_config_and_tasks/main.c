/*
 * ============================================================================
 *  Topic   : 11 Working with Header Files
 *  Example : 06 - An RTOS project: config header, task header, OS-port header
 *  Flavour : RTOS
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : An RTOS application is organised around headers:
 *              rtos_config.h  priorities, periods, stack sizes (like FreeRTOSConfig.h)
 *              app_tasks.h    task prototypes + a task table + an extern shared variable
 *              os_port.h      the few kernel services tasks may call
 *            WHY os_port.h? mini_rtos.h is header-only: its functions are "static inline"
 *            and the kernel state is a static variable inside one of them. A .c file that
 *            includes it gets its OWN private copy of that state - a second, empty kernel!
 *            So exactly one file (this one) includes mini_rtos.h and DEFINES the os_*
 *            functions; app_tasks.c only sees their declarations. Same trick as an OSAL.
 *  Embedded use : keeping tasks free of vendor RTOS headers lets you change RTOS (or test
 *            the tasks on a PC) by rewriting a single small file.
 *  Real FreeRTOS : FreeRTOSConfig.h, task.h, and  xTaskCreate(def->entry, def->name, ...)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../../common main.c app_tasks.c -o ex06
 *  Output  : sensor (100 ms), display (300 ms) and heartbeat (500 ms) tasks interleaved
 *            for one simulated second, all created from the task table
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Edit only rtos_config.h: make DISPLAY_PERIOD_MS 200 and rebuild. What moves?
 *            2) Add #include "mini_rtos.h" to app_tasks.c and call rtos_ticks() there: why
 *               does it always return 0? (Think "second private kernel".)
 * ============================================================================
 */
#include <stdarg.h>
#include "mini_rtos.h"              /* included by THIS file only */
#include "rtos_config.h"
#include "os_port.h"
#include "app_tasks.h"

/* ---- the OS port: definitions of the functions declared in os_port.h ------------ */
void os_delay_ms(uint32_t ms) { rtos_delay(ms); }
uint32_t os_ticks(void)       { return rtos_ticks(); }

void os_log(const char *fmt, ...)
{
    char buf[96];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    rtos_log("%s", buf);                      /* adds time stamp and task name */
}

int main(void)
{
    printf("creating %zu tasks from app_task_table\n", app_task_count);
    for (size_t i = 0; i < app_task_count; i++) {
        const task_def_t *def = &app_task_table[i];
        rtos_task_create(def->name, def->entry, NULL, def->priority, TASK_STACK_BYTES);
        printf("  task %-8s priority %d\n", def->name, def->priority);
    }
    printf("\n");

    rtos_start(RUN_TIME_MS);
    rtos_shutdown();
    return 0;
}
