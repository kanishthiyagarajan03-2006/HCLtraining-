/*
 * app_tasks.h - what the application layer offers to main.c:
 *   * the task entry functions (prototypes),
 *   * a table describing them, so main.c can create every task in a loop,
 *   * one shared variable, declared extern here and defined in app_tasks.c.
 */
#ifndef APP_TASKS_H
#define APP_TASKS_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    const char *name;
    void      (*entry)(void *arg);              /* the RTOS task signature */
    int         priority;
} task_def_t;

void task_sensor(void *arg);
void task_display(void *arg);
void task_heartbeat(void *arg);

extern volatile uint16_t g_latest_adc;          /* written by sensor, read by display */
extern const task_def_t  app_task_table[];      /* defined in app_tasks.c */
extern const size_t      app_task_count;

#endif /* APP_TASKS_H */
