/*
 * os_port.h - a thin "OS abstraction layer": the few kernel services the tasks need.
 * Tasks include THIS header, never the RTOS header, so they stay portable
 * (compare CMSIS-RTOS: osDelay(), osKernelGetTickCount()).
 * The functions are DECLARED here and DEFINED once, in main.c.
 */
#ifndef OS_PORT_H
#define OS_PORT_H

#include <stdint.h>

#if defined(__GNUC__)
#  define OS_PRINTF_LIKE  __attribute__((format(printf, 1, 2)))   /* compiler checks the format */
#else
#  define OS_PRINTF_LIKE
#endif

void     os_delay_ms(uint32_t ms);              /* block the calling task for ms   */
uint32_t os_ticks(void);                        /* time since the scheduler started */
void     os_log(const char *fmt, ...) OS_PRINTF_LIKE;

#endif /* OS_PORT_H */
