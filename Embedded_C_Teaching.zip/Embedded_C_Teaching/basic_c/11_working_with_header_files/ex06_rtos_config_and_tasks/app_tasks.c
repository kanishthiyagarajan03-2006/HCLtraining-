/*
 * app_tasks.c - the application's tasks. It includes os_port.h and rtos_config.h but
 * deliberately NOT mini_rtos.h (see the comment in main.c for the reason).
 */
#include "app_tasks.h"
#include "os_port.h"
#include "rtos_config.h"

volatile uint16_t g_latest_adc;                 /* the one definition of the shared variable */

static uint16_t fake_adc(void)
{
    return (uint16_t)((os_ticks() * 13U) % 4096U);     /* a repeatable "sensor" signal */
}

void task_sensor(void *arg)
{
    (void)arg;
    for (;;) {
        g_latest_adc = fake_adc();
        os_log("sampled ADC = %u", (unsigned)g_latest_adc);
        os_delay_ms(SENSOR_PERIOD_MS);
    }
}

void task_display(void *arg)
{
    (void)arg;
    for (;;) {
        unsigned mv = ((unsigned)g_latest_adc * 3300U) / 4095U;
        os_log("showing %u mV", mv);
        os_delay_ms(DISPLAY_PERIOD_MS);
    }
}

void task_heartbeat(void *arg)
{
    (void)arg;
    for (;;) {
        os_log("heartbeat at %u ms", (unsigned)os_ticks());
        os_delay_ms(HEARTBEAT_PERIOD_MS);
    }
}

/* One table instead of three hard-coded create calls in main.c. */
const task_def_t app_task_table[] = {
    { "sensor",  task_sensor,    PRIO_SENSOR    },
    { "display", task_display,   PRIO_DISPLAY   },
    { "heartbt", task_heartbeat, PRIO_HEARTBEAT },
};
const size_t app_task_count = sizeof app_task_table / sizeof app_task_table[0];
