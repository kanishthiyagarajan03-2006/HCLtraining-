/*
 * rtos_config.h - ALL tuning knobs of the application in one header (cf. FreeRTOSConfig.h).
 * Priorities, periods and stack sizes are decided here, not scattered through the code.
 */
#ifndef RTOS_CONFIG_H
#define RTOS_CONFIG_H

#define TASK_STACK_BYTES      1024U      /* per-task stack (mini_rtos enforces a PC minimum) */

#define PRIO_HEARTBEAT        1          /* bigger number = higher priority, as in FreeRTOS  */
#define PRIO_DISPLAY          2
#define PRIO_SENSOR           3

#define SENSOR_PERIOD_MS      100U
#define DISPLAY_PERIOD_MS     300U
#define HEARTBEAT_PERIOD_MS   500U

#define RUN_TIME_MS           1000U      /* how long this demo lets the scheduler run */

#endif /* RTOS_CONFIG_H */
