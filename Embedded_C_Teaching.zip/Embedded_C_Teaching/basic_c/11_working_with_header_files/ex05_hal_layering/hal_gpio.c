/*
 * hal_gpio.c - the ONLY file that includes hw_sim.h. To move to real silicon you would
 * rewrite this file (include stm32f4xx.h instead) and leave every other file unchanged.
 */
#include "hal_gpio.h"
#include "hw_sim.h"

static GPIO_TypeDef *port_regs(hal_port_t port)
{
    return sim_gpio((unsigned)port);
}

static int args_ok(hal_port_t port, uint8_t pin)
{
    return (unsigned)port < (unsigned)HAL_PORT_COUNT && pin < 16U;
}

hal_status_t hal_gpio_init_output(hal_port_t port, uint8_t pin)
{
    if (!args_ok(port, pin)) return HAL_BAD_ARG;
    GPIO_TypeDef *p = port_regs(port);
    RCC->AHB1ENR |= (1U << (unsigned)port);               /* enable that port's clock */
    p->MODER &= ~(3U << (pin * 2U));
    p->MODER |=  (1U << (pin * 2U));                      /* 01 = output */
    return HAL_OK;
}

hal_status_t hal_gpio_write(hal_port_t port, uint8_t pin, hal_level_t level)
{
    if (!args_ok(port, pin)) return HAL_BAD_ARG;
    GPIO_TypeDef *p = port_regs(port);
    p->BSRR = (level == HAL_HIGH) ? (1U << pin) : (1U << (pin + 16U));
    sim_gpio_apply(p);                                    /* PC only: real HW reacts at once */
    return HAL_OK;
}

hal_level_t hal_gpio_read(hal_port_t port, uint8_t pin)
{
    if (!args_ok(port, pin)) return HAL_LOW;
    return ((port_regs(port)->IDR >> pin) & 1U) ? HAL_HIGH : HAL_LOW;
}

void hal_delay_ms(uint32_t ms)  { sim_delay_ms(ms); }
uint32_t hal_millis(void)       { return sim_millis(); }

uint16_t hal_gpio_read_port(hal_port_t port)
{
    if ((unsigned)port >= (unsigned)HAL_PORT_COUNT) return 0U;
    sim_gpio_apply(port_regs(port));
    return (uint16_t)(port_regs(port)->IDR & 0xFFFFU);
}
