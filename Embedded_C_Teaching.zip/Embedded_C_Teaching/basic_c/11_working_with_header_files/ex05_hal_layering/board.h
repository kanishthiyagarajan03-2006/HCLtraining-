/*
 * board.h - pin map of this PCB. The driver layer reads it; the application never needs to.
 */
#ifndef BOARD_H
#define BOARD_H

#include "hal_gpio.h"                /* hal_port_t for the port names below */

#define BOARD_LED_GREEN_PORT   HAL_PORT_A
#define BOARD_LED_GREEN_PIN    5U
#define BOARD_LED_RED_PORT     HAL_PORT_B
#define BOARD_LED_RED_PIN      7U

#endif /* BOARD_H */
