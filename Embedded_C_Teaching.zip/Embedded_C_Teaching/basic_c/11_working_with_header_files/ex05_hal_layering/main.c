/*
 * ============================================================================
 *  Topic   : 11 Working with Header Files
 *  Example : 05 - Layered headers: application -> driver -> HAL -> registers
 *  Flavour : MCU
 *  Level   : Intermediate
 * ----------------------------------------------------------------------------
 *  Concept : Headers define the layers of a firmware. Each layer includes only the
 *            headers of layers BELOW it (plus shared config such as board.h), never a
 *            header of a layer above it:
 *
 *               main.c          includes led_driver.h, hal_gpio.h (delay/time only)
 *                  |
 *               led_driver.c    includes led_driver.h, board.h, hal_gpio.h
 *                  |
 *               hal_gpio.c      includes hal_gpio.h, hw_sim.h   <- only file with registers
 *                  |
 *               GPIOx->ODR / BSRR (hardware)
 *
 *            board.h holds the pin map, so changing the PCB touches one file.
 *  Embedded use : this is how STM32Cube, Zephyr and every professional code base is organised.
 *            Porting to another MCU means rewriting only the lowest layer.
 *  Real STM32F4 : hal_gpio_write() would become  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, state);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../../common main.c led_driver.c hal_gpio.c -o ex05
 *            List the headers each file pulls in:  gcc -MM -I../../../common led_driver.c
 *  Output  : a green/red pattern with the value of ports A and B after each step
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Move the red LED to port A pin 6 by editing ONLY board.h. Rebuild, compare.
 *            2) Include hw_sim.h in main.c and poke GPIOA->ODR: why would that be a design smell?
 * ============================================================================
 */
#include <stdio.h>
#include "led_driver.h"
#include "hal_gpio.h"          /* only for delay, time stamps and port read-back */

static void show(const char *what)
{
    printf("[%4u ms] %-20s PA = 0x%04X   PB = 0x%04X\n", (unsigned)hal_millis(), what,
           (unsigned)hal_gpio_read_port(HAL_PORT_A), (unsigned)hal_gpio_read_port(HAL_PORT_B));
}

int main(void)
{
    if (led_init() != 0) {
        printf("led_init failed\n");
        return 1;
    }
    show("after led_init");

    for (int i = 0; i < 2; i++) {
        led_set(LED_GREEN, 1);
        show("green ON");
        hal_delay_ms(500);

        led_set(LED_GREEN, 0);
        led_toggle(LED_RED);                      /* driver reads the pin, then flips it */
        show("green off, red flip");
        hal_delay_ms(500);
    }

    led_all_off();
    show("all off");
    return 0;
}
