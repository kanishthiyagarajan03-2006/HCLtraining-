/*
 * hal_gpio.h - LOWEST software layer: the only code that knows about GPIO registers.
 * Upper layers see ports and pins as plain enums, never as GPIO_TypeDef pointers.
 */
#ifndef HAL_GPIO_H
#define HAL_GPIO_H

#include <stdint.h>

typedef enum { HAL_PORT_A = 0, HAL_PORT_B, HAL_PORT_C, HAL_PORT_COUNT } hal_port_t;
typedef enum { HAL_LOW = 0, HAL_HIGH = 1 } hal_level_t;
typedef enum { HAL_OK = 0, HAL_BAD_ARG } hal_status_t;

hal_status_t hal_gpio_init_output(hal_port_t port, uint8_t pin);
hal_status_t hal_gpio_write(hal_port_t port, uint8_t pin, hal_level_t level);
hal_level_t  hal_gpio_read(hal_port_t port, uint8_t pin);

void     hal_delay_ms(uint32_t ms);          /* like HAL_Delay()   */
uint32_t hal_millis(void);                   /* like HAL_GetTick() */
uint16_t hal_gpio_read_port(hal_port_t port);   /* all 16 pins at once (like reading IDR) */

#endif /* HAL_GPIO_H */
