/*
 * led_driver.h - MIDDLE layer interface: "LEDs" instead of "port B bit 7".
 */
#ifndef LED_DRIVER_H
#define LED_DRIVER_H

typedef enum { LED_GREEN = 0, LED_RED, LED_COUNT } led_t;

int  led_init(void);                 /* 0 = ok, -1 = failed */
void led_set(led_t led, int on);
void led_toggle(led_t led);
void led_all_off(void);

#endif /* LED_DRIVER_H */
