/*
 * led_driver.c - uses board.h (where the LEDs are) and hal_gpio.h (how to drive a pin).
 * It does NOT include hw_sim.h: it has no idea what MCU is underneath.
 */
#include "led_driver.h"
#include "board.h"
#include "hal_gpio.h"

static const struct { hal_port_t port; uint8_t pin; } led_map[LED_COUNT] = {
    [LED_GREEN] = { BOARD_LED_GREEN_PORT, BOARD_LED_GREEN_PIN },
    [LED_RED]   = { BOARD_LED_RED_PORT,   BOARD_LED_RED_PIN   },
};

int led_init(void)
{
    for (int i = 0; i < (int)LED_COUNT; i++) {
        if (hal_gpio_init_output(led_map[i].port, led_map[i].pin) != HAL_OK) return -1;
        hal_gpio_write(led_map[i].port, led_map[i].pin, HAL_LOW);      /* start dark */
    }
    return 0;
}

void led_set(led_t led, int on)
{
    hal_gpio_write(led_map[led].port, led_map[led].pin, on ? HAL_HIGH : HAL_LOW);
}

void led_toggle(led_t led)
{
    hal_level_t now = hal_gpio_read(led_map[led].port, led_map[led].pin);
    led_set(led, now == HAL_LOW);                 /* LOW -> on, HIGH -> off */
}

void led_all_off(void)
{
    for (int i = 0; i < (int)LED_COUNT; i++) led_set((led_t)i, 0);
}
