# Topic 13 - Storage Classes
**Suggested session:** 75 min | **Prerequisite topics:** 03 Constants and Variable Types, 10 Functions, 11 Working with Header Files

Students should leave knowing that a variable has two independent properties: **scope** (where its name is visible) and **lifetime / storage** (where it lives and for how long). The examples start with `auto` versus `static` locals in an interrupt handler, move on to `static` and `extern` at file scope (two small multi-file projects), separate the `register`, `volatile` and `const` keywords, and finish with how the same ideas look inside an RTOS (per-task stacks, static TCBs) and in embedded Linux threads (`_Thread_local`).

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_auto_vs_static_local.c` | MCU | `auto` counter resets on each call, `static` local keeps its value; software prescaler in a SysTick-style handler |
| 02 | `ex02_static_debounce_counter.c` | MCU | Three `static` locals form a private debounce state machine; raw edges vs real presses |
| 03 | `ex03_extern_shared_globals/` | MCU | `extern` declaration in a header, one definition in a `.c`, same address seen from two files; `volatile` ISR flag |
| 04 | `ex04_static_file_private/` | MCU | `static` at file scope means "private to this file": two drivers reuse the names `tx_count` and `emit()` |
| 05 | `ex05_volatile_const_register.c` | MCU | `volatile`, `const`, `const volatile` register pointer, and the `register` hint; storage class vs type qualifier |
| 06 | `ex06_rtos_task_static_vs_auto.c` | RTOS | Two tasks run one function: `auto` is per-task (own stack), `static` is shared (hidden global) |
| 07 | `ex07_rtos_static_task_memory.c` | RTOS | `xTaskCreateStatic` idea: static TCB/stack cannot fail at run time; heap creation can; stack memory must not be given to a task |
| 08 | `ex08_linux_thread_local.c` | LINUX | `_Thread_local` gives each pthread its own copy (like `errno`); shared counter needs a mutex |

Multi-file projects (03 and 04) are built from inside their folder, for example `gcc -std=gnu11 -Wall -Wextra main.c app_state.c monitor.c -o ex03`.

## Teaching notes
* The word `static` means two different things: on a **local** it means "lives forever, keeps its value"; on a **global** it means "invisible to other files". Ask the class why the C committee reused one keyword (ex01 vs ex04).
* `auto` is never written in practice, but it is the default for every local. An uninitialised `auto` holds garbage; an uninitialised `static` or global is zero because the startup code clears `.bss`.
* `static` locals make a function non-reentrant and are shared between RTOS tasks and between an ISR and main. Per-instance state belongs in a struct passed by pointer (ex06).
* `extern` only declares. If a student puts `int x = 5;` in a header, every file that includes it defines `x` again and the linker fails (`-DDEMO_BUG` in ex03).
* `volatile` does not make an access atomic and does not replace a mutex. It only forces a real read or write every time. `register` is a historical hint; nobody needs it on modern compilers.

## Live-demo tips
* Show the linker errors: `gcc -DDEMO_BUG main.c app_state.c monitor.c` in ex03 (multiple definition) and in ex04 (undefined reference to a `static` object).
* Paste `int flag; void wait(void){ while(!flag){} }` into godbolt.org with `-O2`, then add `volatile`: without it the loop never re-reads `flag` (ex05 cannot show this itself because its fake ISR is called from `main`).
* `nm ./ex04` (or `nm prog | grep tx_count`) shows lower-case `b` for file-private symbols and upper-case `B` for exported ones.
