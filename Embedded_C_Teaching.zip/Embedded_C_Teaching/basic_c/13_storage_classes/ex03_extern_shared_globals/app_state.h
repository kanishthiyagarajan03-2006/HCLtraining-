/* app_state.h - the PUBLIC face of the shared application state.
 * Rule of thumb: the header holds DECLARATIONS ("extern ..."), exactly one .c
 * file holds the matching DEFINITION (the line that really reserves memory). */
#ifndef APP_STATE_H
#define APP_STATE_H

#include <stdint.h>

typedef enum { MODE_IDLE, MODE_RUN, MODE_ALARM, MODE_COUNT } sys_mode_t;

/* extern = "this object exists in another .c file; no memory is reserved here" */
extern volatile uint8_t  g_adc_ready;   /* set by the ADC "ISR", cleared by main    */
extern volatile uint16_t g_adc_value;   /* latest conversion result (12-bit)        */
extern sys_mode_t        g_mode;        /* written by monitor.c, read by main.c     */
extern const char *const g_mode_name[MODE_COUNT];

void adc_isr(void);                     /* defined in app_state.c */
void monitor_process(void);             /* defined in monitor.c   */
const volatile uint16_t *monitor_adc_addr(void);

#endif /* APP_STATE_H */
