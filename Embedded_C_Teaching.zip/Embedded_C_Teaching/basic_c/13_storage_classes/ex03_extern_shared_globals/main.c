/*
 * ============================================================================
 *  Topic   : 13 Storage Classes
 *  Example : 03 - extern: one global variable shared by several .c files
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : 'extern' DECLARES a variable that is DEFINED in another file. The
 *            definition (with storage) appears in exactly one .c file; every
 *            other file sees only the 'extern' line from a shared header. The
 *            linker then makes all files use the same single object.
 *  Embedded use : ISR-to-main flags, the latest sensor reading, a global error
 *            code. Shared flags written by an ISR must also be 'volatile'.
 *  Real STM32F4 : extern volatile uint8_t g_adc_ready;   // in a driver header
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../../common main.c app_state.c monitor.c -o ex03
 *  Output  : six ADC samples move the mode between IDLE / RUN / ALARM; main.c and
 *            monitor.c print the SAME address for g_adc_value
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a new extern variable g_error_code to the header and the .c
 *               file, then print it from main.c.
 *            2) Build with -DDEMO_BUG and read the linker error carefully.
 * ============================================================================
 */
#include <stdio.h>
#include "app_state.h"

#ifdef DEMO_BUG
/* A second DEFINITION of the same name: every file compiles fine, but the linker
 * stops with "multiple definition of `g_adc_value'". Define once, declare often. */
volatile uint16_t g_adc_value = 0U;
#endif

int main(void)
{
    printf("start: g_adc_value = %u, mode = %s\n", (unsigned)g_adc_value, g_mode_name[g_mode]);

    for (int i = 0; i < 6; i++) {
        adc_isr();                      /* hardware would raise this interrupt      */

        if (g_adc_ready) {              /* main loop polls the flag set by the ISR  */
            g_adc_ready = 0U;
            monitor_process();          /* another file reads g_adc_value, sets mode */
            printf("sample %d: adc = %4u  ->  mode = %s\n",
                   i, (unsigned)g_adc_value, g_mode_name[g_mode]);
        }
    }

    const volatile uint16_t *from_monitor = monitor_adc_addr();
    printf("&g_adc_value seen in main.c    : %p\n", (const void *)&g_adc_value);
    printf("&g_adc_value seen in monitor.c : %p\n", (const void *)from_monitor);
    printf("one shared object: %s\n", (from_monitor == &g_adc_value) ? "yes" : "NO!");
    return 0;
}
