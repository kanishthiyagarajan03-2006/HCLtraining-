/* app_state.c - owns (DEFINES) the shared globals declared in app_state.h. */
#include <stddef.h>
#include "app_state.h"

volatile uint8_t  g_adc_ready = 0U;
volatile uint16_t g_adc_value = 0U;     /* explicit 0 still lands in .bss; it also keeps the
                                         * -DDEMO_BUG link error on old gcc (-fcommon) */
sys_mode_t        g_mode = MODE_IDLE;
const char *const g_mode_name[MODE_COUNT] = { "IDLE", "RUN", "ALARM" };

/* On a real STM32 the ADC end-of-conversion interrupt would call this:
 *     void ADC_IRQHandler(void) { g_adc_value = ADC1->DR; g_adc_ready = 1U; }   */
void adc_isr(void)
{
    static const uint16_t samples[] = { 1200U, 1850U, 3300U, 3900U, 2100U, 800U };
    static size_t next;                 /* static local: remembers where we are     */

    g_adc_value = samples[next];
    next = (next + 1U) % (sizeof samples / sizeof samples[0]);
    g_adc_ready = 1U;
}
