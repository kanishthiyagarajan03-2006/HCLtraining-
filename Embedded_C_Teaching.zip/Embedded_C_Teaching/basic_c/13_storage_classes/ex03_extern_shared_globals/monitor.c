/* monitor.c - a second translation unit that USES the globals through extern. */
#include "app_state.h"

#define ALARM_LIMIT  3500U
#define RUN_LIMIT    1000U

void monitor_process(void)
{
    uint16_t v = g_adc_value;           /* one read of the volatile, then work on v */

    if (v > ALARM_LIMIT)    g_mode = MODE_ALARM;
    else if (v > RUN_LIMIT) g_mode = MODE_RUN;
    else                    g_mode = MODE_IDLE;
}

const volatile uint16_t *monitor_adc_addr(void)
{
    return &g_adc_value;                /* same object that app_state.c defined     */
}
