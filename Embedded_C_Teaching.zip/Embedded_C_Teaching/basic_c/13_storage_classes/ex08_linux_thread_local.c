/*
 * ============================================================================
 *  Topic   : 13 Storage Classes
 *  Example : 08 - _Thread_local: one private copy of a global per thread
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : C11 adds a fourth storage duration: thread. A '_Thread_local' (GCC:
 *            '__thread') variable is created once PER THREAD, starts at 0 and has
 *            the same name everywhere. A plain global or static is shared by all
 *            threads and needs a mutex when they write to it.
 *  Embedded use : embedded Linux daemons run worker threads (sensor, network, log).
 *            This is how 'errno' works: every thread sees its own errno, so one
 *            thread's failed syscall cannot overwrite another thread's error code.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -pthread ex08_linux_thread_local.c -o ex08
 *  Output  : two worker threads each count 1000 events: their thread-local counts
 *            are 1000 each, the shared counter is 2000, main's own copy stays 0
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Remove the mutex lock/unlock and run it a few times with
 *               -fsanitize=thread - what does the sanitizer report?
 *            2) Make the shared counter _Thread_local too - what total do you get?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>

#define EVENTS_PER_THREAD 1000U

static _Thread_local uint32_t tls_events;      /* one copy per thread, starts at 0 */
static uint32_t shared_events;                 /* one copy for the whole process   */
static pthread_mutex_t shared_lock = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
    int      id;
    uint32_t tls_result;                       /* worker reports its private count */
} worker_t;

static void *worker(void *arg)
{
    worker_t *w = (worker_t *)arg;

    for (uint32_t i = 0; i < EVENTS_PER_THREAD; i++) {
        tls_events++;                          /* no lock needed: nobody else sees it */

        pthread_mutex_lock(&shared_lock);      /* shared data: protect the update     */
        shared_events++;
        pthread_mutex_unlock(&shared_lock);
    }
    w->tls_result = tls_events;
    return NULL;
}

int main(void)
{
    worker_t w[2] = { { 1, 0U }, { 2, 0U } };
    pthread_t th[2];

    for (int i = 0; i < 2; i++) {
        if (pthread_create(&th[i], NULL, worker, &w[i]) != 0) {
            fprintf(stderr, "pthread_create failed\n");
            return 1;
        }
    }
    for (int i = 0; i < 2; i++) {
        pthread_join(th[i], NULL);
    }

    for (int i = 0; i < 2; i++) {
        printf("worker %d: thread-local events = %u\n", w[i].id, (unsigned)w[i].tls_result);
    }
    printf("main    : its own tls_events copy    = %u  (never touched by the workers)\n",
           (unsigned)tls_events);
    printf("process : shared_events total        = %u  (expected %u)\n",
           (unsigned)shared_events, 2U * EVENTS_PER_THREAD);
    return (shared_events == 2U * EVENTS_PER_THREAD && tls_events == 0U) ? 0 : 1;
}
