/*
 * ============================================================================
 *  Topic   : 13 Storage Classes
 *  Example : 06 - Two RTOS tasks, one function: auto is per task, static is shared
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Every RTOS task owns a private stack, so an 'auto' local inside the
 *            task function exists once PER TASK. A 'static' local exists once
 *            per PROGRAM: tasks created from the same function silently share it.
 *            Per-task state belongs in locals or in a struct passed as 'arg'.
 *  Embedded use : a 'static' counter inside a shared task body or driver function
 *            is a hidden global; on a preemptive RTOS it is a data race.
 *  Real FreeRTOS : xTaskCreate(vWorker, "sensA", 256, &cfgA, 3, NULL);
 *                  xTaskCreate(vWorker, "sensB", 256, &cfgB, 2, NULL);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_rtos_task_static_vs_auto.c -o ex06
 *  Output  : sensA and sensB log "mine" (their own count) and "shared" (one count
 *            for both); main finally proves the addresses differ / are equal
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the periods to 100 / 150 ms: at which times are both tasks ready at
 *               the same instant, and which one runs first?
 *            2) Move the 'shared' counter into task_cfg_t (per-task) and re-run.
 * ============================================================================
 */
#include "mini_rtos.h"

typedef struct {
    const char *label;
    uint32_t    period_ms;
    int         id;                 /* index into the address tables below */
} task_cfg_t;

static uintptr_t addr_mine[2];      /* address of each task's auto counter     */
static uintptr_t addr_shared[2];    /* address of the static counter, per task */

/* Same code runs as two tasks. 'arg' points to a per-task const configuration. */
static void worker(void *arg)
{
    const task_cfg_t *cfg = (const task_cfg_t *)arg;
    uint32_t mine = 0U;             /* auto: lives on THIS task's own stack      */
    static uint32_t shared;         /* static: ONE copy in .bss for both tasks   */

    addr_mine[cfg->id]   = (uintptr_t)&mine;
    addr_shared[cfg->id] = (uintptr_t)&shared;

    for (;;) {
        mine++;
        shared++;                   /* (not atomic: fine here only because the   */
                                    /*  mini scheduler switches at delay points) */
        rtos_log("%s: mine = %u   shared = %u", cfg->label, (unsigned)mine, (unsigned)shared);
        rtos_delay(cfg->period_ms);
    }
}

int main(void)
{
    static const task_cfg_t cfg_a = { "sensA", 200U, 0 };
    static const task_cfg_t cfg_b = { "sensB", 300U, 1 };

    /* sensA has the higher priority, so it wins whenever both are ready at once. */
    rtos_task_create("sensA", worker, (void *)&cfg_a, 3, 0);
    rtos_task_create("sensB", worker, (void *)&cfg_b, 2, 0);
    rtos_start(700);

    printf("\n'mine'   addresses differ (separate task stacks): %s\n",
           addr_mine[0] != addr_mine[1] ? "yes" : "NO!");
    printf("'shared' addresses equal (one static object)    : %s\n",
           addr_shared[0] == addr_shared[1] ? "yes" : "NO!");

    rtos_shutdown();
    return 0;
}
