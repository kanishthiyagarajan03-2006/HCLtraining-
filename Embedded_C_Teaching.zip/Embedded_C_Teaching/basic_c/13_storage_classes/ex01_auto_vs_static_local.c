/*
 * ============================================================================
 *  Topic   : 13 Storage Classes
 *  Example : 01 - auto vs static local variables (SysTick call counters)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A local variable is 'auto' by default: it lives on the stack and is
 *            created fresh (and thrown away) on every call. A 'static' local
 *            lives in .data/.bss for the whole program, is initialised ONCE
 *            (to 0 if you write nothing) and remembers its value between calls.
 *            Scope (where the NAME is visible) stays inside the function.
 *  Embedded use : a periodic interrupt handler has no place to keep state
 *            between invocations - 'static' locals are the classic answer
 *            (software prescaler, debounce counter, state machine step).
 *  Real STM32F4 : void SysTick_Handler(void) { static uint16_t ms; ... }
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_auto_vs_static_local.c -o ex01
 *  Output  : the auto counter always says 1, the static one counts 1..5; then PA5
 *            toggles every 4th tick thanks to a static software prescaler
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change PRESCALE to 2 - how many toggles in 12 ticks now?
 *            2) Change 'static uint32_t divider;' to 'uint32_t divider = 0U;'
 *               - predict how many LED toggles you get now, then run it.
 * ============================================================================
 */
#include "hw_sim.h"

#define LED_PIN   5U
#define PRESCALE  4U      /* toggle the LED every 4th tick */

/* auto: new variable on the stack every call, so it is always 0 on entry. */
static uint32_t calls_auto(void)
{
    uint32_t calls = 0U;          /* an auto variable MUST be initialised by you */
    calls++;
    return calls;
}

/* static: one copy for the whole run. No initialiser -> starts at 0 (.bss). */
static uint32_t calls_static(void)
{
    static uint32_t calls;        /* zero-initialised once, before main() runs   */
    calls++;
    return calls;
}

/* Called once per millisecond. On real hardware the SysTick interrupt calls it;
 * here main() plays the part of the hardware.                                  */
static void SysTick_Handler(void)
{
    static uint32_t divider;      /* survives between interrupts */

    divider++;
    if (divider >= PRESCALE) {
        divider = 0U;
        GPIOA->ODR ^= (1U << LED_PIN);
        sim_show_port("GPIOA", GPIOA);
    }
}

int main(void)
{
    puts("--- auto vs static local counter ---");
    for (int i = 1; i <= 5; i++) {
        uint32_t a = calls_auto();
        uint32_t s = calls_static();
        printf("call %d: auto = %u   static = %u\n", i, (unsigned)a, (unsigned)s);
    }

    puts("\n--- static prescaler inside the 1 kHz tick handler ---");
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->MODER &= ~(3U << (LED_PIN * 2U));
    GPIOA->MODER |=  (1U << (LED_PIN * 2U));

    for (int tick = 1; tick <= 12; tick++) {
        sim_delay_ms(1);          /* one millisecond passes ...            */
        SysTick_Handler();        /* ... and the "interrupt" fires         */
    }
    return 0;
}
