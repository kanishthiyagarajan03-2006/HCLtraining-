/*
 * ============================================================================
 *  Topic   : 13 Storage Classes
 *  Example : 02 - Button debounce with static locals (state kept between calls)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Several 'static' locals together form a tiny state machine that is
 *            private to ONE function: no global variable is needed, yet the
 *            values survive from one call to the next. A 'static' local is set up
 *            once at program start (0, or its initialiser such as '= 5U'), never
 *            again on each call.
 *  Embedded use : a mechanical switch "bounces" for a few ms. The 1 ms tick
 *            handler only accepts a new level after it was stable for N samples.
 *  Real STM32F4 : if (GPIOA->IDR & (1U << 0)) ...   // PA0 = user button
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_static_debounce_counter.c -o ex02
 *  Output  : one line per millisecond showing the raw pin and the debounced level;
 *            the LED on PA5 toggles once per REAL press, not once per bounce
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Set STABLE_SAMPLES to 1 (no filtering) - how many presses are reported?
 *            2) Add a second button on PA1: why can one static set not serve both?
 * ============================================================================
 */
#include "hw_sim.h"

#define BTN_PIN         0U
#define LED_PIN         5U
#define STABLE_SAMPLES  4U    /* level must hold this many ms to be accepted */

/* Returns the debounced button level. Call once per millisecond. */
static uint8_t button_debounce(uint8_t raw)
{
    static uint8_t last_raw;                  /* all three start at 0 (.bss)   */
    static uint8_t stable_count;
    static uint8_t accepted;

    if (raw == last_raw) {
        if (stable_count < STABLE_SAMPLES) {
            stable_count++;
        }
        if (stable_count >= STABLE_SAMPLES) {
            accepted = raw;                   /* held long enough: believe it  */
        }
    } else {
        last_raw = raw;                       /* level changed: start counting */
        stable_count = 1U;
    }
    return accepted;
}

int main(void)
{
    /* One char per millisecond of the raw pin: a press with contact bounce, a
     * release with bounce, a 1 ms noise spike, then a second clean press.     */
    static const char raw_trace[] = "00010110111111111111101011000000100000011111111111100000";

    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    GPIOA->MODER &= ~(3U << (LED_PIN * 2U));  /* PA5 output; PA0 stays input  */
    GPIOA->MODER |=  (1U << (LED_PIN * 2U));

    uint8_t previous = 0U;
    unsigned raw_edges = 0U, presses = 0U;
    uint8_t prev_raw = 0U;

    for (size_t i = 0; raw_trace[i] != '\0'; i++) {
        if (raw_trace[i] == '1') sim_press(GPIOA, BTN_PIN);
        else                     sim_release(GPIOA, BTN_PIN);
        sim_delay_ms(1);

        uint8_t raw   = (uint8_t)((GPIOA->IDR >> BTN_PIN) & 1U);
        uint8_t level = button_debounce(raw);
        if (raw != prev_raw) raw_edges++;
        prev_raw = raw;

        printf("t=%2u ms  raw=%u  debounced=%u", (unsigned)sim_millis(), raw, level);
        if (level == 1U && previous == 0U) {      /* rising edge = a real press */
            GPIOA->ODR ^= (1U << LED_PIN);
            presses++;
            printf("   <-- press #%u, LED %s", presses,
                   (GPIOA->ODR & (1U << LED_PIN)) ? "ON" : "OFF");
        }
        previous = level;
        putchar('\n');
    }
    printf("raw edges seen: %u, real presses: %u\n", raw_edges, presses);
    return 0;
}
