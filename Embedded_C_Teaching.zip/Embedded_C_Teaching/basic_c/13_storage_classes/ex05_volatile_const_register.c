/*
 * ============================================================================
 *  Topic   : 13 Storage Classes
 *  Example : 05 - volatile, const and register (qualifiers vs storage classes)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : 'register' is a storage-class hint (keep it in a CPU register; you
 *            may not take its address). 'volatile' and 'const' are TYPE
 *            QUALIFIERS: they say how the variable may be accessed, not where
 *            it lives. volatile = "re-read/re-write every time, the world can
 *            change it"; const = "my code must not write it". They combine:
 *            'const volatile' is a read-only hardware status register.
 *  Embedded use : every ISR flag and every peripheral register is volatile; every
 *            lookup table that should stay in flash is const.
 *  Real STM32F4 : #define GPIOA_IDR (*(const volatile uint32_t *)0x40020010U)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_volatile_const_register.c -o ex05
 *  Output  : main waits for a timer flag set by a fake ISR, reads a const volatile
 *            input register, walks a const table and sums bytes with 'register'
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Remove 'volatile' from tick_flag: it still works here because the fake
 *               ISR is called from main. Why could a REAL board hang at -O2?
 *            2) Build with -DDEMO_BUG and read the compiler errors.
 * ============================================================================
 */
#include "hw_sim.h"

#define BTN_PIN 0U

/* 1) volatile: written by an interrupt, read by main. On a real board the compiler
 *    cannot see the ISR being called, so without 'volatile' it may load tick_flag
 *    once, see 0 and spin forever at -O2.                                       */
static volatile uint8_t  tick_flag;
static volatile uint32_t tick_count;

/* Hardware would call this from the TIM2 update interrupt. */
static void TIM2_IRQHandler(void)
{
    tick_count++;
    tick_flag = 1U;
}

/* 2) const: stays in flash (.rodata) on a Cortex-M, costs no RAM. */
static const uint8_t blink_pattern[] = { 0x01U, 0x03U, 0x07U, 0x0FU, 0x07U, 0x03U };

/* 3) register: only a hint. Modern compilers choose registers better than we do,
 *    but the rule is real: you cannot take the address of a register variable. */
static uint32_t sum_bytes(const uint8_t *data, size_t len)
{
    register uint32_t acc = 0U;
    for (size_t i = 0; i < len; i++) {
        acc += data[i];
    }
#ifdef DEMO_BUG
    uint32_t *p = &acc;           /* error: address of register variable requested */
    (void)p;
#endif
    return acc;
}

int main(void)
{
    /* volatile in action: poll the flag until the "interrupt" has fired 3 times. */
    while (tick_count < 3U) {
        sim_delay_ms(10);
        if (sim_millis() % 20U == 0U) {
            TIM2_IRQHandler();    /* stand-in for the hardware interrupt */
        }
        if (tick_flag) {
            tick_flag = 0U;       /* main acknowledges the event */
            printf("[%3u ms] timer tick %u handled by main\n",
                   (unsigned)sim_millis(), (unsigned)tick_count);
        }
    }

    /* const volatile: software may read it but never write it; hardware changes it. */
    const volatile uint32_t *const pins = &GPIOA->IDR;
    sim_release(GPIOA, BTN_PIN);
    printf("button before press: %u\n", (unsigned)((*pins >> BTN_PIN) & 1U));
    sim_press(GPIOA, BTN_PIN);
    printf("button after  press: %u   (same pointer, new value - read happened again)\n",
           (unsigned)((*pins >> BTN_PIN) & 1U));
#ifdef DEMO_BUG
    *pins = 0U;                   /* error: assignment of read-only location */
    blink_pattern[0] = 0xFFU;     /* error: assignment of read-only location */
#endif

    printf("\nconst table walk (%zu entries, would live in flash):\n", sizeof blink_pattern);
    for (size_t i = 0; i < sizeof blink_pattern; i++) {
        sim_show_leds("LEDs", blink_pattern[i], 4U);
    }

    printf("sum of table bytes (register accumulator) = %u\n",
           (unsigned)sum_bytes(blink_pattern, sizeof blink_pattern));
    return 0;
}
