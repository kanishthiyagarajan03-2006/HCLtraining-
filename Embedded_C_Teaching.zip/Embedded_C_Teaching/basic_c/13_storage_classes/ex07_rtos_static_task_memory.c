/*
 * ============================================================================
 *  Topic   : 13 Storage Classes
 *  Example : 07 - Static vs dynamic task memory (the xTaskCreateStatic idea)
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Static-storage objects (file-scope arrays/structs, or 'static' locals)
 *            have a fixed address and live for the whole run, so their size is
 *            known at link time. Heap objects can fail at RUN time. Stack (auto)
 *            objects vanish when the function returns - never hand them to a task.
 *  Embedded use : safety-critical firmware (MISRA, ISO 26262) often forbids the
 *            heap: TCBs and task stacks are static arrays, and an overflow of
 *            RAM shows up as a LINKER error instead of a field failure.
 *  Real FreeRTOS : xTaskCreateStatic(fn, "blink", 64, NULL, 2, stack_buf, &tcb);
 *                  (needs configSUPPORT_STATIC_ALLOCATION = 1)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_rtos_static_task_memory.c -o ex07
 *  Output  : three tasks created from static memory; then dynamic creation from a
 *            tiny 512-byte heap that runs out on the second task
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Increase HEAP_BYTES to 1024 and the loop count in main() from 2 to 4:
 *               how many dynamic tasks get created now?
 *            2) Build with -DDEMO_BUG and think: who owns that stack after return?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>
#include <stddef.h>

typedef uint32_t StackType_t;
typedef struct {
    const char  *name;
    void       (*fn)(void *);
    void        *arg;
    StackType_t *stack;
    uint32_t     stack_words;
    uint8_t      priority;
} StaticTask_t;

#define STACK_WORDS  64U
#define MAX_TASKS    6U
#define HEAP_BYTES   512U

static StaticTask_t *registry[MAX_TASKS];
static size_t        task_count;

/* ---- the three task bodies (each would normally be an endless loop) ---- */
static void blink_task(void *arg)
{
    printf("  blink : toggling LED every %u ms\n", *(const unsigned *)arg);
}
static void sensor_task(void *arg) { (void)arg; puts("  sensor: sampling ADC"); }
static void logger_task(void *arg) { (void)arg; puts("  logger: writing to flash"); }

/* ---- static creation: caller supplies memory, kernel only wires it up ---- */
static StaticTask_t *task_create_static(void (*fn)(void *), const char *name, void *arg,
                                        uint8_t prio, StackType_t *stack, StaticTask_t *tcb)
{
    if (task_count >= MAX_TASKS) return NULL;
    tcb->name = name;  tcb->fn = fn;  tcb->arg = arg;
    tcb->stack = stack;  tcb->stack_words = STACK_WORDS;  tcb->priority = prio;
    registry[task_count++] = tcb;
    return tcb;                   /* cannot fail: nothing was allocated */
}

/* ---- dynamic creation: kernel allocates from a small bump-pointer heap ---- */
static uint8_t heap[HEAP_BYTES];
static size_t  heap_used;

static void *heap_alloc(size_t n)
{
    n = (n + 7U) & ~(size_t)7U;                 /* keep 8-byte alignment */
    if (heap_used + n > HEAP_BYTES) return NULL;
    void *p = &heap[heap_used];
    heap_used += n;
    return p;
}

static StaticTask_t *task_create_dynamic(void (*fn)(void *), const char *name, uint8_t prio)
{
    StaticTask_t *tcb = heap_alloc(sizeof *tcb);
    StackType_t  *stk = heap_alloc(STACK_WORDS * sizeof(StackType_t));
    if (tcb == NULL || stk == NULL) {
        printf("  FAILED '%s': heap exhausted (%zu of %u bytes used) - found at RUN time\n",
               name, heap_used, HEAP_BYTES);
        return NULL;
    }
    return task_create_static(fn, name, NULL, prio, stk, tcb);
}

#ifdef DEMO_BUG
/* The TCB and stack are AUTO variables: they die when this function returns, but
 * registry[] still points at them. Running the task later is undefined behaviour. */
static void create_with_local_memory(void)
{
    StackType_t  local_stack[STACK_WORDS];
    StaticTask_t local_tcb;
    task_create_static(logger_task, "oops", NULL, 1U, local_stack, &local_tcb);
}
#endif

/* Static-storage memory: reserved in .bss by the linker, one pair per task. */
static StackType_t  blink_stack[STACK_WORDS];
static StackType_t  sensor_stack[STACK_WORDS];
static StackType_t  logger_stack[STACK_WORDS];
static StaticTask_t blink_tcb, sensor_tcb, logger_tcb;

int main(void)
{
    static unsigned blink_period = 500U;   /* static: its address stays valid for the task */

    puts("--- static allocation ---");
    task_create_static(blink_task,  "blink",  &blink_period, 2U, blink_stack,  &blink_tcb);
    task_create_static(sensor_task, "sensor", NULL,          3U, sensor_stack, &sensor_tcb);
    task_create_static(logger_task, "logger", NULL,          1U, logger_stack, &logger_tcb);
    printf("  RAM for 3 tasks = 3 x (%zu B TCB + %zu B stack) = %zu bytes, known at link time\n",
           sizeof(StaticTask_t), STACK_WORDS * sizeof(StackType_t),
           3U * (sizeof(StaticTask_t) + STACK_WORDS * sizeof(StackType_t)));

    puts("--- dynamic allocation from a tiny heap ---");
    for (int i = 0; i < 2; i++) {
        StaticTask_t *t = task_create_dynamic(sensor_task, i == 0 ? "sensor2" : "sensor3", 1U);
        if (t != NULL) {
            printf("  created '%s' (heap %zu / %u bytes used)\n", t->name, heap_used, HEAP_BYTES);
        }
    }

#ifdef DEMO_BUG
    create_with_local_memory();
#endif

    puts("--- run every registered task once ---");
    for (size_t i = 0; i < task_count; i++) {
        printf("%s (prio %u, stack %u words)\n", registry[i]->name,
               (unsigned)registry[i]->priority, (unsigned)registry[i]->stack_words);
        registry[i]->fn(registry[i]->arg);
    }
    return 0;
}
