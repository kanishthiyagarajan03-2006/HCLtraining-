/* uart_drv.c - 'static' at file scope = internal linkage = private to this file. */
#include <stdio.h>
#include "uart_drv.h"

static uint32_t tx_count;               /* private counter, zero at start (.bss)    */

/* Same name as the helper in spi_drv.c - no clash, because both are static. */
static void emit(char c)
{
    putchar(c);                         /* a real driver would write USART2->DR     */
    tx_count++;
}

void uart_send(const char *text)
{
    printf("UART> ");
    for (const char *p = text; *p != '\0'; p++) {
        emit(*p);
    }
    putchar('\n');
}

uint32_t uart_bytes_sent(void) { return tx_count; }
