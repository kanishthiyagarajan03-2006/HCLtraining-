/* uart_drv.h - public API of the UART driver. Note what is NOT here: the byte
 * counter and the helper function are private to uart_drv.c. */
#ifndef UART_DRV_H
#define UART_DRV_H

#include <stdint.h>

void     uart_send(const char *text);
uint32_t uart_bytes_sent(void);

#endif /* UART_DRV_H */
