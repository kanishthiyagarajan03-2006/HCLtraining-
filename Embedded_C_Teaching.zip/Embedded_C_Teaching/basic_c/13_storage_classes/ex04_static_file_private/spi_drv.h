/* spi_drv.h - public API of the SPI driver (everything else is file-private). */
#ifndef SPI_DRV_H
#define SPI_DRV_H

#include <stdint.h>
#include <stddef.h>

void     spi_write(const uint8_t *data, size_t len);
uint32_t spi_bytes_sent(void);

#endif /* SPI_DRV_H */
