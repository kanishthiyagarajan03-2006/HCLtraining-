/*
 * ============================================================================
 *  Topic   : 13 Storage Classes
 *  Example : 04 - static at file scope: private variables and private functions
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : On a global variable or function, 'static' does NOT mean "keeps its
 *            value" - it means "invisible outside this .c file" (internal
 *            linkage). Two files may each own a 'static tx_count' and 'static
 *            emit()' with no clash. Without 'static' the names are exported and
 *            the linker reports "multiple definition".
 *  Embedded use : drivers hide buffers and helpers and expose only a small API
 *            (information hiding in plain C), so other code cannot corrupt them.
 *  Real STM32F4 : the HAL does the same: static helper functions inside each
 *            stm32f4xx_hal_xxx.c file, only HAL_XXX_ functions in the header.
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../../common main.c uart_drv.c spi_drv.c -o ex04
 *  Output  : text goes out of the UART, bytes out of SPI; each driver reports its
 *            own private byte counter through its public getter
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Build with -DDEMO_BUG and read the linker error.
 *            2) Delete 'static' from BOTH tx_count lines - what does the linker say?
 *               (gcc 10+: multiple definition. Older gcc merges them silently into ONE
 *               shared counter: try -fcommon. A real-life bug that compiles cleanly.)
 * ============================================================================
 */
#include <stdio.h>
#include "uart_drv.h"
#include "spi_drv.h"

#ifdef DEMO_BUG
/* main.c cannot reach a static object of another file, even with extern:
 * the compiler is happy, the linker says "undefined reference to `tx_count'". */
extern uint32_t tx_count;
#endif

int main(void)
{
    const uint8_t frame[] = { 0xA5U, 0x01U, 0x7FU, 0xFFU };

    uart_send("boot ok");
    uart_send("ADC=1234");
    spi_write(frame, sizeof frame);

#ifdef DEMO_BUG
    printf("peeking: %u\n", (unsigned)tx_count);
#endif

    printf("uart bytes sent: %u\n", (unsigned)uart_bytes_sent());
    printf("spi  bytes sent: %u\n", (unsigned)spi_bytes_sent());
    return 0;
}
