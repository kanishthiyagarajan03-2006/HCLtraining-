/* spi_drv.c - uses the SAME private names as uart_drv.c on purpose. */
#include <stdio.h>
#include "spi_drv.h"

static uint32_t tx_count;               /* a different object from uart_drv.c's     */

static void emit(uint8_t b)
{
    printf("%02X ", (unsigned)b);       /* a real driver would write SPI1->DR       */
    tx_count++;
}

void spi_write(const uint8_t *data, size_t len)
{
    printf("SPI > ");
    for (size_t i = 0; i < len; i++) {
        emit(data[i]);
    }
    putchar('\n');
}

uint32_t spi_bytes_sent(void) { return tx_count; }
