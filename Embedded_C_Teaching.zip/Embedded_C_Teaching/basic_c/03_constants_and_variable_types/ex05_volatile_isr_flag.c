/*
 * ============================================================================
 *  Topic   : 03 Constants and Variable Types
 *  Example : 05 - volatile: registers and ISR-shared flags the compiler must not "optimise"
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : The compiler assumes a variable only changes when YOUR code changes it. A
 *            hardware register or a flag set inside an interrupt handler breaks that
 *            assumption, so it is declared volatile: every read really reads, every write
 *            really writes, none is merged or removed. volatile is NOT atomic and does not
 *            make a multi-step update (counter++) safe against an interrupt.
 *  Embedded use : "while (!tick_flag) {}" without volatile compiles (at -O2) to a loop that reads
 *            the flag ONCE and then spins forever - the classic bug that only appears in the
 *            optimised release build. gcc -O2 -S on  while (!flag) {}  gives:
 *              flag not volatile:   cmpb $0,flag ; jne ret ; .L: jmp .L     (one read, endless)
 *              flag volatile    :   .L: movzbl flag,%eax ; testb %al,%al ; je .L  (re-reads)
 *  Real STM32F4 : void TIM2_IRQHandler(void) { TIM2->SR &= ~TIM_SR_UIF; tick_flag = 1; }
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex05_volatile_isr_flag.c -o ex05
 *  Output  : the CPU loop spins until a (simulated) timer interrupt raises a flag; five tick
 *            events are handled and the main code reads a consistent snapshot of the counter
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Compile with -O2 -S, remove 'volatile' from tick_flag and read the assembly.
 *            2) Why does the ISR clear the UIF bit in TIM2_SR before doing anything else?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define TIM_SR_UIF  (1U << 0)           /* update interrupt flag, set by the timer hardware */

static volatile uint32_t TIM2_SR;       /* hardware status register: changes by itself      */
static volatile uint32_t ms_ticks;      /* written by the ISR, read by main                 */
static volatile uint8_t  tick_flag;     /* message from ISR to main: "a tick happened"      */
static uint32_t events_seen;            /* touched ONLY by main: needs no volatile          */

/* On a real MCU the hardware jumps here when the timer overflows. */
static void TIM2_IRQHandler(void)
{
    if (TIM2_SR & TIM_SR_UIF) {
        TIM2_SR &= ~TIM_SR_UIF;         /* acknowledge first, or the interrupt fires again  */
        ms_ticks++;
        tick_flag = 1U;
    }
}

/* Stand-in for the silicon: every 5th call the timer overflows and "interrupts" the CPU. */
static void timer_hardware_step(void)
{
    static unsigned cycles;
    if (++cycles % 5U == 0U) {
        TIM2_SR |= TIM_SR_UIF;          /* hardware sets the flag ...                       */
        TIM2_IRQHandler();              /* ... and calls the handler                        */
    }
}

/* The classic busy-wait delay. The volatile counter stops the compiler from deleting the
 * empty loop; without it, -O2 removes the loop and the "delay" takes no time at all. */
static void delay_loop(uint32_t n)
{
    for (volatile uint32_t i = 0U; i < n; i++) { }
}

int main(void)
{
    puts("--- Waiting for 5 timer ticks; the 'hardware' fires every 5th pass of the loop ---");
    uint32_t spins = 0U;
    while (ms_ticks < 5U) {             /* a fresh read of the volatile on every pass       */
        timer_hardware_step();
        spins++;
        if (tick_flag) {                /* the ISR set it ...                               */
            tick_flag = 0U;             /* ... main consumes it                             */
            events_seen++;
            uint32_t snapshot = ms_ticks;   /* read the shared counter ONCE, then use the copy */
            printf("  tick event %u: ms_ticks = %u after %u spins\n", (unsigned)events_seen,
                   (unsigned)snapshot, (unsigned)spins);
        }
    }

    delay_loop(100000U);                /* a short busy-wait: instant on a PC, visible on a board */
    printf("\n  TIM2_SR now = 0x%X (the ISR cleared UIF), events handled = %u\n",
           (unsigned)TIM2_SR, (unsigned)events_seen);
    puts("  rule of thumb: volatile for registers and ISR-shared data, not for ordinary variables");
    puts("  counter++ in main AND in an ISR still needs a critical section (it is load/add/store)");
    return (events_seen == 5U && TIM2_SR == 0U) ? 0 : 1;
}
