/*
 * ============================================================================
 *  Topic   : 03 Constants and Variable Types
 *  Example : 09 - Struct padding, alignment and byte order seen through a uint8_t pointer
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A type's size is not the whole story. The compiler inserts PADDING so that every
 *            member sits at a multiple of its own size (alignment); reordering members from
 *            large to small removes most of it, __attribute__((packed)) removes all of it at
 *            the cost of slow or even faulting unaligned access. Multi-byte values are stored
 *            low byte first on little-endian CPUs (x86, ARM); network protocols use big-endian,
 *            so use htonl()/htons().
 *  Embedded use : sending a struct straight over UART, SPI or a socket is a classic bug: the
 *            receiver may have different padding or byte order. Cortex-M0 even HardFaults on an
 *            unaligned 32-bit load. Serialise field by field instead.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex09_struct_padding_endianness.c -o ex09
 *  Output  : sizeof and offsets of three layouts of one record, a byte dump that shows the
 *            padding holes, and the byte order of 0x12345678 before and after htonl()
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add a uint16_t member to sample_ordered_t. Does sizeof change? Predict first.
 *            2) What does htons(0x1234) look like in memory on this machine?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <arpa/inet.h>              /* htonl(), htons(), ntohl(): host <-> network byte order */
#include <stddef.h>                 /* offsetof */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

typedef struct { uint8_t id; uint32_t value; uint8_t flags; } sample_naive_t;
typedef struct { uint32_t value; uint8_t id; uint8_t flags; } sample_ordered_t;
typedef struct __attribute__((packed)) {      /* gcc/clang extension: no padding at all */
    uint8_t id; uint32_t value; uint8_t flags;
} sample_packed_t;

static void dump(const char *label, const void *p, size_t n)
{
    const uint8_t *b = (const uint8_t *)p;              /* any object can be viewed as bytes */
    printf("  %-34s", label);
    for (size_t i = 0; i < n; i++) printf(" %02X", b[i]);
    putchar('\n');
}

int main(void)
{
    puts("--- One record, three layouts ---");
    printf("  naive   { id, value, flags }: sizeof = %2zu, alignment = %zu\n",
           sizeof(sample_naive_t), _Alignof(sample_naive_t));
    printf("            offsets: id %zu, value %zu, flags %zu  (3 padding bytes after id, flags)\n",
           offsetof(sample_naive_t, id), offsetof(sample_naive_t, value),
           offsetof(sample_naive_t, flags));
    printf("  ordered { value, id, flags }: sizeof = %2zu, alignment = %zu\n",
           sizeof(sample_ordered_t), _Alignof(sample_ordered_t));
    printf("            offsets: value %zu, id %zu, flags %zu  (only 2 bytes of tail padding)\n",
           offsetof(sample_ordered_t, value), offsetof(sample_ordered_t, id),
           offsetof(sample_ordered_t, flags));
    printf("  packed  { id, value, flags }: sizeof = %2zu, alignment = %zu\n",
           sizeof(sample_packed_t), _Alignof(sample_packed_t));
    printf("            no padding at all, but 'value' now sits at an unaligned offset 1\n");
    printf("  the payload is 1 + 4 + 1 = 6 bytes; the naive layout wastes %zu of its %zu\n\n",
           sizeof(sample_naive_t) - 6U, sizeof(sample_naive_t));

    puts("--- Byte dump: padding holes keep whatever was in memory (0xAA written first) ---");
    sample_naive_t n;
    /* Fill first so the holes show up. (The C standard calls padding bytes "unspecified";
     * gcc happens to leave them alone, which is why the 0xAA pattern survives.)          */
    memset(&n, 0xAA, sizeof n);
    n.id = 0x01U;
    n.value = 0x11223344U;
    n.flags = 0x80U;
    dump("naive   (12 bytes)", &n, sizeof n);
    sample_ordered_t o;
    memset(&o, 0xAA, sizeof o);
    o.value = 0x11223344U;
    o.id = 0x01U;
    o.flags = 0x80U;
    dump("ordered (8 bytes)", &o, sizeof o);
    sample_packed_t k = { 0x01U, 0x11223344U, 0x80U };
    dump("packed  (6 bytes)", &k, sizeof k);
    puts("  value 0x11223344 appears as 44 33 22 11: the LOW byte comes first (little-endian)\n");

    puts("--- Byte order of a 32-bit value ---");
    uint32_t host = 0x12345678U;
    uint32_t net = htonl(host);
    dump("host order  0x12345678", &host, sizeof host);
    dump("htonl()     (network, big-endian)", &net, sizeof net);
    uint16_t port = htons(0x1234U);
    dump("htons(0x1234)", &port, sizeof port);

    puts("\n--- Portable way: build the bytes with shifts, independent of the CPU ---");
    uint8_t wire[4] = { (uint8_t)(host >> 24), (uint8_t)(host >> 16), (uint8_t)(host >> 8),
                        (uint8_t)host };                /* most significant byte first */
    dump("wire[] = {>>24, >>16, >>8, >>0}", wire, sizeof wire);
    uint32_t back = ((uint32_t)wire[0] << 24) | ((uint32_t)wire[1] << 16) |
                    ((uint32_t)wire[2] << 8) | wire[3];
    printf("  rebuilt value = 0x%08X (%s)\n", (unsigned)back,
           (back == host) ? "round trip OK" : "BUG");
    return (back == host && ntohl(net) == host) ? 0 : 1;
}
