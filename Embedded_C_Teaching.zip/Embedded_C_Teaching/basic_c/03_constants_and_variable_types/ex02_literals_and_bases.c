/*
 * ============================================================================
 *  Topic   : 03 Constants and Variable Types
 *  Example : 02 - Integer, character and float literals: bases, suffixes and their types
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A literal has a TYPE too. 0x5A hex, 90 decimal, 0132 octal (leading zero!) and
 *            0b01011010 binary (GNU/C23) are the same int. Suffixes choose the type: U unsigned,
 *            L long, UL, ULL; 1.0 is double but 1.0f is float. 'A' is the character code 65.
 *            Hex and binary make bit patterns readable; a stray leading zero silently makes
 *            a number octal.
 *  Embedded use : register addresses and masks are written in hex with U/UL suffixes
 *            (0x40020000UL); on an MCU without a double-precision FPU the missing 'f' on 3.3
 *            makes a whole expression run in slow software floating point.
 *  Real STM32F4 : #define GPIOA_BASE 0x40020000UL     #define GPIO_ODR_OFFSET 0x14U
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex02_literals_and_bases.c -o ex02
 *  Output  : one value in four notations, a table of literal types (sizeof), the octal trap,
 *            a register address built from hex literals and a character-code trick
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Predict sizeof(0x7FFFFFFF) and sizeof(0x80000000), then run to check.
 *            2) What does 'a' ^ 0x20 print? Try it with 'Q' and with '5'.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define GPIOA_BASE       0x40020000UL           /* UL: needs 32 bits, even where int is 16 */
#define GPIO_ODR_OFFSET  0x14U

#define SIZE_OF(expr, note) printf("  sizeof(%-11s) = %zu   %s\n", #expr, sizeof(expr), note)

static void print_bin8(uint8_t v)
{
    for (int i = 7; i >= 0; i--) putchar(((v >> i) & 1U) ? '1' : '0');
}

int main(void)
{
    puts("--- The same number in four notations ---");
    const unsigned dec = 90U, hex = 0x5AU, oct = 0132U, bin = 0b01011010U;   /* 0b: GNU extension */
    printf("  decimal 90 = 0x%X = octal 0%o = binary ", hex, oct);
    print_bin8((uint8_t)bin);
    printf("   (all equal: %s)\n\n", (dec == hex && hex == oct && oct == bin) ? "yes" : "no");

    puts("--- The octal trap: a leading zero changes the base ---");
    printf("  10 = %d,   0x10 = %d,   010 = %d   <- \"010\" is octal 8, not ten\n", 10, 0x10, 010);
    puts("  (a literal like 08 does not even compile: 8 is not an octal digit)\n");

    puts("--- The type of a literal (suffixes change it) ---");
    SIZE_OF(1,          "int");
    SIZE_OF(1U,         "unsigned int");
    SIZE_OF(1L,         "long (4 on Cortex-M, 8 on 64-bit Linux)");
    SIZE_OF(1UL,        "unsigned long");
    SIZE_OF(1ULL,       "unsigned long long: 8 everywhere");
    SIZE_OF(0xFFFFFFFF, "hex that does not fit an int becomes unsigned int");
    SIZE_OF(4294967296, "needs 33 bits, so long long (or long)");
    SIZE_OF('A',        "a character constant is an int in C (not a char)");
    SIZE_OF(3.3,        "double: slow software maths on an MCU without a double FPU");
    SIZE_OF(3.3f,       "float: use the f suffix on small MCUs");
    printf("  1ULL << 32 = %llu   (1UL << 32 is undefined where long is only 32 bits)\n\n",
           1ULL << 32);

    puts("--- Register address built from literals ---");
    unsigned long odr_addr = GPIOA_BASE + GPIO_ODR_OFFSET;
    printf("  GPIOA_BASE + 0x14 = 0x%08lX   (ODR register of GPIOA on an STM32F4)\n\n",
           odr_addr);

    puts("--- Character literals are numbers ---");
    printf("  'A' = %d, '0' = %d, '7' - '0' = %d   (digit character -> digit value)\n",
           'A', '0', '7' - '0');
    printf("  'a' - 'A' = %d = 0x%02X   so   'a' ^ 0x20 = '%c',  'Q' ^ 0x20 = '%c'\n",
           'a' - 'A', (unsigned)('a' - 'A'), 'a' ^ 0x20, 'Q' ^ 0x20);
    printf("  escape forms: '\\n' = %d, '\\x41' = '%c', '\\101' (octal) = '%c', '\\0' = %d\n",
           '\n', '\x41', '\101', '\0');
    return 0;
}
