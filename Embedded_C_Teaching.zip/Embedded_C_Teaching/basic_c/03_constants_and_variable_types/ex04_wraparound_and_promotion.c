/*
 * ============================================================================
 *  Topic   : 03 Constants and Variable Types
 *  Example : 04 - Unsigned wrap-around, integer promotion and the signed-overflow trap
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Unsigned arithmetic wraps modulo 2^N: a uint8_t goes 255 -> 0. That is DEFINED and
 *            useful. Signed overflow (INT32_MAX + 1) is undefined behaviour. And C never does
 *            arithmetic below int: uint8_t operands are promoted to int first, so  a + b  can
 *            be 300 even though both are uint8_t; only the final store truncates it to 44.
 *  Embedded use : frame sequence numbers and PWM phase counters wrap on purpose; a saturating
 *            volume or duty-cycle must NOT wrap. Count-down loops with an unsigned index have
 *            a classic off-by-one trap.
 *  Real STM32F4 : TIM2->CNT is a 32-bit counter that simply wraps from 0xFFFFFFFF to 0.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex04_wraparound_and_promotion.c -o ex04
 *  Output  : a counter wrapping 250..255,0..3, wrap vs saturate, promotion results, a checked
 *            signed add, a safe unsigned count-down and the signed/unsigned comparison trap
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change seq to uint16_t. When does it wrap now?
 *            2) Build with -DDEMO_BUG -fsanitize=undefined and read the overflow report.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

/* Would a + b overflow int32_t? Test BEFORE adding, because the add itself would be undefined. */
static int add_would_overflow(int32_t a, int32_t b)
{
    return (b > 0 && a > INT32_MAX - b) || (b < 0 && a < INT32_MIN - b);
}

/* Saturating add for a duty cycle or volume: stop at 255 instead of wrapping to a small number. */
static uint8_t add_saturate_u8(uint8_t a, uint8_t b)
{
    return (a > (uint8_t)(UINT8_MAX - b)) ? UINT8_MAX : (uint8_t)(a + b);
}

int main(void)
{
    puts("--- 1. An 8-bit sequence number wraps around (defined behaviour) ---");
    uint8_t seq = 250U;
    printf("  seq:");
    for (int i = 0; i < 10; i++) {
        printf(" %u", seq);
        seq++;
    }
    puts("   (255 + 1 = 0)\n");

    puts("--- 2. Wrap versus saturate ---");
    uint8_t duty = 200U;
    uint8_t wrapped = (uint8_t)(duty + 100U);
    printf("  200 + 100 as uint8_t, wrapping    = %u   (300 mod 256: LED goes DARK)\n", wrapped);
    printf("  200 + 100 as uint8_t, saturating  = %u  (clamped at full brightness)\n\n",
           add_saturate_u8(duty, 100U));

    puts("--- 3. Integer promotion: the arithmetic happens in int ---");
    uint8_t x = 200U, y = 100U;
    int wide = x + y;                    /* promoted to int: 300, no overflow            */
    uint8_t narrow = (uint8_t)(x + y);   /* only the STORE truncates                     */
    printf("  x + y            = %d   (promoted to int)\n", wide);
    printf("  (x + y) > 255    = %d   (true! both operands are uint8_t)\n", (x + y) > 255);
    printf("  stored back      = %u   (truncated to 8 bits)\n\n", narrow);

    puts("--- 4. Signed overflow is undefined: check first ---");
    int32_t big = INT32_MAX;
    printf("  INT32_MAX + 1 would overflow: %s   (so we do not compute it)\n",
           add_would_overflow(big, 1) ? "yes" : "no");
    printf("  INT32_MAX + (-1) would overflow: %s\n\n", add_would_overflow(big, -1) ? "yes" : "no");

    puts("--- 5. Counting down with an unsigned index ---");
    printf("  for (uint8_t i = 5; i-- > 0; ):");
    for (uint8_t i = 5U; i-- > 0U; )     /* tests i, THEN decrements: runs 4,3,2,1,0 and stops */
        printf(" %u", i);
    puts("\n  (the obvious  i >= 0  is ALWAYS true for an unsigned type: an endless loop)\n");

    puts("--- 6. Mixed signed/unsigned comparison ---");
    int minus_one = -1;
    unsigned one = 1U;
    printf("  (unsigned)(-1) = %u, so  -1 < 1U  is %s in C\n", (unsigned)minus_one,
           ((unsigned)minus_one < one) ? "TRUE" : "FALSE");
    puts("  (the int is silently converted to unsigned; gcc -Wextra warns: -Wsign-compare)");

#ifdef DEMO_BUG
    volatile int32_t limit = INT32_MAX;
    int32_t boom = limit + 1;            /* undefined: UBSan prints "signed integer overflow" */
    printf("  DEMO_BUG: INT32_MAX + 1 = %d\n", (int)boom);
    for (uint8_t i = 5U, guard = 0U; i >= 0U && guard < 20U; i--, guard++)   /* never ends */
        printf("%u ", i);
    if (minus_one < one) puts("  DEMO_BUG: never printed");
#endif
    return 0;
}
