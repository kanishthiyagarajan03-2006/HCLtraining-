/*
 * ============================================================================
 *  Topic   : 03 Constants and Variable Types
 *  Example : 01 - Fixed-width integer types, their sizes and their ranges
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : <stdint.h> gives integer types whose size is GUARANTEED: int8_t, uint8_t, int16_t,
 *            uint16_t, int32_t, uint32_t, int64_t, uint64_t. Plain int and long change size from
 *            one compiler/CPU to the next. <stdint.h> also provides the limits (UINT8_MAX ...)
 *            and <inttypes.h> the matching printf formats (PRIu32 ...).
 *  Embedded use : registers are exactly 8/16/32 bits wide, protocol fields have exact widths,
 *            and RAM is tiny: pick the SMALLEST type that holds the range, and make its size
 *            visible in the code.
 *  Real STM32F4 : uint32_t volatile * - every CMSIS register is declared as volatile uint32_t.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex01_fixed_width_types.c -o ex01
 *  Output  : a size/min/max table of all exact-width types, a "which type for what" table and
 *            the platform-dependent sizes of int, long and the "fast" types on this machine
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Which type would you use for a 16-channel bit mask? For a 0..100 % value?
 *            2) Why is a 32-bit millisecond counter risky in a device that runs for weeks?
 * ============================================================================
 */
#include <inttypes.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>

/* The stdint types promise their size: make the build fail if a compiler ever disagrees. */
_Static_assert(sizeof(uint8_t) == 1U && sizeof(uint16_t) == 2U && sizeof(uint32_t) == 4U,
               "fixed-width types must have the advertised size");

#define ROW_S(T, LO, HI) \
    printf("  %-9s %zu   %20lld %20lld\n", #T, sizeof(T), (long long)(LO), (long long)(HI))
#define ROW_U(T, HI) \
    printf("  %-9s %zu   %20u %20llu\n", #T, sizeof(T), 0U, (unsigned long long)(HI))

/* Which type for which quantity? (the macro prints the type's name and its size) */
#define PICK(what, range, T) printf("  %-26s %-16s -> %-9s (%zu byte%s)\n", what, range, #T, \
                                    sizeof(T), sizeof(T) == 1U ? "" : "s")

int main(void)
{
    puts("--- Exact-width types: name, bytes, minimum, maximum ---");
    ROW_S(int8_t,   INT8_MIN,  INT8_MAX);
    ROW_U(uint8_t,  UINT8_MAX);
    ROW_S(int16_t,  INT16_MIN, INT16_MAX);
    ROW_U(uint16_t, UINT16_MAX);
    ROW_S(int32_t,  INT32_MIN, INT32_MAX);
    ROW_U(uint32_t, UINT32_MAX);
    ROW_S(int64_t,  INT64_MIN, INT64_MAX);
    ROW_U(uint64_t, UINT64_MAX);

    puts("\n--- Choosing the smallest type that fits the quantity ---");
    PICK("GPIO pin number",          "0..15",          uint8_t);
    PICK("percentage",               "0..100",         uint8_t);
    PICK("temperature in degC",      "-40..125",       int8_t);
    PICK("12-bit ADC result",        "0..4095",        uint16_t);
    PICK("signed audio sample",      "-32768..32767",  int16_t);
    PICK("millisecond tick counter", "0..4.29e9",      uint32_t);
    PICK("peripheral register",      "32 bits",        uint32_t);
    PICK("microsecond timestamp",    "years of uptime", uint64_t);
    printf("  (a 32-bit counter in microseconds wraps after only %u minutes)\n",
           (unsigned)(UINT32_MAX / 1000000U / 60U));

    puts("\n--- Plain types: the size is decided by the compiler and CPU ---");
    printf("  sizeof(int)  = %zu   INT_MAX  = %d    (AVR/MSP430: 2 bytes, ARM: 4 bytes)\n",
           sizeof(int), INT_MAX);
    printf("  sizeof(long) = %zu   LONG_MAX = %ld   (Cortex-M: 4, 64-bit Linux: 8)\n",
           sizeof(long), LONG_MAX);
    printf("  sizeof(int_fast16_t) = %zu, sizeof(uint_least8_t) = %zu  (compiler's choice)\n",
           sizeof(int_fast16_t), sizeof(uint_least8_t));

    puts("\n--- <inttypes.h>: printf formats that match fixed-width types ---");
    uint32_t reg = 0xDEADBEEFU;
    uint8_t  pin = 13U;
    int16_t  offs = -1234;
    printf("  reg = 0x%08" PRIX32 ", pin = %" PRIu8 ", offs = %" PRId16 "\n", reg, pin, offs);
    return 0;
}
