# Topic 03 - Constants and Variable Types
**Suggested session:** 75 min | **Prerequisite topics:** 01 Introduction to C, 02 Compilation Process (for `.data`/`.bss`)

Students learn why embedded code uses `<stdint.h>` types, how literals and constants (`#define`, `const`,
`enum`) differ, and where integer types bite: wrap-around, promotion, `volatile`, floats on small CPUs, tick
counters that wrap, and struct padding/endianness. The examples start with ranges and literals (01, 02),
move to constants and arithmetic traps (03, 04), then hardware-related typing (05, 06), numeric formats (07),
and finish with an RTOS time-keeping bug (08) and memory layout on Linux (09).

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_fixed_width_types.c` | MCU | `int8_t`..`uint64_t`, `<limits.h>`/`<stdint.h>` ranges, `PRIu32`, choosing the smallest type that fits |
| 02 | `ex02_literals_and_bases.c` | MCU | Hex, binary, octal trap, suffixes `U L UL ULL f`, literal types via `sizeof`, character codes |
| 03 | `ex03_const_define_enum.c` | MCU | `#define` vs `const` vs `enum`; bracket trap; `const` tables in flash; `switch` over an enum |
| 04 | `ex04_wraparound_and_promotion.c` | MCU | Unsigned wrap, saturation, integer promotion, checked signed add, unsigned count-down, sign-compare trap |
| 05 | `ex05_volatile_isr_flag.c` | MCU | `volatile` for registers and ISR flags; what the optimiser does without it; why `volatile` is not atomic |
| 06 | `ex06_bool_and_status_flags.c` | MCU | `bool` normalises, why `== true` fails on masked values, 8 bools vs one flag byte |
| 07 | `ex07_float_vs_fixed_point.c` | MCU | Float rounding errors, scaled integers (0.1 degC), Q8.8 multiply, no-FPU cost |
| 08 | `ex08_tick_counter_wraparound.c` | RTOS | 32-bit tick wrap after 49.7 days; naive deadline compare vs `now - start` and signed difference |
| 09 | `ex09_struct_padding_endianness.c` | LINUX | Padding, alignment, `packed`, byte dump via `uint8_t *`, `htonl`, shift-based serialisation |

## Teaching notes
* Ask: "How many bytes is an `int`?" The answer "it depends" is the whole motivation for `<stdint.h>`.
* `const` in C is not a compile-time constant (ex03): that is why `enum { N = 8 };` and `#define` size arrays.
* Unsigned wrap is defined and often wanted; signed overflow is undefined behaviour (ex04). Run the `-DDEMO_BUG`
  build with `-fsanitize=undefined` to show the sanitizer message live.
* Integer promotion surprises almost everybody: `uint8_t + uint8_t` is an `int`.
* `volatile` is about the compiler, not about threads or atomicity. Ex05 prints the -O2 assembly difference
  in its header; let students reproduce it on Compiler Explorer.
* Ex08: tie to topic 04 ex07 (shifts and signed conversion). Ask what happens on a 16-bit tick at 1 kHz.

## Live-demo tips
* `gcc -O2 -S` on a two-line `while (!flag) {}` with and without `volatile` (the exact commands are in ex05).
* `gcc -DDEMO_BUG ex03_const_define_enum.c` shows the compiler refusing to write to a `const` table.
* Recompile ex07 and ex09 with `-m32` (if `gcc-multilib` is installed) to see sizes change; or use godbolt.org.
