/*
 * ============================================================================
 *  Topic   : 03 Constants and Variable Types
 *  Example : 07 - float surprises versus scaled integers and Q8.8 fixed point
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : float and double are binary approximations: 0.1 cannot be stored exactly, errors
 *            add up, and a float counter stops counting at 16,777,216. Integers are exact.
 *            Fixed point stores a fraction as an integer scaled by a constant: 23.5 degC kept as
 *            235 (units of 0.1 degC), or Q8.8 = value * 256 in an int16_t. Add and subtract work
 *            directly; after a multiply, shift right by the number of fraction bits.
 *  Embedded use : Cortex-M0/M3 have no FPU, so every float operation calls a software library
 *            (slow, several KB of flash); a Cortex-M4F has a single-precision FPU, but double is
 *            still software. Many sensors, PID loops and audio filters run in fixed point.
 *  Real STM32F4 : temp_x10 = (int16_t)(((int32_t)adc * 3300 / 4095) - 500);   // 0.1 degC units
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex07_float_vs_fixed_point.c -o ex07
 *  Output  : float rounding errors, scaled-integer accumulation, and a Q8.8 multiplication
 *            1.5 * 2.25 = 3.375 done with integer instructions only
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the float counter's start value to 16777215.0f. What happens after 2 steps?
 *            2) Compute 0.5 * 0.5 in Q8.8 by hand: raw 128 * 128 = ? then >> 8 = ?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

typedef int16_t q8_8_t;                 /* Q8.8: value = raw / 256, range -128 .. +127.996 */

/* Convert a CONSTANT to Q8.8 (the compiler does the float maths at build time, so no float
 * instructions end up in the firmware). */
#define Q8_8(x)  ((q8_8_t)((x) * 256.0 + ((x) >= 0.0 ? 0.5 : -0.5)))

/* Multiply: the product of two Q8.8 numbers has 16 fraction bits, so widen to 32 bits,
 * multiply, then shift right by 8 to get back to Q8.8. */
static q8_8_t q_mul(q8_8_t a, q8_8_t b)
{
    return (q8_8_t)(((int32_t)a * (int32_t)b) >> 8);
}

/* Print a non-negative Q8.8 value with two decimals using integers only (no %f needed). */
static void q_print(const char *label, q8_8_t q)
{
    unsigned whole = (unsigned)q >> 8;                  /* integer part: upper 8 bits */
    unsigned frac  = (((unsigned)q & 0xFFU) * 100U) >> 8;   /* fraction part in 1/100 */
    printf("  %-18s raw = %4d = 0x%04X  ->  %u.%02u\n", label, q, (unsigned)q & 0xFFFFU,
           whole, frac);
}

int main(void)
{
    puts("--- 1. Floating point is approximate ---");
    float sum = 0.0f;
    for (int i = 0; i < 1000; i++) sum += 0.1f;
    printf("  adding 0.1f one thousand times = %.5f   (not 100.00000)\n", (double)sum);

    double a = 0.1, b = 0.2, c = 0.3;
    printf("  0.1 + 0.2 == 0.3 ?  %s   (0.1 + 0.2 = %.17f)\n", (a + b == c) ? "yes" : "NO", a + b);

    float ms = 16777216.0f;                 /* 2^24: a float has only 24 bits of precision */
    float next = ms + 1.0f;
    printf("  float ms = 16777216; ms + 1 = %.1f   (the counter is stuck after %.1f hours)\n\n",
           (double)next, 16777216.0 / 3600000.0);

    puts("--- 2. Scaled integers are exact: temperature in units of 0.1 degC ---");
    int32_t total_x10 = 0;
    for (int i = 0; i < 1000; i++) total_x10 += 1;      /* 1000 steps of 0.1 degC */
    printf("  1000 steps of 0.1 degC = %d.%d degC   (exact)\n", (int)(total_x10 / 10),
           (int)(total_x10 % 10));
    int16_t temp_x10 = 235;
    printf("  235 means %d.%d degC; adding 0.5 degC is simply + 5 -> %d.%d degC\n\n", temp_x10 / 10,
           temp_x10 % 10, (temp_x10 + 5) / 10, (temp_x10 + 5) % 10);

    puts("--- 3. Q8.8 fixed point: 8 integer bits, 8 fraction bits ---");
    q8_8_t x = Q8_8(1.5);                               /* 1.5  * 256 = 384 */
    q8_8_t y = Q8_8(2.25);                              /* 2.25 * 256 = 576 */
    q_print("x = 1.5", x);
    q_print("y = 2.25", y);
    q_print("x + y (plain add)", (q8_8_t)(x + y));
    q8_8_t p = q_mul(x, y);
    q_print("x * y (mul, >> 8)", p);                    /* 3.375 prints as 3.37: truncated */
    printf("  (raw x * raw y = %d, which has 16 fraction bits; >> 8 gives %d = 3.375 * 256)\n",
           x * y, p);
    printf("  smallest step = 1/256 = 0.0039; sizeof(q8_8_t) = %zu bytes, sizeof(float) = %zu\n",
           sizeof(q8_8_t), sizeof(float));
    return (p == Q8_8(3.375)) ? 0 : 1;
}
