/*
 * ============================================================================
 *  Topic   : 03 Constants and Variable Types
 *  Example : 08 - RTOS tick counter wrap-around and the safe way to compare times
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A tick counter is an unsigned integer that wraps from 0xFFFFFFFF to 0. Comparing
 *            ABSOLUTE times (now >= deadline) breaks at the wrap. Comparing DURATIONS is always
 *            right: (now - start) >= timeout, because unsigned subtraction wraps like the counter.
 *            The signed difference (int32_t)(now - deadline) works too (Linux time_after() does
 *            this; the unsigned-to-int32_t conversion is implementation-defined, gcc wraps).
 *  Embedded use : FreeRTOS TickType_t is 32 bits (uint16_t if configUSE_16_BIT_TICKS = 1) and
 *            xTaskGetTickCount() wraps after 49.7 days at 1 kHz. A product that "works for weeks
 *            and then hangs" often has exactly this bug in a hand-written timeout.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex08_tick_counter_wraparound.c -o ex08
 *  Output  : three timeout methods run from a safe start tick and from 16 ticks before the wrap;
 *            the naive method returns at once when its deadline lies past the wrap; the wrap
 *            times of 16/32-bit ticks
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Set the start tick to 0xFFFFFF00 and the timeout to 1000. Which methods survive?
 *            2) Make TickType_t a uint16_t (start 0xFFF0). Which cast must change, and to what?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

typedef uint32_t TickType_t;            /* FreeRTOS: 32 bits unless configUSE_16_BIT_TICKS */

static volatile TickType_t tick_count;  /* incremented once per millisecond by the SysTick ISR */

static void SysTick_Handler(void) { tick_count++; }     /* on a Cortex-M the hardware calls this */
static TickType_t xTaskGetTickCount(void) { return tick_count; }

typedef enum { M_NAIVE, M_ELAPSED, M_SIGNED_DIFF } method_t;

/* Busy-wait for 'timeout' ticks using the chosen comparison; return the ticks that really passed.
 * Each loop pass lets one tick go by (a real task would block in vTaskDelay instead). */
static TickType_t wait_ticks(method_t m, TickType_t timeout)
{
    TickType_t start    = xTaskGetTickCount();
    TickType_t deadline = start + timeout;              /* may wrap past 2^32: fine for B and C */
    for (;;) {
        TickType_t now = xTaskGetTickCount();
        int expired = 1;
        switch (m) {                    /* only M_NAIVE breaks at the wrap */
        case M_NAIVE:       expired = (now >= deadline);                      break;
        case M_ELAPSED:     expired = ((TickType_t)(now - start) >= timeout); break;
        case M_SIGNED_DIFF: expired = ((int32_t)(now - deadline) >= 0);       break;
        }
        if (expired) return (TickType_t)(now - start);
        SysTick_Handler();
    }
}

int main(void)
{
    static const char *const names[] = { "naive: now >= deadline", "elapsed: now - start >= t",
                                         "signed diff: (int32_t)(now - deadline) >= 0" };
    const TickType_t starts[] = { 0x00001000U, 0xFFFFFFF0U };
    const TickType_t timeout = 100U;                    /* 100 ticks = 100 ms at 1 kHz */
    int wrong = 0;

    printf("%-12s %-44s %7s  %s\n", "start tick", "method", "elapsed", "verdict");
    for (unsigned s = 0; s < 2U; s++) {
        for (int m = M_NAIVE; m <= M_SIGNED_DIFF; m++) {
            tick_count = starts[s];
            TickType_t took = wait_ticks((method_t)m, timeout);
            int ok = (took == timeout);
            if (!ok && m != M_NAIVE) wrong++;           /* the safe methods must always be right */
            printf("0x%08X   %-44s %7u  %s\n", (unsigned)starts[s], names[m], (unsigned)took,
                   ok ? "ok" : "WRONG: returned long before the timeout");
        }
    }

    puts("\n--- How long until the counter wraps? (1 tick = 1 ms) ---");
    unsigned long long span32 = 1ULL << 32;
    printf("  32-bit ticks: 2^32 ms = %llu days and %llu hours  (the \"works for 7 weeks\" bug)\n",
           span32 / 86400000ULL, (span32 % 86400000ULL) / 3600000ULL);
    printf("  16-bit ticks: 2^16 ms = %u.%u seconds (a wrap bug shows up after about a minute)\n",
           65536U / 1000U, (65536U % 1000U) / 100U);
    puts("  rule: compare durations (now - start), never absolute times, and keep the");
    puts("  timeout below half the counter range so that (int32_t) differences stay valid");
    return wrong;
}
