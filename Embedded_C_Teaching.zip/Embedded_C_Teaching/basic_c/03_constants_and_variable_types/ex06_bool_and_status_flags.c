/*
 * ============================================================================
 *  Topic   : 03 Constants and Variable Types
 *  Example : 06 - bool (_Bool) versus integer flags, and why  == true  can fail
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : <stdbool.h> gives bool (the built-in type _Bool), true (1) and false (0). Whatever
 *            you store in a bool is first normalised: any non-zero value becomes 1. A uint8_t
 *            keeps (or truncates) the number, so a flag test such as  (status & BIT5)  yields
 *            32, and  == true  (== 1) is then FALSE although the bit is set.
 *  Embedded use : readable status variables (button_down, tx_busy) use bool; many flags at
 *            once are packed into ONE integer as bit masks. 8 separate bools cost 8 bytes of
 *            RAM, one uint8_t mask costs 1 byte and can be sent over a wire unchanged.
 *  Real STM32F4 : bool tx_busy = (USART2->SR & USART_SR_TXE) == 0U;   // clean true/false
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex06_bool_and_status_flags.c -o ex06
 *  Output  : conversions into bool vs uint8_t, the broken and the correct "bit is set" test,
 *            the RAM cost of 8 bools vs one flag byte, and a flag byte being set/tested/cleared
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Predict (bool)0.5 and (int)0.5, then run to check.
 *            2) Change STATUS_READY to BIT(0). Does the broken == true test now work? Why?
 * ============================================================================
 */
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

#define BIT(n)         (1U << (n))
#define STATUS_READY   BIT(5)

/* One flag per bit: up to eight flags fit in a single byte (four are used here). */
#define FLAG_LED       BIT(0)
#define FLAG_FAN       BIT(1)
#define FLAG_HEATER    BIT(2)
#define FLAG_ALARM     BIT(3)

typedef struct {                        /* the "obvious" layout: one bool per flag */
    bool led, fan, heater, alarm, door, wifi, ble, buzzer;
} flags_as_bools_t;

static const char *verdict(int ready) { return ready ? "ready" : "NOT ready"; }

int main(void)
{
    puts("--- Conversion: bool normalises, uint8_t truncates ---");
    int big = 256;
    bool    as_bool = big;              /* non-zero -> true                         */
    uint8_t as_u8   = (uint8_t)big;     /* 256 mod 256 = 0                          */
    printf("  value 256 -> bool = %d, uint8_t = %u\n", as_bool, as_u8);
    printf("  (bool)0.5 = %d  but  (int)0.5 = %d\n\n", (int)(bool)0.5, (int)0.5);

    puts("--- Testing one bit of a status register: the == true trap ---");
    uint32_t status = STATUS_READY;     /* bit 5 is set, so the device IS ready     */
    uint8_t raw_flag = (uint8_t)(status & STATUS_READY);    /* 32, not 1            */
    bool    clean    = (status & STATUS_READY) != 0U;       /* 1                    */
    printf("  status & STATUS_READY stored in uint8_t = %u\n", raw_flag);
    printf("  raw_flag == true -> %-9s (32 != 1: WRONG answer)\n", verdict(raw_flag == true));
    printf("  if (raw_flag)    -> %-9s (any non-zero counts as true: fine)\n", verdict(raw_flag));
    printf("  clean == true    -> %-9s (a bool is always 0 or 1)\n\n", verdict(clean == true));

    puts("--- RAM cost: eight bools versus one flag byte ---");
    printf("  sizeof(bool) = %zu, eight bools = %zu bytes, one uint8_t mask = %zu byte\n\n",
           sizeof(bool), sizeof(flags_as_bools_t), sizeof(uint8_t));

    puts("--- A flag byte: set, test, clear, toggle ---");
    uint8_t flags = 0U;
    flags |= FLAG_FAN | FLAG_ALARM;     /* set two flags                            */
    printf("  after set fan+alarm : 0x%02X  fan=%d heater=%d alarm=%d\n", flags,
           (flags & FLAG_FAN) != 0U, (flags & FLAG_HEATER) != 0U, (flags & FLAG_ALARM) != 0U);
    flags &= (uint8_t)~FLAG_ALARM;      /* clear one                                */
    flags ^= FLAG_HEATER;               /* toggle another                           */
    printf("  after clear alarm, toggle heater: 0x%02X  fan=%d heater=%d alarm=%d\n", flags,
           (flags & FLAG_FAN) != 0U, (flags & FLAG_HEATER) != 0U, (flags & FLAG_ALARM) != 0U);
    printf("  note: the result of == , < , && is an int (0 or 1) in C, sizeof(1 == 1) = %zu\n",
           sizeof(1 == 1));
    return 0;
}
