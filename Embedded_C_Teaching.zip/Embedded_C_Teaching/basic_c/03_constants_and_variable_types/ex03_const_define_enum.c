/*
 * ============================================================================
 *  Topic   : 03 Constants and Variable Types
 *  Example : 03 - Three ways to name a constant: #define, const and enum
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : #define  = text replaced by the preprocessor: no type, no address, no scope.
 *            const    = a real variable the compiler forbids you to change: typed, has an
 *                       address, but in C it is NOT usable as an array size or case label.
 *            enum     = named integer constants: perfect for states and for array sizes.
 *            A #define with an operator needs brackets: (85 + 5), not 85 + 5.
 *  Embedded use : a 'const' lookup table is stored only in flash; without 'const' the startup
 *            code copies the whole table into RAM. enum makes state machines readable and lets
 *            the compiler warn about an unhandled state (-Wswitch).
 *  Real STM32F4 : static const uint8_t SEG7[10] = {...};   // lives in flash, 10 bytes of RAM saved
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex03_const_define_enum.c -o ex03
 *  Output  : the #define bracket trap, an array sized by an enum, an enum-driven switch and a
 *            7-segment table read from flash
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Add LED_FAST to led_mode_t but not to the switch. What does gcc -Wall say?
 *            2) Build with -DDEMO_BUG and read the errors for the two lines it enables.
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

#define BAUD_RATE       115200UL        /* a #define: no type, no memory, no debugger symbol */
#define LIMIT_BAD       85 + 5          /* WRONG: no brackets                                */
#define LIMIT_GOOD      (85 + 5)

static const uint16_t ADC_MAX = 4095U;  /* a const: typed, has an address, lives in flash    */

enum { RX_BUF_LEN = 8 };                /* anonymous enum: the C way to get a typed constant */
typedef enum { LED_OFF, LED_ON, LED_BLINK } led_mode_t;     /* values 0, 1, 2 */

static uint8_t rx_buf[RX_BUF_LEN];      /* array size must be a constant expression          */

/* Common-cathode 7-segment codes for 0..9, bit0 = segment a ... bit6 = segment g. */
static const uint8_t SEG7[10] = { 0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F };

_Static_assert(sizeof SEG7 == 10U, "SEG7 must hold one code per decimal digit");

static const char *mode_name(led_mode_t m)
{
    switch (m) {                        /* no 'default': gcc warns if an enumerator is missing */
    case LED_OFF:   return "OFF";
    case LED_ON:    return "ON";
    case LED_BLINK: return "BLINK";
    }
    return "?";
}

int main(void)
{
    puts("--- #define needs brackets ---");
    printf("  2 * LIMIT_BAD  = %d   (expands to 2 * 85 + 5)\n", 2 * LIMIT_BAD);
    printf("  2 * LIMIT_GOOD = %d  (expands to 2 * (85 + 5))\n\n", 2 * LIMIT_GOOD);

    puts("--- const versus enum as array size ---");
    printf("  rx_buf has %zu bytes (sized by the enum constant RX_BUF_LEN = %d), last byte = %u\n",
           sizeof rx_buf, (int)RX_BUF_LEN, (unsigned)rx_buf[RX_BUF_LEN - 1]);
    printf("  ADC_MAX = %u is a const: a real %zu-byte object (you can write &ADC_MAX),\n"
           "  but C will not accept it as the size of a global array\n", (unsigned)ADC_MAX,
           sizeof ADC_MAX);
    printf("  BAUD_RATE = %lu is a #define: no object, no address; the number is pasted in\n\n",
           BAUD_RATE);

    puts("--- enum drives a switch ---");
    for (int m = LED_OFF; m <= LED_BLINK; m++)
        printf("  led_mode_t value %d = %s\n", m, mode_name((led_mode_t)m));
    printf("  sizeof(led_mode_t) = %zu  (int-sized here; some embedded ABIs shrink enums to\n"
           "  1 byte, so never place an enum inside a wire-protocol frame: use uint8_t)\n\n",
           sizeof(led_mode_t));

    puts("--- const table in flash: 7-segment codes ---");
    for (unsigned d = 0; d < sizeof SEG7 / sizeof SEG7[0]; d++) {
        printf("  digit %u -> 0x%02X = ", d, SEG7[d]);
        for (int bit = 6; bit >= 0; bit--) putchar(((SEG7[d] >> bit) & 1U) ? '1' : '0');
        putchar('\n');
    }
    printf("  the table is %zu bytes of flash; WITHOUT const it would also cost %zu bytes of RAM\n",
           sizeof SEG7, sizeof SEG7);

#ifdef DEMO_BUG
    static uint8_t bad_buf[ADC_MAX];    /* ERROR: a const is not a constant expression in C    */
    SEG7[0] = 0U;                       /* ERROR: assignment of read-only location             */
    (void)bad_buf;
#endif
    return 0;
}
