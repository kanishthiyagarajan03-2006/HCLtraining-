# Topic 01 - Introduction to C
**Suggested session:** 60 min | **Prerequisite topics:** none (first session)

Students leave knowing the parts of a C program (directives, globals, functions, `main`, `return`), what
firmware looks like (init once, then an endless loop), how a character reaches a serial console, and how
`main` differs between a PC/Linux program (exit status, `argv`) and an RTOS or bare-metal image. The
examples go from a printed banner (01), through a UART and a blinking LED (02, 03), to hosted-C details
(04, 05), a first two-task RTOS program (06), and a small complete firmware that combines everything (07).

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_program_anatomy.c` | MCU | Preprocessor lines, globals, prototype, `main`, function definitions, statements, comments |
| 02 | `ex02_uart_hello.c` | MCU | `uart_putc()` polling the TXE flag on `volatile` registers; `uart_puts()`; printing numbers digit by digit |
| 03 | `ex03_blink_super_loop.c` | MCU | Firmware shape: `system_init()` then the super-loop; two LEDs swapped with one XOR |
| 04 | `ex04_exit_status_hosted_vs_embedded.c` | LINUX | What `main` returns: exit status read by the parent (like `echo $?`); firmware never exits |
| 05 | `ex05_argv_greeting.c` | LINUX | `int main(int argc, char *argv[])`, defaults, `strtol` with error checking |
| 06 | `ex06_two_blinking_tasks.c` | RTOS | `main` only creates tasks; each task is `void task(void *arg)` with its own endless loop and a delay |
| 07 | `ex07_mini_firmware.c` | MCU | Init functions, UART-style log, button edge detection and a heartbeat in one super-loop |

## Teaching notes
* A statement ends with `;`, a block with `}`. Ask: why does the compiler need the prototype in ex01 before `main`?
* Hosted vs freestanding: on a PC `main` returns to the OS; on a microcontroller nothing is "above" `main`, so it
  must never return. Show the `Reset_Handler` sketch printed by ex04.
* In ex02 the CPU spends most of its time waiting for the UART. That is the motivation for interrupts and DMA later.
* Common mistakes: forgetting `void` in `int main(void)`, a missing `;` after a statement, writing `=` for `==`.
* In ex06, both tasks have priority 1, so they simply take turns whenever one blocks in `rtos_delay()`. The
  simulator starts them in creation order, but on a real RTOS never rely on the start order of equal-priority
  tasks. In ex07, remove the `was_down` test to show level versus edge handling.

## Live-demo tips
* Run `./ex04; echo $?` in a terminal, then `./ex05 Ravi 2` and `./ex05 Ravi abc` to show real arguments.
* Edit `BLINK_MS` in ex03 and rebuild: the simulated timestamps change, nothing really waits (add
  `-DSIM_REALTIME` to see real delays).
* Compile ex01 with `-E` and then `-S` for a first look at what the compiler does (topic 02 goes deeper).
