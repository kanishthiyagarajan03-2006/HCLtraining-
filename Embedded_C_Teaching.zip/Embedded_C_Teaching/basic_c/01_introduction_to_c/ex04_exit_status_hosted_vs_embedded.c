/*
 * ============================================================================
 *  Topic   : 01 Introduction to C
 *  Example : 04 - What main() returns: Linux exit status vs firmware that never exits
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : On a hosted system (Linux, Windows) main() returns an int; the operating system
 *            hands it to the parent process (the shell shows it in $?). 0 = success, anything
 *            else = an error code, and only the low 8 bits survive. A bare-metal main() has no
 *            parent: after reset the startup code calls main() and, if it ever returned,
 *            would just sit in an endless loop (or reset the chip).
 *  Embedded use : Linux services and init scripts decide "restart or not" from exit codes; a
 *            watchdog or supervisor does the same job on a microcontroller.
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex04_exit_status_hosted_vs_embedded.c -o ex04
 *  Output  : a table of child processes and the exit status the parent reads, like  echo $?
 * ----------------------------------------------------------------------------
 *  Try it  : 1) In a shell run  ./ex04 ; echo $?   - what do you get, and why?
 *            2) Add a child that exits with 256. What status does the parent see?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

/* Wait for a child and return the exit status that a shell would show in $?. */
static int exit_status_of(pid_t pid)
{
    int st = 0;
    if (waitpid(pid, &st, 0) < 0) { perror("waitpid"); return -1; }
    return WIFEXITED(st) ? WEXITSTATUS(st) : -1;
}

/* A child that behaves like a program whose main() returned 'code'. */
static int child_returns(int code)
{
    fflush(stdout);                     /* do not duplicate unflushed output into the child */
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return -1; }
    if (pid == 0) _exit(code);          /* like exit(main's value): the final step of a run */
    return exit_status_of(pid);
}

/* A child that runs a shell command (like typing it at the prompt). */
static int child_runs(const char *shell_cmd)
{
    fflush(stdout);
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return -1; }
    if (pid == 0) {
        execlp("sh", "sh", "-c", shell_cmd, (char *)NULL);
        _exit(127);                     /* exec itself failed */
    }
    return exit_status_of(pid);
}

int main(void)
{
    puts("--- Hosted C: the parent reads the child's exit status (shell: echo $?) ---");
    printf("child main() returns 0        -> status %d   (EXIT_SUCCESS = %d)\n",
           child_returns(EXIT_SUCCESS), EXIT_SUCCESS);
    printf("child main() returns 1        -> status %d   (EXIT_FAILURE = %d)\n",
           child_returns(EXIT_FAILURE), EXIT_FAILURE);
    printf("child main() returns 300      -> status %d  (only the low 8 bits: 300 & 0xFF)\n",
           child_returns(300));
    printf("shell command  true           -> status %d\n", child_runs("true"));
    printf("shell command  false          -> status %d\n", child_runs("false"));
    printf("shell command  exit 42        -> status %d\n", child_runs("exit 42"));
    printf("unknown command               -> status %d  (127 = command not found)\n",
           child_runs("no_such_command_xyz 2>/dev/null"));

    puts("\n--- Freestanding firmware: nobody to return to ---");
    puts("startup code (Reset_Handler) on a Cortex-M does roughly this:");
    puts("    copy .data from flash to RAM; zero .bss; set up the clock;");
    puts("    main();            <- your code, normally an endless loop");
    puts("    for (;;) { }       <- if main() ever returns, the chip just spins here");

    puts("\nThis program's own main() now returns 0 -> the shell will see $? = 0");
    return EXIT_SUCCESS;
}
