/*
 * ============================================================================
 *  Topic   : 01 Introduction to C
 *  Example : 02 - "Hello" through a UART: uart_putc(), uart_puts() and polling TXE
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : On a microcontroller printf() does not exist until YOU provide the character
 *            output. The lowest layer is uart_putc(): wait until the status flag TXE says the
 *            transmitter is free, then write one byte to the data register. uart_puts() and
 *            number printing are plain loops on top of it. 'volatile' marks the registers.
 *  Embedded use : the first thing every board bring-up needs is a serial console. printf
 *            retargeting (_write()) just calls uart_putc() for each character.
 *  Real STM32F4 : while (!(USART2->SR & USART_SR_TXE)) { }   USART2->DR = c;
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex02_uart_hello.c -o ex02
 *  Output  : a greeting, five squares printed digit by digit, the baud-rate maths and the
 *            number of times the CPU had to wait on the slow UART
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Remove the TXE wait loop in uart_putc(). Which characters go missing, and why?
 *            2) Print uart_put_u32(0) - does the do/while loop handle zero correctly?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

/* ---- Fake USART2 registers (plain memory here; real addresses on the chip) ------------ */
#define USART_SR_TXE  (1U << 7)         /* TXE = 1: data register empty, safe to write      */
static volatile uint32_t USART_SR = USART_SR_TXE;
static volatile uint32_t USART_DR;
static volatile uint32_t USART_BRR;

static unsigned polls_spent;            /* how often the CPU looked at TXE and found it busy */

/* The real UART shifts bits out on its own. On the PC we advance the model by hand: it takes
 * three "bit times" per byte, then the byte appears on the console and TXE is set again. */
static void uart_hw_step(void)
{
    static unsigned busy;
    if ((USART_SR & USART_SR_TXE) == 0U && ++busy >= 3U) {
        int c = (int)(USART_DR & 0xFFU);
        if (c != '\r') putchar(c);      /* the PC console adds its own carriage return      */
        busy = 0U;
        USART_SR |= USART_SR_TXE;
    }
}

static void uart_putc(char c)
{
    while ((USART_SR & USART_SR_TXE) == 0U) {   /* busy-wait until the last byte has left    */
        polls_spent++;
        uart_hw_step();                         /* (on real silicon this happens by itself)  */
    }
    USART_DR = (uint32_t)(uint8_t)c;            /* writing DR starts the transmission        */
    USART_SR &= ~USART_SR_TXE;                  /* (the hardware clears TXE for us)          */
}

static void uart_flush(void)                    /* wait until the very last byte is out      */
{
    while ((USART_SR & USART_SR_TXE) == 0U) uart_hw_step();
}

static void uart_puts(const char *s)
{
    for (size_t i = 0; s[i] != '\0'; i++) {
        if (s[i] == '\n') uart_putc('\r');      /* terminals want CR+LF at the end of a line */
        uart_putc(s[i]);
    }
}

/* printf without printf: peel off decimal digits with % and /, then print them reversed. */
static void uart_put_u32(uint32_t v)
{
    char digits[10];                            /* 2^32 - 1 has 10 decimal digits            */
    int n = 0;
    do {
        digits[n++] = (char)('0' + v % 10U);    /* '0' + 7 = '7'                             */
        v /= 10U;
    } while (v != 0U);
    while (n > 0) uart_putc(digits[--n]);
}

int main(void)
{
    const uint32_t f_clk = 16000000U, baud = 115200U;
    /* STM32F4 with 16x oversampling: BRR holds 16 * USARTDIV, so baud = f_clk / BRR.        */
    USART_BRR = (f_clk + baud / 2U) / baud;     /* integer divide, rounded to nearest: 139   */

    uart_puts("Hello from the UART!\n");
    uart_puts("Squares: ");
    for (uint32_t i = 1U; i <= 5U; i++) {
        uart_put_u32(i * i);
        uart_putc(' ');
    }
    uart_puts("\nBRR = ");
    uart_put_u32(USART_BRR);
    uart_puts(" -> real baud rate ");
    uart_put_u32(f_clk / USART_BRR);
    uart_puts("\n");
    uart_flush();

    printf("(the CPU waited on TXE %u times: a UART is MUCH slower than the CPU)\n", polls_spent);
    return 0;
}
