/*
 * ============================================================================
 *  Topic   : 01 Introduction to C
 *  Example : 05 - main(int argc, char *argv[]): command-line arguments on embedded Linux
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : A hosted program may declare  int main(int argc, char *argv[]).  argc counts the
 *            words on the command line INCLUDING the program name; argv[0] is the program name,
 *            argv[1..argc-1] are the arguments as strings and argv[argc] is NULL. Numbers arrive
 *            as TEXT: convert with strtol() and check that the conversion really succeeded.
 *  Embedded use : Linux daemons are configured this way:  ./uart_logger --port /dev/ttyS1 115200
 *            Bare-metal firmware has no command line, so it declares  int main(void).
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex05_argv_greeting.c -o ex05
 *  Output  : with no arguments, a canned command line "ex05 Asha 3" is parsed and the greeting
 *            is printed three times; run  ./ex05 Ravi 2  to use your own arguments
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Run  ./ex05 Ravi 9  and  ./ex05 Ravi abc  - how does the program react?
 *            2) Add a third argument that sets the greeting word ("Hello" by default).
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* The "real" program: works on any argc/argv pair, real or canned. */
static int greet(int argc, char *argv[])
{
    const char *prog = (argc > 0 && argv[0] != NULL) ? argv[0] : "program";
    const char *slash = strrchr(prog, '/');
    if (slash != NULL) prog = slash + 1;                /* show the name without its folder */

    printf("argc = %d\n", argc);
    for (int i = 0; i < argc; i++)
        printf("  argv[%d] = \"%s\"\n", i, (i == 0) ? prog : argv[i]);

    const char *name = (argc > 1) ? argv[1] : "student";   /* default when missing */
    int times = 1;
    if (argc > 2) {
        char *end = NULL;                               /* strtol tells us where it stopped */
        long v = strtol(argv[2], &end, 10);
        if (end == argv[2] || *end != '\0' || v < 1 || v > 5)
            fprintf(stderr, "%s: bad repeat count '%s' (use 1..5), using 1\n", prog, argv[2]);
        else
            times = (int)v;
    }

    for (int i = 1; i <= times; i++)
        printf("Hello, %s! (greeting %d of %d)\n", name, i, times);
    return EXIT_SUCCESS;
}

int main(int argc, char *argv[])
{
    if (argc > 1)
        return greet(argc, argv);                       /* the user gave real arguments      */

    puts("(no arguments - using the canned command line:  ex05 Asha 3)");
    char *demo_argv[] = { argv[0], "Asha", "3", NULL };  /* argv[argc] is always NULL        */
    return greet(3, demo_argv);
}
