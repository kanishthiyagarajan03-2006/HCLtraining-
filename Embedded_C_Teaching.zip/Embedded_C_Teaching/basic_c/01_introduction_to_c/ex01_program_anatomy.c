/*
 * ============================================================================
 *  Topic   : 01 Introduction to C
 *  Example : 01 - Anatomy of a C program: directives, globals, functions, main, return
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Every C file has the same parts, read top to bottom: preprocessor lines
 *            (#include, #define), global data, function declarations, main(), and function
 *            definitions. Statements end with ';' and are grouped with { }.
 *            The compiler must see a name BEFORE you use it - hence the prototypes.
 *  Embedded use : a firmware project has this exact shape: chip constants at the top, a few
 *            small driver functions, and a main() that initialises the hardware.
 *  Real STM32F4 : int main(void) { HAL_Init(); SystemClock_Config(); while (1) { ... } }
 *  Build   : gcc -std=gnu11 -Wall -Wextra ex01_program_anatomy.c -o ex01
 *  Output  : a firmware banner, an 8-bit checksum of the board name and three boot steps
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Move checksum8() below main() and delete its prototype - what does gcc say?
 *            2) Change FW_MINOR and predict whether the checksum changes (it should not - why?).
 * ============================================================================
 */

/* ---- 1. Preprocessor lines start with '#'. They run BEFORE the compiler proper. ------- */
#include <stdint.h>             /* fixed-width types: uint8_t, uint32_t ...              */
#include <stdio.h>              /* printf()                                              */

#define FW_MAJOR 1U             /* text replacement: every FW_MAJOR becomes 1U           */
#define FW_MINOR 4U

/* ---- 2. Global data: lives for the whole run. 'const' data can sit in flash. ---------- */
static const char board_name[] = "NUCLEO-F446RE";
static uint32_t boot_count = 0U;                        // C99 single-line comment

/* ---- 3. Prototypes: the signature (return type, name, parameters) without the body. ---- */
static uint8_t checksum8(const char *text);
static void print_banner(void);

/* ---- 4. main(): where execution starts. On a PC it returns an exit code; ------------- */
/*         on a bare-metal MCU it never returns.                                          */
int main(void)
{
    print_banner();                                     /* a statement: a call ending in ; */

    for (int step = 1; step <= 3; step++) {             /* braces make a compound statement */
        boot_count = boot_count + 1U;                   /* an expression statement          */
        printf("boot step %d done (boot_count = %u)\n", step, (unsigned)boot_count);
    }

    /* Comments are removed by the preprocessor. They cannot be nested, so never write a
       slash-star inside a slash-star comment; use #if 0 ... #endif to disable big blocks. */
    return 0;                                           /* 0 = success on a PC               */
}

/* ---- 5. Function definitions: return type, name, parameter list, then the { body }. ---- */
static uint8_t checksum8(const char *text)
{
    uint8_t sum = 0U;                                   /* local variable: exists only here */
    for (size_t i = 0; text[i] != '\0'; i++)            /* a C string ends with a '\0' byte */
        sum = (uint8_t)(sum + (uint8_t)text[i]);        /* 8-bit sum wraps around at 256    */
    return sum;
}

static void print_banner(void)
{
    printf("==== Firmware v%u.%u on %s ====\n", FW_MAJOR, FW_MINOR, board_name);
    printf("board name checksum = 0x%02X\n", checksum8(board_name));
}
