/*
 * ============================================================================
 *  Topic   : 01 Introduction to C
 *  Example : 07 - A complete tiny firmware: init functions, UART log, button, heartbeat
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Putting the pieces together: small init functions called from main(), then a
 *            super-loop that runs every 100 ms "tick". Inside the loop: read an input, make a
 *            decision with if, update an output, and count the events - all with the plain
 *            statements and operators you meet in the next topics.
 *  Embedded use : this is the skeleton of real products: boot log over the UART, a heartbeat
 *            LED that proves the main loop is alive, and a button handled once per press.
 *  Real STM32F4 : if (!(GPIOC->IDR & (1U << 13))) { ... }   // B1 on Nucleo-64 is ACTIVE-LOW
 *            (pressed reads 0); this simulator uses an active-high button for simplicity
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_mini_firmware.c -o ex07
 *  Output  : a boot log, then 12 ticks: heartbeat LED blinking every 300 ms and two button
 *            presses (one long, one short) each counted exactly once
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Remove the "was_down" test. How many presses are counted for the long press?
 *            2) Make the heartbeat blink every 200 ms using only the HEARTBEAT_TICKS macro.
 * ============================================================================
 */
#include "hw_sim.h"

#define LED_PIN          5U             /* PA5: heartbeat LED   */
#define BUTTON_PIN       13U            /* PC13: user button    */
#define TICK_MS          100U
#define HEARTBEAT_TICKS  3U             /* toggle the LED every 3 ticks = 300 ms */
#define RUN_TICKS        12U            /* demo length; real firmware never stops */

/* Stand-in for the UART driver from ex02 (it would call uart_putc() per character). */
static void log_line(const char *msg) { printf("[uart] %s\n", msg); }

static void clock_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOCEN;
    log_line("clocks enabled");
}

static void gpio_init(void)
{
    GPIOA->MODER &= ~(3U << (LED_PIN * 2U));
    GPIOA->MODER |=  (1U << (LED_PIN * 2U));     /* PA5 output; PC13 stays an input */
    log_line("GPIO configured");
}

int main(void)
{
    /* What the button does on each tick: 1 = pressed. A long press then a short one. */
    const uint8_t button_script[RUN_TICKS] = { 0, 0, 0, 0, 1, 1, 1, 0, 0, 1, 0, 0 };
    unsigned presses = 0U;
    int was_down = 0;

    /* ---- Phase 1: initialise, in a sensible order ---- */
    clock_init();
    gpio_init();
    log_line("boot complete, entering main loop");

    /* ---- Phase 2: the super-loop ---- */
    for (unsigned tick = 0U; tick < RUN_TICKS; tick++) {
        if (button_script[tick]) sim_press(GPIOC, BUTTON_PIN);
        else                     sim_release(GPIOC, BUTTON_PIN);

        int is_down = (GPIOC->IDR & (1U << BUTTON_PIN)) != 0U;
        if (is_down && !was_down) {              /* count the moment of pressing only */
            presses++;
            printf("      -> button press #%u detected\n", presses);
        }
        was_down = is_down;

        if (tick % HEARTBEAT_TICKS == 0U)        /* every third tick */
            GPIOA->ODR ^= (1U << LED_PIN);

        sim_delay_ms(TICK_MS);
        printf("[%4u ms] tick %2u  heartbeat LED %-3s  button %-8s presses = %u\n",
               (unsigned)sim_millis(), tick, (GPIOA->ODR & (1U << LED_PIN)) ? "ON" : "off",
               is_down ? "pressed" : "released", presses);
    }

    log_line("demo finished");
    return (presses == 2U) ? 0 : 1;
}
