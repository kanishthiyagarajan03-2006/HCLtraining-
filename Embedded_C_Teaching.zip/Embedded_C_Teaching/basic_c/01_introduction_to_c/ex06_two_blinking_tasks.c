/*
 * ============================================================================
 *  Topic   : 01 Introduction to C
 *  Example : 06 - First RTOS skeleton: two tasks blink two LEDs at different rates
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : With an RTOS, main() no longer contains the endless loop. It only creates
 *            tasks (each task IS a function with its own endless loop) and starts the
 *            scheduler. A task has the fixed signature  void task(void *arg)  and gives up the
 *            CPU by blocking in a delay, so other tasks can run in the meantime.
 *  Embedded use : FreeRTOS  xTaskCreate(green_task, "green", 128, NULL, 1, NULL);  ...
 *            vTaskStartScheduler();  - the same two steps, the same task shape.
 *  Real STM32F4 : vTaskDelay(pdMS_TO_TICKS(500));   // block this task for 500 ms
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_two_blinking_tasks.c -o ex06
 *  Output  : a timestamped log; the green LED (every 500 ms) and red LED (every 300 ms) toggle
 *            independently over 1.5 simulated seconds
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change the red delay to 250 ms. Both tasks now wake together at 500 and 1000 ms:
 *               which one logs first?   2) Give red priority 2 - does the order change?
 * ============================================================================
 */
#include "hw_sim.h"
#include "mini_rtos.h"

#define LD1_GREEN (1U << 0)             /* PB0  */
#define LD3_RED   (1U << 14)            /* PB14 */

/* Both tasks use read-modify-write on the same port. That is safe here because mini_rtos only
 * switches tasks when one blocks; on a preemptive RTOS you would use BSRR (topic 04 ex05). */
static void green_task(void *arg)
{
    (void)arg;                          /* this task does not use its parameter */
    for (;;) {                          /* a task never returns                 */
        GPIOB->ODR ^= LD1_GREEN;
        rtos_log("LD1 green %s", (GPIOB->ODR & LD1_GREEN) ? "ON " : "off");
        rtos_delay(500);                /* vTaskDelay(): block, the CPU is free for others */
    }
}

static void red_task(void *arg)
{
    (void)arg;
    for (;;) {
        GPIOB->ODR ^= LD3_RED;
        rtos_log("LD3 red   %s", (GPIOB->ODR & LD3_RED) ? "ON " : "off");
        rtos_delay(300);
    }
}

int main(void)
{
    /* Same hardware set-up as bare metal. */
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    GPIOB->MODER |= (1U << (0 * 2)) | (1U << (14 * 2));

    /* Priority 1 for both: equal priorities take turns whenever a task blocks. This simulator
     * starts them in creation order ("green" first). On a real RTOS the start order of
     * equal-priority tasks is an implementation detail: never build logic that relies on it. */
    rtos_task_create("green", green_task, NULL, 1, 512);
    rtos_task_create("red",   red_task,   NULL, 1, 512);

    puts("tasks created, starting the scheduler");
    rtos_start(1500);                   /* run 1500 ms of simulated time */
    puts("demo over (on a real RTOS vTaskStartScheduler() never returns)");
    rtos_shutdown();
    return 0;
}
