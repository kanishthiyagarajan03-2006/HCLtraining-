/*
 * ============================================================================
 *  Topic   : 05 Formatted and Unformatted I/O
 *  Example : 02 - Retargeting printf to a UART (uart_printf with vsnprintf)
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : printf is only a formatter sitting on top of ONE low-level "send a char"
 *            function. snprintf-style formatting into a small buffer, then a loop of
 *            uart_putc, gives you printf for any device. vsnprintf returns the length it
 *            WANTED to write, so you can detect truncation (a value >= buffer size).
 *  Embedded use : on bare metal, newlib's printf calls _write(); you implement it with
 *            uart_putc and printf "just works". A terminal also needs CR+LF line endings.
 *  Real STM32F4 : int _write(int fd, char *buf, int len)   // newlib / arm-none-eabi-gcc
 *                 { for (int i = 0; i < len; i++) uart_putc(buf[i]); return len; }
 *                 (Keil/ARMCC retargets fputc(); IAR retargets __write().)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex02_retarget_printf_to_uart.c -o ex02
 *  Output  : messages as the terminal sees them (CR and LF shown as <CR> <LF>), then a
 *            message that is too long and gets cut, with the return value explained
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Change TX_BUF_SIZE to 16 - which messages now get truncated?
 *            2) Remove the '\r' insertion in uart_putc. What would a serial terminal show?
 * ============================================================================
 */
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>

#define USART_SR_TXE (1U << 7)
#define TX_BUF_SIZE  48U            /* small on purpose: RAM is precious, and we want a demo */

static volatile uint32_t USART_SR = USART_SR_TXE;   /* fake USART status register */
static volatile uint32_t USART_DR;                  /* fake USART data register   */

/* Low level: one byte out. '\n' becomes CR+LF because serial terminals expect it. */
static void uart_putc(char c)
{
    if (c == '\n') {
        uart_putc('\r');
    }
    while ((USART_SR & USART_SR_TXE) == 0U) { /* wait for TXE */ }
    USART_DR = (uint8_t)c;
    /* PC only: draw the "wire" so that the invisible CR and LF can be seen. */
    if (USART_DR == '\r')      fputs("<CR>", stdout);
    else if (USART_DR == '\n') fputs("<LF>\n", stdout);
    else                       putchar((int)USART_DR);
}

/* Formatted: build the text in a RAM buffer, then push it out byte by byte.
 * Returns the length the full text would have had (like snprintf), or <0 on error. */
static int uart_printf(const char *fmt, ...)
{
    char buf[TX_BUF_SIZE];
    va_list ap;

    va_start(ap, fmt);
    int len = vsnprintf(buf, sizeof buf, fmt, ap);   /* never writes past buf */
    va_end(ap);

    for (const char *p = buf; len >= 0 && *p != '\0'; p++) {
        uart_putc(*p);
    }
    return len;
}

int main(void)
{
    uint16_t adc = 2048U;
    uint32_t mv  = ((uint32_t)adc * 3300U) / 4095U;      /* 12-bit ADC, 3.3 V reference */

    puts("-- what the terminal receives --");
    uart_printf("boot ok, build %d\n", 7);
    uart_printf("ADC=%u raw -> %u mV\n", (unsigned)adc, (unsigned)mv);

    /* A message longer than the buffer. TX_BUF_SIZE counts the '\0', so max 47 chars. */
    int want = uart_printf("sensor name: %s\n", "outdoor-temperature-probe-north-wall");
    putchar('\n');                                       /* the cut text has no '\n' left */

    puts("-- truncation check --");
    printf("snprintf-family return value = %d, buffer holds %u chars\n", want, TX_BUF_SIZE - 1U);
    if (want >= (int)TX_BUF_SIZE) {
        printf("TRUNCATED by %d chars: make the buffer bigger or shorten the message\n",
               want - (int)(TX_BUF_SIZE - 1U));
    }
    return 0;
}
