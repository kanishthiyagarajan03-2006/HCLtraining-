/*
 * ============================================================================
 *  Topic   : 05 Formatted and Unformatted I/O
 *  Example : 06 - stdout for data, stderr for diagnostics, with log levels
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Every process starts with three streams: stdin (0), stdout (1), stderr (2).
 *            Results go to stdout, messages about the program go to stderr. The shell can
 *            then split them:  ./ex06 2>/dev/null  (data only),  ./ex06 >/dev/null (logs only).
 *            stderr is unbuffered, so a log line appears even if the program crashes next.
 *  Embedded use : embedded Linux daemons log to stderr (captured by systemd/journald or a
 *            serial console) and keep stdout clean for machine-readable output. A log
 *            LEVEL lets you ship quiet firmware and still debug in the field.
 *  Real Linux   : fprintf(stderr, ...);  syslog(LOG_WARNING, ...);  env var LOG_LEVEL=debug
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex06_linux_stderr_log_levels.c -o ex06
 *  Output  : stdout: two sensor results (the broken third reading is dropped). stderr: INFO/WARN/
 *            ERROR lines (DEBUG too if you run LOG_LEVEL=debug ./ex06). Exit status is still 0
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Run:  ./ex06 2>/dev/null   then   ./ex06 >/dev/null   - what is left each time?
 *            2) Run:  LOG_LEVEL=error ./ex06 2>&1   - which log lines survive?
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

typedef enum { LOG_ERROR, LOG_WARN, LOG_INFO, LOG_DEBUG } log_level_t;

static const char *const level_name[] = { "ERROR", "WARN", "INFO", "DEBUG" };
static log_level_t g_level = LOG_INFO;      /* default: hide DEBUG */

static void log_msg(log_level_t lvl, const char *fmt, ...)
{
    if (lvl > g_level) {
        return;                             /* filtered out: costs only this compare */
    }
    va_list ap;
    fprintf(stderr, "[%-5s] ", level_name[lvl]);
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
}

/* LOG_LEVEL=error|warn|info|debug picks the verbosity; anything else keeps the default. */
static void level_from_env(void)
{
    const char *v = getenv("LOG_LEVEL");
    if (v == NULL) {
        return;
    }
    for (int i = LOG_ERROR; i <= LOG_DEBUG; i++) {
        if (strncasecmp(v, level_name[i], strlen(level_name[i])) == 0) {
            g_level = (log_level_t)i;
            return;
        }
    }
    log_msg(LOG_WARN, "unknown LOG_LEVEL '%s', keeping default", v);
}

int main(void)
{
    static const int raw_mv[] = { 1650, 1790, 9999 };   /* the last one is a broken reading */

    level_from_env();
    log_msg(LOG_INFO, "sensor app starting (log level %s)", level_name[g_level]);

    for (size_t i = 0; i < sizeof raw_mv / sizeof raw_mv[0]; i++) {
        int mv = raw_mv[i];
        log_msg(LOG_DEBUG, "sample %zu: raw=%d mV", i, mv);

        if (mv > 3300) {
            log_msg(LOG_ERROR, "sample %zu: %d mV is above the 3300 mV supply, dropped", i, mv);
            continue;
        }
        if (mv > 1700) {
            log_msg(LOG_WARN, "sample %zu: %d mV is close to the limit", i, mv);
        }
        /* The RESULT is data: it belongs on stdout so another program can read it.
         * (Piped to a file, stdout is buffered, so these lines may show up after the
         * unbuffered stderr ones - the same effect as in ex05.) */
        printf("sample %zu = %d mV\n", i, mv);
    }
    log_msg(LOG_INFO, "done");
    return 0;                               /* bad data is not a program failure */
}
