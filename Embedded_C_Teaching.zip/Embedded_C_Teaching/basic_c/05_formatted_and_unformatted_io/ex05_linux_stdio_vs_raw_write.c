/*
 * ============================================================================
 *  Topic   : 05 Formatted and Unformatted I/O
 *  Example : 05 - Buffered stdio vs raw read()/write() system calls (setvbuf, fflush)
 *  Flavour : LINUX
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : stdio (printf, fputs, fgets) collects data in a user-space buffer and calls the
 *            kernel only when the buffer is flushed. write()/read() talk to the kernel
 *            at once, one system call each. Mixing them reorders output unless you fflush.
 *            read() returns 0 at EOF and may return fewer bytes than you asked for.
 *  Embedded use : on an embedded Linux board a debug print to /dev/ttyS0 or to a log file
 *            can lose its last lines if the process dies before fflush; and a system call
 *            per byte (115200 baud!) wastes CPU. Know which layer you are using.
 *  Real Linux   : write(1, buf, len);  read(0, buf, n);  setvbuf(stdout, NULL, _IOLBF, 0);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex05_linux_stdio_vs_raw_write.c -o ex05
 *  Output  : raw write() lines overtaking buffered printf lines, a read(0) fallback to
 *            simulated input, and the number of write() system calls for 64 bytes sent two ways
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Delete the fflush(stdout) line - in which order do the lines appear now?
 *            2) Run it on a terminal and again with  ./ex05 | cat  - same order? (setvbuf
 *               makes stdout fully buffered in both cases, which is what the demo needs.)
 * ============================================================================
 */
#ifndef __linux__
#error "Linux example: run in WSL, GitHub Codespaces or an online Linux VM"
#endif

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static char stdout_buf[4096];

/* Thin wrapper: write() can fail or write less than asked, so check it. */
static void raw_puts(const char *s)
{
    size_t len = strlen(s);
    if (write(STDOUT_FILENO, s, len) != (ssize_t)len) {
        _exit(2);                           /* nothing sensible to do in a demo */
    }
}

/* Number of write() system calls this process has made so far (Linux /proc/self/io). */
static long syscw_count(void)
{
    long n = -1;
    FILE *f = fopen("/proc/self/io", "r");
    if (f != NULL) {
        char line[64];
        while (fgets(line, sizeof line, f) != NULL) {
            if (sscanf(line, "syscw: %ld", &n) == 1) {
                break;
            }
        }
        fclose(f);
    }
    return n;                               /* -1 = not available in this sandbox */
}

/* Send 64 bytes to a temp file: one write() per byte, or fputc through a stdio buffer. */
static long count_writes(int use_stdio)
{
    char path[] = "/tmp/ex05_XXXXXX";
    int fd = mkstemp(path);
    if (fd < 0) {
        return -1;
    }
    long before = syscw_count();
    if (use_stdio) {
        FILE *fp = fdopen(fd, "w");
        if (fp == NULL) {
            close(fd);
            unlink(path);
            return -1;
        }
        for (int i = 0; i < 64; i++) {
            fputc('x', fp);                 /* goes into the 4 KB stdio buffer */
        }
        fclose(fp);                         /* flush: ONE write() here, then close */
    } else {
        for (int i = 0; i < 64; i++) {
            if (write(fd, "x", 1) != 1) {   /* one system call per byte */
                break;
            }
        }
        close(fd);
    }
    long after = syscw_count();
    unlink(path);                           /* always clean up what we create */
    return (before < 0 || after < 0) ? -1 : after - before;
}

int main(void)
{
    /* Force full buffering so the result is the same on a terminal and in a pipe. */
    setvbuf(stdout, stdout_buf, _IOFBF, sizeof stdout_buf);

    printf("1. stdio  printf  (sits in the buffer)\n");
    raw_puts("2. raw    write() (goes to the kernel at once)\n");
    printf("3. stdio  printf  (still in the buffer)\n");
    fflush(stdout);                         /* lines 1 and 3 are pushed out NOW */
    raw_puts("4. raw    write() after fflush\n");
    printf("-> the raw lines overtook the stdio lines until fflush was called\n");

    /* Unformatted input with read(): 0 = EOF (stdin is /dev/null or closed), -1 = error. */
    char buf[16];
    if (isatty(STDIN_FILENO)) {             /* only prompt a human, never a pipe */
        raw_puts("type a number + Enter (Ctrl-D = use simulated input): ");
    }
    ssize_t n = read(STDIN_FILENO, buf, sizeof buf - 1U);
    if (n <= 0) {
        printf("(no stdin - using simulated input \"42\")\n");
        n = (ssize_t)snprintf(buf, sizeof buf, "42\n");
    }
    buf[n] = '\0';
    printf("read() gave %zd byte(s): value = %ld\n", n, strtol(buf, NULL, 10));

    long raw = count_writes(0);
    long buffered = count_writes(1);
    if (raw < 0 || buffered < 0) {
        printf("write() call counts: not available here (/proc/self/io unreadable)\n");
    } else {
        printf("64 bytes with write() per byte : %ld system calls\n", raw);
        printf("64 bytes with fputc + fclose   : %ld system call(s)\n", buffered);
    }
    return 0;
}
