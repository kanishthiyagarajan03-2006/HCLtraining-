/*
 * ============================================================================
 *  Topic   : 05 Formatted and Unformatted I/O
 *  Example : 03 - Build and parse a UART frame with snprintf and sscanf
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : snprintf formats values INTO a char array (printf to memory); sscanf does the
 *            reverse, parsing text from a char array. Always check snprintf's return value
 *            for truncation and sscanf's return value (= number of fields converted).
 *            Never pass the address of a narrow type (uint8_t) to %u: read into a wide
 *            temporary, range-check, then narrow.
 *  Embedded use : NMEA-style text frames ($GPGGA,...*5A) are used by GPS modules, ESP AT
 *            commands, lab instruments and debug consoles. XOR checksum = cheap integrity.
 *  Real STM32F4 : HAL_UART_Transmit(&huart2, (uint8_t *)frame, len, 100);
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex03_snprintf_sscanf_frame.c -o ex03
 *  Output  : one good frame built and parsed back, then a corrupted, a malformed and an
 *            out-of-range frame, each rejected with a reason
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Replace bad[10] = '9' with bad[10] = frame[10]. Nothing is corrupt now -
 *               which status do you expect?
 *            2) Shrink FRAME_MAX to 20. What does frame_build() return, and why?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define FRAME_MAX 40U

typedef struct {
    uint8_t  id;
    int16_t  temp_c10;              /* temperature in tenths of a degree, e.g. 253 = 25.3 C */
    uint16_t mv;
} reading_t;

typedef enum { FR_OK, FR_TOO_LONG, FR_BAD_FORMAT, FR_BAD_CHECKSUM, FR_BAD_RANGE } fr_status_t;

static const char *fr_name(fr_status_t s)
{
    static const char *const names[] = { "OK", "TOO_LONG", "BAD_FORMAT", "BAD_CHECKSUM",
                                         "BAD_RANGE" };
    return names[s];
}

/* NMEA-style checksum: XOR of every character between '$' and '*'. */
static uint8_t xor_sum(const char *s, size_t n)
{
    uint8_t x = 0U;
    for (size_t i = 0; i < n; i++) {
        x ^= (uint8_t)s[i];
    }
    return x;
}

/* Build "$SENS,id,temp,mv*CS\r\n" into out. Returns the frame length, or 0 if it did not fit. */
static size_t frame_build(char *out, size_t cap, const reading_t *r)
{
    int n = snprintf(out, cap, "$SENS,%u,%d,%u", (unsigned)r->id, (int)r->temp_c10,
                     (unsigned)r->mv);
    if (n < 0 || (size_t)n >= cap) {
        return 0;                                    /* snprintf says: it would not fit */
    }
    uint8_t cs = xor_sum(out + 1, (size_t)n - 1U);   /* skip the '$' */
    int m = snprintf(out + n, cap - (size_t)n, "*%02X\r\n", (unsigned)cs);
    if (m < 0 || (size_t)m >= cap - (size_t)n) {
        return 0;
    }
    return (size_t)n + (size_t)m;
}

static fr_status_t frame_parse(const char *s, reading_t *r)
{
    const char *star = strchr(s, '*');
    if (star == NULL) {
        return FR_BAD_FORMAT;
    }
    unsigned id, mv, cs;
    int temp;
    /* Wide temporaries: %u needs an unsigned int, not a uint8_t. Return value must be 4. */
    if (sscanf(s, "$SENS,%u,%d,%u*%2x", &id, &temp, &mv, &cs) != 4) {
        return FR_BAD_FORMAT;
    }
    if (xor_sum(s + 1, (size_t)(star - s) - 1U) != (uint8_t)cs) {
        return FR_BAD_CHECKSUM;
    }
    if (id > 255U || mv > 5000U || temp < -400 || temp > 1250) {
        return FR_BAD_RANGE;
    }
    r->id = (uint8_t)id;
    r->temp_c10 = (int16_t)temp;
    r->mv = (uint16_t)mv;
    return FR_OK;
}

static void try_frame(const char *label, const char *frame)
{
    reading_t r = { 0, 0, 0 };
    fr_status_t st = frame_parse(frame, &r);
    printf("%-8s -> %s", label, fr_name(st));
    if (st == FR_OK) {
        printf("  (id=%u temp=%d in 0.1 C units, mv=%u)", (unsigned)r.id, r.temp_c10,
               (unsigned)r.mv);
    }
    putchar('\n');
}

int main(void)
{
    const reading_t tx = { 7U, 253, 1650U };
    char frame[FRAME_MAX];

    size_t len = frame_build(frame, sizeof frame, &tx);
    if (len == 0U) {
        puts("frame does not fit");
        return 1;
    }
    /* "%.*s": the precision comes from an argument - print len-2 chars, hiding the CR LF. */
    printf("built (%u bytes): %.*s\n", (unsigned)len, (int)len - 2, frame);
    try_frame("good", frame);

    char bad[FRAME_MAX];
    snprintf(bad, sizeof bad, "%s", frame);
    bad[10] = '9';                                   /* a bit flipped on the wire */
    try_frame("corrupt", bad);
    try_frame("garbage", "$SENS,abc,25,100*00\r\n");
    try_frame("no star", "$SENS,7,253,1650\r\n");

    const reading_t wild = { 7U, 253, 9000U };       /* 9 V from a 3.3 V ADC: impossible */
    frame_build(bad, sizeof bad, &wild);
    try_frame("range", bad);
    return 0;
}
