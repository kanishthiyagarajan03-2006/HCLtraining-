/*
 * ============================================================================
 *  Topic   : 05 Formatted and Unformatted I/O
 *  Example : 07 - Two RTOS tasks sharing one printf: garbled lines, then a mutex
 *  Flavour : RTOS
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : The UART (or stdout) is a shared resource. If a task can be switched out in
 *            the middle of a print, two messages get woven together. Wrapping the whole
 *            line in a mutex (take ... print ... give) lets only one task print at a time.
 *            Phase 1 runs without the lock, phase 2 with it - same tasks, same code.
 *  Embedded use : printf from several FreeRTOS tasks is a classic source of scrambled debug
 *            output. Fixes: a mutex around prints, or one "gatekeeper" task that owns the
 *            UART and receives text through a queue (xQueueSend).
 *  Real FreeRTOS: xSemaphoreCreateMutex(); xSemaphoreTake(m, portMAX_DELAY); ...
 *                 xSemaphoreGive(m);   (never take a mutex inside an ISR)
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex07_rtos_shared_printf_mutex.c -o ex07
 *  Output  : phase 1: lines of the two tasks mixed together; phase 2: clean separate lines
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Move the give to just BEFORE rtos_yield() (after the first printf): what breaks?
 *            2) Give the two tasks different priorities and run phase 1 again: why is the output
 *               clean now? Why would a PREEMPTIVE RTOS still need the mutex?
 * ============================================================================
 */
#include "mini_rtos.h"

static rtos_sem_t *print_lock;      /* max 1, initially available = a simple mutex */
static int use_lock;                /* 0 in phase 1, 1 in phase 2                   */

/* One logical message made of two printf calls. On a slow UART a task can be switched out
 * between them; rtos_yield() models exactly that moment of preemption.             */
static void print_reading(const char *who, int value)
{
    if (use_lock) {
        rtos_sem_take(print_lock, RTOS_WAIT_FOREVER);
    }
    printf("[%-6s] reading = ", who);       /* first half of the line  */
    rtos_yield();                           /* <- another task may run here */
    printf("%d\n", value);                  /* second half of the line */
    if (use_lock) {
        rtos_sem_give(print_lock);
    }
}

static void sensor_task(void *arg)
{
    (void)arg;
    for (int v = 100; ; v += 5) {           /* tasks never return */
        print_reading("sensor", v);
        rtos_delay(50);
    }
}

static void motor_task(void *arg)
{
    (void)arg;
    for (int v = 900; ; v -= 10) {
        print_reading("motor", v);
        rtos_delay(50);
    }
}

int main(void)
{
    print_lock = rtos_sem_create(1U, 1U);
    if (print_lock == NULL) {
        return 1;
    }
    /* Equal priority = round-robin: no task is favoured (do not rely on who goes first). */
    rtos_task_create("motor", motor_task, NULL, 1, RTOS_MIN_STACK);
    rtos_task_create("sensor", sensor_task, NULL, 1, RTOS_MIN_STACK);

    puts("--- phase 1: NO mutex (read the lines carefully) ---");
    use_lock = 0;
    rtos_start(100);                        /* ticks 0 .. 99: each task prints twice */

    puts("--- phase 2: mutex around the whole line ---");
    use_lock = 1;
    rtos_start(100);                        /* ticks 100 .. 199 */

    rtos_log("end of demo at tick %u", (unsigned)rtos_ticks());
    rtos_sem_delete(print_lock);
    rtos_shutdown();
    return 0;
}
