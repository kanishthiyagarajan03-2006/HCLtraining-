/*
 * ============================================================================
 *  Topic   : 05 Formatted and Unformatted I/O
 *  Example : 04 - Reading a console line safely: fgets + sscanf, with canned-input fallback
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Read a whole LINE with fgets (bounded, can never overflow), then parse it with
 *            sscanf. Do not call scanf("%d") straight on the console: it leaves '\n' (and any
 *            text it could not convert) in the buffer, so a retry loop spins forever on bad
 *            input, and %s without a width overflows.
 *            Always give %s a width (%7s), check the return value, handle EOF.
 *  Embedded use : a debug console on a UART RX line is exactly this loop: collect a line,
 *            then parse "led on", "rate 250", "status". stdin is the UART RX here.
 *  Real STM32F4 : HAL_UART_Receive(&huart2, &ch, 1, HAL_MAX_DELAY);  // one byte at a time
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex04_fgets_console_commands.c -o ex04
 *  Output  : with no stdin (or Ctrl-D) a note, then six simulated commands with replies;
 *            when you type, the same commands work live. "quit" ends the program
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Type: rate 99999999999 - why is strtol + a range check safer than sscanf?
 *            2) Change %7s to %s and type 20 letters. Why is that dangerous on a 1 KB RAM MCU?
 * ============================================================================
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LINE_MAX_LEN 32U
#define ARRAY_LEN(a) (sizeof(a) / sizeof((a)[0]))

static const char *const canned[] = {   /* what a technician "typed" on the UART */
    "led on\n", "rate 250\n", "rate fast\n", "status\n", "reboot\n", "quit\n"
};
static int    stdin_dead;               /* set once fgets reports EOF or error */
static size_t canned_next;

/* Returns 1 if buf holds a line, 0 if there is nothing more to read. */
static int get_line(char *buf, size_t cap)
{
    if (!stdin_dead) {
        fputs("> ", stdout);                  /* a prompt has no '\n', so flush it */
        fflush(stdout);
        if (fgets(buf, (int)cap, stdin) != NULL) {
            if (strchr(buf, '\n') == NULL && !feof(stdin)) {
                int ch;                       /* line too long: throw the rest away */
                while ((ch = getchar()) != '\n' && ch != EOF) { }   /* int, not char! */
            }
            return 1;
        }
        stdin_dead = 1;
        puts("\n(no stdin - using simulated UART input)");
    }
    if (canned_next >= ARRAY_LEN(canned)) {
        return 0;
    }
    snprintf(buf, cap, "%s", canned[canned_next++]);
    printf("> %s", buf);                      /* echo, as a terminal would show it */
    return 1;
}

int main(void)
{
    unsigned led = 0U;
    unsigned rate_ms = 1000U;
    char line[LINE_MAX_LEN];

    puts("console ready: led on|off, rate <ms>, status, quit");
    while (get_line(line, sizeof line)) {
        line[strcspn(line, "\r\n")] = '\0';   /* strip the line ending */

        char cmd[8] = "";
        char arg[16] = "";
        int fields = sscanf(line, "%7s %15s", cmd, arg);   /* widths = size - 1 */

        if (fields < 1) {
            continue;                         /* empty line: ignore */
        }
        if (strcmp(cmd, "led") == 0 && fields == 2) {
            led = (strcmp(arg, "on") == 0);
            printf("  LED is now %s\n", led ? "ON" : "OFF");
        } else if (strcmp(cmd, "rate") == 0 && fields == 2) {
            /* sscanf splits the words; strtol converts a number safely. An int that is
             * too big for sscanf("%d") is undefined behaviour, strtol just saturates. */
            char *end;
            long ms = strtol(arg, &end, 10);
            if (end != arg && *end == '\0' && ms > 0 && ms <= 60000L) {
                rate_ms = (unsigned)ms;
                printf("  rate set to %u ms\n", rate_ms);
            } else {
                printf("  error: '%s' is not a number from 1 to 60000\n", arg);
            }
        } else if (strcmp(cmd, "led") == 0 || strcmp(cmd, "rate") == 0) {
            printf("  error: '%s' needs an argument\n", cmd);   /* fields was 1 */
        } else if (strcmp(cmd, "status") == 0) {
            printf("  led=%u rate=%u ms\n", led, rate_ms);
        } else if (strcmp(cmd, "quit") == 0) {
            puts("  bye");
            break;
        } else {
            printf("  unknown command '%s'\n", cmd);
        }
    }
    return 0;
}
