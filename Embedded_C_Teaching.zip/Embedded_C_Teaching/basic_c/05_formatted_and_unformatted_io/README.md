# Topic 05 - Formatted and Unformatted I/O
**Suggested session:** 60-75 min | **Prerequisite topics:** 01 Introduction, 03 Variable types, 04 Operators

Students learn that all console output is built from one tiny primitive (`uart_putc`), and that
`printf`/`scanf` are convenience layers on top of it. We start with raw character output
(`putchar`, `puts`, `fputs`, hand-made number printing), retarget `printf` to a UART, build and
parse a checksummed text frame with `snprintf`/`sscanf`, read a console line safely with `fgets`,
and finish on Linux and RTOS issues: buffering, `stderr`, and sharing one output device between tasks.

| # | File | Flavour | What it teaches |
|---|------|---------|-----------------|
| 01 | `ex01_unformatted_uart_output.c` | MCU | `putchar`/`puts`/`fputs` vs `printf`; TXE polling; numbers without printf |
| 02 | `ex02_retarget_printf_to_uart.c` | MCU | `_write`/`fputc` retargeting, `vsnprintf`, CR+LF, truncation detection |
| 03 | `ex03_snprintf_sscanf_frame.c` | MCU | build/parse an NMEA-style frame, XOR checksum, return-value checks, `%.*s` |
| 04 | `ex04_fgets_console_commands.c` | MCU | `fgets` + `sscanf` + `strtol`, EOF fallback to canned UART input, `%7s` widths |
| 05 | `ex05_linux_stdio_vs_raw_write.c` | LINUX | stdio buffer vs `write()`/`read()`, `setvbuf`, `fflush`, counting syscalls |
| 06 | `ex06_linux_stderr_log_levels.c` | LINUX | stdout vs stderr, log levels, `LOG_LEVEL` env var, shell redirection |
| 07 | `ex07_rtos_shared_printf_mutex.c` | RTOS | garbled shared prints, then a mutex around the whole line |

## Teaching notes
* `puts` adds a newline, `fputs` does not; `putchar` takes and returns an `int` (so EOF fits).
* `printf` is slow and big on an MCU: show it at 115200 baud (ex01 prints the wire time) and
  mention newlib-nano (`--specs=nano.specs`) and that `%f` needs `-u _printf_float`.
* Never `scanf("%d")` on a console and never `%s` without a width. Show the `fgets` + `sscanf` pattern
  (ex04) and why `sscanf` return values matter (ex03). `getchar()` must store into an `int`.
* A prompt without `\n` stays in the stdio buffer: use `fflush(stdout)`. This is the same
  buffering story as ex05 and the reason debug prints "disappear" before a crash.
* Ask: which line of output of ex07 phase 1 is garbled and which instruction caused the switch?

## Live-demo tips
* Show that `printf("hello\n")` becomes `puts`: `gcc -S -O0 file.c` and look for `call puts`.
* Programs never block when stdin is empty. To type live, run `./ex04` in a terminal; Ctrl-D
  switches ex04 to the simulated input. Try `./ex06 2>/dev/null` and `LOG_LEVEL=debug ./ex06`.
* ex05 ordering: delete the `fflush(stdout)` line, rebuild, and let students predict the order.
