/*
 * ============================================================================
 *  Topic   : 05 Formatted and Unformatted I/O
 *  Example : 01 - Unformatted output: uart_putc, uart_puts and numbers without printf
 *  Flavour : MCU
 *  Level   : Basic
 * ----------------------------------------------------------------------------
 *  Concept : Unformatted I/O moves raw characters and converts nothing:
 *            putchar/fputc send ONE char, puts/fputs send a whole string.
 *            Formatted I/O (printf) parses a format string and converts values.
 *            puts() appends '\n', fputs() does not - a favourite exam question.
 *  Embedded use : a UART sends one byte at a time. A 20-line uart_puts costs a few dozen
 *            bytes of flash; dragging in printf can cost 10-20 KB. Many small
 *            firmwares print numbers with hand-written helpers like the ones below.
 *  Real STM32F4 : while (!(USART2->SR & USART_SR_TXE)) { }  USART2->DR = c;
 *  Build   : gcc -std=gnu11 -Wall -Wextra -I../../common ex01_unformatted_uart_output.c -o ex01
 *  Output  : a number/status printed by hand-made UART helpers, the byte count and wire time,
 *            then the same text with puts / fputs / printf
 * ----------------------------------------------------------------------------
 *  Try it  : 1) Replace the FIRST fputs line with puts(...) - what changes in the output?
 *            2) Call uart_put_u32(4294967295u). Why does digits[] need 10 elements?
 * ============================================================================
 */
#include <stdint.h>
#include <stdio.h>

/* File-local fake USART registers (the real USART2 sits at 0x40004400). */
#define USART_SR_TXE (1U << 7)      /* TX data register empty: safe to write DR */
static volatile uint32_t USART_SR = USART_SR_TXE;
static volatile uint32_t USART_DR;

static uint32_t tx_bytes;           /* bytes that left through uart_putc */

/* The one low-level output function. Every other output call is built on it. */
static void uart_putc(char c)
{
    while ((USART_SR & USART_SR_TXE) == 0U) { /* wait until the shifter can take a byte */ }
    USART_DR = (uint8_t)c;
    putchar((int)USART_DR);         /* PC only: show the byte on the "serial line" */
    tx_bytes++;
}

/* Unformatted: send the bytes as they are until '\0'. Unlike puts(), no '\n' is added. */
static void uart_puts(const char *s)
{
    while (*s != '\0') {
        uart_putc(*s++);
    }
}

/* Unsigned decimal without printf: peel digits off the right, then send them reversed. */
static void uart_put_u32(uint32_t v)
{
    char digits[10];                /* 4294967295 has 10 digits */
    unsigned n = 0U;
    do {
        digits[n++] = (char)('0' + (v % 10U));
        v /= 10U;
    } while (v != 0U);              /* do-while so that v == 0 still prints "0" */
    while (n > 0U) {
        uart_putc(digits[--n]);
    }
}

static void uart_put_hex8(uint8_t v)
{
    static const char hex[] = "0123456789ABCDEF";   /* const: lives in flash, not RAM */
    uart_putc(hex[v >> 4]);
    uart_putc(hex[v & 0x0FU]);
}

int main(void)
{
    uart_puts("== unformatted: uart_puts / uart_put_u32 / uart_put_hex8 ==\n");
    uart_puts("uptime ms : ");  uart_put_u32(1234567U);  uart_putc('\n');
    uart_puts("status    : 0x"); uart_put_hex8(0xA5U);   uart_putc('\n');
    uart_puts("zero      : ");  uart_put_u32(0U);        uart_putc('\n');

    /* 115200 baud, 8N1 = 10 bits per byte: the wire is SLOW compared to the CPU. */
    uint32_t us = (uint32_t)(((uint64_t)tx_bytes * 10U * 1000000U) / 115200U);
    printf("sent %u bytes -> about %u us on a 115200-baud line\n",
           (unsigned)tx_bytes, (unsigned)us);

    puts("== the C library: unformatted vs formatted ==");
    puts("puts  : adds the newline by itself");
    fputs("fputs : does not, ", stdout);
    fputs("so this stays on the same line", stdout);
    putchar('\n');                  /* putchar: one char, returns it (or EOF) as an int */
    printf("printf: uptime ms : %u, status : 0x%02X\n", 1234567U, 0xA5U);
    return 0;
}
