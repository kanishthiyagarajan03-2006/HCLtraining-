# Embedded C Teaching Examples

188 runnable C programs for 3rd/4th-year engineering students, covering 25 topics from "Introduction to C"
to "Passing an array of arrays to a function". Every example is written around **embedded systems**:
bare-metal microcontroller code (STM32-style registers), RTOS tasks/queues/semaphores, and embedded-Linux
user space. **No hardware is needed**: the GPIO registers and the RTOS are simulated, so every program
compiles with plain `gcc` and prints what the hardware would do.

| Flavour | Programs | Typical content |
|---------|----------|-----------------|
| `MCU`   | 134 | GPIO bit manipulation, UART, ADC buffers, ring buffers, ISR flags, lookup tables, memory map |
| `RTOS`  | 26  | tasks, priorities, delays, queues, semaphores/mutex, TCBs, stacks (FreeRTOS-style) |
| `LINUX` | 28  | sysfs-style GPIO files, `/proc`, `argv`, `fork/pipe`, `mmap`, signals, `stat` |

139 programs build on Windows, Linux, WSL and Codespaces. 49 need Linux (all `LINUX` ones plus the `RTOS`
ones that run real tasks); `INDEX.md` has a **Runs on** column for every program.

> **If `.vscode/`, `.devcontainer/` or `Makefile` are missing from this folder:** they could not be copied
> here automatically (the file-copy tool refuses to write those config files). Copy them from
> `Embedded_C_Teaching.zip`, which has the same folder structure. Nothing else depends on them: you can always
> build with the plain `gcc` commands shown below.

## Folder layout

```
Embedded_C_Teaching/
  basic_c/            topics 01-14   (Introduction ... Recursion)
  intermediate_c/     topics 15-25   (Arrays ... Passing array of arrays to a function)
    NN_topic_name/
      README.md       session length, teaching notes, live-demo tips
      exNN_name.c     one idea per program, simple -> advanced
      exNN_name/      a multi-file example (main.c + other .c/.h files)
  common/
    hw_sim.h          simulated STM32F4-style GPIO / RCC registers + fake delay
    mini_rtos.h       tiny FreeRTOS-like scheduler (Linux only)
  tools/              check.sh (test everything), run.sh, gen_index.py, example_template.c
  .vscode/            build / run / debug setup (Ctrl+Shift+B, F5)
  .devcontainer/      one-click Linux machine for GitHub Codespaces
  INDEX.md            table of every program: topic, flavour, what it shows
```

Every program starts with the same header: topic, flavour, the concept, why it matters in embedded work,
the real STM32 register line it mimics, the build command, the expected output, and two "Try it" exercises
for students.

## Running the examples

### On Windows with VS Code (139 programs)

1. Install VS Code and the **C/C++** extension (it is recommended automatically when you open the folder).
2. Install a compiler: MSYS2 from msys2.org, then in the MSYS2 terminal run
   `pacman -S --needed base-devel mingw-w64-ucrt-x86_64-toolchain`
   and add `C:\msys64\ucrt64\bin` to your user `Path`. This also installs `gdb`.
3. Open this folder in VS Code, open any `.c` file and press **Ctrl+Shift+B**: it builds into `build/` and
   runs the program in the terminal. **F5** starts the debugger. For a multi-file example, open a file inside
   its `exNN_...` folder and run the task **Build and run current project folder** (Terminal > Run Task).

Or from a terminal: `gcc -std=gnu11 -Wall -Wextra -I common basic_c/04_expressions_and_operators/ex01_set_clear_toggle_pin.c -o ex01`

### On Linux, WSL or Codespaces (all 188 programs)

```
tools/run.sh basic_c/04_expressions_and_operators/ex01_set_clear_toggle_pin.c   # build + run one
tools/run.sh basic_c/11_working_with_header_files/ex01_led_module               # a multi-file example
EXTRA_CFLAGS=-DSIM_REALTIME tools/run.sh <file.c>   # make the simulated delays really wait
tools/check.sh                                       # compile and run everything with sanitizers
```
`make run F=<file>`, `make check` and `make index` do the same. Programs with deliberate bugs keep the bug
switched off; turn it on to show the failure: `EXTRA_CFLAGS=-DDEMO_BUG tools/run.sh <file.c>`.

## A free online machine for demos

| Option | Good for | What I verified |
|--------|----------|-----------------|
| **GitHub Codespaces** (github.com/features/codespaces) | A full Linux machine with VS Code in the browser: all 188 programs, tasks, debugger | Free personal accounts get 120 core-hours and 15 GB of storage per month. A 2-core machine counts double, so about 60 hours of use. Without a payment method it stops at the limit and resets monthly. |
| **OnlineGDB** (onlinegdb.com) | Quick demos of single programs, no setup | Compiles C with gcc, debugs with gdb (breakpoints, call stack, variables), supports multiple files and stdin. |
| **Compiler Explorer** (godbolt.org) | The compilation topic: see the assembly the compiler generates | Shows compiler output side by side with the source; its Arm tutorial says to pick an Arm compiler to see Arm instructions. |
| **Wokwi** (wokwi.com) | Showing the same bit operations on a simulated board | Lists Arduino, ESP32, STM32 and Raspberry Pi Pico boards. The free Community plan allows unlimited simulations of public projects. |

**Codespaces steps:** create a private repository on github.com, upload this folder (or `git push` it),
then Code > Codespaces > Create codespace. The `.devcontainer` folder installs gcc, gdb, valgrind and make
automatically; open a file and press Ctrl+Shift+B. If your organisation blocks Codespaces, use WSL or OnlineGDB.

**OnlineGDB:** create `hw_sim.h` (copy from `common/`) next to your program using the New File menu, then
paste the program. The site compiles with gcc, which is what the programs are written for. I have not tried
them on that site myself, so test your demo programs there before class (add `mini_rtos.h` the same way for the RTOS ones).

**Same idea on a simulated Arduino Uno (Wokwi):** standard AVR register code, a good follow-up to topic 04:

```c
void setup() { DDRB |= (1 << PB5); }                  // PB5 = pin 13 (on-board LED) as output
void loop()  { PORTB ^= (1 << PB5); delay(500); }     // toggle it every 500 ms
```

## How the simulation works

* `hw_sim.h` gives you `GPIOA->MODER`, `GPIOA->ODR`, `GPIOA->BSRR`, `RCC->AHB1ENR` with the same names,
  layout and bit meanings as an STM32F4, plus `sim_delay_ms()` (fake `HAL_Delay`) and `sim_show_port()` /
  `sim_show_leds()` to print pin states. The one difference: real hardware reacts to a `BSRR` write instantly,
  the PC applies it when you call `sim_delay_ms()` or a `sim_show_*()` function. A good talking point.
* `mini_rtos.h` runs real tasks, each with its own stack and saved context, so students write
  `for(;;){ ...; rtos_delay(500); }` exactly like FreeRTOS. Time is simulated, so demos finish instantly.
  Higher number = higher priority. The header documents the differences from a real RTOS.

| FreeRTOS | mini_rtos |
|----------|-----------|
| `xTaskCreate(fn, name, stack, arg, prio)` | `rtos_task_create(name, fn, arg, prio, stack)` |
| `vTaskStartScheduler()` | `rtos_start(run_ms)` |
| `vTaskDelay(ticks)` | `rtos_delay(ms)` |
| `xQueueCreate(length, item_size)` | `rtos_queue_create(length, item_size)` |
| `xQueueSend` / `xQueueReceive` | `rtos_queue_send` / `rtos_queue_recv` |
| `xSemaphoreGive` / `xSemaphoreTake` | `rtos_sem_give` / `rtos_sem_take` |

## What was checked, and what to know

* `tools/check.sh` compiles every program with `-Wall -Wextra -Werror` plus AddressSanitizer and
  UndefinedBehaviorSanitizer, runs each with empty input and a 10 s limit, and requires exit code 0 and no
  sanitizer report. Result: **188 of 188 pass** (gcc 13, Linux).
* The 139 portable programs were also cross-compiled warning-free with MinGW-w64 gcc for Windows.
* A separate review pass checked the technical claims in the comments (STM32 registers, FreeRTOS behaviour,
  C semantics) and the outputs against the headers; dozens of wording and accuracy problems were corrected.
* **Not tested on a real Windows machine:** I could compile for Windows but not run there, so the
  `.vscode` tasks for Windows follow the VS Code documentation but have not been exercised. Linux/WSL/Codespaces
  paths were run.
* Some programs print memory addresses, stack sizes or the host name, which differ between machines and runs.
  The comments say so.
* `hw_sim.h` and `mini_rtos.h` keep their state per source file. In a multi-file example, include them from
  only one `.c` file.
* The `LINUX` programs never touch real hardware or need root: GPIO is simulated with files in a temporary
  folder that is deleted afterwards.

## Adding your own examples

Copy `tools/example_template.c` into a topic folder as `exNN_name.c`, edit the header, run
`tools/check.sh <your file>`, then `python3 tools/gen_index.py` to refresh `INDEX.md`.

## Sources

* [GitHub Codespaces billing](https://docs.github.com/en/billing/concepts/product-billing/github-codespaces)
* [OnlineGDB](https://www.onlinegdb.com/)
* [Compiler Explorer](https://godbolt.org/) and [Arm: Compiler Explorer tutorial](https://learn.arm.com/learning-paths/cross-platform/mca-godbolt/mca_on_godbolt/)
* [Wokwi](https://wokwi.com/) and [Wokwi pricing](https://wokwi.com/pricing)
* [VS Code: Using GCC with MinGW](https://code.visualstudio.com/docs/cpp/config-mingw)
